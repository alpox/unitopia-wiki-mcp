---
type: Wiki Article
title: Fischnix
description: Eine große Angel.
resource: "http://unitopia.intelligense.de/wiki/Fischnix"
tags: [NPC, NPC/Gallien, NPC/Gallien/defensiv, NPC/defensiv, Rasse, Rasse/Mensch]
timestamp: 2018-11-07T18:26:24Z
revid: 214380
namespace: 0
contenthash: 1727014d45fb2cc9e03949712e40cee1adb35c4c128474da68442f2f254aac56
---

## Aussehen

Fischnix angelt fuer sein Leben gern. Doch scheint nichts anzubeissen.

## Ausrüstung

Eine [große Angel](/angel-fischnix.md "Angel/Fischnix").

## Heimat

Am Westufer von [Lutetia](/lutetia.md "Lutetia").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Gallien
- Rasse: Mensch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Fischnix)
