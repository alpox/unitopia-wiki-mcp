---
type: Wiki Article
title: Schlüssel/Burg Tregyln
description: In der Dose in Sabines Schlafgemach auf Burg Tregyln auf Drachenland.
resource: "http://unitopia.intelligense.de/wiki/Schlüssel/Burg_Tregyln"
tags: [Gegenstand, Gegenstand/Ebenen, Gegenstand/Ebenen/Schlüssel, Gegenstand/Schlüssel, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Metall]
timestamp: 2024-03-02T19:21:39Z
revid: 259133
namespace: 0
contenthash: 509c1575a28746149937a2190b7e377e2f650aa47da853518571ff3bdc88283b
---

## Aussehen

Ein langer, eiserner Schluessel. Auf einem Anhaenger am Schluessel steht:
Turmverlies.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

In der Dose in Sabines Schlafgemach auf [Burg Tregyln](/burg-tregyln.md "Burg Tregyln") auf [Drachenland](/drachenland.md "Drachenland").

## Funktion

Für die Tür zum Turmverlies auf [Burg Tregyln](/burg-tregyln.md "Burg Tregyln").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Schlüssel
- Gegend: Ebenen
- Material: Metall
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schlüssel/Burg_Tregyln)
