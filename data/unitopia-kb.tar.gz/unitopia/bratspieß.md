---
type: Wiki Article
title: Bratspieß
description: Aus der Berghütte in den weltumspannenden Bergen auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/Bratspieß"
tags: [Adjektiv, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/4, Info/Material, Info/Material/Metall, Info/Waffenstärke, Info/Waffenstärke/toll, Info/Waffenzustand, Info/Waffenzustand/ziemlich spröde, Waffe, Waffe/Kokosinseln, Waffe/Kokosinseln/Wurfmesser, Waffe/Wurfmesser]
timestamp: 2024-03-02T19:20:27Z
revid: 228494
namespace: 0
contenthash: e7d5faa2d2c9657b62ecea5df379aee98469e179ff2812c07873a4b28d6f86f1
---

## Aussehen

Ein kurzer Bratspiess. Als Lanze ist er nicht zu gebrauchen, aber wenn man
ihn auf den Gegner wirft, hat der nichts zu lachen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [8 (toll)](/kategorie/info-waffenstärke-toll.md "Kategorie:Info/Waffenstärke/toll") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [1 (ziemlich spröde)](/kategorie/info-waffenzustand-ziemlich-spröde.md "Kategorie:Info/Waffenzustand/ziemlich spröde") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [4 (gerade noch leicht)](/kategorie/info-gewicht-4.md "Kategorie:Info/Gewicht/4") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Aus der [Berghütte](/kreta.md "Kreta") in den [weltumspannenden Bergen](/weltumspannende-berge.md "Weltumspannende Berge") auf [Kreta](/kreta.md "Kreta").

## Besonderheit

-   Wenn man versucht die Tür zu öffnen, kommt einem der Bratspieß entgegen geflogen.
-   Der Bratspieß gehört zu den Waffen, die ständig wechselnde Adjektive haben. Diese werden hier nicht gesondert aufgelistet.

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Wurfmesser
- Gegend: Kokosinseln
- Material: Metall
- Waffenstärke: toll
- Waffenzustand: ziemlich spröde
- Gewicht: 4
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Bratspieß)
