---
type: Wiki Article
title: Schriftmappe
description: In der Blockhütte auf der Hochebene auf Cyprus.
resource: "http://unitopia.intelligense.de/wiki/Schriftmappe"
tags: [Behälter, Behälter/Große, Behälter/Kokosinseln, Behälter/Kokosinseln/Große, Fundort, Info, Info/Brennbar, Info/Fasst, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Leder, Info/Volumen, Info/Volumen/14]
timestamp: 2026-03-18T18:21:07Z
revid: 265305
namespace: 0
contenthash: 0e5b0b5e7076160447ec7cb4ac17bf09015fc68f7e5db465afc30ca4d47b6803
---

## Aussehen

Dies ist eine Mappe aus schwarzem Leder. Man kann darin sehr gut seinen
Papierkram aufbewahren. Sie ist gross genug fuer Zeitungen, aber auch breit
genug fuer Schriftrollen. Vorne ist eine Metallplakette angebracht.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder") |
| --- | --- |
| **[Fasst](/kategorie/info-fasst.md "Kategorie:Info/Fasst"):** | [Papier](/kategorie/info-material-papier.md "Kategorie:Info/Material/Papier") |
| **[Volumen](/kategorie/info-volumen.md "Kategorie:Info/Volumen"):** | 14 |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

In der Blockhütte auf der [Hochebene](/hochebene.md "Hochebene") auf [Cyprus](/cyprus.md "Cyprus").

* * *


## Kenndaten

- Kategorie: Behälter
- Typ: große
- Gegend: Kokosinseln
- Material: Leder
- Fasst: Papier
- Volumen: 14
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schriftmappe)
