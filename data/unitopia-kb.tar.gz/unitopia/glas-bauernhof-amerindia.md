---
type: Wiki Article
title: Glas/Bauernhof/Amerindia
description: In der Küche auf dem Bauernhof auf Amerindia.
resource: "http://unitopia.intelligense.de/wiki/Glas/Bauernhof/Amerindia"
tags: [Behälter, Behälter/Ebenen, Behälter/Ebenen/Gefäß, Behälter/Gefäß, Info, Info/Fasst, Info/Fasst/Flüssigkeit, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Glas, Info/Volumen, Info/Volumen/2]
timestamp: 2026-03-18T18:21:15Z
revid: 251276
namespace: 0
contenthash: 55e65a77b572a20f959b70baed79f4f89e91f9d58c9e49be8c675e7e7b25e591
---

## Aussehen

Ein handliches Glas das eine kleine Menge Fluessigkeit fasst.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Glas](/kategorie/info-material-glas.md "Kategorie:Info/Material/Glas") |
| --- | --- |
| **[Fasst](/kategorie/info-fasst.md "Kategorie:Info/Fasst"):** | [Flüssigkeit](/flüssigkeit.md "Flüssigkeit") |
| **[Volumen](/kategorie/info-volumen.md "Kategorie:Info/Volumen"):** | 2 |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

In der Küche auf dem [Bauernhof](/amerindia.md "Amerindia") auf [Amerindia](/amerindia.md "Amerindia").

* * *


## Kenndaten

- Kategorie: Behälter
- Typ: Gefäß
- Gegend: Ebenen
- Material: Glas
- Fasst: Flüssigkeit
- Volumen: 2
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Glas/Bauernhof/Amerindia)
