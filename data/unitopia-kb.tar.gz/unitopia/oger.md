---
type: Wiki Article
title: Oger
description: Eine schwere Kampfaxt
resource: "http://unitopia.intelligense.de/wiki/Oger"
tags: [NPC, NPC/Kokosinseln, NPC/Kokosinseln/aggressiv, NPC/aggressiv, Rasse, Rasse/Oger]
timestamp: 2018-11-07T18:41:02Z
revid: 215400
namespace: 0
contenthash: 4835c4ab65d3750c9fd797de0e180f31f47d0e22fa4ab824eb2f9ab08f867dbe
---

## Aussehen

Ein gewaltiger Oger. Etwa 3 Meter gross, mit einem dicken braunen Fell,
gewaltigen Pranken und riesigen Reisszaehnen. Eine Attraktion in jeder
Kampfarena!

## Ausrüstung

Eine [schwere Kampfaxt](/kampfaxt-oger.md "Kampfaxt/Oger")

## Heimat

Im [Labyrinth des Daedalus](/labyrinth-des-daedalus.md "Labyrinth des Daedalus") in [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").

* * *


## Kenndaten

- Typ: aggressiv
- Gegend: Kokosinseln
- Rasse: Oger

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Oger)
