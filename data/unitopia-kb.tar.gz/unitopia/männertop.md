---
type: Wiki Article
title: Männertop
description: Zu kaufen bei Pauline in der Lederboutique von Lutetia.
resource: "http://unitopia.intelligense.de/wiki/Männertop"
tags: [Fundort/Kauf, Hidden, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Leder, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Kleidung, Kleidung/Brust, Kleidung/Gallien, Kleidung/Gallien/Brust, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2024-04-23T19:27:42Z
revid: 261592
namespace: 0
contenthash: 510dca387f7704eb0d5fcddb4a7ba9501dbccf709e9426a71a172940b5570158
---

## Aussehen

Ein Maennertop, welches wirklich eng geschnitten ist. Und ich meine eng.
Darunter wird jeder Muskel sichtbar. Naja, nicht ganz, ist ja doch noch
Leder, aber es ist SO eng geschnitten. Die Aermel gehen knapp ueber den
Oberarm, sie liegen eng an. Der Kragen ist v-foermig ausgeschnitten.
Drei schwarze Lederstreifen wurden quer ueber den Brustkorb eingearbeitet.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Pauline](/pauline.md "Pauline") in der Lederboutique von [Lutetia](/lutetia.md "Lutetia").

## Besonderheit

Zusätzliches Aussehen beim Betrachten einer Person:

| -   **Mann:** | <Spieler> traegt ein Maennertop. Es betont seinen aufregenden Oberkoerper. |
| --- | --- |
| -   **Frau:** | <Spielerin> traegt ein Maennertop, welches ihr nicht so gut steht, da es fuer Maenner hergestellt wurde. |
| -   **Etwas:** | <Spielendes> traegt ein Maennertop. Es sieht sehr sexy aus. |

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Brust
- Gegend: Gallien
- Material: Leder
- Temperaturschutz: wärmt etwas
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein
- Mann: traegt ein Maennertop. Es betont seinen aufregenden Oberkoerper.
- Etwas: traegt ein Maennertop. Es sieht sehr sexy aus.

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Männertop)
