---
type: Wiki Article
title: Druidenelixier/Umfallen
description: Von einem Mitglied der Druidengilde.
resource: "http://unitopia.intelligense.de/wiki/Druidenelixier/Umfallen"
tags: [Fundort, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Nahrung, Nahrung/Getränk, Nahrung/Kokosinseln, Nahrung/Kokosinseln/Getränk, Subpages, Subpages/Content]
timestamp: 2024-09-16T12:13:08Z
revid: 210420
namespace: 0
contenthash: fe1f97992c88ca746da5120b30557f2052c680845c331d0e0e4280556cd98610
---

< [Druidengilde](/druidengilde.md "Druidengilde") < [Elixiere](/druidengilde.md "Druidengilde")

## Aussehen

Variiert je nach Zutaten.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [siehe Funktion](#Funktion), zieht 7 AP |

## Fundort

Von einem Mitglied der [Druidengilde](/druidengilde.md "Druidengilde").

## Funktion

Der Magen bläht sich kurz auf und man fällt um.

## Besonderheit

| Geruch | _variabel_ |
| --- | --- |
| Tasten | _variabel_ |
| Meldung | Dein Magen blaeht sich sichtbar auf... ...ein dumpfes Grollen ist zu hoeren, dann haut es Dich der Laenge nach hin! AUA! |

* * *


## Kenndaten

- Typ: Content
- Kategorie: Nahrung
- Gegend: Kokosinseln
- Gewicht: 1
- Wirkung: siehe Funktion/zieht 7 AP

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Druidenelixier/Umfallen)
