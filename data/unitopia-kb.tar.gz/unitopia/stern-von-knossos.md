---
type: Wiki Article
title: Stern von Knossos
description: In einer schweren Schatztruhe auf dem Grund des ägäischen Meeres.
resource: "http://unitopia.intelligense.de/wiki/Stern_von_Knossos"
tags: [Hidden, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Edelmetall, Info/Material/Edelstein, Kleidung, Kleidung/Brust, Kleidung/Kokosinseln, Kleidung/Kokosinseln/Brust, Mineral, Mineral/Edelstein, Mineral/Kokosinseln, Mineral/Kokosinseln/Edelstein, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2024-03-02T19:17:46Z
revid: 261961
namespace: 0
contenthash: 07a286e8ebe261ec89246c52242a80adb24709a4955fc8f764622fd18fdfd409
---

## Aussehen

Das ist der sagenumwobene Stern von Knossos, eine goldene Brosche mit einem
gigantischen Smaragd in der Mitte. Die Verzierungen um den Stein herum
bilden einen Stern mit sieben Strahlen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Edelmetall](/kategorie/info-material-edelmetall.md "Kategorie:Info/Material/Edelmetall"), [Edelstein](/kategorie/info-material-edelstein.md "Kategorie:Info/Material/Edelstein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

In einer [schweren Schatztruhe](/schatztruhe-ägäisches-meer.md "Schatztruhe/Ägäisches Meer") auf dem Grund des [ägäischen Meeres](/ägäisches-meer.md "Ägäisches Meer").

## Besonderheit

-   Nach jedem "blitzen" gibt er einem 40 [ZP](/zp.md "ZP")[![Zauberpunkte](/images/4/4c/ZP.gif)](/zp.md "Zauberpunkte").

-   Zusätzliches Aussehen beim Betrachten einer Person:

| -   **Mann:** | Er traegt den Stern von Knossos auf der Brust. |
| --- | --- |
| -   **Frau:** | Sie traegt den Stern von Knossos auf der Brust. |
| -   **Etwas:** | Es traegt den Stern von Knossos auf der Brust. |

* * *


## Kenndaten

- Typ: Edelstein
- Gegend: Kokosinseln
- Kategorie: Kleidung
- Material: Edelmetall/Edelstein
- Gewicht: 2
- Licht: 0
- Brennbar: nein
- Schwimmt: nein
- ul: ja
- Mann: Er traegt den Stern von Knossos auf der Brust.
- Frau: Sie traegt den Stern von Knossos auf der Brust.
- Etwas: Es traegt den Stern von Knossos auf der Brust.

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Stern_von_Knossos)
