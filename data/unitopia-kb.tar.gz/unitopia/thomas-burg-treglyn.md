---
type: Wiki Article
title: Thomas/Burg Treglyn
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Thomas/Burg_Treglyn"
tags: [NPC, NPC/Ebenen, NPC/Ebenen/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Wächter]
timestamp: 2018-11-07T18:28:20Z
revid: 259002
namespace: 0
contenthash: cbc980e4a4c83634afbf9d2d0b0ec190fd825c082d8c41e4cb2332d9e55013c2
---

## Aussehen

Ein ungemein grimmig ausschauender Waechter, der dir auf den ersten Blick
topfit aussieht. Mit ihm ist wohl nicht gut Kirschen essen.

## Ausrüstung

Keine.

## Heimat

Auf einem Turm auf [Burg Tregyln](/burg-tregyln.md "Burg Tregyln") auf [Drachenland](/drachenland.md "Drachenland").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Ebenen
- Rasse: Mensch
- Tätigkeit: Wächter

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Thomas/Burg_Treglyn)
