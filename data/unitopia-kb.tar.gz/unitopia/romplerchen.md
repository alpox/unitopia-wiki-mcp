---
type: Wiki Article
title: Romplerchen
description: Zu kaufen bei Merklin im Spielzeugladen in Koboldingen.
resource: "http://unitopia.intelligense.de/wiki/Romplerchen"
tags: [Fundort/Kauf, Gegenstand, Gegenstand/Märchenland, Gegenstand/Märchenland/Sonstige, Gegenstand/Sonstige, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Holz, Info/Schwimmt]
timestamp: 2024-04-23T19:28:18Z
revid: 213873
namespace: 0
contenthash: 37cbc4f1d937b62eb3251fd3b0c342620432b8cbfd18692bf10a91451a5e5073
---

## Aussehen

Das Romplerchen ist in weite, weisse, wallende Gewaendergehuellt und traegt
einen Turban auf dem Kopf. Es macht den Eindruck eines Wuestenprinzen.
Allerdings scheint es heftiger Basteltaetigkeit nachzugehen, denn seine
Kleidung ist ueberall verschmiert. Bestimmt kann man an den Gewaendern ganz
toll ziehen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Zu kaufen bei [Merklin](/merklin.md "Merklin") im Spielzeugladen in [Koboldingen](/koboldingen.md "Koboldingen").

## Funktion

zieh an gewaender

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Märchenland
- Material: Holz
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Romplerchen)
