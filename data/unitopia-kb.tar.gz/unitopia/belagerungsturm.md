---
type: Wiki Article
title: Belagerungsturm
description: Im Hof auf Dol Guldur.
resource: "http://unitopia.intelligense.de/wiki/Belagerungsturm"
tags: [Gegenstand, Gegenstand/Midgard, Gegenstand/Midgard/Sonstige, Gegenstand/Sonstige, Info, Info/Brennbar, Info/Gewicht, Info/Gewicht/unbeweglich, Info/Material, Info/Material/Holz, Info/Schwimmt]
timestamp: 2024-03-02T19:19:24Z
revid: 259581
namespace: 0
contenthash: 607b9b0384f419d77ec3f9ee1aca2764819a2194dca2f853e796ec5d637442fd
---

## Aussehen

Ein mittelgrosser Belagerungsturm aus Holz. Er ist etwa so gross wie die
Mauer im Osten, sieht jedoch schon ziemlich ausgedient aus. Ueberall am
Holz kann man Brandspuren finden, und die oberste Plattform ist fast
vollstaendig ausgebrannt. Jedoch die Raeder scheinen in Ordnung zu sein.
Der Turm steht hier wohl schon eine ganze Weile herum, da das Holz schon
langsam angefangen hat, zu schimmeln.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [unbeweglich](/kategorie/info-gewicht-unbeweglich.md "Kategorie:Info/Gewicht/unbeweglich") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Im Hof auf [Dol Guldur](/dol-guldur.md "Dol Guldur").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Midgard
- Material: Holz
- Gewicht: unbeweglich
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Belagerungsturm)
