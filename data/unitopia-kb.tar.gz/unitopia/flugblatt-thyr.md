---
type: Wiki Article
title: Flugblatt/Thyr
description: Auf dem Deck des Handelsschiffes Thyr.
resource: "http://unitopia.intelligense.de/wiki/Flugblatt/Thyr"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Papier, Info/Schwimmt, Schriften, Schriften/Gallien, Schriften/Gallien/Sonstige, Schriften/Ozean, Schriften/Ozean/Sonstige, Schriften/Sonstige, Schriften/Vaniorh, Schriften/Vaniorh/Sonstige]
timestamp: 2024-03-02T19:20:15Z
revid: 255279
namespace: 0
contenthash: 6e828c9fa99e4d44d6204382086f0edaa4b74abc5afd1d5d0c39e90d47745cb2
---

## Aussehen

Ein Flugblatt von der Eislaufbahn in den gallischen Alpen. Man kann es
lesen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Papier](/kategorie/info-material-papier.md "Kategorie:Info/Material/Papier") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Auf dem Deck des [Handelsschiffes Thyr](/thyr.md "Thyr").

## Inhalt

Eine Werbung für die [Eisbahn](/eisbahn.md "Eisbahn").

## Faksimile

Sie suchen ein Freizeitvergnuegen fuer die ganze Familie? Ihnen ist es in
Doerrland zu heiss? Kommen Sie in die Eisbahn in den gallischen Alpen.

Jetzt neu: Familientickets!

* * *


## Kenndaten

- Kategorie: Schriften
- Typ: Sonstige
- Gegend: Gallien/Ozean/Vaniorh
- Material: Papier
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Flugblatt/Thyr)
