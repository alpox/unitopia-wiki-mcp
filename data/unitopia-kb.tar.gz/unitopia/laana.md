---
type: Wiki Article
title: Laana
description: Im Labor der Alchemistengilde von Borsippa.
resource: "http://unitopia.intelligense.de/wiki/Laana"
tags: [NPC, NPC/Vaniorh, NPC/Vaniorh/defensiv, NPC/defensiv, Rasse, Rasse/Mensch]
timestamp: 2018-11-07T18:30:34Z
revid: 209063
namespace: 0
contenthash: d5661b38c3eea2df4ab502b50434c1c211fd2862cb0a6be25968b52356b861dc
---

## Aussehen

Die Laborantin steckt in einem weiszen Kittel durch den ihre schlanke
Silhouette durchschimmert. Langes schwarzes Haar umrahmt ihr Gesicht und
faellt ihr ueber die Schulter. Eine Straehne faellt ihr dauernd ueber eines
ihrer schelmisch blitzenden blaugruenen Augen. Sie laechelt dich neckisch
an.

## Ausrüstung

-   Ein [robuster Kittel für die Feldforschung](/kittel-laana.md "Kittel/Laana").
-   Ein [Kurzschwert](/kurzschwert-laana.md "Kurzschwert/Laana").
-   Ein [Ledertop](/ledertop-laana.md "Ledertop/Laana").
-   Eine [schwarze Lederhose](/lederhose-laana.md "Lederhose/Laana").
-   Ein Paar [versilberte Kampfstiefel](/kampfstiefel-laana.md "Kampfstiefel/Laana").
-   [Laanas Alchemistenköfferchen](/alchemistenköfferchen-praktikant.md "Alchemistenköfferchen/Praktikant").

## Heimat

Im Labor der [Alchemistengilde](/alchemistengilde.md "Alchemistengilde") von [Borsippa](/borsippa.md "Borsippa").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Vaniorh
- Rasse: Mensch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Laana)
