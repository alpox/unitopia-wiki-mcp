---
type: Wiki Article
title: Apparat/Verfluchter Wald
description: Durch den schwarzen Altar (oder Obsidiantisch) auf der Lichtung im verfluchten Wald auf Cyprus.
resource: "http://unitopia.intelligense.de/wiki/Apparat/Verfluchter_Wald"
tags: [Adjektiv, Behälter, Behälter/Große, Behälter/Kokosinseln, Behälter/Kokosinseln/Große, Fundort, Info, Info/Brennbar, Info/Fasst, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/7, Info/Material, Info/Material/Holz, Info/Schwimmt, Info/Volumen, Info/Volumen/12]
timestamp: 2026-03-18T18:21:13Z
revid: 266902
namespace: 0
contenthash: 7fb5559cfbc4614959632a1b89cb2991c622b6d3fdfcef7e09c06ab78954ca8e
---

## Aussehen

Der Apparat sieht etwas merkwuerdig aus. Das Grundgeruest bildet ein
Holzkasten, an dem allerlei Hebel befestigt und miteinander verbunden sind.
Oben ist ein Greifarm angebracht und seitlich faellt dir da auch noch eine
Linse auf.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Fasst](/kategorie/info-fasst.md "Kategorie:Info/Fasst"):** | [Auerhuhn-Ei](/auerhuhn-ei.md "Auerhuhn-Ei"), [Ikameisen-Ei](/ikameisen-ei.md "Ikameisen-Ei") |
| **[Volumen](/kategorie/info-volumen.md "Kategorie:Info/Volumen"):** | 12 |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [7 (eher schwer)](/kategorie/info-gewicht-7.md "Kategorie:Info/Gewicht/7") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Durch den [schwarzen Altar](/altar-verfluchter-wald.md "Altar/Verfluchter Wald") (oder [Obsidiantisch](/obsidiantisch.md "Obsidiantisch")) auf der Lichtung im [verfluchten Wald](/verfluchter-wald.md "Verfluchter Wald") auf [Cyprus](/cyprus.md "Cyprus").

## Funktion

Der Apparat sammelt im Raum liegende [Auerhuhn-Eier](/auerhuhn-ei.md "Auerhuhn-Ei") oder [Ikameisen-Eier](/ikameisen-ei.md "Ikameisen-Ei") ein und legt sie in sich hinein.

## Besonderheit

Der Apparat gehört zu den Behältern, die ständig wechselnde Adjektive haben. Diese werden hier nicht gesondert aufgelistet.

* * *


## Kenndaten

- Kategorie: Behälter
- Typ: Große
- Gegend: Kokosinseln
- Material: Holz
- Fasst: Auerhuhn-Ei/Ikameisen-Ei
- Volumen: 12
- Gewicht: 7
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Apparat/Verfluchter_Wald)
