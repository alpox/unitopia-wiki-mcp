---
type: Wiki Article
title: Karte/Wiesenland
description: Von Hamann Cotton auf der Kirmes von Fabeln
resource: "http://unitopia.intelligense.de/wiki/Karte/Wiesenland"
tags: [Gegenstand, Gegenstand/Autoloader, Gegenstand/Midgard, Gegenstand/Midgard/Autoloader, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Papier, Schriften, Schriften/Karte, Schriften/Midgard, Schriften/Midgard/Karte]
timestamp: 2024-03-02T19:20:47Z
revid: 255446
namespace: 0
contenthash: b082c7ff8a02eaf24ce4a0dc168afeee4086ebb6e37165ee3ea996b706bf0621
---

## Aussehen

Die Karte ist aus Papier; auf ihr sind mit roter und schwarzer Tinte Wege,
Fluesse und Orte des Wiesenlandes verzeichnet. Sie wird Dir helfen, Dich
zurechtzufinden, wenn Du sie lesen kannst.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Papier](/kategorie/info-material-papier.md "Kategorie:Info/Material/Papier") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Von [Hamann Cotton](/hamann.md "Hamann") auf der [Kirmes](/festwiese.md "Festwiese") von [Fabeln](/fabeln.md "Fabeln")

## Inhalt

Eine Karte des Wiesenlandes.

## Faksimile

### Vorderseite

  ^ N                                                                     
 -+-                                                                      
  | (nicht massstabstreu)                                                 
                                                                          
                           Der Berg                                       
                               | Kirmes                                   
- - - Michelbinge              |/                                         
  |               \           /                                           
  |                  - - -Fabeln - - == - - - - - - - - - - -nach Ambring 
  |                                        Gold|                          
  |                                      wasser|mark                          
  |                                            |                          
  |\                                       Gold|                          
  |  Langgrund                           wasser|haus                          
  |                                                                       
  |                                                                       
  nach Bruggstad                                                            
                                                                          
Eine Karte des Wiesenlands um die Oststrasse.                                                                          
Auf der Rueckseite stehen zur Erinnerung die verschiedenen Zeichen.

### Rückseite

Folgende Zeichen werden verwendet: 

        \                        |      \  \*entgegen\* der 
 --------> in Pfeilrichtung      |-------> Pfeilrichtung  
        /  folgen                |      /  folgen 

   \_\_  
    /| 
   /    \                           - 
 -+------> Weggabelung            ( O )    Irrweg 
        /                           - 
  \_\_\_\_\_
  |\ /|    hier ist eine  
  | X |    Nachricht versteckt - 
  |/\_\|    anschliessend in Pfeilrichtung weiter.

* * *


## Kenndaten

- Typ: Autoloader
- Gegend: Midgard
- Kategorie: Schriften
- Material: Papier
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Karte/Wiesenland)
