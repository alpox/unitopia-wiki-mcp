---
type: Wiki Article
title: Skelett/NankeaStadt
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Skelett/NankeaStadt"
tags: [NPC, NPC/Midgard, NPC/Midgard/aggressiv, NPC/aggressiv, Rasse, Rasse/Untoter, Tätigkeit, Tätigkeit/Wächter]
timestamp: 2018-11-07T18:33:59Z
revid: 215333
namespace: 0
contenthash: 855bd30c2cf784dfddce6950ad475daf98a94bef2438eaffd59189672a07a148
---

## Aussehen

Ein Haufen verwester Knochen steht vor dir und grinst dich breit an.

## Ausrüstung

Keine.

## Heimat

In der Krypta unter der [Kathedrale](/nankea-\(stadt\).md "Nankea (Stadt)") von [Nankea (Stadt)](/nankea-\(stadt\).md "Nankea (Stadt)") auf [Nankea](/nankea.md "Nankea").

* * *


## Kenndaten

- Typ: aggressiv
- Gegend: Midgard
- Rasse: Untoter
- Tätigkeit: Wächter

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Skelett/NankeaStadt)
