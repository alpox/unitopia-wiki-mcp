---
type: Wiki Article
title: LeberKäsWecken
description: Zu kaufen bei der Verkäuferin in der Bauigelcafete auf dem Campusgelände der Universität Stuttgart.
resource: "http://unitopia.intelligense.de/wiki/LeberKäsWecken"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Campus, Nahrung/Campus/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:14:09Z
revid: 246477
namespace: 0
contenthash: b5653d2a86e3765a32531c094eac8838efdd57ace15fb342f1f9c0bdbf9f423b
---

## Aussehen

Ein Tafelbroetchen belegt mit warmem saftigen Fleischkaese und etwas Senf.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Zu kaufen bei der [Verkäuferin](/verkäuferin-bauigelcafete.md "Verkäuferin/Bauigelcafete") in der [Bauigelcafete](/bauigelcafete.md "Bauigelcafete") auf dem [Campusgelände](/campusgelände.md "Campusgelände") der [Universität Stuttgart](/universität.md "Universität").

## Besonderheit

Der Leberkäswecken wird nur verkauft, wenn man einen "LKW" verlangt.

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Campus
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/LeberKäsWecken)
