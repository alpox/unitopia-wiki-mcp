---
type: Wiki Article
title: Rubin/Esmeralda
description: Zu kaufen bei Esmeralda im Esoterikladen von Ephesos auf Phrygia.
resource: "http://unitopia.intelligense.de/wiki/Rubin/Esmeralda"
tags: [Fundort/Kauf, Hidden, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Edelstein, Kleidung, Kleidung/Hals, Kleidung/Kokosinseln, Kleidung/Kokosinseln/Hals, Mineral, Mineral/Edelstein, Mineral/Kokosinseln, Mineral/Kokosinseln/Edelstein, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2024-04-23T19:27:39Z
revid: 261992
namespace: 0
contenthash: 44f90ab8d2bd6e71fc5e248e1081368814ddc4da652d9b7a6cb51bf956b181e6
---

## Aussehen

Dieser Edelstein leuchtet in einem so intensiven Rot, dass er schon fast
von innen heraus zu gluehen scheint. Sein Bezugsmonat ist der Juli.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Edelstein](/kategorie/info-material-edelstein.md "Kategorie:Info/Material/Edelstein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Esmeralda](/esmeralda.md "Esmeralda") im Esoterikladen von [Ephesos](/ephesos.md "Ephesos") auf [Phrygia](/phrygia.md "Phrygia").

## Besonderheit

Zusätzliches Aussehen beim Betrachten einer Person:

| **Alle:** | <Spieler> traegt an einem Silberkettchen einen gluehenden Rubin um den Hals. Er scheint Glueck zu bringen. |
| --- | --- |

## Wirkung

| Waffe | Effekt |
| --- | --- |
| [blauglänzende Axt](/axt-blauglänzende.md "Axt/blauglänzende") |  |
| [blauglänzender Degen](/degen-blauglänzender.md "Degen/blauglänzender") |  |
| [blauglänzender Dolch](/dolch-blauglänzender.md "Dolch/blauglänzender") |  |
| [blauglänzender Kampfhammer](/kampfhammer-blauglänzender.md "Kampfhammer/blauglänzender") |  |
| [blauglänzender Kampfstab](/kampfstab-blauglänzender.md "Kampfstab/blauglänzender") |  |
| [blauglänzendes Kurzschwert](/kurzschwert-blauglänzendes.md "Kurzschwert/blauglänzendes") |  |
| [blauglänzendes Langschwert](/langschwert-blauglänzendes.md "Langschwert/blauglänzendes") |  |
| [blauglänzender Säbel](/säbel-blauglänzender.md "Säbel/blauglänzender") |  |

* * *


## Kenndaten

- Typ: Hals
- Gegend: Kokosinseln
- Kategorie: Mineral
- Material: Edelstein
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Rubin/Esmeralda)
