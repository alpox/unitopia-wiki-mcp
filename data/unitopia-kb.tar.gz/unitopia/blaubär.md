---
type: Wiki Article
title: Blaubär
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Blaubär"
tags: [NPC, NPC/Vaniorh, NPC/Vaniorh/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Spieler]
timestamp: 2018-11-07T18:26:22Z
revid: 215780
namespace: 0
contenthash: 654a0d52390343e2f78eeca8e878f050fbdc201e2f0c95cbee6c8010cc14723c
---

## Aussehen

Blaubaer ist ein erfahrener Seebaer wie er im Buche steht. Wind und Wetter
gegerbtes Fell und eine mittlerweile doch recht mitgenommene
Kapitaensmuetze sind seine Markenzeichen. Die meiste Zeit sitzt er irgendwo
rum und spinnt Seemannsgarn. Aber fuer eine Partie Schiffeversenken laesst
er alles stehen und liegen.
Versuch doch mal: '[hilfe schiffeversenken](/schiffe-versenken.md "Schiffe versenken")'.

## Ausrüstung

Keine.

## Heimat

Auf dem ehemaligen Werft-Gelände am [Hafen](/tadmor.md "Tadmor") von [Tadmor](/tadmor.md "Tadmor").

## Besonderheit

Man kann bei Käptn Blaubär eine Runde [Schiffe versenken](/schiffe-versenken.md "Schiffe versenken") spielen oder sogar gegen ihn.

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Vaniorh
- Rasse: Mensch
- Tätigkeit: Spieler

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Blaubär)
