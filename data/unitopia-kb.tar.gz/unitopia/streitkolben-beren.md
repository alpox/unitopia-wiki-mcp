---
type: Wiki Article
title: Streitkolben/Beren
description: Waffe vom Torwächter Beren am Nordtor von Londar.
resource: "http://unitopia.intelligense.de/wiki/Streitkolben/Beren"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/4, Info/Material, Info/Material/Metall, Info/Waffenstärke, Info/Waffenstärke/toll, Info/Waffenzustand, Info/Waffenzustand/recht beständig, Waffe, Waffe/Keule, Waffe/Midgard, Waffe/Midgard/Keule]
timestamp: 2024-03-02T19:19:20Z
revid: 232802
namespace: 0
contenthash: 26cb091e1f758b9cb5372a5fa1aa1bfbbcdb389e9259d02f9078b3cce4693a19
---

## Aussehen

Ein schwerer Streitkolben. Er besteht aus einem etwa vierzig Zentimeter
langen Metallstab, der oben in einem etwas dickeren Kopfstueck endet. Daran
sind rundum acht garstig gezackte Klingen angebracht. Dadurch ist er nicht
nur eine massive Hiebwaffe, sondern treibt auch noch mit der vollen Wucht
des schweren Kolbens die Zacken in das Opfer. Eine gefaehrliche Waffe.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [8 (toll)](/kategorie/info-waffenstärke-toll.md "Kategorie:Info/Waffenstärke/toll") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [5 (recht beständig)](/kategorie/info-waffenzustand-recht-beständig.md "Kategorie:Info/Waffenzustand/recht beständig") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [4 (gerade noch leicht)](/kategorie/info-gewicht-4.md "Kategorie:Info/Gewicht/4") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Waffe vom [Torwächter Beren](/beren.md "Beren") am Nordtor von [Londar](/londar.md "Londar").

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Keule
- Gegend: Midgard
- Material: Metall
- Waffenstärke: toll
- Waffenzustand: recht beständig
- Gewicht: 4
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Streitkolben/Beren)
