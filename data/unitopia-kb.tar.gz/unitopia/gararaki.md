---
type: Wiki Article
title: Gararaki
description: "Das Buch \"Magy für Anfenger\"."
resource: "http://unitopia.intelligense.de/wiki/Gararaki"
tags: [NPC, NPC/Vaniorh, NPC/Vaniorh/defensiv, NPC/defensiv, Rasse, Rasse/Säugetier]
timestamp: 2018-11-07T18:30:34Z
revid: 215679
namespace: 0
contenthash: d6dc150da60085ebf7ea3be3a2dc8c1a24be3c385435fd7d05ebaa5e5b8236cb
---

## Aussehen

Gararaki, der Bibliothekar.
Er macht einen verschlagenen Eindruck mit seinen langen Armen und seiner
hohen Stirn. Augenblicklich bohrt er sich mit seinem linken grossen Zeh
in der Nase und sucht mit der rechten Hand auf dem Boden nach einer
runtergefallenen Banane.
Nebenbei faellt Dir auf, dass das Bibliothekswesen eine ungewoehnliche
Taetigkeit fuer einen ausgewachsenen Orang-Utan ist...

## Ausrüstung

Das [Buch "Magy für Anfenger"](/buch-gararaki.md "Buch/Gararaki").

## Heimat

In einem dreieckigen Raum der [Magiergilde](/magiergilde.md "Magiergilde") von [Tadmor](/tadmor.md "Tadmor").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Vaniorh
- Rasse: Säugetier

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Gararaki)
