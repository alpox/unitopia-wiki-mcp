---
type: Wiki Article
title: Schlange/Tadmor
description: Ein Lichtkristall.
resource: "http://unitopia.intelligense.de/wiki/Schlange/Tadmor"
tags: [Braten, Braten/Haut, Braten/Jagen, Braten/Stück, NPC, NPC/Vaniorh, NPC/Vaniorh/defensiv, NPC/defensiv, Rasse, Rasse/Reptil, Tätigkeit, Tätigkeit/Wächter]
timestamp: 2019-02-13T19:42:30Z
revid: 251703
namespace: 0
contenthash: 96e4469f3a675dde9fd9d88f62ef8553d5b92aaa8ea129f755e953144f562de6
---

## Aussehen

```
Eine Schlange, die sich von anderen Schlangen dadurch unterscheidet, dass
sie blaeulich schimmert.
```

## Ausrüstung

Ein [Lichtkristall](/lichtkristall.md "Lichtkristall").

## Heimat

Im [Labyrinth](/tadmor.md "Tadmor") unter der [Stadmauer](/tadmor.md "Tadmor") von [Tadmor](/tadmor.md "Tadmor").

## Besonderheit

-   Nach dem Töten ist die Schlange [häut-](/schlangenhaut-schlange-tadmor.md "Schlangenhaut/Schlange/Tadmor") und [bratbar](/braten-magyra.md "Braten/Magyra"). Der Braten lässt sich in mehrere handliche [Braten](/bratenscheibe.md "Bratenscheibe")[scheiben](/braten-scheibe.md "Braten/Scheibe"), [Braten](/bratenstück.md "Bratenstück")[stücke](/braten-stück.md "Braten/Stück") oder [Braten](/bratenteil.md "Bratenteil")[teile](/braten-teil.md "Braten/Teil") zerlegen.
-   Wenn man die Schlange angreift, beißt sie zu und man erleidet eine [Vergiftung](/schlangenbiss-am-bein.md "Schlangenbiss am Bein").

## Kenndaten

- Typ: defensiv
- Gegend: Vaniorh
- Rasse: Reptil
- Tätigkeit: Wächter
- Artikel: die
- Haut: Schlangenhaut/Schlange/Tadmor
- Stück: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schlange/Tadmor)
