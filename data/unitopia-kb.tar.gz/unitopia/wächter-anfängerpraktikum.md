---
type: Wiki Article
title: Wächter/Anfängerpraktikum
description: Eine Fliegenklatsche.
resource: "http://unitopia.intelligense.de/wiki/Wächter/Anfängerpraktikum"
tags: [NPC, NPC/Vaniorh, NPC/Vaniorh/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Wächter]
timestamp: 2018-11-07T18:29:03Z
revid: 215447
namespace: 0
contenthash: ccdded05cc67c3a24b094b7700fd6a26deecdc475b5ea59e52ef804dce3546c6
---

## Aussehen

Vor Dir steht ein riesiges Muskelpaket, das in eine Uniform gepresst wurde.
Die Waffen und sonstigen Ausruestungsgegenstaende auf dieser Etage des
Anfaengerpraktikums scheinen wohl doch mehr Wert gewesen zu sein, als Du
zuerst gedacht hattest. Mit diesem Typen solltest Du Dich besser nicht
anlegen, wenn Dir Dein Leben lieb ist

## Ausrüstung

Eine [Fliegenklatsche](/fliegenklatsche.md "Fliegenklatsche").

## Heimat

Im Raum des Kampfes im [Anfängerpraktikum](/anfängerpraktikum.md "Anfängerpraktikum") des [Museums](/museum.md "Museum") von [Tadmor](/tadmor.md "Tadmor").


## Kenndaten

- Typ: defensiv
- Gegend: Vaniorh
- Rasse: Mensch
- Tätigkeit: Wächter

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Wächter/Anfängerpraktikum)
