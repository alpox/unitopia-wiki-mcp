---
type: Wiki Article
title: Däumlingsstiefel
description: Zu kaufen bei Metira bei der Schmiedin in Ameros auf Amerindia.
resource: "http://unitopia.intelligense.de/wiki/Däumlingsstiefel"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Metall, Info/Rüstungsstärke, Info/Rüstungsstärke/geht so, Info/Rüstungszustand, Info/Rüstungszustand/extrem solide, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Rüstung, Rüstung/Ebenen, Rüstung/Ebenen/Füße, Rüstung/Füße]
timestamp: 2024-04-23T19:27:45Z
revid: 226895
namespace: 0
contenthash: a7455bdc4b27fbfbc6daae7e99a512b5696ede2334697a8ac909b82cda38db53
---

## Aussehen

Diese winzigen Stiefel sind nur fuer Daeumlinge geeignet.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [3 (geht so)](/kategorie/info-rüstungsstärke-geht-so.md "Kategorie:Info/Rüstungsstärke/geht so") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [9 (extrem solide)](/kategorie/info-rüstungszustand-extrem-solide.md "Kategorie:Info/Rüstungszustand/extrem solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Metira](/metira.md "Metira") bei der Schmiedin in [Ameros](/ameros.md "Ameros") auf [Amerindia](/amerindia.md "Amerindia").

* * *


## Kenndaten

- Kategorie: Rüstung
- Typ: Füße
- Gegend: Ebenen
- Material: Metall
- Temperaturschutz: wärmt etwas
- Rüstungsstärke: geht so
- Rüstungszustand: extrem solide
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Däumlingsstiefel)
