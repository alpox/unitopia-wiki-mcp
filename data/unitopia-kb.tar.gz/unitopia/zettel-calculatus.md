---
type: Wiki Article
title: Zettel/Calculatus
description: Von Calculatus im Prüfungszimmer der Universität von Lutetia.
resource: "http://unitopia.intelligense.de/wiki/Zettel/Calculatus"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Papier, Info/Schwimmt, Schriften, Schriften/Gallien, Schriften/Gallien/Sonstige, Schriften/Sonstige]
timestamp: 2024-03-02T19:21:07Z
revid: 220819
namespace: 0
contenthash: 3f46306027b09bb15fe02381d0b8224a734fd33ac006fa29c7c38c46a12c9daf
---

## Aussehen

Ein Zettel mit Pruefungsergebnissen. Man kann ihn lesen. Wenn man ihn
loswerden will, zerknuellt man ihn einfach.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Papier](/kategorie/info-material-papier.md "Kategorie:Info/Material/Papier") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Von [Calculatus](/calculatus.md "Calculatus") im Prüfungszimmer der [Universität](/lutetia.md "Lutetia") von [Lutetia](/lutetia.md "Lutetia").

## Inhalt

Die Prüfungsergebnisse.

## Faksimile

Die Pruefungsergebnisse von <Spieler>:
Die 1. Frage war: Wieviel ist 8 \* 10 in roemisch?
Deine Antwort war: XVIII, richtig waere gewesen: LXXX
Die 2. Frage war: Wieviel ist 28 / 7 in roemisch?
Deine Antwort war: IV, das war richtig.
Die 3. Frage war: Wieviel ist 169 + 1060 in roemisch?
Deine Antwort war: MCCXXIX, das war richtig.
Die 4. Frage war: Wieviel ist 1025 - 719 in roemisch?
Deine Antwort war: CCCVI, das war richtig.
Die 5. Frage war: Wieviel ist IX \* VI in arabisch?
Deine Antwort war: 54, das war richtig.
Die 6. Frage war: Wieviel ist 33 / 11 in roemisch?
Deine Antwort war: III, das war richtig.
Die 7. Frage war: Wieviel ist 175 + 1391 in roemisch?
Deine Antwort war: MDLXVI, das war richtig.
Die 8. Frage war: Wieviel ist 959 - 574 in roemisch?
Deine Antwort war: CCCLXXXV, das war richtig.

* * *


## Kenndaten

- Kategorie: Schriften
- Typ: Sonstige
- Gegend: Gallien
- Material: Papier
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Zettel/Calculatus)
