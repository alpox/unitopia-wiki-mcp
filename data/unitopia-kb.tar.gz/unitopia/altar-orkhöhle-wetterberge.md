---
type: Wiki Article
title: Altar/Orkhöhle/Wetterberge
description: In einer Höhle nördlich der Wetterberge.
resource: "http://unitopia.intelligense.de/wiki/Altar/Orkhöhle/Wetterberge"
tags: [Gegenstand, Gegenstand/Midgard, Gegenstand/Midgard/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, Info/Gewicht/unbeweglich, Info/Material, Info/Material/Stein]
timestamp: 2024-03-02T19:20:47Z
revid: 215289
namespace: 0
contenthash: f2d46be828643b302a0820517fb76a9daa15d91f07ae0d9bd14dbf95b54d394a
---

## Aussehen

Ein wunderschoener Altar aus weissem Marmor. Um ein Haar haettest du ihn
uebersehen! Als du ihn nun genau anschaust, fallen dir noch einige
Malereien auf.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Stein](/kategorie/info-material-stein.md "Kategorie:Info/Material/Stein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [unbeweglich](/kategorie/info-gewicht-unbeweglich.md "Kategorie:Info/Gewicht/unbeweglich") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

In einer [Höhle](/wetterberge.md "Wetterberge") nördlich der [Wetterberge](/wetterberge.md "Wetterberge").

## Besonderheit

Auf dem Altar liegt das [sagenumwobende Askajoest](/askajoest.md "Askajoest").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Midgard
- Material: Stein
- Gewicht: unbeweglich
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Altar/Orkhöhle/Wetterberge)
