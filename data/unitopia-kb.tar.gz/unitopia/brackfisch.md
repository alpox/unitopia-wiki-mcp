---
type: Wiki Article
title: Brackfisch
description: Im See im Anglertal auf Cyprus.
resource: "http://unitopia.intelligense.de/wiki/Brackfisch"
tags: [Angeln, Braten, Braten/Angeln, Braten/Stück, Fundort, Gegenstand, Gegenstand/Kokosinseln, Gegenstand/Kokosinseln/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, Info/Material, Info/Material/Bein]
timestamp: 2024-09-16T12:12:19Z
revid: 255665
namespace: 0
contenthash: e3836ab484141a6357dc7d77bf9710784e485b1ff76a5eb42fd208821c93e75f
---

## Aussehen

```
Der grosse Brackfisch hat einen typisch fischfoermigen Koerper von ca. x
cm Laenge. Der Brackfisch ist gruenbraun an der Oberseite, die Unterseite
ist silbergrau. Vorn ist ein rundliches Maul, hinten eine dreieckige
Schwanzflosse.
```

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Bein](/kategorie/info-material-bein.md "Kategorie:Info/Material/Bein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [siehe Besonderheit](#Besonderheit) |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Im See im [Anglertal](/anglertal.md "Anglertal") auf [Cyprus](/cyprus.md "Cyprus").

## Besonderheit

-   Nach dem Angeln ist der Brackfisch [bratbar](/braten-magyra.md "Braten/Magyra"). Der Braten lässt sich in mehrere handliche [Braten](/bratenscheibe.md "Bratenscheibe")[scheiben](/braten-scheibe.md "Braten/Scheibe"), [Braten](/bratenstück.md "Bratenstück")[stücke](/braten-stück.md "Braten/Stück") oder [Braten](/bratenteil.md "Bratenteil")[teile](/braten-teil.md "Braten/Teil") zerlegen.  
    Sofern eine bestimmte Mindestgröße gefangen wurde.
-   Der Brackfisch erscheint mit wechselnden Adjektiven, die seine Größe im Anglerjargon angeben.  
    Weitere [Fischarten](/kategorie/angeln.md "Kategorie:Angeln") oder generelle Informationen sind der [Kategorie:Angeln](/kategorie/angeln.md "Kategorie:Angeln") zu entnehmen.

## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Kokosinseln
- Material: Bein
- Gewicht: siehe Besonderheit
- Licht: 0
- Brennbar: nein
- Schwimmt: nein
- Artikel: der
- Stück: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Brackfisch)
