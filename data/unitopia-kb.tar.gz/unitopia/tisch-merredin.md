---
type: Wiki Article
title: Tisch/Merredin
description: Im Häuschen auf der Schafweide im Merreland von Merredin.
resource: "http://unitopia.intelligense.de/wiki/Tisch/Merredin"
tags: [Behälter, Behälter/Midgard, Behälter/Midgard/Möbel, Behälter/Möbel, Info, Info/Brennbar, Info/Fasst, Info/Fasst/Gegenstand, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/7, Info/Material, Info/Material/Holz, Info/Schwimmt, Info/Volumen, Info/Volumen/16]
timestamp: 2026-03-18T18:21:32Z
revid: 253794
namespace: 0
contenthash: ffca226bbb7be138582af54bf7b8162684b19cdfa8514b4003e152dea99bf1be
---

## Aussehen

Ein alter, etwas abgenutzter Tisch steht hier herum.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Fasst](/kategorie/info-fasst.md "Kategorie:Info/Fasst"):** | [Gegenstand](/kategorie/gegenstand-sonstige.md "Kategorie:Gegenstand/Sonstige") |
| **[Volumen](/kategorie/info-volumen.md "Kategorie:Info/Volumen"):** | 16 |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [7 (eher schwer)](/kategorie/info-gewicht-7.md "Kategorie:Info/Gewicht/7") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Im Häuschen auf der Schafweide im Merreland von [Merredin](/merredin.md "Merredin").

## Besonderheit

Der Tisch enthält anfangs eine [Schere](/schere-tisch-merredin.md "Schere/Tisch/Merredin").

* * *


## Kenndaten

- Kategorie: Behälter
- Typ: Möbel
- Gegend: Midgard
- Material: Holz
- Fasst: Gegenstand
- Volumen: 16
- Gewicht: 7
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Tisch/Merredin)
