---
type: Wiki Article
title: Pilzvergiftung/Sarasande
description: Durch die fiesen Pilze im Keller von Achims Haus in Sarasande.
resource: "http://unitopia.intelligense.de/wiki/Pilzvergiftung/Sarasande"
tags: [Info, Info/Heilung, Info/Heilung/Antidots, Info/Heilung/Heiler, Info/Heilung/Heilstab, Info/Heilung/Hexenvolk, Info/Heilung/Kräuter, Info/Wirkung, Info/Wirkung/Zustand, Info/Wirkung/Zustand/tödlich, Zustand, Zustand/Dörrland, Zustand/Dörrland/Vergiftung, Zustand/Vergiftung]
timestamp: 2024-08-29T15:20:43Z
revid: 217333
namespace: 0
contenthash: ef3e1d835ecb278cac6df7f31f28e8380c320159fa856500e474cbdb54408ae1
---

## Aussehen

Er/Sie/Es leidet an einer Pilzvergiftung.

## Informationen

| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [tödlich](/kategorie/info-wirkung-zustand-tödlich.md "Kategorie:Info/Wirkung/Zustand/tödlich") |
| --- | --- |
| **[Heilung](/kategorie/info-heilung.md "Kategorie:Info/Heilung"):** | [Antidots](/druidengilde.md "Druidengilde"), [Heilstab](/heilstab.md "Heilstab"), [Heiler](/heiler.md "Heiler"), [Hexenvolk](/hexenvolk.md "Hexenvolk"), [Kräuter](/kräuter.md "Kräuter") |

## Fundort

Durch die [fiesen Pilze](/pilze-sarasande.md "Pilze/Sarasande") im Keller von [Achims Haus](/sarasande.md "Sarasande") in [Sarasande](/sarasande.md "Sarasande").

## Gefährlichkeit

-   Zieht ca. 25 [AP](/ap.md "AP")[![Ausdauerpunkte](/images/b/b4/AP.gif)](/ap.md "Ausdauerpunkte") in der Minute ab, hält ca.5 Minuten ab.
-   Startmeldung:

Du bekommst ganz schreckliche Bauchschmerzen.

-   Zwischenmeldungen:

Die Pilze rumoren in deinem Magen herum.
Du kotzt dir die Seele aus dem Leib.
Du brichst einen einzelnen Pilz.
Ein Himmelreich fuer einen grossen Eimer.

-   Endmeldung:

Du hast endlich alle Pilze erbrochen.

* * *


## Kenndaten

- Kategorie: Zustand
- Typ: Vergiftung
- Gegend: Dörrland
- Wirkung: tödlich
- Heilung: Antidots/Heilstab/Heiler/Hexenvolk/Kräuter

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Pilzvergiftung/Sarasande)
