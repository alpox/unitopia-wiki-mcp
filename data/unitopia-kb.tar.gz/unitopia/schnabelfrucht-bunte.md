---
type: Wiki Article
title: Schnabelfrucht/bunte
description: "Die Schnabelfrucht unterscheidet sich in ihren Farbtönen (und Geschmack):"
resource: "http://unitopia.intelligense.de/wiki/Schnabelfrucht/bunte"
tags: [Fundort, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, "Info/Wirkung/gibt 1-5 AP", "Info/Wirkung/gibt 1-5 ZP", Info/Wirkung/sättigt, Nahrung, Nahrung/Kokosinseln, Nahrung/Kokosinseln/Pflanze, Nahrung/Pflanze]
timestamp: 2024-09-16T12:10:44Z
revid: 264163
namespace: 0
contenthash: 71d6c5864192b495d1f2ad37f804dd03ee47aef95d36fee23823f59004726d6d
---

## Aussehen

Die Schnabelfrucht sieht aus wie zwei Bananen, die an der Aussenseite
aneinandergeklebt wurden. Die hauchduenne Schale ist leicht rau und
erinnert an die Schale einer Birne. Sie <[Besonderheit](#Besonderheit)\>.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt"), gibt 4 ZP wenn AP voll |

## Fundort

-   Nach dem Töten der [Geschöpfe](/verfluchter-wald.md "Verfluchter Wald") im [verfluchten Wald](/verfluchter-wald.md "Verfluchter Wald") auf [Cyprus](/cyprus.md "Cyprus").
-   Zu pflücken von den den Schnabelfruchtbäumen auf [Cyprus](/cyprus.md "Cyprus").

## Besonderheit

Die Schnabelfrucht unterscheidet sich in ihren Farbtönen (und Geschmack):

-   hat eine graue Grundfarbe, ist aber in verschiedensten Farben geringelt (Radiergummi)
-   hat eine hellgelbe Hintergrundfarbe, auf der kreisrunde Flecken in den verschiedensten Farbtönen schimmern (Kaugummi)
-   hat Flecken aller möglichen Farben (Knetmasse)
-   ist in allen möglichen Farben gefleckt (Kerzen)
-   ist weiß, hat aber verschiedenfarbige Kringel (Seife)

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Pflanze
- Gegend: Kokosinseln
- Gewicht: 1
- Wirkung: sättigt/gibt 4 ZP wenn AP voll

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schnabelfrucht/bunte)
