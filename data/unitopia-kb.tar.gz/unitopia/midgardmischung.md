---
type: Wiki Article
title: Midgardmischung
description: "Zu kaufen bei Drancol im Gasthaus \"Zum Blutsauger\" auf Phrygia."
resource: "http://unitopia.intelligense.de/wiki/Midgardmischung"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/durstlöschend, "Info/Wirkung/gibt 1-5 AP", "Info/Wirkung/gibt 1-5 ZP", Info/Wirkung/sättigt, Nahrung, Nahrung/Kokosinseln, Nahrung/Kokosinseln/Vampyr, Nahrung/Vampyr]
timestamp: 2024-08-29T15:13:59Z
revid: 190440
namespace: 0
contenthash: 8cb056742306615fd67f9a7ba70105946f4feadcf290dcf3883876f4d0f8a489
---

## Aussehen

Die Midgardmischung besteht aus dem besten, was Midgard an Blut zu bieten
hat. Eine ausgezeichnete Komposition von Halbling-, Elfen-, Menschen- und
Zwergenblut, gemischt mit einigen Tropfen Schaf- und Pferdeblut. Was für
ein Genuss.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend"), [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt"), gibt 3 ZP wenn AP voll |

## Fundort

Zu kaufen bei [Drancol](/drancol.md "Drancol") im [Gasthaus "Zum Blutsauger"](/blutsauger.md "Blutsauger") auf [Phrygia](/phrygia.md "Phrygia").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Vampyr
- Gegend: Kokosinseln
- Gewicht: 1
- Wirkung: durstlöschend/sättigt/gibt 3 ZP wenn AP voll

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Midgardmischung)
