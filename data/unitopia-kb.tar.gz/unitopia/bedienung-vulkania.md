---
type: Wiki Article
title: Bedienung/Vulkania
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Bedienung/Vulkania"
tags: [Angebot, NPC, NPC/Kokosinseln, NPC/Kokosinseln/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Gastwirt]
timestamp: 2022-04-25T21:07:48Z
revid: 217030
namespace: 0
contenthash: e5c2ee7106fada99412884bf90c351a1c60f21cb1bd6c15d3cafa35db5a3f7c1
---

## Aussehen

Die Bedienung dieses traurigen Schuppens. Das Maedchen - Oder waere 'Girl'
passender? - sieht etwa genauso hoeflich wie volljaehrig aus.
Kaugummikauend schaut sie dich an mit einem Blick, der dich verstummen
laesst: Du hast das Gefuehl, sehr zu stoeren.

## Ausrüstung

Keine.

## Heimat

In der Kneipe 'Pinatubo' von [Vulkania](/vulkania.md "Vulkania") auf [Vulkanien](/vulkanien.md "Vulkanien").

## Angebot

| ![Angebot-tl.gif](/images/d/db/Angebot-tl.gif) | Preisliste | ![Angebot-tr.gif](/images/5/52/Angebot-tr.gif) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | \| **Getränk:** \| **[Gulden](/währung.md "Währung")**: \| \| --- \| --- \| \| Ein [Twitburger Pils](/pils-bedienung-kaugummikauende.md "Pils/Bedienung/kaugummikauende") \| 10 \| \| Ein [Schlamm-Bräu](/schlamm-bräu.md "Schlamm-Bräu") \| 20 \| \| Ein [Seismo-Flip](/seismo-flip.md "Seismo-Flip") \| 60 \| \| Ein [Lava-Shocker](/lava-shocker.md "Lava-Shocker") \| 80 \| \| Eine [Dröhnung](/dröhnung-bedienung-vulkania.md "Dröhnung/Bedienung/Vulkania") \| 140 \| \| Ein [Tschiquila](/tschiquila.md "Tschiquila") \| 180 \| | **Getränk:** | **[Gulden](/währung.md "Währung")**: | Ein [Twitburger Pils](/pils-bedienung-kaugummikauende.md "Pils/Bedienung/kaugummikauende") | 10 | Ein [Schlamm-Bräu](/schlamm-bräu.md "Schlamm-Bräu") | 20 | Ein [Seismo-Flip](/seismo-flip.md "Seismo-Flip") | 60 | Ein [Lava-Shocker](/lava-shocker.md "Lava-Shocker") | 80 | Eine [Dröhnung](/dröhnung-bedienung-vulkania.md "Dröhnung/Bedienung/Vulkania") | 140 | Ein [Tschiquila](/tschiquila.md "Tschiquila") | 180 |  |
| **Getränk:** | **[Gulden](/währung.md "Währung")**: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Twitburger Pils](/pils-bedienung-kaugummikauende.md "Pils/Bedienung/kaugummikauende") | 10 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Schlamm-Bräu](/schlamm-bräu.md "Schlamm-Bräu") | 20 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Seismo-Flip](/seismo-flip.md "Seismo-Flip") | 60 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Lava-Shocker](/lava-shocker.md "Lava-Shocker") | 80 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Dröhnung](/dröhnung-bedienung-vulkania.md "Dröhnung/Bedienung/Vulkania") | 140 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Tschiquila](/tschiquila.md "Tschiquila") | 180 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ![Angebot-bl.gif](/images/3/3b/Angebot-bl.gif) |  | ![Angebot-br.gif](/images/9/92/Angebot-br.gif) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Kokosinseln
- Rasse: Mensch
- Tätigkeit: Gastwirt
- Gegenstand: Getränk

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Bedienung/Vulkania)
