---
type: Wiki Article
title: Mäuschen/Hexenwald
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Mäuschen/Hexenwald"
tags: [NPC, NPC/Nordische Inseln, NPC/Nordische Inseln/defensiv, NPC/defensiv, Rasse, Rasse/Säugetier]
timestamp: 2023-07-12T21:00:04Z
revid: 267573
namespace: 0
contenthash: 8e47d5f63f1a5002bfe0e7f8b03945ab4ee862a01b6c662233afa3243d5968ca
---

## Aussehen

Vor dir wuselt ein sehr kleines, niedliches Maeuschen herum. Es scheint
wirklich keinen Moment stillhalten zu koennen. Der Koerper ist vielleicht
drei Zentimeter lang und mit graubraunem Fell bewachsen, das unglaublich
weich aussieht. Staendig zuckt ihre spitze Schnauze umher und schnuppert
unruhig herum. Dich hat das kleine Tierchen auch schon laengst wahrgenommen,
es mustert dich unbeholfen, etwas aengstlich, aber auch neugierig mit seinen
kleinen Aeuglein und gibt ein hohes Piepsen von sich.

## Ausrüstung

Keine.

## Heimat

Im [südlichen Hexenwald](/dunkelwald.md "Dunkelwald") auf [Thule](/thule.md "Thule").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Nordische Inseln
- Rasse: Säugetier

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Mäuschen/Hexenwald)
