---
type: Wiki Article
title: Schokoladenei
description: "Überall, wo zu Ostern etwas versteckt wurde."
resource: "http://unitopia.intelligense.de/wiki/Schokoladenei"
tags: [Info, Nahrung, Nahrung/Campus, Nahrung/Campus/Produkt, Nahrung/Dörrland, Nahrung/Dörrland/Produkt, Nahrung/Ebenen, Nahrung/Ebenen/Produkt, Nahrung/Gallien, Nahrung/Gallien/Produkt, Nahrung/Kokosinseln, Nahrung/Kokosinseln/Produkt, Nahrung/Midgard, Nahrung/Midgard/Produkt, Nahrung/Märchenland, Nahrung/Märchenland/Produkt, Nahrung/Nordische Inseln, Nahrung/Nordische Inseln/Produkt, Nahrung/Produkt, Nahrung/Vaniorh, Nahrung/Vaniorh/Produkt]
timestamp: 2024-08-29T15:15:30Z
revid: 255002
namespace: 0
contenthash: 74684436f5c833322e80a166887951c662530c08b3d7585211dbc873bd17d33d
---

## Aussehen

Ein kleines, aber sehr lecker aussehendes Schokoladen-Ei. Wenn es schon so
lecker mit Verpackung aussieht, wie gut wird es dann wohl ohne aussehen?!

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** |  |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** |  |

## Fundort

Überall, wo zu [Ostern](/ostern.md "Ostern") etwas versteckt wurde.

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schokoladenei)
