---
type: Wiki Article
title: Brennesselausschlag
description: Durch den Fall vom Baum oder betasten der Brennnesseln am ruhigen Fleck in Tadmor.
resource: "http://unitopia.intelligense.de/wiki/Brennesselausschlag"
tags: [Info, Info/Heilung, Info/Heilung/Antidots, Info/Heilung/Heiler, Info/Heilung/Heilstab, Info/Heilung/Hexenvolk, Info/Heilung/Kräuter, Info/Wirkung, Info/Wirkung/Zustand, Info/Wirkung/Zustand/negativ, Zustand, Zustand/Vaniorh, Zustand/Vaniorh/Vergiftung, Zustand/Vergiftung]
timestamp: 2024-08-29T15:20:39Z
revid: 221432
namespace: 0
contenthash: 6d290580d90c6cfc6f893e1c2a055e01e42e8fc487f6f228ae7af770bcb1d567
---

## Aussehen

Er/Sie/Es hat einen unschoenen Brennnesselausschlag.

## Informationen

| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [negativ](/kategorie/info-wirkung-zustand-negativ.md "Kategorie:Info/Wirkung/Zustand/negativ") |
| --- | --- |
| **[Heilung](/kategorie/info-heilung.md "Kategorie:Info/Heilung"):** | [Antidots](/druidengilde.md "Druidengilde"), [Heiler](/heiler.md "Heiler"), [Hexenvolk](/hexenvolk.md "Hexenvolk"), [Kräuter](/kräuter.md "Kräuter"), [Heilstab](/heilstab.md "Heilstab") |

## Fundort

Durch den Fall vom Baum oder betasten der Brennnesseln am ruhigen Fleck in [Tadmor](/tadmor.md "Tadmor").

## Gefährlichkeit

-   Zieht ca. 1 [AP](/ap.md "AP")[![Ausdauerpunkte](/images/b/b4/AP.gif)](/ap.md "Ausdauerpunkte") in der Minute ab, hält ca. 6 Minuten an.
-   Startmeldung - Fall:

Todesmutig laesst du deinen Ast los.
Statt auf dem Boden aufzuschlagen, landest du sanft in einem Busch. Leider
waehrt deine Freude nicht lange - Du sitzt in feurigen Brennesseln,
springst ueber die Parkbank und bruellst: Seit wann wachsen hier
Brennesseln?

-   Startmeldung - Tasten:

Das fuehlt sich unangenehm an. Es faengt dich unwillkuerlich an zu jucken.

-   Zwischenmeldungen:

Allgemein:
Du fluchst ueber den Juckreiz.
Brennesseln in Tee sind jedenfalls besser als roh.
Ein kuehles Bier wuerde dir ueber deinen Schmerz hinweghelfen. 
Fall: 
Ein Jucken wandert durch deine Beine - bloede Brennesseln.
Ja, Muttern hatte schon immer Recht: Auf Baeume klettern, das ist schlecht.
Dein Hintern juckt noch gewaltig von den Brennesseln.
Betasten:
Deine Hand juckt noch gewaltig von den Brennesseln. 
Ja, Muttern hatte schon immer Recht: Du musst nicht immer alles gleich anfassen.

-   Endmeldung:

Endlich ist der Ausschlag abgeheilt.

* * *


## Kenndaten

- Kategorie: Zustand
- Typ: Vergiftung
- Gegend: Vaniorh
- Wirkung: negativ
- Heilung: Antidots/Heiler/Hexenvolk/Kräuter/Heilstab

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Brennesselausschlag)
