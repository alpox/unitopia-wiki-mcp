---
type: Wiki Article
title: Goldmünze/Große Sandinsel
description: Auf der großen Sandinsel.
resource: "http://unitopia.intelligense.de/wiki/Goldmünze/Große_Sandinsel"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Edelmetall, Info/Material/Gold, Mineral, Mineral/Dörrland, Mineral/Dörrland/Metall, Mineral/Metall]
timestamp: 2024-03-02T19:20:47Z
revid: 244244
namespace: 0
contenthash: 2d5fb4ce20633bbb8a542130d7d9b4ad74532553c24602be4fb7998672dc1d26
---

## Aussehen

Eine kleine Goldmuenze mit interessanten Praegungen auf Vorder- und
Rueckseite. Die Muenze selbst erinnert etwas an einen Franken.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Edelmetall](/kategorie/info-material-edelmetall.md "Kategorie:Info/Material/Edelmetall"), [Gold](/kategorie/info-material-gold.md "Kategorie:Info/Material/Gold") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Auf der [großen Sandinsel](/große-sandinsel.md "Große Sandinsel").

* * *


## Kenndaten

- Kategorie: Mineral
- Typ: Metall
- Gegend: Dörrland
- Material: Edelmetall/Gold
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Goldmünze/Große_Sandinsel)
