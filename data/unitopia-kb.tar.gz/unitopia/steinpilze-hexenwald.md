---
type: Wiki Article
title: Steinpilze/Hexenwald
description: Im Hexenwald auf Thule.
resource: "http://unitopia.intelligense.de/wiki/Steinpilze/Hexenwald"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/3, Info/Wirkung, "Info/Wirkung/gibt 11-15 AP", "Info/Wirkung/gibt 11-15 ZP", Info/Wirkung/sättigt, Nahrung, Nahrung/Nordische Inseln, Nahrung/Nordische Inseln/Sonstige, Nahrung/Sonstige]
timestamp: 2024-08-29T15:17:33Z
revid: 247240
namespace: 0
contenthash: 5a16c8a8299b668edb5808028392063fdb65e3e1c6b59755d3df8b505ce139f0
---

## Aussehen

Frische Steinpilze, mittelgross, mit filzigen, nussbraunen Hueten und
weissen Stielen. Sicher sind sie auch noch laengere Zeit geniessbar, denn
ihre Schirme sind noch nicht vollstaendig geoeffnet und der Schirmschwamm
hat noch die sanft altrosa Farbe.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [3 (schon eher leicht)](/kategorie/info-gewicht-3.md "Kategorie:Info/Gewicht/3") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt"), gibt 15 ZP wenn AP voll |

## Fundort

Im [Hexenwald](/hexenwald.md "Hexenwald") auf [Thule](/thule.md "Thule").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Sonstige
- Gegend: Nordische Inseln
- Gewicht: 3
- Wirkung: sättigt/gibt 15 ZP wenn AP voll

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Steinpilze/Hexenwald)
