---
type: Wiki Article
title: Dornenranke
description: Nach dem Töten von Kreuzdorn beim Fels in der Wüste südlich vom einsamen Rastplatz in Nordwestdörrland.
resource: "http://unitopia.intelligense.de/wiki/Dornenranke"
tags: [Fundort, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Licht, Info/Licht/leuchtet, Info/Material, Info/Material/Holz, Info/Schwimmt, Info/Waffenstärke, Info/Waffenstärke/sehr gut, Info/Waffenzustand, Info/Waffenzustand/solide, Set, Set/Feuer, Waffe, Waffe/Dörrland, Waffe/Dörrland/Peitsche, Waffe/Peitsche]
timestamp: 2024-09-16T12:12:19Z
revid: 232083
namespace: 0
contenthash: 5bee1ece601e7732961aa9d98b0e578aebc6bf3e07e173d2c93fa47464692d52
---

## Aussehen

Dies ist die brennende Ranke eines ehemals brennenden Dornbusches. Der
Dornbusch braucht sie wohl nicht mehr. Sie ist lang, biegsam und mit
boesartigen Dornen besetzt. Außerdem brennt ihr vorderes Ende lichterloh,
ohne sie zu verzehren.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [6 (sehr gut)](/kategorie/info-waffenstärke-sehr-gut.md "Kategorie:Info/Waffenstärke/sehr gut") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [6 (solide)](/kategorie/info-waffenzustand-solide.md "Kategorie:Info/Waffenzustand/solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [+1 (leuchtet normal)](/kategorie/info-licht-leuchtet.md "Kategorie:Info/Licht/leuchtet") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Nach dem Töten von [Kreuzdorn](/kreuzdorn.md "Kreuzdorn") beim Fels in der Wüste südlich vom [einsamen Rastplatz](/rastplatz.md "Rastplatz") in [Nordwestdörrland](/nordwestdörrland.md "Nordwestdörrland").

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Peitsche
- Gegend: Dörrland
- Set: Feuer
- Material: Holz
- Waffenstärke: sehr gut
- Waffenzustand: solide
- Gewicht: 2
- Licht: +1
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Dornenranke)
