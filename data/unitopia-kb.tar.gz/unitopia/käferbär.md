---
type: Wiki Article
title: Käferbär
description: Variabel
resource: "http://unitopia.intelligense.de/wiki/Käferbär"
tags: [NPC, NPC/Dörrland, NPC/Dörrland/aggressiv, NPC/aggressiv, Rasse, Rasse/Goblin, Rasse/Säugetier, Rasse/multi]
timestamp: 2018-11-07T18:29:52Z
revid: 214980
namespace: 0
contenthash: 095cdf8a573d7688f3abab4a487b938100262f9e7db60dc8cb63391e03433c7b
---

## Aussehen

Dieses Wesen erinnert dich an einen grossen Goblin mit Haaren. Das Haar
variiert von einem dunklen braun bis zu einem strahlenden rot. Es ist recht
kurz und stoppelig. Das Gesicht ist ziemlich langgezogen und die Nase
erinnert dich doch sehr an einen Baeren.

## Ausrüstung

[Variabel](/unterwelt.md "Unterwelt")

## Heimat

Im Unterreich der [Höhlenwelt](/höhlenwelt.md "Höhlenwelt").

* * *


## Kenndaten

- Typ: aggressiv
- Gegend: Dörrland
- Rasse: Goblin/Säugetier

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Käferbär)
