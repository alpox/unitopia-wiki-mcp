---
type: Wiki Article
title: "Schildkrötenpanzer/String-Dreieck"
description: ""
resource: "http://unitopia.intelligense.de/wiki/Schildkrötenpanzer/String-Dreieck"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/4, Info/Material, Info/Material/Bein, Info/Rüstungsstärke, Info/Rüstungsstärke/prima, Info/Rüstungszustand, Info/Rüstungszustand/sehr solide, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Rüstung, Rüstung/Brust, Rüstung/Dörrland, Rüstung/Dörrland/Brust]
timestamp: 2024-03-02T19:18:47Z
revid: 267254
namespace: 0
contenthash: 7c0e279c9dc65cb4695fd9b8e159ac45795bc0601379237145c41e957753a61f
---

## Aussehen

Ein riesiger, gruener Schildkroetenpanzer. Dicke Hornplatten, die wie harte
Beulen aussehen formen den groessten Teil dieser Ruestung. Die Oeffnungen
fuer Hals und Arme sind sorgfaeltig mit rotgefaerbtem Seegras umwickelt.
Das macht den groben Panzer etwas schoener und komfortabler.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Bein](/kategorie/info-material-bein.md "Kategorie:Info/Material/Bein") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [5 (prima)](/kategorie/info-rüstungsstärke-prima.md "Kategorie:Info/Rüstungsstärke/prima") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [7 (sehr solide)](/kategorie/info-rüstungszustand-sehr-solide.md "Kategorie:Info/Rüstungszustand/sehr solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [4 (gerade noch leicht)](/kategorie/info-gewicht-4.md "Kategorie:Info/Gewicht/4") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Rüstung der [Wachen](/wache.md "Wache") in der Eingangshalle des Unterwasserschlosses der [Unterwassersiedlung](/unterwassersiedlung.md "Unterwassersiedlung") im [String-Dreieck](/string-dreieck.md "String-Dreieck").
-   Rüstung der [Wachen](/wache.md "Wache") im Thronsaal des Unterwasserschlosses der [Unterwassersiedlung](/unterwassersiedlung.md "Unterwassersiedlung") im [String-Dreieck](/string-dreieck.md "String-Dreieck").

* * *


## Kenndaten

- Kategorie: Rüstung
- Typ: Brust
- Gegend: Dörrland
- Material: Bein
- Temperaturschutz: wärmt etwas
- Rüstungsstärke: prima
- Rüstungszustand: sehr solide
- Gewicht: 4
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schildkrötenpanzer/String-Dreieck)
