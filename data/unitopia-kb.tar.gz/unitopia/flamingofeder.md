---
type: Wiki Article
title: Flamingofeder
description: Vom ausgestopften Flamingo im Rittersaal der Felsenfestung in der Camargue.
resource: "http://unitopia.intelligense.de/wiki/Flamingofeder"
tags: [Gegenstand, Gegenstand/Gallien, Gegenstand/Gallien/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Bein]
timestamp: 2024-03-02T19:18:20Z
revid: 239409
namespace: 0
contenthash: 781e2a02847c6557d8e64015f1ba2fcdfec10dc7d59c233f7f6b9deabeaa88d6
---

## Aussehen

Eine wunderschoene, lange Feder eines Flamingos. Sie leuchtet rosafarben
auf und fuehlt sich sehr weich und flaumig an. Ob man damit nicht jemanden
kitzeln kann?

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Bein](/kategorie/info-material-bein.md "Kategorie:Info/Material/Bein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Vom ausgestopften Flamingo im Rittersaal der [Felsenfestung](/felsenfestung.md "Felsenfestung") in der [Camargue](/camargue.md "Camargue").

## Funktion

kitzel <Name> mit Feder

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Gallien
- Material: Bein
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Flamingofeder)
