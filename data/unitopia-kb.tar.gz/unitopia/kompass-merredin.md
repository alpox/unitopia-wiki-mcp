---
type: Wiki Article
title: Kompass/Merredin
description: "Der UNItopiawiki-Kompass zeigt dir sämtliche Kurse von einem Hafen zum anderen in nur 2 Schritten:"
resource: "http://unitopia.intelligense.de/wiki/Kompass/Merredin"
tags: [Kompass]
timestamp: 2020-06-04T16:52:15Z
revid: 190032
namespace: 0
contenthash: b744ed104500d4e428a89afbf714b045857217fc3e3d8b37285ea62ac15abd21
---

[![Kompass.png](/images/7/76/Kompass.png)](/kompass.md "Kompass")

| **Wähle deinen Zielhafen:** |  |  |  |
| --- | --- | --- | --- |
|  |  |  |  |
| ###### Dörrland: -   Dörrstadt: -   Oroonoque: -   Sarasande: -   Tobago: ###### Gallien: -   Aremorica: -   Lutetia: -   Massilia: -   Nordgallien: -   Rhonehafen: -   Sehavre: -   Westgallien: ###### Kokosinseln: -   Avalon: -   Cyprus: -   Dschungelinsel: -   Ephesos: -   Knossos: -   Kyra: -   Nublar: -   Vulkania: ###### Märchenland: -   Rumsrüttelkoge: | ###### (256sm 33°) (272sm 10°) (316sm 33°) (271sm 27°) ###### (399sm 132°) (369sm 139°) (301sm 135°) (395sm 137°) (326sm 137°) (387sm 138°) (383sm 133°) ###### (215sm 222°) (227sm 227°) (329sm 239°) (235sm 224°) (194sm 220°) (257sm 226°) (127sm 251°) (263sm 253°) ###### (1403sm 6°) | ###### Midgard: -   Bruggstad: -   Cygninia: -   Elfenhaven: -   Glamoth: -   Londar: -   Magny: -   Merredin: -   Moaki-Bucht: -   Mompracem: -   Nankea: -   Nordhafen: -   Port Amber: -   Tol Ethraid: -   Tolfalas: ###### Nordische Inseln: -   Hexenwald: -   Imneboerg: -   Orchid: -   Pandas: -   Phexcaer: -   Vandras: -   Veldergautland: ###### Vaniorh: -   Dur-Scharrukin: -   Tadmor: -   Terqa: | ###### (1184sm 351°) (1125sm 350°) (1165sm 352°) (1214sm 348°) (1199sm 351°) (1152sm 351°) (1215sm 349°) (1153sm 349°) (1107sm 353°) (1350sm 2°) (1232sm 349°) (1225sm 352°) (1225sm 352°) (1166sm 352°) ###### (1252sm 168°) (1272sm 167°) (1231sm 168°) (1242sm 166°) (1238sm 168°) (1249sm 168°) (1811sm 181°) ###### (7sm 180°) (8sm 270°) (10sm 354°) |
| **zurück zum: [Kompass](/kategorie/kompass.md "Kategorie:Kompass")** |  |  |  |

Der UNItopiawiki-Kompass zeigt dir sämtliche Kurse von einem Hafen zum anderen in nur 2 Schritten:

-   _[Starthafen](/häfen.md "Häfen") wählen (Liste auf der linken Seite)_
-   _[Zielhafen](/häfen.md "Häfen") wählen_

Bei der Wahl des Zielhafens habt ihr die Möglichkeit zu dieser Seite wieder zurückzukehren, falls ihr euch mal verklickt haben solltet. Auf der Kursseite könnt ihr einen neuen Zielhafen wählen, eine komplett neue Kursberechnung starten oder direkt den Rückweg berechnen lassen.

Außer den hier aufgelisteten Standardkursen gibt es noch eine Liste der [Kurse zu exotischen Reisezielen](/kategorie/kompass-reiseziele.md "Kategorie:Kompass/Reiseziele").

Wir bemühen uns, alle Kurse so genau wie möglich zu halten. Sollte sich doch ein Fehler einschleichen, so sagt uns unter [Diskussion:Kompass](http://unitopia.intelligense.de/wiki/Diskussion:Kompass "Diskussion:Kompass") Bescheid und wir werden den Fehler so schnell wie möglich ausbessern.

Für **Windows-User** gibt es einen solchen Kompass auch als Download. [Tetlok](http://unitopia.intelligense.de/wiki/Benutzer:Tetlok "Benutzer:Tetlok") hat vor langer Zeit ein solches Programm geschrieben. Allerdings sind die Kurse massiv veraltet, daher ist nur noch die Punkt-zu-Punkt-Berechnung wirklich tauglich. Den Download der Normal- und Lightversion findet man [\>>hier<<](/hauptseite.md "Hauptseite").

* * *

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Kompass/Merredin)
