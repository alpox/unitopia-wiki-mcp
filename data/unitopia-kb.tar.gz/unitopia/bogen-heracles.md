---
type: Wiki Article
title: Bogen/Heracles
description: ""
resource: "http://unitopia.intelligense.de/wiki/Bogen/Heracles"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Holz, Info/Schwimmt, Info/Waffenstärke, Info/Waffenstärke/sehr toll, Info/Waffenzustand, Info/Waffenzustand/mäßig haltbar, Waffe, Waffe/Bogen, Waffe/Kokosinseln, Waffe/Kokosinseln/Bogen]
timestamp: 2024-03-02T19:18:56Z
revid: 253326
namespace: 0
contenthash: ad28fef5f351098eeda0b6f51d9b6e481597bd212cf533dda01634e35f40adbe
---

## Aussehen

Ein mannshoher Bogen aus feinstem glatten Nussbaumholz. Fuer einen, der ihn
spannen kann ist er sicherlich eine vorzuegliche Waffe.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [9 (sehr toll)](/kategorie/info-waffenstärke-sehr-toll.md "Kategorie:Info/Waffenstärke/sehr toll") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [3 (mäßig haltbar)](/kategorie/info-waffenzustand-mäßig-haltbar.md "Kategorie:Info/Waffenzustand/mäßig haltbar") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

-   Waffe von [Heracles](/heracles.md "Heracles") an der Nordküste auf [Kreta](/kreta.md "Kreta").
-   Waffe von [Heracles](/heracles.md "Heracles") im Innenhof seines [Landhauses](/landhaus-heracles.md "Landhaus/Heracles") auf [Kreta](/kreta.md "Kreta").

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Bogen
- Gegend: Kokosinseln
- Material: Holz
- Waffenstärke: sehr toll
- Waffenzustand: mäßig haltbar
- Gewicht: 2
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Bogen/Heracles)
