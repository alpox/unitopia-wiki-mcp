---
type: Wiki Article
title: Steinriese/Nebelberge
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Steinriese/Nebelberge"
tags: [NPC, NPC/Midgard, NPC/Midgard/defensiv, NPC/defensiv, Rasse, Rasse/Elementar, Rasse/Riese, Rasse/multi]
timestamp: 2018-11-07T18:27:09Z
revid: 211805
namespace: 0
contenthash: a01e48b65cc4e7ba8e0cd15eb14ae5f29b0839083c5dc51e222d47e68cda023a
---

## Aussehen

Steinriesen sind enorme Geschoepfe, alt wie das Gestein und gross wie die
Berge. In dunklen Sturmnaechten spielen sie mit Felsbrocken wie andere
Leute mit Volleybaellen.

## Ausrüstung

Keine.

## Heimat

Auf einem Sattel in den [Nebelbergen](/nebelberge.md "Nebelberge") nahe [Hochelfenstatt](/hochelfenstatt.md "Hochelfenstatt").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Midgard
- Rasse: Elementar/Riese

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Steinriese/Nebelberge)
