---
type: Wiki Article
title: Hahnenfeder
description: Von der Wollmilchsau im Stall des Bauernhofes von Phexcaer auf Thule.
resource: "http://unitopia.intelligense.de/wiki/Hahnenfeder"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Bein, Kleidung, Kleidung/Kopf, Kleidung/Nordische Inseln, Kleidung/Nordische Inseln/Kopf]
timestamp: 2024-03-02T19:21:07Z
revid: 219606
namespace: 0
contenthash: 8325f60060a3ca8ae0e00848a1c0f02ff5ac39a16db1d0fa52535bdaa81b0f50
---

## Aussehen

Eine praechtige, bunte Hahnenfeder. Zumindest sieht sie taeuschend aehnlich
aus. Sie ist jedoch so riesig, dass sie niemals von einem Hahn, sondern nur
von der eierlegenden Wollmilchsau stammen kann. Sie schimmert in den
verschiedensten Farben.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Bein](/kategorie/info-material-bein.md "Kategorie:Info/Material/Bein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Von der [Wollmilchsau](/wollmilchsau.md "Wollmilchsau") im Stall des [Bauernhofes](/phexcaer.md "Phexcaer") von [Phexcaer](/phexcaer.md "Phexcaer") auf [Thule](/thule.md "Thule").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Kopf
- Gegend: Nordische Inseln
- Material: Bein
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Hahnenfeder)
