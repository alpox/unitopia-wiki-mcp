---
type: Wiki Article
title: Matschige Füße
description: "Durch den Gemüsegarten hinter dem Gasthof \"Zur Stadtwache\" von Magny."
resource: "http://unitopia.intelligense.de/wiki/Matschige_Füße"
tags: [Info, Info/Heilung, Info/Wirkung, Info/Wirkung/Zustand, Info/Wirkung/Zustand/neutral, Zustand, Zustand/Midgard, Zustand/Midgard/Sonstige, Zustand/Sonstige]
timestamp: 2024-08-29T15:20:43Z
revid: 228399
namespace: 0
contenthash: 56fa1b15a52fc34a7f71d8f3d166e36cae563fea3539caea32b7cd7c9daa62b3
---

## Aussehen

<SPIELER>s erdige Fuesse sind bis ueber die Knoechel mit Matsch eingesaut.

## Informationen

| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [neutral](/kategorie/info-wirkung-zustand-neutral.md "Kategorie:Info/Wirkung/Zustand/neutral") |
| --- | --- |
| **[Heilung](/kategorie/info-heilung.md "Kategorie:Info/Heilung"):** | automatisch |

## Fundort

Durch den Gemüsegarten hinter dem Gasthof "Zur Stadtwache" von [Magny](/magny.md "Magny").

## Gefährlichkeit

-   Hält ca. 10 Minuten an.
-   Startmeldung:

Deine Fuesse versinken bis zu den Knoecheln im Matsch.

-   Endmeldung:

Deine Fuesse sind endlich wieder sauber.

* * *


## Kenndaten

- Kategorie: Zustand
- Typ: Sonstige
- Gegend: Midgard
- Wirkung: neutral
- Heilung: automatisch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Matschige_Füße)
