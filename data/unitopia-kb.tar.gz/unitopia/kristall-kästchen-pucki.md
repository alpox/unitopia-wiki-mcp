---
type: Wiki Article
title: Kristall/Kästchen/Pucki
description: "Im kleinen, schwarzen Kästchen von Pucki auf einer Waldwiese im alten Troja auf Phrygia."
resource: "http://unitopia.intelligense.de/wiki/Kristall/Kästchen/Pucki"
tags: [Gegenstand, Gegenstand/Kokosinseln, Gegenstand/Kokosinseln/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Licht, Info/Licht/absorbiert, Info/Material, Info/Material/Unbekannt]
timestamp: 2024-03-02T19:21:21Z
revid: 247688
namespace: 0
contenthash: ad09225fff09a5de77abf2970992cc9a5aa1db5778baa4af3575abbcc23e8ddf
---

## Aussehen

Ein dunkler Kristall, der das Licht um sich herum foermlich zu schlucken
scheint.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Unbekannt](/kategorie/info-material-unbekannt.md "Kategorie:Info/Material/Unbekannt") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [\-1 (schluckt ein wenig Licht)](/kategorie/info-licht-absorbiert.md "Kategorie:Info/Licht/absorbiert") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Im [kleinen, schwarzen Kästchen](/kästchen-pucki.md "Kästchen/Pucki") von [Pucki](/pucki.md "Pucki") auf einer Waldwiese im [alten Troja](/troja.md "Troja") auf [Phrygia](/phrygia.md "Phrygia").

## Funktion

Der [Kristall](/kristall-kästchen-pucki.md "Kristall/Kästchen/Pucki") des [Kästchens](/kästchen-pucki.md "Kästchen/Pucki") verdunkelt den Raum und kann nicht entnommen werden:

-   öffne Kästchen
-   schließe Kästchen

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Kokosinseln
- Material: Unbekannt
- Gewicht: 1
- Licht: -1
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Kristall/Kästchen/Pucki)
