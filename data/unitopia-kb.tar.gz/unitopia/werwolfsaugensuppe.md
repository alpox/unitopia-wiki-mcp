---
type: Wiki Article
title: Werwolfsaugensuppe
description: "Zu kaufen bei Redgar in der Kneipe \"Zum lebenden TOD\" in Barovia."
resource: "http://unitopia.intelligense.de/wiki/Werwolfsaugensuppe"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Dörrland, Nahrung/Dörrland/Tier, Nahrung/Tier]
timestamp: 2024-08-29T15:23:30Z
revid: 266212
namespace: 0
contenthash: 9c1290a76b78603d3417741a1ee7de4e1d11b76c1365f25d53dec4d4cad9e3f7
---

## Aussehen

Frische, waehrend der Verwandlung bei Vollmond, entnommene Werwolfsaugen
schwimmen in einer pikant wuerzig, kalten, abgestandenen Tomatensuppe. Der
Tellerrand ist liebevoll mit ausgezupften Werwolfsaugenbrauen dekoriert,
jedenfalls, wenn man sie von Redgar's Haaren, die waehrend der Zubereitung
draufgefallen sind, unterscheiden kann... Nichts desto trotz, ist diese
Suppe das Insidergericht aller Schurken und Einwohner von Barovia - die
deren Magen so leer ist, wie ihr Portemonaie.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Zu kaufen bei [Redgar](/redgar.md "Redgar") in der Kneipe "Zum lebenden TOD" in [Barovia](/barovia.md "Barovia").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Tier
- Gegend: Dörrland
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Werwolfsaugensuppe)
