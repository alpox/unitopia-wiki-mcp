---
type: Wiki Article
title: Streitaxt/Godehard
description: Zu kaufen bei Godehard in Nankea (Stadt).
resource: "http://unitopia.intelligense.de/wiki/Streitaxt/Godehard"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/4, Info/Material, Info/Material/Metall, Info/Waffenstärke, Info/Waffenstärke/prima, Info/Waffenzustand, Info/Waffenzustand/eher beständig, Waffe, Waffe/Axt, Waffe/Midgard, Waffe/Midgard/Axt]
timestamp: 2024-04-23T19:27:37Z
revid: 231374
namespace: 0
contenthash: 774c15d174c7e53328fff92ab5e33e28d9e6e1ac3bd9d31bc51f780d54ee9fa8
---

## Aussehen

Eine Streitaxt, eine edle Zwergenwaffe.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [7 (prima)](/kategorie/info-waffenstärke-prima.md "Kategorie:Info/Waffenstärke/prima") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [4 (eher beständig)](/kategorie/info-waffenzustand-eher-beständig.md "Kategorie:Info/Waffenzustand/eher beständig") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [4 (gerade noch leicht)](/kategorie/info-gewicht-4.md "Kategorie:Info/Gewicht/4") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Godehard](/godehard.md "Godehard") in [Nankea (Stadt)](/nankea-\(stadt\).md "Nankea (Stadt)").

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Axt
- Gegend: Midgard
- Material: Metall
- Waffenstärke: prima
- Waffenzustand: eher beständig
- Gewicht: 4
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Streitaxt/Godehard)
