---
type: Wiki Article
title: Mr X
description: In seinem Pförtnerhaus im Norden von Ambring.
resource: "http://unitopia.intelligense.de/wiki/Mr_X"
tags: [NPC, NPC/Midgard, NPC/Midgard/defensiv, NPC/defensiv, Rasse, Rasse/Halbling, Tätigkeit, Tätigkeit/Spieler]
timestamp: 2018-11-07T18:28:07Z
revid: 217453
namespace: 0
contenthash: 2142dd07172dcfa190f1af752f0b5146c100e8730158debab9a1519dbd20f70c
---

## Aussehen

Ein zierlicher, unscheinbarer Herr, ganz in Schwarz gekleidet, der Statur
nach ein Halbling. Es ist seltsam, wenn Du nicht ganz genau hingeschaut
haettest, haettest Du ihn hundertprozentig uebersehen. Auch jetzt beginnt
er bereits, Deinem Gedaechtnis zu entschwinden.

## Ausrüstung

-   Ein [unschuldiger, kleiner Gummipunkt](/gummipunkt.md "Gummipunkt").
-   Eine [stinkfeine Taschenuhr](/taschenuhr-mr-x.md "Taschenuhr/Mr X").
-   Ein [goldener Füller](/füller.md "Füller").
-   Ein [Rucksack](/rucksack-diebesgilde.md "Rucksack/Diebesgilde").

## Heimat

In seinem Pförtnerhaus im Norden von [Ambring](/ambring.md "Ambring").

## Besonderheit

Du kannst ihn ja mal nach [Heimlich und Co](/heimlich-und-co.md "Heimlich und Co") fragen.

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Midgard
- Rasse: Halbling
- Tätigkeit: Spieler

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Mr_X)
