---
type: Wiki Article
title: Khaldoun
description: "Im Triceratops-Gehege im Dinopark auf Isla Nublar."
resource: "http://unitopia.intelligense.de/wiki/Khaldoun"
tags: [NPC, NPC/Kokosinseln, NPC/Kokosinseln/defensiv, NPC/defensiv, Rasse, Rasse/Mensch]
timestamp: 2018-11-07T18:31:22Z
revid: 219684
namespace: 0
contenthash: ba99945cb2ab7d9ae8887c0599cd84f942114d2c762f820da4d99fd7ca59e124
---

## Aussehen

Khaldoun, ein ernster Beduine mit schwarz geschminkten Augen, um die
Vierzig. Er erwidert Deinen Blick, und Du glaubst darin die Vorahnung auf
eine schicksalshafte Begegnung, moeglicherweise mit Raptoren, zu erkennen.
Dennoch fuehlst Du Dich bei diesem starken und autoritaeren Mann in
Sicherheit.

## Ausrüstung

-   Das [Horn eines Triceratops](/horn-khaldoun.md "Horn/Khaldoun").
-   Eine [blutige Axt](/axt-khaldoun.md "Axt/Khaldoun").
-   Ein [dunkelblauer Turban](/turban-khaldoun.md "Turban/Khaldoun").
-   Ein [dunkelblauer Kaftan](/kaftan-khaldoun.md "Kaftan/Khaldoun").

## Heimat

Im Triceratops-Gehege im Dinopark auf [Isla Nublar](/nublar.md "Nublar").

## Besonderheit

Der Großwildjäger ist im Dinopark generell auf jagt und läuft daher auch ab und zu herum.

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Kokosinseln
- Rasse: Mensch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Khaldoun)
