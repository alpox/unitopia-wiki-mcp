---
type: Wiki Article
title: Dribbel Boys/Rhino Rauhbein
description: Zufällig zu finden in jedem Wunderei.
resource: "http://unitopia.intelligense.de/wiki/Dribbel_Boys/Rhino_Rauhbein"
tags: [Fundort, Gegenstand, Gegenstand/Campus, Gegenstand/Campus/Sonstige, Gegenstand/Dörrland, Gegenstand/Dörrland/Sonstige, Gegenstand/Ebenen, Gegenstand/Ebenen/Sonstige, Gegenstand/Gallien, Gegenstand/Gallien/Sonstige, Gegenstand/Kokosinseln, Gegenstand/Kokosinseln/Sonstige, Gegenstand/Levitanis, Gegenstand/Levitanis/Sonstige, Gegenstand/Midgard, Gegenstand/Midgard/Sonstige, Gegenstand/Märchenland, Gegenstand/Märchenland/Sonstige, Gegenstand/Nordische Inseln, Gegenstand/Nordische Inseln/Sonstige, Gegenstand/Sonstige, Gegenstand/Vaniorh, Gegenstand/Vaniorh/Sonstige, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Holz, Info/Schwimmt, Set, Set/Sammelfiguren]
timestamp: 2024-09-16T12:12:42Z
revid: 254091
namespace: 0
contenthash: e03f0ee9123d79042c974a121fa1f76ba9f2ca69d48745a7de0ec97f3dd2f724
---

## Aussehen

Rhino Rauhbein aus der Reihe <Die Dribbel Boys>.
Wenn Rhino richtig in Fahrt ist, dann nimmt er gern mal den Ball auf's
Horn. So geruestet hat er die Vorteile auf seiner Seite.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Zufällig zu finden in jedem [Wunderei](/wunderei.md "Wunderei").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Set: Sammelfiguren
- Material: Holz
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Dribbel_Boys/Rhino_Rauhbein)
