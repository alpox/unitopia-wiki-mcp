---
type: Wiki Article
title: Stavros
description: "Stavros' Trommel."
resource: "http://unitopia.intelligense.de/wiki/Stavros"
tags: [NPC, NPC/Kokosinseln, NPC/Kokosinseln/defensiv, NPC/defensiv, Rasse, Rasse/Mensch]
timestamp: 2018-11-07T18:26:47Z
revid: 215861
namespace: 0
contenthash: d286f5351dddfb3dab4fd674c3b8161e49d5c7247e5c943b178d26178dc99662
---

## Aussehen

Stavros ist ein grosser, grobschlaechtiger Klotz. Bei seinen Schuelern ist
er gefuerchtet, selten hat es einer geschafft, sein Wohlwollen zu erringen.
Er ist bekannt dafuer, dass er in der Musik die haertere Gangart bevorzugt.

## Ausrüstung

[Stavros' Trommel](/trommel-amati.md "Trommel/Amati").

## Heimat

In der [Bardengilde](/bardengilde.md "Bardengilde") von [Ephesos](/ephesos.md "Ephesos") auf [Phrygia](/phrygia.md "Phrygia").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Kokosinseln
- Rasse: Mensch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Stavros)
