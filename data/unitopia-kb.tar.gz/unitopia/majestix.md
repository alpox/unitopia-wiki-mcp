---
type: Wiki Article
title: Majestix
description: Verschiedene Dinge zum Essen.
resource: "http://unitopia.intelligense.de/wiki/Majestix"
tags: [NPC, NPC/Gallien, NPC/Gallien/defensiv, NPC/defensiv, Rasse, Rasse/Mensch]
timestamp: 2018-11-07T18:26:35Z
revid: 257621
namespace: 0
contenthash: 3bb65e874331556a285d3b647d2efe3291be087a55be46fdd3d8f7fe0f1a7353
---

## Aussehen

_Tags:_

Majestix, ist der Haeuptling des Stammes. Ein majestaetischer, mutiger,
argwoenischer alter Krieger, von seinen Leuten respektiert, von seinen
Feinden gefuerchtet. Seine roten Haare sind zu zwei Zoepfen geflochten,
ueber jenen traegt er einen Helm. Unter seiner riesigen Nase ist ein
gewaltiger, buschiger Schnurrbart. Er traegt ein gruenes Hemd, ueber
welchem ein dunkelgruener Umhang haengt und eine blau/schwarz gestreifte
Hose die mit einem gelben Guertel zugezogen ist, an dem ein Schwert haengt.

_Abends:_

Majestix, der Haeuptling des Dorfes. Er sitzt nackt und wuerdevoll in einem
als Badewanne umfunktionierten Waschzuber.

_Nachts:_

Majestix der Haeuptling. Er liegt friedlich schlafend im Bett. Du moechtest
ihn doch wohl nicht aufwecken?

## Ausrüstung

_Mittags:_

[Verschiedene Dinge zum Essen](/essen-majestix.md "Essen/Majestix").

## Heimat

Bei ihm im [Gallischen Dorf](/gallierdorf.md "Gallierdorf").

## Besonderheit

-   Mittags zum Essen erhält er folgenden Zusatz im Aussehen:

Er ist gerade am Essen. Es ist wohl nicht gerade die richtige Zeit, ihn zu
stoeren.

-   Sitzt er auf seinem Hochsitz, erhält er folgenden Zusatz im Aussehen:

Momentan geht er seinen Regierungsgeschaeften nach.

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Gallien
- Rasse: Mensch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Majestix)
