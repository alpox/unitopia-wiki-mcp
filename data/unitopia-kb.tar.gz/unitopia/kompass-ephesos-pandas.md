---
type: Wiki Article
title: Kompass/Ephesos/Pandas
description: "Route von [[]] nach [[]] :"
resource: "http://unitopia.intelligense.de/wiki/Kompass/Ephesos/Pandas"
tags: [Kompass]
timestamp: 2020-06-04T16:56:50Z
revid: 207019
namespace: 0
contenthash: 35234bfd0db08e0ec7b5709b13b31151a9b3ba9502f3fde8095a9bbe6d89071d
---

[![Kompass.png](/images/7/76/Kompass.png)](/kompass.md "Kompass")

| Route von \[\[\]\] nach \[\[\]\] : |
| --- |
|  |
| steuere 20 sm 270 grad steuere 239 sm 0 grad steuere 437 sm 270 grad steuere 794 sm 0 grad |
|  |
| Rückfahrt, Weiterfahrt von , Neuer Zielhafen, Neue [Kursberechnung](/kategorie/kompass.md "Kategorie:Kompass") |

Der UNItopiawiki-Kompass zeigt dir sämtliche Kurse von einem Hafen zum anderen in nur 2 Schritten:

-   _[Starthafen](/häfen.md "Häfen") wählen (Liste auf der linken Seite)_
-   _[Zielhafen](/häfen.md "Häfen") wählen_

Bei der Wahl des Zielhafens habt ihr die Möglichkeit zu dieser Seite wieder zurückzukehren, falls ihr euch mal verklickt haben solltet. Auf der Kursseite könnt ihr einen neuen Zielhafen wählen, eine komplett neue Kursberechnung starten oder direkt den Rückweg berechnen lassen.

Außer den hier aufgelisteten Standardkursen gibt es noch eine Liste der [Kurse zu exotischen Reisezielen](/kategorie/kompass-reiseziele.md "Kategorie:Kompass/Reiseziele").

Wir bemühen uns, alle Kurse so genau wie möglich zu halten. Sollte sich doch ein Fehler einschleichen, so sagt uns unter [Diskussion:Kompass](http://unitopia.intelligense.de/wiki/Diskussion:Kompass "Diskussion:Kompass") Bescheid und wir werden den Fehler so schnell wie möglich ausbessern.

Für **Windows-User** gibt es einen solchen Kompass auch als Download. [Tetlok](http://unitopia.intelligense.de/wiki/Benutzer:Tetlok "Benutzer:Tetlok") hat vor langer Zeit ein solches Programm geschrieben. Allerdings sind die Kurse massiv veraltet, daher ist nur noch die Punkt-zu-Punkt-Berechnung wirklich tauglich. Den Download der Normal- und Lightversion findet man [\>>hier<<](/hauptseite.md "Hauptseite").

* * *

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Kompass/Ephesos/Pandas)
