---
type: Wiki Article
title: Elfenbeinständer
description: Im Aleipterion in der Therme von Lutetia.
resource: "http://unitopia.intelligense.de/wiki/Elfenbeinständer"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/3, Info/Material, Info/Material/Bein, Info/Waffenstärke, Info/Waffenstärke/recht gut, Info/Waffenzustand, Info/Waffenzustand/recht beständig, Waffe, Waffe/Gallien, Waffe/Gallien/Keule, Waffe/Keule]
timestamp: 2024-03-02T19:21:13Z
revid: 232205
namespace: 0
contenthash: a0e7df3e182666e15f584c6c64b0d3866a62a427f1c1ca4bca8dd32ff1a40d1b
---

## Aussehen

Ein elfenbeinerner Staender von der Groesse eines Wurfspeeres. An der
Spitze wurde eine eine flache Tonschale befestigt; ein quadratischer
Pflasterstein steckt am unteren Ende des Ständers, als ob er irgendwo
herausgerissen wurde.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Bein](/kategorie/info-material-bein.md "Kategorie:Info/Material/Bein") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [5 (recht gut)](/kategorie/info-waffenstärke-recht-gut.md "Kategorie:Info/Waffenstärke/recht gut") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [5 (recht beständig)](/kategorie/info-waffenzustand-recht-beständig.md "Kategorie:Info/Waffenzustand/recht beständig") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [3 (schon eher leicht)](/kategorie/info-gewicht-3.md "Kategorie:Info/Gewicht/3") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Im Aleipterion in der [Therme](/therme.md "Therme") von [Lutetia](/lutetia.md "Lutetia").

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Keule
- Gegend: Gallien
- Material: Bein
- Waffenstärke: recht gut
- Waffenzustand: recht beständig
- Gewicht: 3
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Elfenbeinständer)
