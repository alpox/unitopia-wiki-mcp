---
type: Wiki Article
title: Gulasch
description: Mit einigen speziellen Zutaten kann man eine Variante kochen.
resource: "http://unitopia.intelligense.de/wiki/Gulasch"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Gallien, Nahrung/Gallien/Produkt, Nahrung/Kokosinseln, Nahrung/Kokosinseln/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:24:16Z
revid: 254698
namespace: 0
contenthash: f37301a636b02026ae30e1e581b867b24de2b680442f95572cbff322ea1826be
---

## Aussehen

Ein leckeres, selbst gemachtes Gulasch. Es sieht sehr appetitlich aus.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

-   Durch den [Kessel](/kessel-druidengilde.md "Kessel/Druidengilde") auf der Lichtung im [Karnutenwald](/karnutenwald.md "Karnutenwald").
-   Durch den [Kessel](/kessel-druidengilde.md "Kessel/Druidengilde") in der Küche der [Druidengilde](/druidengilde.md "Druidengilde") von [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").

## Besonderheit

Mit einigen speziellen Zutaten kann man eine Variante kochen.

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Kokosinseln/Gallien
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Gulasch)
