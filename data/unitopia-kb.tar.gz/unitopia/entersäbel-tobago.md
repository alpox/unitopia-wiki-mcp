---
type: Wiki Article
title: Entersäbel/Tobago
description: In der rostigen Schatzkiste der Schatzkammer des Piratenkapitäns in der Grotte auf Tobago.
resource: "http://unitopia.intelligense.de/wiki/Entersäbel/Tobago"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/4, Info/Material, Info/Material/Metall, Info/Waffenstärke, Info/Waffenstärke/toll, Info/Waffenzustand, Info/Waffenzustand/solide, Waffe, Waffe/Dörrland, Waffe/Dörrland/Säbel, Waffe/Säbel]
timestamp: 2024-03-02T19:17:53Z
revid: 231711
namespace: 0
contenthash: 6dd5772c6a49c90198177e04f03dd7832af109580e24baa19b47c572b2ed0ed6
---

## Aussehen

Dieser Saebel ist eine antike, furchtbare Seemannswaffe. Seine elegant
geschwungene Klinge kann furchtbare Wunden schlagen. Der Griff des Saebels
ist mit Leder umwickelt und weist einen altertuemlichen Parierkorb auf.
Etwas Unheimliches geht von dieser Waffe aus.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [8 (toll)](/kategorie/info-waffenstärke-toll.md "Kategorie:Info/Waffenstärke/toll") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [6 (solide)](/kategorie/info-waffenzustand-solide.md "Kategorie:Info/Waffenzustand/solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [4 (gerade noch leicht)](/kategorie/info-gewicht-4.md "Kategorie:Info/Gewicht/4") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

In der [rostigen Schatzkiste](/schatzkiste-tobago.md "Schatzkiste/Tobago") der Schatzkammer des Piratenkapitäns in der [Grotte](/tobago.md "Tobago") auf [Tobago](/tobago.md "Tobago").

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Säbel
- Gegend: Dörrland
- Material: Metall
- Waffenstärke: toll
- Waffenzustand: solide
- Gewicht: 4
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Entersäbel/Tobago)
