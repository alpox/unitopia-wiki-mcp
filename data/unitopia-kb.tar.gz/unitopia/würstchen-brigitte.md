---
type: Wiki Article
title: Würstchen/Brigitte
description: Zu kaufen bei Brigitte in Gittis Hofladen von Magny.
resource: "http://unitopia.intelligense.de/wiki/Würstchen/Brigitte"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/giftig, Info/Wirkung/sättigt, Nahrung, Nahrung/Midgard, Nahrung/Midgard/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:15:27Z
revid: 244452
namespace: 0
contenthash: bb049c9d0989095ae79af712ed0703db4988c2d6e1c9c6d250fe3b002b52bf59
---

## Aussehen

Ein Wuerstchen aus Getreide. Es ist ungefaehr 15 cm lang, leicht gebogen
und von hellbrauner Farbe. Gebraten ist es bestimmt sehr lecker und
schmackhaft.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt"), [Magenverstimmung](/magenverstimmung-magny.md "Magenverstimmung/Magny") |

## Fundort

Zu kaufen bei [Brigitte](/brigitte.md "Brigitte") in Gittis Hofladen von [Magny](/magny.md "Magny").

## Besonderheit

Wenn man das Würstchen brät, wird es zu einem [Getreidewürstchen](/getreidewürstchen.md "Getreidewürstchen").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Midgard
- Gewicht: 1
- Wirkung: sättigt/Magenverstimmung-Magny

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Würstchen/Brigitte)
