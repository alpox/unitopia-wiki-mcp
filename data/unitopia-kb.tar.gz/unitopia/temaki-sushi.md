---
type: Wiki Article
title: "Temaki-Sushi"
description: "Zu kaufen bei Miyoshi in der Sushi-Bar von Foo-Ling-Yoo auf Asia."
resource: "http://unitopia.intelligense.de/wiki/Temaki-Sushi"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Ebenen, Nahrung/Ebenen/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:13:59Z
revid: 250078
namespace: 0
contenthash: 1dd23f1517d8335489f3b4f4c4cbddbe21b4dc3a89dcc0f92f86f32864e60039
---

## Aussehen

Eine Algentuete, gefuellt mit rosafarbenem Lachs, Avocado und Gurke, mit
Reis umhuellt. Dieses Sushi kann man gut mit der Hand essen. Daneben ist
etwas Sojasauce und Wasabi angerichtet. Das Ganze schaut sehr appetitlich
aus.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Zu kaufen bei [Miyoshi](/miyoshi.md "Miyoshi") in der Sushi-Bar von [Foo-Ling-Yoo](/foo-ling-yoo.md "Foo-Ling-Yoo") auf [Asia](/asia.md "Asia").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Ebenen
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Temaki-Sushi)
