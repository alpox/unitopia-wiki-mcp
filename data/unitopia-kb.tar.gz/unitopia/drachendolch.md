---
type: Wiki Article
title: Drachendolch
description: Im Bach bei dem Markawasserfall im Wurzelwald im Wurzelwald auf Nankea.
resource: "http://unitopia.intelligense.de/wiki/Drachendolch"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Bein, Info/Waffenstärke, Info/Waffenstärke/naja, Info/Waffenzustand, Info/Waffenzustand/kaputt, Info/Waffenzustand/recht beständig, Waffe, Waffe/Messer, Waffe/Midgard, Waffe/Midgard/Messer]
timestamp: 2024-03-02T19:20:41Z
revid: 228172
namespace: 0
contenthash: b5421478b21173d3391a468772eea9b7b473f7177d4c19032e4c892733923089
---

## Aussehen

Ein Drachendolch. Er ist aus Drachenzahn gefertigt. Sein Griff ist mit
Schnitzereien verziert.
Der Drachendolch ist beschaedigt.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Bein](/kategorie/info-material-bein.md "Kategorie:Info/Material/Bein") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [3 (naja)](/kategorie/info-waffenstärke-naja.md "Kategorie:Info/Waffenstärke/naja") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [0 (kaputt)](/kategorie/info-waffenzustand-kaputt.md "Kategorie:Info/Waffenzustand/kaputt"), [5 (recht beständig)](/kategorie/info-waffenzustand-recht-beständig.md "Kategorie:Info/Waffenzustand/recht beständig") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Im Bach bei dem Markawasserfall im Wurzelwald im [Wurzelwald](/wurzelwald.md "Wurzelwald") auf [Nankea](/nankea.md "Nankea").

## Besonderheit

Nach einer Reparatur, erhält man den zweiten Wert beim Waffenzustand.

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Messer
- Gegend: Midgard
- Material: Bein
- Waffenstärke: naja
- Waffenzustand: kaputt/recht beständig
- Gewicht: 2
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Drachendolch)
