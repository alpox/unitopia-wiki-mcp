---
type: Wiki Article
title: Flussbiber
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Flussbiber"
tags: [Braten, Braten/Haut, Braten/Jagen, Braten/Stück, Braten/Trophäe, NPC, NPC/Midgard, NPC/Midgard/defensiv, NPC/defensiv, Rasse, Rasse/Säugetier]
timestamp: 2019-02-13T19:42:30Z
revid: 238635
namespace: 0
contenthash: 5c07b54825e1b1f24ffb412e4e6a5565c82bf4686128d0621f86c53d5e624eed
---

## Aussehen

```
Ein netter Biber mit einem dicken Schwanz, der auf der Suche nach
Holz ist, um einen Damm an der Wässer zu bauen.
```

## Ausrüstung

Keine.

## Heimat

In [Fabeln](/fabeln.md "Fabeln").

## Besonderheit

Nach dem Töten ist der Flussbiber [häut-](/biberfell.md "Biberfell") und [bratbar](/braten-magyra.md "Braten/Magyra"). Der Braten lässt sich in mehrere handliche [Braten](/bratenscheibe.md "Bratenscheibe")[scheiben](/braten-scheibe.md "Braten/Scheibe"), [Braten](/bratenstück.md "Bratenstück")[stücke](/braten-stück.md "Braten/Stück") oder [Braten](/bratenteil.md "Bratenteil")[teile](/braten-teil.md "Braten/Teil") zerlegen.  
Zusätzlich kann man noch den [Biberschwanz](/biberschwanz.md "Biberschwanz") abschneiden.

## Kenndaten

- Typ: defensiv
- Gegend: Midgard
- Rasse: Säugetier
- Artikel: der
- Haut: Biberfell
- Stück: ja
- TrophäeA: den Biberschwanz

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Flussbiber)
