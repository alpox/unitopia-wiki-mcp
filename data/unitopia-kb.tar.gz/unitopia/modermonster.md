---
type: Wiki Article
title: Modermonster
description: Durch den den Komposthaufen im alten Stadtpark von Terqa.
resource: "http://unitopia.intelligense.de/wiki/Modermonster"
tags: [Info, Info/Heilung, Info/Wirkung, Info/Wirkung/Zustand, Info/Wirkung/Zustand/neutral, Zustand, Zustand/Sonstige, Zustand/Vaniorh, Zustand/Vaniorh/Sonstige]
timestamp: 2024-08-29T15:23:30Z
revid: 264914
namespace: 0
contenthash: bbb94c9a9b5bc1a65127711f78fcaf54c65fff4c61cb952ad6f5cb90e6857859
---

## Aussehen

Ein Modermonster, das dich mit grossen Augen anschaut. Beim genaueren
Betrachten des Monsters faellt dir auf, dass er einige Aehnlichkeit mit
<Spieler> hat.

## Informationen

| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [neutral](/kategorie/info-wirkung-zustand-neutral.md "Kategorie:Info/Wirkung/Zustand/neutral") |
| --- | --- |
| **[Heilung](/kategorie/info-heilung.md "Kategorie:Info/Heilung"):** | [siehe Besonderheit](#Besonderheit) |

## Fundort

Durch den den Komposthaufen im alten Stadtpark von [Terqa](/terqa.md "Terqa").

## Besonderheit

-   Der eigene Name wird zu _Modermonster_.
-   Der Zustand hält an, bis man sich wäscht oder mit dem [Spritzgewehr](/spritzgewehr.md "Spritzgewehr") nass gespritzt wird.
-   Die Bewegungsmeldung ändert sich, man geht nicht mehr, man _platscht_.

## Gefährlichkeit

-   Startmeldung:

Du durchsuchst den Komposthaufen. IGITT!!!

-   Endmeldung:

Endlich bist du kein Modermonster mehr!

* * *


## Kenndaten

- Kategorie: Zustand
- Typ: Sonstige
- Gegend: Vaniorh
- Wirkung: neutral
- Heilung: siehe Besonderheit

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Modermonster)
