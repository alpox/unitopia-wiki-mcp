---
type: Wiki Article
title: Ameise/Terqa
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Ameise/Terqa"
tags: [NPC, NPC/Vaniorh, NPC/Vaniorh/pseudo, NPC/pseudo, Rasse, Rasse/Insekt, Tätigkeit, Tätigkeit/Bankier]
timestamp: 2018-11-07T18:47:16Z
revid: 197794
namespace: 0
contenthash: 76377757e74b67effeeeabd0853d3a2c12b41f033a6c949c566c6e7901fa826b
---

## Aussehen

Eine Ameise mit kessen Fuehlern und einem etwas zu cleveren Laecheln.

## Ausrüstung

Keine.

## Heimat

Auf dem Ameisenhügel der [Ameisenbank](/ameisenbank.md "Ameisenbank") von [Terqa](/terqa.md "Terqa").

* * *


## Kenndaten

- Typ: pseudo
- Gegend: Vaniorh
- Rasse: Insekt
- Tätigkeit: Bankier

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Ameise/Terqa)
