---
type: Wiki Article
title: Draht
description: Auf der Müllhalde beim Klippenturm auf Cyprus.
resource: "http://unitopia.intelligense.de/wiki/Draht"
tags: [Fundort, Gegenstand, Gegenstand/Kokosinseln, Gegenstand/Kokosinseln/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Metall]
timestamp: 2024-09-16T12:12:30Z
revid: 238642
namespace: 0
contenthash: 00e148408b0717d2777ad09256b79fd256e12ee1954643af241ca1cdcd70fde7
---

## Aussehen

Das ist ein kleines Stueck verbogenen Drahtes. Er ist schon etwas rostig,
sieht ansonsten aber noch halbwegs stabil aus.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Auf der Müllhalde beim [Klippenturm](/klippenturm.md "Klippenturm") auf [Cyprus](/cyprus.md "Cyprus").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Kokosinseln
- Material: Metall
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Draht)
