---
type: Wiki Article
title: Brann
description: In der riesigen Kaverne unter dem Felsenkloster Laksos auf dem Klosterberg (Luntayberg) der Drachenberge.
resource: "http://unitopia.intelligense.de/wiki/Brann"
tags: [NPC, NPC/Midgard, NPC/Midgard/defensiv, NPC/defensiv, Rasse, Rasse/Zwerg]
timestamp: 2019-11-28T08:56:05Z
revid: 262798
namespace: 0
contenthash: da42e3bf22d1a16b564b43342412e5cf2364fccb9d45002de3f6700364e3870f
---

## Aussehen

Du siehst einen stattlichen Ausgraeber und Erkunder vor dir, dem es nur an
Koerpergroesse fehlt, um alles andere im Raum zu ueberstrahlen. Er traegt
rein praxisorienterte Kleidung und ist fuer Expeditionen bestens
ausgeruestet. Ansonsten ist an ihm nur noch sein echt zwergischer Bart
auffaellig.

## Ausrüstung

-   Ein [Rucksack](/rucksack-magyra.md "Rucksack/Magyra").
-   Ein [Zwergenkettenhemd](/zwergenkettenhemd-laksos.md "Zwergenkettenhemd/Laksos").
-   Ein [Zwergenkurzschwert](/zwergenkurzschwert.md "Zwergenkurzschwert").
-   Ein [Seil](/seil-magyra.md "Seil/Magyra").
-   Eine [Schaufel](/schaufel-magyra.md "Schaufel/Magyra").
-   Eine [Rezeptur](/rezeptur.md "Rezeptur").
-   Ein [zerfleddertes Traumfänger-Einleitungsbuch für Mystiker](/traumfänger-einleitungsbuch.md "Traumfänger-Einleitungsbuch")

## Heimat

In der riesigen Kaverne unter dem [Felsenkloster Laksos](/felsenkloster-laksos.md "Felsenkloster Laksos") auf dem [Klosterberg (Luntayberg)](/klosterberg.md "Klosterberg") der [Drachenberge](/drachenberge.md "Drachenberge").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Midgard
- Rasse: Zwerg

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Brann)
