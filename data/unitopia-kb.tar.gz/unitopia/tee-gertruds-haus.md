---
type: Wiki Article
title: Tee/Gertruds Haus
description: Auf dem Herd der Küche in Gertruds Haus in Borsippa.
resource: "http://unitopia.intelligense.de/wiki/Tee/Gertruds_Haus"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/durstlöschend, Nahrung, Nahrung/Getränk, Nahrung/Vaniorh, Nahrung/Vaniorh/Getränk]
timestamp: 2024-08-29T15:19:03Z
revid: 247647
namespace: 0
contenthash: 74ed5fa6e557f5319c580f564652cd270873ab41949921a299273d2bd12c8d06
---

## Aussehen

Eine Tasse mit wohlriechendem Fruchttee.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend") |

## Fundort

Auf dem Herd der Küche in [Gertruds Haus](/gertruds-haus.md "Gertruds Haus") in [Borsippa](/borsippa.md "Borsippa").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Getränk
- Gegend: Vaniorh
- Gewicht: 1
- Wirkung: durstlöschend

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Tee/Gertruds_Haus)
