---
type: Wiki Article
title: Vogel/Hochelfenstatt
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Vogel/Hochelfenstatt"
tags: [NPC, NPC/Midgard, NPC/Midgard/defensiv, NPC/defensiv, Rasse, Rasse/Vogel]
timestamp: 2018-11-07T18:46:15Z
revid: 217193
namespace: 0
contenthash: 50c1bcd7e85b7ded204fdbde8085d604f39d26e68a35aaa5075690beab954fc0
---

## Aussehen

Ein bunter kleiner Vogel, der froehlich zwitschert.

## Ausrüstung

Keine.

## Heimat

Im Garten von [Hochelfenstatt](/hochelfenstatt.md "Hochelfenstatt").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Midgard
- Rasse: Vogel

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Vogel/Hochelfenstatt)
