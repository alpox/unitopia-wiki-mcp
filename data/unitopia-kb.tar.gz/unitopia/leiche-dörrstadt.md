---
type: Wiki Article
title: Leiche/Dörrstadt
description: Auf einem Felsen mitten in der Lava der Minen unter Dörrstadt.
resource: "http://unitopia.intelligense.de/wiki/Leiche/Dörrstadt"
tags: [Gegenstand, Gegenstand/Dörrland, Gegenstand/Dörrland/Sonstige, Gegenstand/Sonstige]
timestamp: 2018-11-07T18:48:26Z
revid: 255938
namespace: 0
contenthash: 653966613593289bf4236271a533fbd88f355b777a648ab36df264a98930f25f
---

## Aussehen

Eine furchtbar verkohlte und entstellte Leiche. Dieser arme Tropf hat wohl
zu lange in der Lava gebadet und ist deshalb so verendet!?

## Ausrüstung

-   Ein [alter, rostiger Schlüssel](/schlüssel-leiche-dörrstadt.md "Schlüssel/Leiche/Dörrstadt").
-   Ein [ziemlich schartiges Kurzschwert](/kurzschwert-leiche-dörrstadt.md "Kurzschwert/Leiche/Dörrstadt").
-   Ein [schweres Kettenhemd](/kettenhemd-dörrstadt.md "Kettenhemd/Dörrstadt").

## Fundort

Auf einem Felsen mitten in der Lava der [Minen](/dörrstadt.md "Dörrstadt") unter [Dörrstadt](/dörrstadt.md "Dörrstadt").

* * *


## Kenndaten

- Typ: Sonstige
- Gegend: Dörrland

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Leiche/Dörrstadt)
