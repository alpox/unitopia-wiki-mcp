---
type: Wiki Article
title: Feenkettenhemd
description: Zu kaufen bei Metira bei der Schmiedin in Ameros auf Amerindia.
resource: "http://unitopia.intelligense.de/wiki/Feenkettenhemd"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Metall, Info/Rüstungsstärke, Info/Rüstungsstärke/gut, Info/Rüstungszustand, Info/Rüstungszustand/extrem solide, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Rüstung, Rüstung/Brust, Rüstung/Ebenen, Rüstung/Ebenen/Brust]
timestamp: 2024-04-23T19:27:45Z
revid: 227082
namespace: 0
contenthash: 8592b89665e4b99f42369b12ed692a4d4aec9b599bf739cf116b8ce8ab5f12ec
---

## Aussehen

Dieses winzige Kettenhemd ist nur fuer Feen geeignet.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [4 (gut)](/kategorie/info-rüstungsstärke-gut.md "Kategorie:Info/Rüstungsstärke/gut") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [9 (extrem solide)](/kategorie/info-rüstungszustand-extrem-solide.md "Kategorie:Info/Rüstungszustand/extrem solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Metira](/metira.md "Metira") bei der Schmiedin in [Ameros](/ameros.md "Ameros") auf [Amerindia](/amerindia.md "Amerindia").

* * *


## Kenndaten

- Kategorie: Rüstung
- Typ: Brust
- Gegend: Ebenen
- Material: Metall
- Temperaturschutz: wärmt etwas
- Rüstungsstärke: gut
- Rüstungszustand: extrem solide
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Feenkettenhemd)
