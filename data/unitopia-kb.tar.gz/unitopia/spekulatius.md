---
type: Wiki Article
title: Spekulatius
description: In einem Tütchen im Schreibtisch und im Küchenschrank in der Hütte des Weihnachtsorks auf Veldergautland.
resource: "http://unitopia.intelligense.de/wiki/Spekulatius"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Nordische Inseln, Nahrung/Nordische Inseln/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:15:41Z
revid: 249578
namespace: 0
contenthash: 171a1f4405cbd99d788a7de774fbbb06a3464ab6b4f42ee5d19f61e3577d04ac
---

## Aussehen

Ein trockener, knuspriger, flacher Keks. Er ist knusprig und mit feinen
Mandelplaettchen verziert ist. Er duftet intensiv nach Zimt, Muskat und
Kardamom.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

In einem [Tütchen](/tütchen.md "Tütchen") im Schreibtisch und im Küchenschrank in der [Hütte](/weihnachtshütte.md "Weihnachtshütte") des [Weihnachtsorks](/weihnachtsork.md "Weihnachtsork") auf [Veldergautland](/veldergautland.md "Veldergautland").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Nordische Inseln
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Spekulatius)
