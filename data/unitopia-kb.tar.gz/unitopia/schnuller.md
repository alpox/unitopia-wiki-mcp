---
type: Wiki Article
title: Schnuller
description: Vom Sandmännchen auf seiner Wolke westlich vom Schneewittchental.
resource: "http://unitopia.intelligense.de/wiki/Schnuller"
tags: [Gegenstand, Gegenstand/Autoloader, Gegenstand/Märchenland, Gegenstand/Märchenland/Autoloader, Hidden, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Unbekannt, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2024-03-02T19:17:16Z
revid: 262051
namespace: 0
contenthash: ca2f19b24e4b25f3770b84039901d891b0943b144e5dc6c705e86fd107998ce3
---

## Aussehen

Ein wunderschoener, farbiger, kleiner, niedlicher [Schnuller](/hilfe/schnuller.md "Hilfe:Schnuller"). Er ist
schnullerfoermig und hat die Farbe lila. Dieser Schnuller symbolisiert in
der harten, grausamen Mud-Welt eine Beziehung zwischen Spielern, die es
nicht mehr oft gibt - er steht fuer die wahre, echte Freundschaft.

<X> von <X> Schnullerfreundschaften: 
_Schnullerfreunde in alphabetischer Reihenfolge_

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Unbekannt](/kategorie/info-material-unbekannt.md "Kategorie:Info/Material/Unbekannt") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Vom [Sandmännchen](/sandmännchen.md "Sandmännchen") auf seiner [Wolke](/sandmännchenwolke.md "Sandmännchenwolke") westlich vom [Schneewittchental](/schneewittchental.md "Schneewittchental").

## Besonderheit

Zusätzliches Aussehen beim Betrachten einer Person:

| -   **Mann:** | Seine Schnullerfreunde sind: <Freund 1>, <Freund 2>, ... <Freund n> _oder_ Er hat viel zuviele Schnullerfreunde. |
| --- | --- |
| -   **Frau:** | Ihre Schnullerfreunde sind: <Freund 1>, <Freund 2>, ... <Freund n> _oder_ Sie hat viel zuviele Schnullerfreunde. |
| -   **Etwas:** | Seine Schnullerfreunde sind: <Freund 1>, <Freund 2>, ... <Freund n> _oder_ Es hat viel zuviele Schnullerfreunde. |

## Funktion

Ab einem Alter von 106 Tagen erhält man alle 10 Tage Spielalter einen weiteren Schnullerplatz.

In Deinen [Schnuller](/schnuller.md "Schnuller") hast Du Dich gleich von Anfang an verliebt. 
An ihm kannst Du naemlich nuckeln,
    \[nuckle schnuller\],
Du kannst ihm eine neue Farbe geben,
    \[farbe schnuller <farbe>\] - ohne <farbe> zeigt er Dir die aktuelle
Farbe an
Du kannst ihm eine neue Form geben,
    \[form schnuller <form>\] - ohne <form> zeigt er Dir die aktuelle Form an
Du kannst ihn in die Hosentasche stecken - dann sieht ihn niemand mehr,
    \[verstecke schnuller\]
Du kannst ihn aus der Hosentasche rausholen und umhaengen,
    \[rausholen schnuller\]
Du kannst immer ueberpruefen, wo Deine Freunde sind
    \[freunde\]
Du kannst feststellen wann du mit wem geschnullert hast
    \[freunde info\]
Du kannst auch feststellen wann sie ungefaehr das letzte mal anwesend waren
    \[freunde wann\]
Sortieren kannst du die Auflistung mit einem zusaetzlichen Parameter: 
     \[freunde info|wann name+\] sortiert den Name aufsteigend
     \[freunde info|wann name-\] sortiert den Name absteigend
     \[freunde info|wann zeit+\] sortiert die Zeit aufsteigend
     \[freunde info|wann zeit-\] sortiert die Zeit absteigend 
Du kannst immer mit Deinen Freunden sprechen.
    \[hallo <freund> <nachricht>\]
       Wenn fuer <freund> "freunde" eingegeben wird, hoeren Dich alle
       Freunde gleichzeitig. Wenn die <nachricht> weggelassen wird,
       begruesst Du einfach Deine Freunde.
       Beispiele:  hallo freunde
                   hallo freunde Wie geht es Euch?
                   hallo balou Wie geht es Dir?
                   hallo balou
                   hallo balou,wluut Hallo Ihr
und Du kannst zu den Freunden deiner Freunde sprechen
    \[rfv <freund> <nachricht>\]
       Du sprichst damit zu allen Freunden deines Freundes <freund>, die
       die "rede zu den Freunden von" - Option ihres Schnullers ebenfalls
       verwenden wollen. Hierbei fallen die gleichen Zauberpunktekosten,
       wie beim Reden zu allen Leuten gleichzeitig an. 
     \[rfv aus|an\] 
       Du kannst die rfv-Funktion Deines Schnullers an und abschalten.
       Wenn Du die Funktion abgeschaltet hast, erhaeltst Du keine Meldungen
       von Freunden Deiner Freunde mehr, Deine Freunde koennen nicht mehr
       zu Deinen anderen Freunden sprechen und Du kannst selbst natuerlich
       auch nicht mehr zu den Freunden Deiner Freunde sprechen.

Ausserdem kannst Du mit \[verachte <freund>\] eine Freundschaft beenden,
oder mit \[wirf schnuller weg\] Deinen Schnuller ganz wegwerfen. 

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Autoloader
- Gegend: Märchenland
- Material: Unbekannt
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein
- Mann: Seine Schnullerfreunde sind: , , ... oder Er hat viel zuviele Schnullerfreunde.
- Frau: Ihre Schnullerfreunde sind: , , ... oder Sie hat viel zuviele Schnullerfreunde.
- Etwas: Seine Schnullerfreunde sind: , , ... oder Es hat viel zuviele Schnullerfreunde.

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schnuller)
