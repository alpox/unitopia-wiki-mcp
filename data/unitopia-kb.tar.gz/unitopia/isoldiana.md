---
type: Wiki Article
title: Isoldiana
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Isoldiana"
tags: [NPC, NPC/Ebenen, NPC/Ebenen/defensiv, NPC/defensiv, Rasse, Rasse/Elf, Tätigkeit, Tätigkeit/Questgeber]
timestamp: 2018-11-07T18:28:20Z
revid: 212854
namespace: 0
contenthash: 501d043f60339a28f9ba33b984b2a5e3e1a9e7c5d0b49cabd1c9645f6c0d8c0e
---

## Aussehen

Eine schon recht alte Elfin, mit langem, krausem, weissem Haar. Sie sitzt
neben dem Bett und beobachtet aengstlich den kranken Grossvater.

## Ausrüstung

Keine.

## Heimat

In ihrer Hütte im [Elfendorf](/elfendorf.md "Elfendorf") auf [Drachenland](/drachenland.md "Drachenland").

## Besonderheit

-   Wenn man ihr die richtigen [Drachenland-Kräuter](/kategorie/nahrung-ebenen-pflanze.md "Kategorie:Nahrung/Ebenen/Pflanze") bringt, gibt sie einem ein [heilendes Brot](/brot-isoldiana.md "Brot/Isoldiana").
-   Sie ist die Frau von [Illios](/illios.md "Illios"), Mutter von [Inxenia](/inxenia.md "Inxenia") und Großmutter von [Fraidil](/fraidil.md "Fraidil").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Ebenen
- Rasse: Elf
- Tätigkeit: Questgeber

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Isoldiana)
