---
type: Wiki Article
title: Oscar/Tierpark
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Oscar/Tierpark"
tags: [NPC, NPC/Märchenland, NPC/Märchenland/defensiv, NPC/defensiv, Rasse, Rasse/Insekt]
timestamp: 2018-11-07T18:28:22Z
revid: 244466
namespace: 0
contenthash: df71d3b2467563374f3e1182e89faaed7090160ba55d0a1d3d1da38aa967e83e
---

## Aussehen

Das ist einer dieser laestigen Plagegeister, die immer um einen
herumschwirren und zu ueberhaupt nichts nuetze scheinen.
Momentan schwirrt er um dich herum.

## Ausrüstung

Keine.

## Heimat

Im [Tierpark](/tierpark.md "Tierpark") von [Koboldingen](/koboldingen.md "Koboldingen").

## Besonderheit

Er fliegt jedem hartnäckig hinterher der vorbeikommt.

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Märchenland
- Rasse: Insekt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Oscar/Tierpark)
