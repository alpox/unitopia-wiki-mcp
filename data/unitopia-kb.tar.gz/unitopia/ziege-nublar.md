---
type: Wiki Article
title: Ziege/Nublar
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Ziege/Nublar"
tags: [NPC, NPC/Kokosinseln, NPC/Kokosinseln/pseudo, NPC/pseudo, Rasse, Rasse/Säugetier]
timestamp: 2023-03-02T12:02:49Z
revid: 267326
namespace: 0
contenthash: 0c794f2c36439c33670ca761613ee2b0bd80b83e108b3434ca82a2022d4d60be
---

## Aussehen

Die Ziege kaut gleichgueltig an ein paar Grashalmen und beachtet Dich nicht
weiter; sie ist offensichtlich unverletzt - Ein Millionen Jahre alter
Jagdinstinkt laesst sich eben nicht so einfach ausschalten.

## Ausrüstung

Keine.

## Heimat

Am Nord-Ost-Ende im Dinopark auf [Isla Nublar](/nublar.md "Nublar").

* * *


## Kenndaten

- Typ: pseudo
- Gegend: Kokosinseln
- Rasse: Säugetier

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Ziege/Nublar)
