---
type: Wiki Article
title: Druidenelixier/Wund
description: Von einem Mitglied der Druidengilde.
resource: "http://unitopia.intelligense.de/wiki/Druidenelixier/Wund"
tags: [Fundort, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Nahrung, Nahrung/Getränk, Nahrung/Kokosinseln, Nahrung/Kokosinseln/Getränk, Subpages, Subpages/Content]
timestamp: 2024-09-16T12:13:08Z
revid: 210417
namespace: 0
contenthash: 3b5f9b6ca96ff02154fb09005b1ca8cf0ac6dfeab22b060eacf86bc170711bb4
---

< [Druidengilde](/druidengilde.md "Druidengilde") < [Elixiere](/druidengilde.md "Druidengilde")

## Aussehen

In der Flasche befindet sich eine blubbernde, braungraue Fluessigkeit.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [siehe Funktion](#Funktion) |

## Fundort

Von einem Mitglied der [Druidengilde](/druidengilde.md "Druidengilde").

## Funktion

Gießt man es über die Wunden einer <Person>, werden die Wunden verarztet.

## Besonderheit

| Geruch | Riecht nach mehr! |
| --- | --- |
| Tasten | Du tauchst Deinen Finger in die Flasche und es fühlt sich maskulin an. |
| Meldung | Du gießt ein Druidenelixier über <Person>. |

* * *


## Kenndaten

- Typ: Content
- Kategorie: Nahrung
- Gegend: Kokosinseln
- Gewicht: 1
- Wirkung: siehe Funktion

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Druidenelixier/Wund)
