---
type: Wiki Article
title: Duftkerze
description: Zu kaufen bei Herrn Holle in einem verwinkelten kleinen Laden in Koboldingen.
resource: "http://unitopia.intelligense.de/wiki/Duftkerze"
tags: [Fundort/Kauf, Gegenstand, Gegenstand/Märchenland, Gegenstand/Märchenland/Sonstige, Gegenstand/Sonstige, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Licht, Info/Licht/leuchtet, Info/Material, Info/Material/Wachs]
timestamp: 2024-04-23T19:28:32Z
revid: 238648
namespace: 0
contenthash: 2f9026b01822e464d39e0be69ac7e47f4e8dd12c59456fdedad1562e47912400
---

## Aussehen

Eine spezialgemixte <Pflanze>kerze. Du kannst durch das halbdurchsichtige
Wachs darin eingeschmolzen noch ganze Stueckchen von einer <Pflanze> erkennen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Wachs](/kategorie/info-material-wachs.md "Kategorie:Info/Material/Wachs") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel"), [+1 (leuchtet normal)](/kategorie/info-licht-leuchtet.md "Kategorie:Info/Licht/leuchtet") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Herrn Holle](/holle.md "Holle") in einem [verwinkelten kleinen Laden](/koboldingen.md "Koboldingen") in [Koboldingen](/koboldingen.md "Koboldingen").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Märchenland
- Material: Wachs
- Gewicht: 1
- Licht: 0/+1
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Duftkerze)
