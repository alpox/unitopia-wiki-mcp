---
type: Wiki Article
title: Dämonenwildeber
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Dämonenwildeber"
tags: [Braten, Braten/Haut, Braten/Jagen, Braten/Stück, Fundort, NPC, NPC/Kokosinseln, NPC/Kokosinseln/aggressiv, NPC/aggressiv, Rasse, Rasse/Dämon, Rasse/Säugetier, Rasse/multi]
timestamp: 2024-09-16T12:10:56Z
revid: 223198
namespace: 0
contenthash: 75e3d026bde0a01b81b419cd6660c6a3252ad02d5d9b60acc6758dfa8d6bc7ab
---

## Aussehen

```
Der Daemonenwildeber erinnert dich an deine schlimmsten Alptraeume. Ein
erschreckendes Monstrum, das dich aus blutunterlaufenen Augen ueber seinem
Ruessel anstarrt und dich sicher gleich auf die Hauer nehmen will.
```

## Ausrüstung

Keine.

## Heimat

Im [verfluchten Wald](/verfluchter-wald.md "Verfluchter Wald") auf [Cyprus](/cyprus.md "Cyprus").

## Besonderheit

Nach dem Töten ist der Dämonenwildeber [häut-](/fell-verfluchter-wald2.md "Fell/Verfluchter Wald2") und [bratbar](/braten-magyra.md "Braten/Magyra"). Der Braten lässt sich in mehrere handliche [Braten](/bratenscheibe.md "Bratenscheibe")[scheiben](/braten-scheibe.md "Braten/Scheibe"), [Braten](/bratenstück.md "Bratenstück")[stücke](/braten-stück.md "Braten/Stück") oder [Braten](/bratenteil.md "Bratenteil")[teile](/braten-teil.md "Braten/Teil") zerlegen.

## Kenndaten

- Typ: aggressiv
- Gegend: Kokosinseln
- Rasse: Dämon/Säugetier
- Artikel: der
- Haut: Fell/Verfluchter Wald2
- Stück: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Dämonenwildeber)
