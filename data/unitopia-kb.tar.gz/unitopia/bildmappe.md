---
type: Wiki Article
title: Bildmappe
description: Man kann bei Vincent Farben als auch Leinwände für die Bildmappe kaufen.
resource: "http://unitopia.intelligense.de/wiki/Bildmappe"
tags: [Behälter, Behälter/Große, Behälter/Midgard, Behälter/Midgard/Große, Gegenstand, Gegenstand/Autoloader, Gegenstand/Midgard, Gegenstand/Midgard/Autoloader, Info, Info/Fasst, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Unbekannt, Info/Volumen, Info/Volumen/10]
timestamp: 2026-03-18T18:21:24Z
revid: 259903
namespace: 0
contenthash: f9eb62bbc6ea6c04f836c6968fb71c9696a92e5a30139748dc48118eebc5a557
---

## Aussehen

In die Bildmappe kannst Du Oelbilder legen, die du oder jemand anderes
gemalt hat. Hinweise erhaeltst Du mit '[hilfe bildmappe](/hilfe/bildmappe.md "Hilfe:Bildmappe")'.
Sie enthaelt einen Satz verschiedener Pinsel in einer Innentasche. Die
beiliegenden Oelfarben reichen noch zum Malen.
        Sie enthaelt <X> Leinwaende und <X> Oelbilder:

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Unbekannt](/kategorie/info-material-unbekannt.md "Kategorie:Info/Material/Unbekannt") |
| --- | --- |
| **[Fasst](/kategorie/info-fasst.md "Kategorie:Info/Fasst"):** | [Leinwand](/leinwand.md "Leinwand") |
| **[Volumen](/kategorie/info-volumen.md "Kategorie:Info/Volumen"):** | 10 |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Als [Belohnung](/vincent-der-brotlose-künstler.md "Vincent der brotlose Künstler") von [Vincent](/vincent.md "Vincent") in seinem vollgestopften Lagerschuppen in [Londar](/londar.md "Londar").
-   Mappe von [Ottodix](/ottodix.md "Ottodix") bei der Westbrücke von [Lutetia](/lutetia.md "Lutetia").
-   Mappe von [Vincent](/vincent.md "Vincent") in seinem Schuppen in [Londar](/londar.md "Londar").

## Besonderheit

Man kann bei [Vincent](/vincent.md "Vincent") [Farben](/vincent.md "Vincent") als auch [Leinwände](/vincent.md "Vincent") für die Bildmappe kaufen.

## Funktion

[Zur Bildmappe](/bildmappe.md "Bildmappe"):
^^^^^^^^^^^^^^^
In deine Bildmappe kannst du Bilder von wichtigen Ereignissen aus deinem 
Mudleben legen. Hier sind sie vor Armageddon sicher aufbewahrt. Hast du 
vor, etwas zu malen, lege eine weisse Leinwand hinein. 

Die enthaltenen Bilder kannst du jeder Zeit herausnehmen. Du solltest 
sie jedoch wieder hineinlegen, bevor du dich ausloggst, da sie ausserhalb
nicht geschuetzt sind.

Mit deiner Bildmappe, den beiliegenden Pinseln, (vollen) Oelfarben, und einer 
weissen Leinwand ist es dir moeglich, Bilder von Gegenden oder Spielern
zu malen.

Die Syntax lautet:
        male Oelbild                      >>  um den Raum/die Gegend zu malen
        male Oelbild von <Raumdetail>     >>  um ein Detail zu malen
        male Oelbild von <Lebewesen>      >>  um ein Lebewesen zu malen

Unterbrechen kannst du das Malen mit:
        stoppe malen / stop malen

Willst du die Mappe loswerden, kannst du dies tun mit:
        werfe Bildmappe weg

Bedenke dabei, dass du alle Bilder, die immer noch drin sind mit wegwirfst!

[Zu den Oelbildern](/leinwand.md "Leinwand"):
^^^^^^^^^^^^^^^^^^^
Die Oelbilder haben eine Beschriftung am Bildrand und eine Signatur des
Malers und dem Datum auf der Rueckseite.

Die Beschriftung deines Bildes kannst Du aendern mit:
        beschrifte Oelbild <Kurzbeschreibung>

Dein Oelbild kannst du in einem Innenraum deines Schiffes aufhaengen. Zu
beachten dabei ist, dass es als Raumdetail ein integraler Bestandteil des 
Schiffes wird ...also geschuetzt gegen Armageddon ist.

Die Syntax hierfuer lautet:
        haenge Oelbild auf/an \[Wand\]

Entfernen kann man aufgehaengte Bilder mit:
        entferne Oelbild \[von Wand\]
        
Achtung: Aus technischen Gruenden kann man vorhandene Oelbilder zwar ohne 
Mappe aufhaengen, entfernen geht allerdings nur mit einer Bildmappe.

VIEL SPASS BEIM MALEN!  

* * *


## Kenndaten

- Typ: Autoloader
- Gegend: Midgard
- Kategorie: Behälter
- Material: Unbekannt
- Fasst: Leinwand
- Volumen: 10
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Bildmappe)
