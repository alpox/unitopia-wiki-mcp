---
type: Wiki Article
title: Mistkäfer
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Mistkäfer"
tags: [NPC, NPC/Vaniorh, NPC/Vaniorh/aggressiv, NPC/aggressiv, Rasse, Rasse/Insekt]
timestamp: 2018-11-07T18:31:04Z
revid: 215247
namespace: 0
contenthash: 952733151be4ea6eac8d0488397fc73cdd934561eab7163d25c6a8539db30537
---

## Aussehen

Ein riesiger Mistkaefer hat sich hier eingenistet. Sein blaeulich
glaenzender Chitinpanzer scheint ein sehr guter Schutz fuer ihn zu sein.
Nimm Dich in Acht vor seinen wild fuchtelnden Gliedmassen!

## Ausrüstung

Keine.

## Heimat

In einem dunklen Gang in der [Kanalisation](/borsippa.md "Borsippa") unter [Borsippa](/borsippa.md "Borsippa").

* * *


## Kenndaten

- Typ: aggressiv
- Gegend: Vaniorh
- Rasse: Insekt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Mistkäfer)
