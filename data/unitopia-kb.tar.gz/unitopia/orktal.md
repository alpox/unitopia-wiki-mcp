---
type: Wiki Article
title: Orktal
description: ""
resource: "http://unitopia.intelligense.de/wiki/Orktal"
tags: []
timestamp: 2025-06-10T19:16:52Z
revid: 158443
namespace: 0
contenthash: 23c2972a0bda33a1709357184651bc715747c81451f4e67546f149640f555af5
---

1.  WEITERLEITUNG [Handelsweg/Borsippa#Orktal](/handelsweg-borsippa.md "Handelsweg/Borsippa")

* * *

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Orktal)
