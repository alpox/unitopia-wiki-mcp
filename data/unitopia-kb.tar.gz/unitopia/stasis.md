---
type: Wiki Article
title: Stasis
description: Von einem Mitglied des Hexenvolkes.
resource: "http://unitopia.intelligense.de/wiki/Stasis"
tags: [Fundort, Info, Info/Heilung, Info/Wirkung, Info/Wirkung/Zustand, Info/Wirkung/Zustand/neutral, Zustand, Zustand/Fluch, Zustand/Nordische Inseln, Zustand/Nordische Inseln/Fluch]
timestamp: 2024-09-16T12:10:33Z
revid: 229271
namespace: 0
contenthash: b412d64e19bd8cf4bec1d98ff37c6f4f5e6584e72dee9938795242fd6479a122
---

## Aussehen

_Keines._

## Informationen

| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [neutral](/kategorie/info-wirkung-zustand-neutral.md "Kategorie:Info/Wirkung/Zustand/neutral") |
| --- | --- |
| **[Heilung](/kategorie/info-heilung.md "Kategorie:Info/Heilung"):** | automatisch |

## Fundort

Von einem Mitglied des [Hexenvolkes](/hexenvolk.md "Hexenvolk").

## Besonderheit

-   Versucht man, während der Stasis etwas zu tun, kommt die Meldung:

Das geht nicht - Du bist in Stasis!

-   Während man in Stasis ist, sind die [AP](/ap.md "AP")[![Ausdauerpunkte](/images/b/b4/AP.gif)](/ap.md "Ausdauerpunkte") und [ZP](/zp.md "ZP")[![Zauberpunkte](/images/4/4c/ZP.gif)](/zp.md "Zauberpunkte") auf 0 gesetzt.

## Gefährlichkeit

-   Hält ca. 30 Sekunden an.
-   Startmeldung:

<Hexe> verdreht ihre giftgruenen Augen.
<Hexe> reisst ihre giftgruenen Augen weit auf.
<Hexe> wirft einen ziemlich ueblen Blick auf Dich.
Du kannst Dich kaum noch bewegen.
Du erstarrst vor Schreck!

-   Endmeldung:

Du erwachst aus der Stasis.

* * *


## Kenndaten

- Kategorie: Zustand
- Typ: Fluch
- Gegend: Nordische Inseln
- Wirkung: neutral
- Heilung: automatisch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Stasis)
