---
type: Wiki Article
title: Pergament/Leiche/Althequinos2
description: Bei der Leiche in einem schwarzen Felsen im verfluchten Wald auf Cyprus.
resource: "http://unitopia.intelligense.de/wiki/Pergament/Leiche/Althequinos2"
tags: [Fundort, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Papier, Info/Schwimmt, Schriften, Schriften/Kokosinseln, Schriften/Kokosinseln/Sonstige, Schriften/Sonstige]
timestamp: 2024-09-16T12:12:30Z
revid: 240037
namespace: 0
contenthash: b191ecea273b162e465b93e24d9005d725313be30c9cec2249457ece46950fca
---

## Aussehen

Das Pergament sieht etwas zerknittert aus. Es steht etwas darauf
geschrieben.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Papier](/kategorie/info-material-papier.md "Kategorie:Info/Material/Papier") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Bei der [Leiche](/leiche-althequinos.md "Leiche/Althequinos") in einem schwarzen Felsen im [verfluchten Wald](/verfluchter-wald.md "Verfluchter Wald") auf [Cyprus](/cyprus.md "Cyprus").

## Inhalt

Forschungsbericht Nr. 84 von Professor Althequinos

## Faksimile

Forschungsbericht Nr. 84.

Nachdem ich einige der guten Wesen untersucht habe, habe
ich festgestellt, dass jedes ein Bruchstueck einer.
verdorbenen Seele in sich traegt. Damit habe ich die
fehlende Verbindung zu den Monstern im Wald gefunden.
Diese Wesen des Lichtes halten durch ihre Existenz das.
Boese im Wald am Leben.
Das Zentrum des Boesen schein eine Art Altar zu sein.
Als ich dort ein Messer ablegte, sowie einige verdorbene
Seelenbruchstuecke, wurde dieses Messer verdorben.
Es schien nun etwas Boeses in dem Messer zu sein, ich
habe es besser entsorgt.
Meine Bauchverletzung macht mir immernoch Probleme. Die
Blutung hat stark zugenommen. Ich haette nicht versuchen
sollen, dieses Rhystophalex zu vernichten. Daher werde
ich meine Forschungen unterbrechen, bis ich wieder
vollkommen genesen bin.

gez. Professor Althequinos.

* * *


## Kenndaten

- Kategorie: Schriften
- Typ: Sonstige
- Gegend: Kokosinseln
- Material: Papier
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Pergament/Leiche/Althequinos2)
