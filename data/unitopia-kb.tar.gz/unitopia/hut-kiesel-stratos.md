---
type: Wiki Article
title: Hut/Kiesel/Stratos
description: ""
resource: "http://unitopia.intelligense.de/wiki/Hut/Kiesel/Stratos"
tags: [Fundort/Kauf, Hidden, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/3, Info/Material, Info/Material/Stein, Kleidung, Kleidung/Kokosinseln, Kleidung/Kokosinseln/Kopf, Kleidung/Kopf, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2024-04-23T19:27:56Z
revid: 261845
namespace: 0
contenthash: 9220ac3f88fe78d90d5d44baeba9f556586d245f18396dfcab8800e66389b142
---

## Aussehen

Dieser Hut wurde, so massiv wie er aussieht, wohl aus einem einzigen Stueck
Stein gemeisselt. Er ist fast ganz mit Moos ueberwachsen und wirkt so
nahezu komplett gruen. Im Hut wurde ein unauffaelliger Zettel angebracht.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Stein](/kategorie/info-material-stein.md "Kategorie:Info/Material/Stein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [3 (schon eher leicht)](/kategorie/info-gewicht-3.md "Kategorie:Info/Gewicht/3") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Zu kaufen bei [Kiesel](/kiesel-stratos.md "Kiesel/Stratos") im Laden 'Rock n Roll' auf [Stratos](/stratos.md "Stratos").
-   Kleidung von [Kiesel](/kiesel-stratos.md "Kiesel/Stratos") im Laden 'Rock n Roll' auf [Stratos](/stratos.md "Stratos").

## Besonderheit

-   Kann nur von [Golems](/metamorpher.md "Metamorpher"), [Riesen](/metamorpher.md "Metamorpher") und [Trollen](/metamorpher.md "Metamorpher") getragen werden.

-   Zusätzliches Aussehen beim Betrachten einer Person:

| -   **Mann:** | Er hat einen bemoosten Hut aufgesetzt. |
| --- | --- |
| -   **Frau:** | Sie hat einen bemoosten Hut aufgesetzt. |
| -   **Etwas:** | Es hat einen bemoosten Hut aufgesetzt. |

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Kopf
- Gegend: Kokosinseln
- Material: Stein
- Gewicht: 3
- Licht: 0
- Brennbar: nein
- Schwimmt: nein
- ul: ja
- Mann: Er hat einen bemoosten Hut aufgesetzt.
- Frau: Sie hat einen bemoosten Hut aufgesetzt.
- Etwas: Es hat einen bemoosten Hut aufgesetzt.

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Hut/Kiesel/Stratos)
