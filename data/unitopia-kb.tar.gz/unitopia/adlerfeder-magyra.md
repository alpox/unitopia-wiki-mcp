---
type: Wiki Article
title: Adlerfeder/Magyra
description: "Der Adlerfeder im Nest nördlich der Tadmorebene fehlt das Adjektiv:"
resource: "http://unitopia.intelligense.de/wiki/Adlerfeder/Magyra"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Bein, Info/Rüstungsstärke, Info/Rüstungsstärke/schwach, Info/Rüstungszustand, Info/Rüstungszustand/eher beständig, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Rüstung, Rüstung/Kopf, Rüstung/Midgard, Rüstung/Midgard/Kopf, Rüstung/Vaniorh, Rüstung/Vaniorh/Kopf]
timestamp: 2024-03-02T19:19:24Z
revid: 253882
namespace: 0
contenthash: 98b9b0068392031421e3f947c4a6669ed7093882c450923ea27d2618a617f482
---

## Aussehen

Eine sehr grosse Adlerfeder. Du wunderst Dich, welch gigantischer Adler das
gewesen sein muss, der diese Feder verloren hat. Sie sieht wunderschoen
aus.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Bein](/kategorie/info-material-bein.md "Kategorie:Info/Material/Bein") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [2 (schwach)](/kategorie/info-rüstungsstärke-schwach.md "Kategorie:Info/Rüstungsstärke/schwach") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [4 (eher beständig)](/kategorie/info-rüstungszustand-eher-beständig.md "Kategorie:Info/Rüstungszustand/eher beständig") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Im alten Tor von [Ambring](/ambring.md "Ambring").
-   In einer Schublade im Schreibtisch im Kontor im [Herrenhaus](/bruggstad.md "Bruggstad") von [Bruggstad](/bruggstad.md "Bruggstad").
-   In seinem großen Nest in [Elfenhaven](/elfenhaven.md "Elfenhaven").
-   Auf einer Wiese der [Nebelberge](/nebelberge.md "Nebelberge").
-   In seinem Adlernest auf der [Wetterfestung Sentinelle](/sentinelle.md "Sentinelle").
-   In einem riesigen Nest an der Felswand nördlich der [Tadmor-Ebene](/ebene-tadmor.md "Ebene/Tadmor").
-   Auf dem Hügel irgendwo in den [Wetterbergen](/wetterbergen.md "Wetterbergen").

## Besonderheit

Der Adlerfeder im Nest nördlich der [Tadmorebene](/ebene-tadmor.md "Ebene/Tadmor") **fehlt** das Adjektiv:

-   Eine Adlerfeder.

* * *


## Kenndaten

- Kategorie: Rüstung
- Typ: Kopf
- Gegend: Midgard/Vaniorh
- Material: Bein
- Temperaturschutz: wärmt etwas
- Rüstungsstärke: schwach
- Rüstungszustand: eher beständig
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Adlerfeder/Magyra)
