---
type: Wiki Article
title: Sojaburger
description: "Zu kaufen bei Valandil im Gasthaus 'Valandils Erker' auf der Wetterfestung Sentinelle."
resource: "http://unitopia.intelligense.de/wiki/Sojaburger"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, "Info/Wirkung/gibt 1-5 AP", "Info/Wirkung/gibt 1-5 ZP", Info/Wirkung/sättigt, Nahrung, Nahrung/Midgard, Nahrung/Midgard/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:17:03Z
revid: 249518
namespace: 0
contenthash: 32dbf8801236c3c68ee3f2407b2186e4f50bf47aaba11b5c3b0d0df142ae12c1
---

## Aussehen

Ein grosser, saftiger Sojaburger mit vielen Kraeutern - da lacht das Herz
eines jeden Vegetarier.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt"), gibt 5 ZP wenn AP voll |

## Fundort

Zu kaufen bei [Valandil](/valandil.md "Valandil") im Gasthaus 'Valandils Erker' auf der [Wetterfestung Sentinelle](/sentinelle.md "Sentinelle").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Midgard
- Gewicht: 1
- Wirkung: sättigt/gibt 5 ZP wenn AP voll

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Sojaburger)
