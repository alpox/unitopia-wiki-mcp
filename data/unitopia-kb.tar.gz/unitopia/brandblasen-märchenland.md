---
type: Wiki Article
title: Brandblasen/Märchenland
description: Durch den Herd in der Küche von Großmutters Haus im westlichen Märchenwald.
resource: "http://unitopia.intelligense.de/wiki/Brandblasen/Märchenland"
tags: [Info, Info/Heilung, Info/Heilung/Antidots, Info/Heilung/Heiler, Info/Heilung/Heilstab, Info/Heilung/Hexenvolk, Info/Wirkung, Info/Wirkung/Zustand, Info/Wirkung/Zustand/neutral, Zustand, Zustand/Märchenland, Zustand/Märchenland/Verletzung, Zustand/Verletzung]
timestamp: 2024-08-29T15:19:43Z
revid: 255409
namespace: 0
contenthash: bfb438f3260aeb7a2e779170e31eeb3e1f942e623edb93d38213e7f15d8e6821
---

## Aussehen

Er/Sie/Es hat Brandblasen an den Haenden.

## Informationen

| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [neutral](/kategorie/info-wirkung-zustand-neutral.md "Kategorie:Info/Wirkung/Zustand/neutral") |
| --- | --- |
| **[Heilung](/kategorie/info-heilung.md "Kategorie:Info/Heilung"):** | [Antidots](/druidengilde.md "Druidengilde"), [Heiler](/heiler.md "Heiler"), [Heilstab](/heilstab.md "Heilstab"), [Hexenvolk](/hexenvolk.md "Hexenvolk") |

## Fundort

Durch den Herd in der Küche von [Großmutters Haus](/großmutters-haus.md "Großmutters Haus") im [westlichen Märchenwald](/westlicher-märchenwald.md "Westlicher Märchenwald").

## Gefährlichkeit

-   Hält ca. 15 Minuten an.
-   Startmeldung:

Als du versuchst den Herd anzuzuenden, schlaegt dir eine Stichflamme
entgegen, die dir die Haende verbrennt.

-   Zwischenmeldungen:

Deine Haende schmerzen.

-   Endmeldung:

Deine Haende sind wieder verheilt.

* * *


## Kenndaten

- Kategorie: Zustand
- Typ: Verletzung
- Gegend: Märchenland
- Wirkung: neutral
- Heilung: Antidots/Heiler/Heilstab/Hexenvolk

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Brandblasen/Märchenland)
