---
type: Wiki Article
title: Spinne/Bruggstad
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Spinne/Bruggstad"
tags: [NPC, NPC/Midgard, NPC/Midgard/aggressiv, NPC/aggressiv, Rasse, Rasse/Spinnentier]
timestamp: 2018-11-07T18:48:02Z
revid: 215334
namespace: 0
contenthash: 65f202dac04251279b2eb081458be7375ac5fdefd45640e7e767c63c58a56792
---

## Aussehen

Ein besonders grosses Exemplar einer dir unbekannten Spinnenrasse mit
haarigem Koerper und besonders langen Beinen.

## Ausrüstung

Keine.

## Heimat

Im düsteren Keller der [Abenteurergilde](/abenteurergilde.md "Abenteurergilde") von [Bruggstad](/bruggstad.md "Bruggstad").

* * *


## Kenndaten

- Typ: aggressiv
- Gegend: Midgard
- Rasse: Spinnentier

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Spinne/Bruggstad)
