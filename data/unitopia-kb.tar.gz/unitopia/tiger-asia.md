---
type: Wiki Article
title: Tiger/Asia
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Tiger/Asia"
tags: [NPC, NPC/Ebenen, NPC/Ebenen/defensiv, NPC/defensiv, Rasse, Rasse/Säugetier]
timestamp: 2019-03-20T16:21:50Z
revid: 262206
namespace: 0
contenthash: 6c39db01bf964b15edd6a06291191fd8a84f1805f5cf62f6bd238acc2e1df3dd
---

## Aussehen

Ein kraeftiger Tiger mit gefaehrlichen Pranken und Maul.

## Ausrüstung

Keine.

## Heimat

Im Dschungel auf [Asia](/asia.md "Asia")

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Ebenen
- Rasse: Säugetier

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Tiger/Asia)
