---
type: Wiki Article
title: Bergkristall/Weissager
description: Beim Stufenaufstieg von Monakia in der Sehergilde.
resource: "http://unitopia.intelligense.de/wiki/Bergkristall/Weissager"
tags: [Gegenstand, Gegenstand/Autoloader, Gegenstand/Gallien, Gegenstand/Gallien/Autoloader, Info, Info/Gewicht, Info/Gewicht/0, "Info/Gewicht/0-9", Info/Material, Info/Material/Edelstein, Info/Wirkung, Info/Wirkung/besondere, Mineral, Mineral/Gallien, Mineral/Gallien/Kristall, Mineral/Kristall]
timestamp: 2024-08-29T15:13:41Z
revid: 224594
namespace: 0
contenthash: 9a74dd58032554af61b78d9d3fbb679eeea4030aad55b4636b638b7d2a18d288
---

## Aussehen

Der Bergkristall funkelt in einem warmen, freundlichen Rot vor sich hin.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Edelstein](/kategorie/info-material-edelstein.md "Kategorie:Info/Material/Edelstein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [0 (federleicht)](/kategorie/info-gewicht-0.md "Kategorie:Info/Gewicht/0") |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [Dunkelsicht](/dunkelsicht.md "Dunkelsicht") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Beim Stufenaufstieg von [Monakia](/monakia.md "Monakia") in der [Sehergilde](/sehergilde.md "Sehergilde").

## Funktion

Sämtliche [Fähigkeiten](/sehergilde.md "Sehergilde") der [Seher](/sehergilde.md "Sehergilde") erwirbt man durch den Kristall.

* * *


## Kenndaten

- Typ: Kristall
- Gegend: Gallien
- Kategorie: Gegenstand
- Material: Edelstein
- Gewicht: 0
- Wirkung: Dunkelsicht
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Bergkristall/Weissager)
