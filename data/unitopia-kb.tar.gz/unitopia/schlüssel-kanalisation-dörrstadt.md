---
type: Wiki Article
title: Schlüssel/Kanalisation/Dörrstadt
description: Am Haken in der Kammer in der Kanalisation von Dörrstadt.
resource: "http://unitopia.intelligense.de/wiki/Schlüssel/Kanalisation/Dörrstadt"
tags: [Gegenstand, Gegenstand/Dörrland, Gegenstand/Dörrland/Schlüssel, Gegenstand/Schlüssel, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Metall]
timestamp: 2024-03-02T19:21:45Z
revid: 256258
namespace: 0
contenthash: 33a2fd67f431f7d74d4af7a8d12e8d376350119f72bbdd6a781c0f794f2236dc
---

## Aussehen

Ein grosser, korrodierter Schluessel.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Am Haken in der Kammer in der [Kanalisation](/dörrstadt.md "Dörrstadt") von [Dörrstadt](/dörrstadt.md "Dörrstadt").

## Funktion

Für die Eisentür in der Kammer in der [Kanalisation](/dörrstadt.md "Dörrstadt").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Schlüssel
- Gegend: Dörrland
- Material: Metall
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schlüssel/Kanalisation/Dörrstadt)
