---
type: Wiki Article
title: Uhr/orkische
description: Zu kaufen bei Jakub auf dem Trödelmarkt von Bruggstad.
resource: "http://unitopia.intelligense.de/wiki/Uhr/orkische"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Metall, Info/Waffenstärke, Info/Waffenstärke/naja, Info/Waffenzustand, Info/Waffenzustand/recht beständig, Waffe, Waffe/Keule, Waffe/Midgard, Waffe/Midgard/Keule]
timestamp: 2024-04-23T19:27:42Z
revid: 232290
namespace: 0
contenthash: 55605a22e773d07201787e8bff3844ec5bc5e89562f6a9157a08bb5e6f87ea6c
---

## Aussehen

Dieses abscheuliche Gebilde ist die haesslichste Uhr, die Du jemals gesehen
hast. Zwei eklige Zeiger kratzen ueber eine widerwaertige Fratze, die als
Zifferblatt dient. Der Rahmen der Uhr besteht aus Stacheln und Dornen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [3 (naja)](/kategorie/info-waffenstärke-naja.md "Kategorie:Info/Waffenstärke/naja") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [5 (recht beständig)](/kategorie/info-waffenzustand-recht-beständig.md "Kategorie:Info/Waffenzustand/recht beständig") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Jakub](/jakub.md "Jakub") auf dem Trödelmarkt von [Bruggstad](/bruggstad.md "Bruggstad").

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Keule
- Gegend: Midgard
- Material: Metall
- Waffenstärke: naja
- Waffenzustand: recht beständig
- Gewicht: 2
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Uhr/orkische)
