---
type: Wiki Article
title: Joggingjacke
description: Zu kaufen bei Odian beim Olympiastadion von Phexcaer auf Thule.
resource: "http://unitopia.intelligense.de/wiki/Joggingjacke"
tags: [Fundort/Kauf, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Textil, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Kleidung, Kleidung/Brust, Kleidung/Nordische Inseln, Kleidung/Nordische Inseln/Brust]
timestamp: 2024-04-23T19:27:50Z
revid: 232873
namespace: 0
contenthash: cc9d34b417c3cc90101601b4abe6649f0c35e6c757e06939b4a16f2f59ce1890
---

## Aussehen

Eine offizielle olympische Joggingjacke. Auf der Vorderseite sind die acht
olympischen Ringe dargestellt. Sie ist sehr leicht, aber trotzdem warm. Am
besten ist sie dazu geeignet, in kalter Landschaft zu trainieren oder
einfach um zu protzen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Odian](/odian.md "Odian") beim [Olympiastadion](/olympiastadion.md "Olympiastadion") von [Phexcaer](/phexcaer.md "Phexcaer") auf [Thule](/thule.md "Thule").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Brust
- Gegend: Nordische Inseln
- Material: Textil
- Temperaturschutz: wärmt etwas
- Gewicht: 2
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Joggingjacke)
