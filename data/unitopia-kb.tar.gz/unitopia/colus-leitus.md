---
type: Wiki Article
title: Colus Leitus
description: Zu kaufen bei der Maus im Eurodisnix.
resource: "http://unitopia.intelligense.de/wiki/Colus_Leitus"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/durstlöschend, Nahrung, Nahrung/Gallien, Nahrung/Gallien/Getränk, Nahrung/Getränk]
timestamp: 2024-08-29T15:15:27Z
revid: 232845
namespace: 0
contenthash: c00e68598b55117751bea738559cd33ebf772d7ce357f5089783140dbb272825
---

## Aussehen

Colus heisst auf deutsch Spinnrocken, und genau so leicht schmeckt dieses
schwarze Getraenk auch.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend") |

## Fundort

Zu kaufen bei der [Maus](/maus-eurodisnix.md "Maus/Eurodisnix") im [Eurodisnix](/eurodisnix.md "Eurodisnix").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Getränk
- Gegend: Gallien
- Gewicht: 1
- Wirkung: durstlöschend

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Colus_Leitus)
