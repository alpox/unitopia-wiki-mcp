---
type: Wiki Article
title: Mauerhaken
description: Zu kaufen bei Alfred in der Schmiede auf Burg Tregyln auf Drachenland.
resource: "http://unitopia.intelligense.de/wiki/Mauerhaken"
tags: [Behälter, Behälter/Ebenen, Behälter/Ebenen/Kleine, Behälter/Kleine, Fundort/Kauf, Info, Info/Fasst, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Metall]
timestamp: 2026-03-18T18:21:23Z
revid: 233125
namespace: 0
contenthash: 8d98d3f9836697ecb1f9899bb8c8cd8da8129e0b6751972b9d04fe4bf2caebc2
---

## Aussehen

Ein Mauerhaken, wie er von Bergsteigern zur Sicherung beim Klettern
verwendet wird. Es ist ein Metallstift mit einer mit Widerhaken besetzten
Metallspitze am einen Ende und einem Ring am anderen Ende. Man kann ihn mit
geeignetem Werkzeug in eine Wand oder Mauer einschlagen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Fasst](/kategorie/info-fasst.md "Kategorie:Info/Fasst"):** | [Seil](/seil.md "Seil") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Alfred](/alfred-burg-tregyln.md "Alfred/Burg Tregyln") in der Schmiede auf [Burg Tregyln](/burg-tregyln.md "Burg Tregyln") auf [Drachenland](/drachenland.md "Drachenland").

* * *


## Kenndaten

- Kategorie: Behälter
- Typ: Kleine
- Gegend: Ebenen
- Material: Metall
- Fasst: Seil
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Mauerhaken)
