---
type: Wiki Article
title: "Praline/Stratos-Arkaden"
description: "In Glasschale in der Boutique der Stratos-Arkaden auf Stratos."
resource: "http://unitopia.intelligense.de/wiki/Praline/Stratos-Arkaden"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Kokosinseln, Nahrung/Kokosinseln/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:19:43Z
revid: 262488
namespace: 0
contenthash: 8d4d85fbcac4f9467e1f1504e7847c7d77e6ab55f5b95b937688ba3461859489
---

## Aussehen

Hmm, diese Praline sieht sehr lecker aus. Sie ist mit edler Schokolade
ueberzogen und mit Nougat gefuellt. Du solltest sie essen, bevor sie dir in
der Hand noch wegschmilzt.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

In [Glasschale](/glasschale.md "Glasschale") in der Boutique der [Stratos-Arkaden](/stratos-arkaden.md "Stratos-Arkaden") auf [Stratos](/stratos.md "Stratos").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Kokosinseln
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Praline/Stratos-Arkaden)
