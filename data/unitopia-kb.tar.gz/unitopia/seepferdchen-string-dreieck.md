---
type: Wiki Article
title: "Seepferdchen/String-Dreieck"
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Seepferdchen/String-Dreieck"
tags: [NPC, NPC/Dörrland, NPC/Dörrland/defensiv, NPC/defensiv, Rasse, Rasse/Fisch]
timestamp: 2018-11-07T18:34:58Z
revid: 260562
namespace: 0
contenthash: 6ad5917a6d67f4e1942f85e539e243e5fc3d68eb8c4114802eca34e6435c46e5
---

## Aussehen

Ein winzig kleines Seepferdchen schwimmt hier zwischen dem ganzen wild
wachsenden Gestruepp umher. Trotz seiner leuchtenden Farbe hast Du Muehe es
zu entdecken.

## Ausrüstung

Keine.

## Heimat

Im [dichten Unterwasserwald](/unterwasserwald.md "Unterwasserwald") im [String-Dreieck](/string-dreieck.md "String-Dreieck").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Dörrland
- Rasse: Fisch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Seepferdchen/String-Dreieck)
