---
type: Wiki Article
title: "T-Shirt/Jacky"
description: Kleidung von Jacky in der Schnapsbrennerei der Alchemistengilde von Borsippa.
resource: "http://unitopia.intelligense.de/wiki/T-Shirt/Jacky"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Kleidung, Kleidung/Brust, Kleidung/Vaniorh, Kleidung/Vaniorh/Brust]
timestamp: 2024-03-02T19:19:35Z
revid: 249985
namespace: 0
contenthash: 872066a06e5f9824b1caa6ccd8b1559ce59ac2ac1c5e1b318609b0668ed8285a
---

## Aussehen

Ein gut sitzendes T-Shirt. Eigentlich nichts besonderes.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Kleidung von [Jacky](/jacky.md "Jacky") in der Schnapsbrennerei der [Alchemistengilde](/alchemistengilde.md "Alchemistengilde") von [Borsippa](/borsippa.md "Borsippa").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Brust
- Gegend: Vaniorh
- Material: Textil
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/T-Shirt/Jacky)
