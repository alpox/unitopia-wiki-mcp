---
type: Wiki Article
title: Rotwein/Elfenwald
description: ""
resource: "http://unitopia.intelligense.de/wiki/Rotwein/Elfenwald"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/betrunken, Info/Wirkung/durstlöschend, "Info/Wirkung/gibt 1-5 AP", "Info/Wirkung/gibt 1-5 ZP", Nahrung, Nahrung/Alkohol, Nahrung/Midgard, Nahrung/Midgard/Alkohol]
timestamp: 2024-08-29T15:20:39Z
revid: 247820
namespace: 0
contenthash: d6304d26f6e0ce376f36ff103b064969f7f2e8592c1017dae831c6bf227c1623
---

## Aussehen

Ein Rotwein mit ziemlich dunkler Farbe.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend"), [betrunken](/kategorie/info-wirkung-betrunken.md "Kategorie:Info/Wirkung/betrunken"), gibt 5 ZP wenn AP voll |

## Fundort

-   Von [Feanorin](/feanorin.md "Feanorin") im Empfangszimmer von [Namibs](/namib.md "Namib") Baumhaus im [Elfenwald](/elfenwald.md "Elfenwald").
-   Im Fürstenzimmer von [Namibs](/namib.md "Namib") Baumhaus im [Elfenwald](/elfenwald.md "Elfenwald").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Alkohol
- Gegend: Midgard
- Gewicht: 1
- Wirkung: durstlöschend/betrunken/gibt 5 ZP wenn AP voll

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Rotwein/Elfenwald)
