---
type: Wiki Article
title: Marzipanmagier
description: ""
resource: "http://unitopia.intelligense.de/wiki/Marzipanmagier"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Midgard, Nahrung/Midgard/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:18:15Z
revid: 223486
namespace: 0
contenthash: 3f20a13e3349213891011215f916a68fd2a39c615b954b2f428b549948553326
---

## Aussehen

Eine Figur mit Spitzhut und Runenbeutel, von der etwas magisches auszugehen
scheint.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

-   Zu kaufen bei [Adventi](/adventi.md "Adventi") in den [Adventskalendern](/adventskalender.md "Adventskalender") auf dem [Weihnachtsmarkt](/weihnachtsmarkt.md "Weihnachtsmarkt") in [Nankea (Stadt)](/nankea-\(stadt\).md "Nankea (Stadt)") auf [Nankea](/nankea.md "Nankea").
-   Zu kaufen bei [Sarotti](/sarotti.md "Sarotti") in der [Marzipanschachtel](/marzipanschachtel.md "Marzipanschachtel") im Schokoladengeschäft von [Nankea (Stadt)](/nankea-\(stadt\).md "Nankea (Stadt)") auf [Nankea](/nankea.md "Nankea").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Midgard
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Marzipanmagier)
