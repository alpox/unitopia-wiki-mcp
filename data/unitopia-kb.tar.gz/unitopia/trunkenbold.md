---
type: Wiki Article
title: Trunkenbold
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Trunkenbold"
tags: [NPC, NPC/Märchenland, NPC/Märchenland/defensiv, NPC/defensiv, Rasse, Rasse/Kobold]
timestamp: 2018-11-07T18:28:22Z
revid: 212025
namespace: 0
contenthash: 4261671c7bed5b1787d8afd773404d22badee18fb6e075a77574e37e304498f8
---

## Aussehen

Der Trunkenbold koennte der Zwilling des Saufboldes sein, so aehnlich sehen
sie sich.

## Ausrüstung

Keine.

## Heimat

Im Pub der [Destillerie](/destillerie.md "Destillerie") von [Koboldingen](/koboldingen.md "Koboldingen").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Märchenland
- Rasse: Kobold

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Trunkenbold)
