---
type: Wiki Article
title: Helm/Goliath
description: Rüstung vom Riesen Goliath in der Riesenburg des Märchenparks von Tadmor.
resource: "http://unitopia.intelligense.de/wiki/Helm/Goliath"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/5, Info/Material, Info/Material/Metall, Info/Rüstungsstärke, Info/Rüstungsstärke/geht so, Info/Rüstungszustand, Info/Rüstungszustand/solide, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Rüstung, Rüstung/Kopf, Rüstung/Vaniorh, Rüstung/Vaniorh/Kopf]
timestamp: 2024-03-02T19:18:11Z
revid: 227172
namespace: 0
contenthash: 85bfc21423c2c6f285b2df93018d1360b0b448baebb62dd6f3276a5c09567170
---

## Aussehen

Der Helm des Riesen Goliath.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [3 (geht so)](/kategorie/info-rüstungsstärke-geht-so.md "Kategorie:Info/Rüstungsstärke/geht so") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [6 (solide)](/kategorie/info-rüstungszustand-solide.md "Kategorie:Info/Rüstungszustand/solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [5 (ein klein wenig schwer)](/kategorie/info-gewicht-5.md "Kategorie:Info/Gewicht/5") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Rüstung vom [Riesen Goliath](/goliath.md "Goliath") in der Riesenburg des [Märchenparks](/märchenpark.md "Märchenpark") von [Tadmor](/tadmor.md "Tadmor").

* * *


## Kenndaten

- Kategorie: Rüstung
- Typ: Kopf
- Gegend: Vaniorh
- Material: Metall
- Temperaturschutz: wärmt etwas
- Rüstungsstärke: geht so
- Rüstungszustand: solide
- Gewicht: 5
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Helm/Goliath)
