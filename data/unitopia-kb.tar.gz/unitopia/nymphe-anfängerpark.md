---
type: Wiki Article
title: Nymphe/Anfängerpark
description: Im Anfängerpark von Tadmor.
resource: "http://unitopia.intelligense.de/wiki/Nymphe/Anfängerpark"
tags: [NPC, NPC/Vaniorh, NPC/Vaniorh/defensiv, NPC/defensiv, Rasse, Rasse/Nymphe]
timestamp: 2018-11-07T18:30:34Z
revid: 215587
namespace: 0
contenthash: 5ab8858a8904339221d6222d2d9ad55dd7319a05c0c99a4dc1d38a1976e9958f
---

## Aussehen

Eine bildhuebsche, kichernde Nymphe.

## Ausrüstung

**Variabel:**

-   Ein [goldener Armreif](/armreif-nymphe-anfängerpark.md "Armreif/Nymphe/Anfängerpark")
-   Eine [goldene Fußkette](/fußkette.md "Fußkette")
-   Eine [goldene Halskette](/halskette-nymphe-anfängerpark.md "Halskette/Nymphe/Anfängerpark")
-   Ein Paar [Goldene Ohrringe](/ohrringe-nymphe-anfängerpark.md "Ohrringe/Nymphe/Anfängerpark")

## Heimat

Im [Anfängerpark](/anfängerpark.md "Anfängerpark") von [Tadmor](/tadmor.md "Tadmor").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Vaniorh
- Rasse: Nymphe

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Nymphe/Anfängerpark)
