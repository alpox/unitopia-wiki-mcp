---
type: Wiki Article
title: Gorin/Dvaergen
description: In der Bierbrauerei von Dvaergen.
resource: "http://unitopia.intelligense.de/wiki/Gorin/Dvaergen"
tags: [Angebot, NPC, NPC/Midgard, NPC/Midgard/defensiv, NPC/defensiv, Rasse, Rasse/Zwerg, Tätigkeit, Tätigkeit/Gastwirt]
timestamp: 2022-04-25T21:07:47Z
revid: 217650
namespace: 0
contenthash: 3b9c790bb59c73015321db438d7a949b3ca1c616866b17356cd766c7faaba462
---

## Aussehen

Du siehst einen dicken, ordentlich gekleideten Zwerg mit einem langen, rotbraunen Bart
und ordentlich gekaemmten Haaren vor Dir.

## Ausrüstung

-   Ein [weißes Leinenhemd](/leinenhemd-gorin-dvaergen.md "Leinenhemd/Gorin/Dvaergen").
-   Eine [grüne Wollhose](/wollhose-gorin-dvaergen.md "Wollhose/Gorin/Dvaergen").

## Heimat

In der Bierbrauerei von [Dvaergen](/dvaergen.md "Dvaergen").

## Angebot

| ![Angebot-tl.gif](/images/d/db/Angebot-tl.gif) | Getränkekarte | ![Angebot-tr.gif](/images/5/52/Angebot-tr.gif) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | \| **Alkoholisches::** \| **[Taler](/währung.md "Währung")**: \| \| --- \| --- \| \| Ein [Zwergenblondes](/zwergenblondes.md "Zwergenblondes") \| 60 \| \| Ein [Altzwergisches](/altzwergisches.md "Altzwergisches") \| 80 \| \| Ein [Zwergenbock](/zwergenbock.md "Zwergenbock") \| 120 \| \| Ein [echtes Zwergenbier](/zwergenbier-gorin-dvaergen.md "Zwergenbier/Gorin/Dvaergen") \| 150 \| \| Ein [Sammlerkrug](/bierkrug-gorin-dvaergen.md "Bierkrug/Gorin/Dvaergen") (gefüllt) \| 250 \| \|  \|  \| \| **Antialkoholisches:** \|  \| \| Ein [Wasser](/wasser-gorin-dvaergen.md "Wasser/Gorin/Dvaergen") \| 10 \| \| Ein [Zwergfrei](/zwergfrei.md "Zwergfrei") (ohne Alkohol) \| 30 \| | **Alkoholisches::** | **[Taler](/währung.md "Währung")**: | Ein [Zwergenblondes](/zwergenblondes.md "Zwergenblondes") | 60 | Ein [Altzwergisches](/altzwergisches.md "Altzwergisches") | 80 | Ein [Zwergenbock](/zwergenbock.md "Zwergenbock") | 120 | Ein [echtes Zwergenbier](/zwergenbier-gorin-dvaergen.md "Zwergenbier/Gorin/Dvaergen") | 150 | Ein [Sammlerkrug](/bierkrug-gorin-dvaergen.md "Bierkrug/Gorin/Dvaergen") (gefüllt) | 250 |  |  | **Antialkoholisches:** |  | Ein [Wasser](/wasser-gorin-dvaergen.md "Wasser/Gorin/Dvaergen") | 10 | Ein [Zwergfrei](/zwergfrei.md "Zwergfrei") (ohne Alkohol) | 30 |  |
| **Alkoholisches::** | **[Taler](/währung.md "Währung")**: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Zwergenblondes](/zwergenblondes.md "Zwergenblondes") | 60 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Altzwergisches](/altzwergisches.md "Altzwergisches") | 80 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Zwergenbock](/zwergenbock.md "Zwergenbock") | 120 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [echtes Zwergenbier](/zwergenbier-gorin-dvaergen.md "Zwergenbier/Gorin/Dvaergen") | 150 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Sammlerkrug](/bierkrug-gorin-dvaergen.md "Bierkrug/Gorin/Dvaergen") (gefüllt) | 250 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| **Antialkoholisches:** |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Wasser](/wasser-gorin-dvaergen.md "Wasser/Gorin/Dvaergen") | 10 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Zwergfrei](/zwergfrei.md "Zwergfrei") (ohne Alkohol) | 30 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ![Angebot-bl.gif](/images/3/3b/Angebot-bl.gif) |  | ![Angebot-br.gif](/images/9/92/Angebot-br.gif) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Midgard
- Rasse: Zwerg
- Tätigkeit: Gastwirt
- Gegenstand: Alkoholisches:

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Gorin/Dvaergen)
