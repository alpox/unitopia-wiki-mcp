---
type: Wiki Article
title: Rotweinglas
description: "Zu kaufen bei Raul in der Lounge der Stratos-Arkaden auf Stratos."
resource: "http://unitopia.intelligense.de/wiki/Rotweinglas"
tags: [Behälter, Behälter/Gefäß, Behälter/Kokosinseln, Behälter/Kokosinseln/Gefäß, Fundort/Kauf, Info, Info/Fasst, Info/Fasst/Flüssigkeit, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Glas, Info/Volumen, Info/Volumen/7]
timestamp: 2026-03-18T18:21:36Z
revid: 256871
namespace: 0
contenthash: 365a078fbe8ab70d0694c1c1e33d37fae05b9c3dfd7ee708da77d7edd542e38c
---

## Aussehen

Ein langstieliges Glas mit grossen, runden Kelch aus Bleikristall. Ein
kleiner Schriftzug ist in das Glas eingeaetzt. Die dunkelrote Fluessigkeit
in dem Glas sieht verfuehrerisch aus. 
Es ist ganz mit Chateau Baindelacide gefuellt.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Glas](/kategorie/info-material-glas.md "Kategorie:Info/Material/Glas") |
| --- | --- |
| **[Fasst](/kategorie/info-fasst.md "Kategorie:Info/Fasst"):** | [Flüssigkeit](/flüssigkeit.md "Flüssigkeit") |
| **[Volumen](/kategorie/info-volumen.md "Kategorie:Info/Volumen"):** | 7, Schluck |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Raul](/raul-stratos-arkaden.md "Raul/Stratos-Arkaden") in der Lounge der [Stratos-Arkaden](/stratos-arkaden.md "Stratos-Arkaden") auf [Stratos](/stratos.md "Stratos").

## Besonderheit

-   Das Glas enthält anfangs [Chateau Baindelacide](/chateau-baindelacide.md "Chateau Baindelacide").
-   Ist das Glas leer, stellt man es ab und es verschwindet.

* * *


## Kenndaten

- Kategorie: Behälter
- Typ: Gefäß
- Gegend: Kokosinseln
- Material: Glas
- Fasst: Flüssigkeit
- Volumen: 7/Schluck
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Rotweinglas)
