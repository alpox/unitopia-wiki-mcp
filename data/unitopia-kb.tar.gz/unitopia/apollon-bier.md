---
type: Wiki Article
title: "Apollon-Bier"
description: Zu kaufen bei Sokrates in seinem Gasthof in Knossos auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/Apollon-Bier"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/betrunken, Info/Wirkung/durstlöschend, Nahrung, Nahrung/Alkohol, Nahrung/Kokosinseln, Nahrung/Kokosinseln/Alkohol]
timestamp: 2024-08-29T15:14:41Z
revid: 222573
namespace: 0
contenthash: ab168c8060aac1e7137fc0fff5143282d6f8d9cce21f86d521b39e6de94973ce
---

## Aussehen

Das Apollon-Bier ist ein Pils mit feincremigem Schaum, steht gut in der
Blume, ist feinherb und von goldgelber Farbe. Allerdings soll sich
kuerzlich sogar der unverwundbare Recke Achilles, von Troja kommend, eine
toedliche Magenverstimmung geholt haben, als er einige Glaeser Apollon
leerte. Aufgrund ihres Einflusses gelang es der Brauerei jedoch, zu
verbreiten, der Kunde sei einem Fussleiden erlegen (sog.
'Achillesfersenpils').

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [betrunken](/kategorie/info-wirkung-betrunken.md "Kategorie:Info/Wirkung/betrunken"), [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend") |

## Fundort

Zu kaufen bei [Sokrates](/sokrates.md "Sokrates") in seinem Gasthof in [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Alkohol
- Gegend: Kokosinseln
- Gewicht: 1
- Wirkung: betrunken/durstlöschend

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Apollon-Bier)
