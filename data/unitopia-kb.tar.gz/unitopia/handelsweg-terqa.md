---
type: Wiki Article
title: Handelsweg/Terqa
description: "Der Terqa-Handelsweg verläuft zwischen Tadmors Südtor und Terqa und umfasst auch den alten Handelsweg, sowie ein Stück des südlichen Stadtgrabens von Tadmor. Der alte Handelsweg beginnt am Trampelpfad"
resource: "http://unitopia.intelligense.de/wiki/Handelsweg/Terqa"
tags: [Karte, Vaniorh]
timestamp: 2020-05-29T17:01:16Z
revid: 244727
namespace: 0
contenthash: c729cfe6da1833f15949cc4168627a8840ea3804acffe4cd66a45596d8fdaeb0
---

| **[Koordinaten](/kategorie/kompass.md "Kategorie:Kompass"):** | **[Gegend](/kategorie/magyra.md "Kategorie:Magyra"):** [Vaniorh](/vaniorh.md "Vaniorh") | **[Währung](/kategorie/gegenstand-geld.md "Kategorie:Gegenstand/Geld"):** [Taler](/taler.md "Taler") |
| --- | --- | --- |

Der [Terqa](/terqa.md "Terqa")\-[Handelsweg](/handelsweg.md "Handelsweg") verläuft zwischen [Tadmors](/tadmor.md "Tadmor") Südtor und [Terqa](/terqa.md "Terqa") und umfasst auch den [alten Handelsweg](#Alter_Handelsweg), sowie ein Stück des [südlichen Stadtgrabens](/tadmor.md "Tadmor") von [Tadmor](/tadmor.md "Tadmor"). Der [alte Handelsweg](#Alter_Handelsweg) beginnt am Trampelpfad im [Laubwald](#Laubwald) südlich von [Tadmor](/tadmor.md "Tadmor"). Am nördlichen Teil des Handelsweges direkt findet man nicht nur die [Kapelle der heiligen Anna](#Kapelle), sondern auch einen Rastplatz mit dem berühmten [Go-Spieler](/go-spieler.md "Go-Spieler"). Am südlichen Abschnitt des Handelsweges findet man an einer Steilküste einen [Altar](#Altar). Vom Handelsweg aus, kann man auch einen farbenprächtigen [Laubwald](#Laubwald) erreichen, dort befindet sich eine [Waldschänke](/waldschänke.md "Waldschänke") und die [Cosiranhöhle](#Cosiranhöhle). Wenn man den [Laubwald](#Laubwald) durchquert, gelangt man sogar in den gefährlichen [Düsterwald](#Düsterwald), dessen Mitte die Seeinsel [Istaro](/istaro.md "Istaro") kürt.

# [Karte](#toc)

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

   S  3
   |  |
   |  |
1--o--o--o--o--o--4
   |   \
   |    \
   2     o
          \
           \
            o
             \
              \
               o
                \
                 \
                  o--5
                  |
                  |
                  o
                  |
                  |
                  o
                  |
                  |
                  o
                  |
                  |
                  o--6
                  |
                  |
                  W

S [Südtor](/tadmor.md "Tadmor") von [Tadmor](/tadmor.md "Tadmor")
W Weg nach [Terqa](/terqa.md "Terqa")

1 [Kapelle der heiligen Anna](#Kapelle)
2 [Laubwald](#Laubwald)
3 Hütte von [Sara](/sara-cluedo.md "Sara/Cluedo")
4 Pfad im Wald
  ([Alter Handelsweg](#Alter_Handelsweg))
5 Rastplatz
  ([Go-Spieler](/go-spieler.md "Go-Spieler"))
6 Steilküste
  ([Altar](#Altar))
  ([Alte Beschwörergilde](#Alte_Beschwörergilde))

## [Kapelle](#toc)

In der Kapelle der heiligen Anna kann man zu jedem anwesenden [Engel](/engel.md "Engel") um Hilfe beten. Wer gerade da ist, steht auf einer Marmortafel im Raum mit dem Altar. [Engel](/engel.md "Engel") können sich hier mit der [Gabe](/gabe.md "Gabe") [Heilung](/heilung.md "Heilung") ihre [AP](/ap.md "AP")[![Ausdauerpunkte](/images/b/b4/AP.gif)](/ap.md "Ausdauerpunkte") auffüllen. Doch [Bruder Bernhard](/bernhard.md "Bernhard") lässt niemanden mit [Waffen](/waffen.md "Waffen") dort hinein. Wer das Bild in der Kapelle sehr gründlich untersucht, findet den Weg in eine geheime Kammer. Doch in den verschlossenen Geheimraum im Keller kann nur, wer von heiliger [Gesinnung](/gesinnung.md "Gesinnung") ist.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

      3
      |
      |
4  o-.2--1
| ˅
|˄
o

H [Handelsweg](#Karte)

1 Vor der Kapelle
2 Kapelle ([Bernhard](/bernhard.md "Bernhard"))
3 Kapelle ([Altar](/altar-handelsweg-terqa-kapelle.md "Altar/Handelsweg/Terqa/Kapelle"))
4 Kammer

## [Laubwald](#toc)

Den Laubwald südlich von [Tadmor](/tadmor.md "Tadmor") erreicht man durch das Südtor. Im Laubwald geht es auf den ersten Blick recht friedlich zu. [Eichhörnchen](/eichhörnchen-laubwald.md "Eichhörnchen/Laubwald") und ein [Fuchs](/fuchs-laubwald.md "Fuchs/Laubwald") sind die einzigen Tiere, denen man hier begegnet. Und überall liegen hübsche [Laubhaufen](/laubhaufen.md "Laubhaufen"), als hätte jemand frisch geharkt. Doch der Eindruck täuscht. Wehe dem, der dumm genug ist, sich mit dem [Fuchs](/fuchs-laubwald.md "Fuchs/Laubwald") anzulegen. Ja, selbst, wer an ihm riecht, bekommt einen Biss ab! Das Tier hat die [Tollwut](/tollwut.md "Tollwut") und überträgt diese tückische [Krankheit](/kategorie/zustand-krankheit.md "Kategorie:Zustand/Krankheit"). Und wer die Warnhinweise unbedingt missachten will, gerät auf eigenes Risiko in die [Höhle](/cosiranhöhle.md "Cosiranhöhle"), die der Volksmund mit einem gewissen [Cosiran](/cosiran-befreien.md "Cosiran befreien") in Verbindung bringt.

Weiter westlich im Wald steht die Hütte des [Holzfällers](/stephanus.md "Stephanus"), dem man hier bei der Arbeit begegnen kann und wer vom Waldspaziergang Durstig geworden ist, sollte vielleicht in der [Waldschänke](/agathe.md "Agathe") einkehren. Noch ein Stück weiter in Richtung zur Grenze des Waldes in Richtung [Düsterwald](#Düsterwald) liegt das Forsthaus. Im Forsthaus lebt Förster [Harald](/harald.md "Harald") mit seiner Frau [Helga](/helga-forsthaus.md "Helga/Forsthaus") und gelegentlich schaut auch seine Schwiegermutter [Hermine](/hermine.md "Hermine") vorbei. Der Förster braucht jemanden, der ihm [Hilfe](/förstergehilfe.md "Förstergehilfe") leistet.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

               H
               |
               |
5              o
|              |
|              |
4  3           o
|  |           |
|  |           |
o--o--o--2--o--o--o--1
         |     |
         |     |
  11--o--o--o--o
   |  |
   |  |
   D  6..7--8
      |
      |
      9.10

 H [Handelsweg](#Karte)
 D [Düsterwald](#Düsterwald)
 
 1 [Cosiranhöhle](#Cosiranhöhle)
 2 Laubwald
   ([Stephanus](/stephanus.md "Stephanus"))
 3 Blockhaus
 4 Waldschänke
   ([Agathe](/agathe.md "Agathe"))
   ([Max](/max.md "Max"))
 5 Küche
 6 Vor dem Forsthaus
 7 Forsthaus
   ([Harald](/harald.md "Harald"))
 8 Forsthaus
 9 Vor dem Schuppen
10 Schuppen
11 Mischwald

### [Cosiranhöhle](#toc)

Die Höhle des Cosiran liegt im [Laubwald](/laubwald.md "Laubwald") südlich von [Tadmor](/tadmor.md "Tadmor"). In den Tiefen dieser Höhle begegnet man einigen sehr seltsamen Gestalten. So begegnet einem der ängstliche [Golgar](/golgar.md "Golgar"), gibt es Labyrinthe, die von [Eisgar](/eisgar.md "Eisgar") und [Dorgal](/dorgal.md "Dorgal") bewacht werden. Und man begegnet auch noch [Zergal](/zergal.md "Zergal") und sogar unter dem Wasserfall von Trostar, der von einem unterirdischen Fluss gespeist wird, einem Regenwurm, der verzauberten Prinzessin [Xynia](/xynia.md "Xynia"). Alles scheint mit dem versteinerten [Cosiran](/cosiran-befreien.md "Cosiran befreien") zu tun zu haben.

In einer Höhle, die als "Trollhöhle" bekannt geworden ist, in die man aber nur schwer hineinkommt, wenn man zu groß oder mit zu viel Gepäck versucht, hinein zu gelangen, haben sich einige [Orks](/ork.md "Ork") und Trolle eingenistet. In den Gängen der Trollhöhle laufen die Trolle [Grd](/grd.md "Grd"), [Esthn](/esthn.md "Esthn"), [Tsorn](/tsorn.md "Tsorn") und [Ywol](/ywol.md "Ywol") herum. In einem Trainingsraum trainieren eine [gefährliche Trollfrau](/trollfrau-cosiranhöhle.md "Trollfrau/Cosiranhöhle"), eine [gemeingefährliche Trollfrau](/trollfrau-cosiranhöhle.md "Trollfrau/Cosiranhöhle"), eine [hühnenhafte Trollfrau](/trollfrau-cosiranhöhle.md "Trollfrau/Cosiranhöhle"), eine [widerliche Orkfrau](/orkfrau.md "Orkfrau"), ein [fetter Ork](/ork-cosiranhöhle.md "Ork/Cosiranhöhle") und ein [kampferprobter Ork](/ork-cosiranhöhle.md "Ork/Cosiranhöhle") miteinander, als wollten sie über kurz oder lang den Rest dieser Zwergenhöhlen erobern.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

         19
          |˅
          | ˄
          | 20-o--o-21
          | 
          |   
          o--o
              \
               \
                o
                |
                |
 o-17--o        o
 |\    |        |
 | \   |        |
16 18 14--o--o--o
 |   \ |        |
 |    \|        |
 o-15--o        o--o--o
                      |
                      |
             D        o
             |+       |
             | +      |
 L--1       10  D--o--9--o--o
     ˅               ˅▲     |
      ˄             ˄ '     ▼
       o     o     o  '     E++E
        ˅    |˅    |  '.......˅...
         ˄   | '   |         ˄    '
          o--4  '  o        E 12  '
         ˅       ' |         ˅ |  ▲
        ˄         ˄|          ˅|  |
       2        o--5--7       11-13
      ˅         |      ˅
     ˄          |       ˄
   3           6        8

 L [Laubwald](#Laubwald)
 
 D [Dorgals](/dorgal.md "Dorgal") dunkles Labyrinth
 E Eisgars Labyrinth der Zeichen

 1 Eingang einer dunklen Höhle
 2 Katakomben
 3 Tiefer Keller
 4 Unterirdische Halle 
   ([Statue des Cosiran](/statue-cosiran.md "Statue/Cosiran"))
 5 Leuchtender Raum
 6 Ehemalige Waffenkammer
 7 Düsterer Wachraum
 8 Dunkles, kaltes Verlies
 9 Unterirdischer Kreuzweg 
   ([Golgar](/golgar.md "Golgar"))
10 Guten Stube eines Gnoms
   ([Zergal](/zergal.md "Zergal"))
11 [Eisgars](/eisgar.md "Eisgar") Wohnzimmer
12 Eisgars Garten
13 Eisgars Küche 
14 Unterirdischer Gang 
   ([Grd](/grd.md "Grd"))
15 Unterirdischer Gang 
   ([Tsorn](/tsorn.md "Tsorn")) 
16 Unterirdischer Gang 
   ([Ywol](/ywol.md "Ywol"))
17 Unterirdischer Gang
   ([Esthn](/esthn.md "Esthn"))
18 Trainingsraum 
   ([Ork](/ork-cosiranhöhle.md "Ork/Cosiranhöhle"))
   ([Orkfrau](/orkfrau.md "Orkfrau"))
   ([Trollfrau](/trollfrau-cosiranhöhle.md "Trollfrau/Cosiranhöhle"))
19 Wasserfall von Trostar
20 Unter einem Wasserfall
21 Höhle 
   ([Xynia](/xynia.md "Xynia"))

### [Düsterwald](#toc)

Der Düsterwald, im Süden von [Vaniorh](/vaniorh.md "Vaniorh") gelegen, ist eine gefährliche Gegend. Gleich am Eingang des Düsterwaldes steht ein übel gelaunter [Troll](/troll-düsterwald-vaniorh.md "Troll/Düsterwald/Vaniorh"), der die Besucher auf seine liebenswerte Art willkommen heißt. Gelegentlich springen zu ihm die besonders gefährlichen [Wölfe](/wolf-vaniorh.md "Wolf/Vaniorh") des Düsterwaldes und greifen so z.B. in einen Kampf zwischen einem Besucher und dem Troll ein. Diese [Wölfe](/wolf-vaniorh.md "Wolf/Vaniorh") sind auch eine stetige Gefahr im übrigen Gebiet des Waldes, denn sie streunen umher, greifen dank ihres sehr guten Geruchsinnes selbst Unsichtbare an und verfolgen einen, bis man sich dem Kampf stellt, den Tod findet oder aus dem Wald entkommt.

Was weiterhin jeden Besucher nervös machen dürfte, sind die unheimlichen [Raben](/rabe-düsterwald-vaniorh.md "Rabe/Düsterwald/Vaniorh"), die hier leben und die gleichfalls folgen, wohin man geht, bis man eine beachtliche Menge von ihnen eingesammelt hat. Zwar greifen sie nicht an, doch der Gedanke, dass sie darauf warten, dass man ein fressbarer Kadaver wird, lässt einen schier verzweifeln. Direkt diebisch wie Elstern sind sie nicht, doch liegen Wertsachen im Wald, schleppen die [Raben](/rabe-düsterwald-vaniorh.md "Rabe/Düsterwald/Vaniorh") sie nach und nach in ihre [Rabennester](/nest-düsterwald-vaniorh.md "Nest/Düsterwald/Vaniorh"). Dazu noch diese [fürchterliche Dunkelheit](/forschen.md "Forschen"), die den Wald so verdüstert, dass man in den meisten Bereichen mindestens die Leuchtkraft von zwei [Fackeln](/fackel-magyra.md "Fackel/Magyra") auf einmal braucht.

Fast könnte man glauben, es gäbe am Düsterwald nichts, was einen zum Besuch verleiten könnte, doch weit gefehlt. Die [Bäume](/baum-düsterwald-vaniorh.md "Baum/Düsterwald/Vaniorh") des Waldes kann man fällen und zu weiterer Verwendung wegrollen. Und überall kann man Pilze suchen . Und wer für den Sonntagsbraten [Rebhühner](/rebhuhn-düsterwald-vaniorh.md "Rebhuhn/Düsterwald/Vaniorh") erjagen will, wird hier gewiss auch ihre bevorzugten Verstecke finden. Wie zum Ausgleich leben auch friedliche Geschöpfe in diesem Wald. Eine Gemeinschaft von Gnomen, darunter ein [hagerer Gnom](/gnom-düsterwald-vaniorh.md "Gnom/Düsterwald/Vaniorh"), ein [gieriger Gnom](/gnom-düsterwald-vaniorh.md "Gnom/Düsterwald/Vaniorh"), sowie ein [dummer Gnom](/gnom-düsterwald-vaniorh.md "Gnom/Düsterwald/Vaniorh") leben in ihrem Versteck und ignorieren zufällige Besucher in der Regel. Und selbst Schönheit und Frieden kann man finden. Auf einer Lichtung voller Blumen, leckerer Walderdbeeren und einer friedlichen Atmosphäre leben ein [Rehbock](/rehbock.md "Rehbock"), seine [Rehricke](/rehricke.md "Rehricke") und ihr [Rehkitz](/rehkitz.md "Rehkitz") und man kommt sich vor, als wäre der Wald ringsum weit weg. Das Herz des Düsterwaldes bildet der Sichelsee, in dem die Insel [Istaro](/istaro.md "Istaro") liegt.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

                                            L
                                            |
                                            |
                                            1
                                           /|\
                                          o-o-o
                                          |X|X|\
            3                         o   o-o-o-o
             \                       /|    \|X|X|
              2             o-o   o-o-o     o-o-o
               \           /|X|\ /|X|X|\   /|X|X|\
                o-o   o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o
               /|X|\ /|X|X|X|X|X|X|X|X|X|X|X|X|X|X|X|X|
        o-o-o-o-o-o-o-U-U-U-U-U-o-o-o-o-o-o-o-o-o-o-o-o
        |X|X|X|X|X|X|X|/     \|X|X|X|X|X|X|X|X|X|X|X|X|\
        o-o-o-o-o-U-U-U       U-o-o-U-U-U-U-o-o-o-o-o-o-o-o
       /|X|X|X|X|X|/          |X|X|X|/   \|X|X|X|X|X|X|X|X|
    o-o-o-o-o-o-o-U           U-U-U-U     U-U-o-o-o-o-o-o-o
    |X|X|X|X|X|X|X|                 '      \|X|X|X|X|X|/
    o-o-o-o-o-o-o-U                 I-I-I   U-U-o-o-o-o       o-o
     \|X|X|X|X|X|X|                /| | |    \|X|X|X|X|      /|X|
      o-o-o-o-U-U-U           I-I-I-I-I-I     U-o-o-o-o     o-o-o
     /|X|X|X|X|/               \| | | | |    /|X|X|X|X|\    |X|/
  o-o-o-o-o-o-U                 I-I-I-I-I   U-o-o-o-o-o-o   o-o
  |X|X|X|X|X|X|                  \| | |/   /|X|X|X|X|X|X|\ /|X|\
  o-o-o-o-o-o-U                   I-I-I   U-o-o-o-o-o-o-o-o-o-o-o
   \|X|X|X|X|X|                    \|/    |X|X|X|X|X|X|X|X|X|X|/
    o-o-o-o-o-U                     I     U-o-o-o-o-o-o-o-o-o-o
   /|X|X|X|X|X|\                         /|X|X|X|X|X|/ \|/
  o-o-o-4-o-o-U-U                       U-U-o-o-o-o-o   o
  |X|X|X|X|X|X|X|\                     /|X|X|X|X|/
  o-o-o-o-o-o-o-U-U                 U-U-o-o-o-o-o
   \|X|/ \|X|X|X|X|\               /|X|X|X|/ \|X|
    o-o   o-o-o-o-U-U-U-U-U-U-U-U-U-o-o-o-o   o-o
             \|X|X|X|X|X|X|X|X|X|X|X|/        |X|\
              o-o-o-o-o-o-o-o-o-o-o-o         o-o-o-o
             /|X|X|X|X|X|X|X|X|X|X|X|\       /|X|X|X|\
          o-o-o-o-o-o-o-o-o-o-o-o-o-o-o     o-o-o-o-o-o
          |X|/ \|/   \|X|X|X|X|X|/           \|X|X|X|/
    o     o-o   o     o-o-o-o-o-o             o-o-o-o
   / \   /           /|X|X|X|X|X|\
  o   o-o           o-o-o-o-o-o-o-o
 /    |X|\           \|X|/ \|X|X|/
5     o-o-o           o-o   o-o-o

I [Seeinsel Istaro](/istaro.md "Istaro")
L [Laubwald](#Laubwald)
U Ufer des Sichelsees

1 Düsterwald
  ([Troll](/troll-düsterwald-vaniorh.md "Troll/Düsterwald/Vaniorh"))
2 Düsterwald
  (2 [Gnome](/gnom-düsterwald-vaniorh.md "Gnom/Düsterwald/Vaniorh"))
3 Lichte Stelle
  ([Rebhuhn](/rebhuhn-düsterwald-vaniorh.md "Rebhuhn/Düsterwald/Vaniorh"))
4 Düsterwald
  ([Rehbock](/rehbock.md "Rehbock"))
  ([Rehricke](/rehricke.md "Rehricke"))
  ([Rehkitz](/rehkitz.md "Rehkitz"))
5 Grenze des Düsterwaldes

## [Alter Handelsweg](#toc)

Am Ende des Trampelpfades steht man vor einer scheinbaren Sackgasse. Doch durch einen Spalt kann man hin durchkriechen und landet auf einer Lichtung voller [Glühwürmchen](/glühwürmchen.md "Glühwürmchen"). Geht man von hier nach Süden, so gelangt man in einen Raum, der eine teuflische Falle darstellt. Man läuft auf ewig in alle Richtungen zurück in dieses Feld und entkommt nicht! In andere Richtungen begegnet man [Dornenvögeln](/dornenvogel.md "Dornenvogel"), die nicht so harmlos sind, wie sie scheinen. Ebenso gefährlich sind die [Gremlins](/gremlin.md "Gremlin"). Aber besonders gefährlich sind die Dornen, wenn man sich verletzt, erkrankt man an [Tetanus](/tetanus.md "Tetanus").

Ist man glücklich nach Südosten in Richtung des Handelswegs entkommen, läuft man einer seltsamen Menagerie von Wesen über den Weg. Hier begegnet man einem [Wildschwein](/wildschwein-handelsweg.md "Wildschwein/Handelsweg"), [Tausendfüßlern](/tausendfüßler-handelsweg.md "Tausendfüßler/Handelsweg"), einer [Erdkröte](/erdkröte.md "Erdkröte"), einer [Waldmaus](/waldmaus.md "Waldmaus"), einem [Feuersalamander](/feuersalamander-handelsweg.md "Feuersalamander/Handelsweg") und einem [Felsenspringer](/felsenspringer.md "Felsenspringer"). Der einzige freundliche Bewohner dieser Gegend ist eine kleine [Waldelfe](/waldelfe.md "Waldelfe"). Am Weg liegt ein verschlossenes Tor, hinter dem Gerüchten zufolge ein Friedhof liegen soll. Der alte Handelsweg endet im tiefen Süden an einer Schlucht. Man sollte unbedingt eine Leiter mitnehmen, denn wenn man in eine [Grube](/fallgrube.md "Fallgrube") oder den Graben fällt, kommt man nur damit wieder raus. Die Dornen sind giftig, man vergiftet sich leicht. Vorsicht ist geboten!

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

   4
    \
     \
o--5  3  4
|   \ | /
▼    \|/
H--1.-2--4
▲    /|\
|   / | \
o--5  o  o
      |   \
      |    \
      o◄-8--7
     '|     |
     '▼     |
      6     9 
             \
              \
              10-11
                \
                 \
                 12
                 / \
                /   \
              12    13
                     |
                     |
                    14

 H [Handelsweg](#Karte)
 
 1 Pfad im Wald
 2 Lichtung
   ([Chefglühwürmchen](/chefglühwürmchen.md "Chefglühwürmchen"))
   ([Glühwürmchen](/glühwürmchen-handelsweg.md "Glühwürmchen/Handelsweg"))
 3 Schmaler Weg im Dickicht
   ([Dornenvogel](/dornenvogel.md "Dornenvogel"))
 4 Irrweg
   ([Dornenvogel](/dornenvogel.md "Dornenvogel"))
 5 Schmaler Weg im Dickicht
   ([Gremlin](/gremlin-handelsweg.md "Gremlin/Handelsweg"))
 6 [Fallgrube](/fallgrube.md "Fallgrube")
 7 Schmaler Weg
   ([Erdkröte](/erdkröte.md "Erdkröte"))
 8 Schmaler Weg
   ([Wildschwein](/wildschwein-handelsweg.md "Wildschwein/Handelsweg"))
 9 Schmaler Weg
   ([Tausendfüßler](/tausendfüßler-handelsweg.md "Tausendfüßler/Handelsweg"))
10 Schmaler Weg
   ([Waldmaus](/waldmaus-handelsweg.md "Waldmaus/Handelsweg"))
11 Friedhof
12 Schmaler Weg
   ([Waldelfe](/waldelfe.md "Waldelfe"))
13 Schmaler Weg
   ([Feuersalamander](/feuersalamander-handelsweg.md "Feuersalamander/Handelsweg"))
14 Schmaler Weg
   ([Felsenspringer](/felsenspringer.md "Felsenspringer"))

## [Steilküste](#toc)

Der [alte Opferaltar](/altar-handelsweg-terqa.md "Altar/Handelsweg/Terqa") liegt an einer Steilküste östlich vom [Handelsweg](#Karte) nach [Terqa](/terqa.md "Terqa"). Vor einem offensichtlich sehr alten Altar steht ein [Wächter](/wächter-altar-handelsweg-terqa.md "Wächter/Altar/Handelsweg/Terqa") und wacht darüber, dass hier niemand blutige Opfer bringt oder etwa Geld in die große Opferschale legt. Die Tür im Boden neben dem Altar ist fest verschlossen! Tötet jemand den [Wächter](/wächter-altar-handelsweg-terqa.md "Wächter/Altar/Handelsweg/Terqa"), dann erscheint sofort ein [Monster](/gnorf-altar-handelsweg-terqa.md "Gnorf/Altar/Handelsweg/Terqa") und greift an! Hat man auch dieses überwunden, steht es einem frei, den Altar seiner finsteren Bestimmung gemäß zu benutzen. Gelangt man nach richtiger Durchführung des Rituals hinab in die düstere Kammer, so kann man ein [Schwarzes Langschwert](/langschwert-schwarzes.md "Langschwert/schwarzes") erbeuten. [Magier](/magiergilde.md "Magiergilde") und [Beschwörer](/orden-der-finsternis.md "Orden der Finsternis") werden sich hier sicher noch mehr freuen. Letztere sollten eine [Schaufel](/schaufel.md "Schaufel") dabei haben.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

H--o--o--o--1
             ˅
              ˄
               2     W
                '   ˄
                 ' ˄
                  3

H [Handelsweg](#Karte)
W Schmaler Waldpfad ([Alte Beschwörergilde](#Alte_Beschwörergilde))

1 Kleiner Platz ([Altar](/altar-handelsweg-terqa.md "Altar/Handelsweg/Terqa"), [Gnorf](/gnorf-altar-handelsweg-terqa.md "Gnorf/Altar/Handelsweg/Terqa") & [Wächter](/wächter-altar-handelsweg-terqa.md "Wächter/Altar/Handelsweg/Terqa"))
2 Kleine Kammer direkt unter dem Altar
3 Irgendwo unter der Erde

### [Alte Beschwörergilde](#toc)

Die alte Beschwörergilde erreicht man, wenn man sich durch die Knochen im Brunnen des [Altares](/altar-handelsweg-terqa.md "Altar/Handelsweg/Terqa") gräbt. Betritt man diesen Bereich, so begegnet einem gleich ein [Dämon](/dämon-beschwörergilde.md "Dämon/Beschwörergilde"). Geht man weiter, so kommt man zu den alten Räumlichkeiten. Hier ist sogar der [Pförtner](/skelett-beschwörergilde.md "Skelett/Beschwörergilde") untot. Irgendwo soll noch eine [Gestalt](/gestalt-beschwörergilde.md "Gestalt/Beschwörergilde") zu finden sein.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

      6  7  8
      |  |  |˅
      |  |  | ˄
      o--3--o  o
     /|  |  |   ˅
    / |  |  |    ˄
   4  5  2  9-10  o
         |       ˅
         |      ˄
         1     o    12
         |      ˅    |
         |       ˄   |
         o        o  |
         |         ˅ |
         |          ˄|
o        o          11
'\      /
' \    /
A  o--W

 A [Altar](#Altar)
 W Schmaler Waldpfad
   ([Hässlicher Dämon](/dämon-beschwörergilde.md "Dämon/Beschwörergilde"))

 1 Eingangshalle
 2 Anmeldung
   ([Skelett](/skelett-beschwörergilde.md "Skelett/Beschwörergilde"))
 3 Aufenthaltsraum
 4 Verwaister Klassenraum
 5 Büro
 6 Alte Bibliothek
 7 Verwilderter Hof
 8 Verwüsteter Raum
 9 [Laden](/laden.md "Laden")
10 Vorratsraum
11 Dunkler Schacht
12 Höhle der Initiation
   ([Gestalt](/gestalt-beschwörergilde.md "Gestalt/Beschwörergilde"))

* * *

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Handelsweg/Terqa)
