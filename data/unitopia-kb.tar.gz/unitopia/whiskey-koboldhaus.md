---
type: Wiki Article
title: Whiskey/Koboldhaus
description: Auf dem Tisch auf der Veranda des Koboldhauses in Koboldingen.
resource: "http://unitopia.intelligense.de/wiki/Whiskey/Koboldhaus"
tags: [Fundort, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/betrunken, Info/Wirkung/durstlöschend, Nahrung, Nahrung/Alkohol, Nahrung/Märchenland, Nahrung/Märchenland/Alkohol]
timestamp: 2024-09-16T12:12:07Z
revid: 264428
namespace: 0
contenthash: 4e574a9b6c0907f5a732b5b9c4af3dd23295898635455eab8f3914b1b6df2e76
---

## Aussehen

Ein Glas voll mit Whiskey auf Eiswuerfeln.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend"), [betrunken](/kategorie/info-wirkung-betrunken.md "Kategorie:Info/Wirkung/betrunken") |

## Fundort

Auf dem [Tisch](/koboldingen.md "Koboldingen") auf der Veranda des [Koboldhauses](/koboldhaus.md "Koboldhaus") in [Koboldingen](/koboldingen.md "Koboldingen").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Alkohol
- Gegend: Märchenland
- Gewicht: 1
- Wirkung: durstlöschend/betrunken
- 1: Koboldtisch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Whiskey/Koboldhaus)
