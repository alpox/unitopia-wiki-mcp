---
type: Wiki Article
title: Koboldinger
description: Zu kaufen bei Herr Knapp in der Käsebude auf dem Markt von Koboldingen.
resource: "http://unitopia.intelligense.de/wiki/Koboldinger"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Märchenland, Nahrung/Märchenland/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:13:59Z
revid: 245742
namespace: 0
contenthash: 9fd0b1eaebcfd767595173ecf3d2e7e3802f376bacc5e05e8107e2e590b5e58a
---

## Aussehen

Ein sehr wuerziger Kaese. Ein Hausrezept von Herrn Knapp. Der schmeckt
bestimmt einfach Spitze.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Zu kaufen bei [Herr Knapp](/knapp-herr.md "Knapp/Herr") in der Käsebude auf dem Markt von [Koboldingen](/koboldingen.md "Koboldingen").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Märchenland
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Koboldinger)
