---
type: Wiki Article
title: Jean Pierre
description: In Jean Pierres Fechtschule Fechtschule von Barovia.
resource: "http://unitopia.intelligense.de/wiki/Jean_Pierre"
tags: [NPC, NPC/Dörrland, NPC/Dörrland/defensiv, NPC/defensiv, Rasse, Rasse/Mensch]
timestamp: 2018-11-07T18:29:03Z
revid: 215062
namespace: 0
contenthash: 198406dacaeb9ca5dfb6cf4bd798ad55f74c9d4f853991bc838c1f036e42e644
---

## Aussehen

Jean Pierre ist der typische Franzose im gehobenen Alter, der schon eine
Menge durchgemacht hat und immer mit dem Leben davon kam:
Eine eher unscheinbare, drahtige Gestalt, das Gesicht durchpfluegt von
einigen tiefen Furchen und einer dekorativen Narbe am Kinn. Selbiges, samt
den Backen, von einem ergrauten Dreitagebart bedeckt. Das markanteste an
ihm ist jedoch seine Baskenmuetze, die, etwas schief getragen, seinen Kopf
bedeckt.

## Ausrüstung

-   Eine [französische Baskenmütze](/baskenmütze-jean-pierre.md "Baskenmütze/Jean Pierre")
-   Ein [Spazierstock](/spazierstock.md "Spazierstock") ([Stockdegen](/stockdegen.md "Stockdegen")).

## Heimat

In Jean Pierres Fechtschule Fechtschule von [Barovia](/barovia.md "Barovia").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Dörrland
- Rasse: Mensch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Jean_Pierre)
