---
type: Wiki Article
title: Lukoglavix
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Lukoglavix"
tags: [NPC, NPC/Gallien, NPC/Gallien/defensiv, NPC/defensiv, Rasse, Rasse/Mensch]
timestamp: 2018-11-07T18:31:44Z
revid: 232481
namespace: 0
contenthash: cd647770b5750e0bf42052b3a9921fe7f0aff251577c0712d1e7ff69d491b57c
---

## Aussehen

Ein untersetzter, nicht sonderlich intelligent wirkender Gallier. Er
aehnelt Stupidix auf auffallende Weise. Vielleicht ist es ja ein entfernter
Verwandter von ihm.

## Ausrüstung

Keine.

## Heimat

Im Hügelgrabversteck nahe [Lutetia](/lutetia.md "Lutetia").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Gallien
- Rasse: Mensch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Lukoglavix)
