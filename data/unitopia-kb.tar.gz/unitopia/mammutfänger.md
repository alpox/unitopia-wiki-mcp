---
type: Wiki Article
title: Mammutfänger
description: Auf dem Dach der Abenteurergilde von Bruggstad.
resource: "http://unitopia.intelligense.de/wiki/Mammutfänger"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Edelmetall, Info/Waffenstärke, Info/Waffenstärke/naja, Info/Waffenzustand, Info/Waffenzustand/solide, Waffe, Waffe/Messer, Waffe/Midgard, Waffe/Midgard/Messer]
timestamp: 2024-03-02T19:17:11Z
revid: 232053
namespace: 0
contenthash: 0aa79c7c076a1a7bf234c9c7f2f717cda3b939bae29c2884bab1b15954e9fd05
---

## Aussehen

Ein stabiles, handliches Messer, wie es vor ewigen Zeiten, und lange vor
allen Artenschutzabkommen, von Jaegern in der Antarktis benutzt wurde, um
den Schaedel hinter den Ohren der erlegten Mammuts zu spalten.
Mit diesem Exemplar haeltst du den beruehmten Mammutfaenger in Haenden, mit
dem die Ururgrossmutter des vergesslichen Lorenzsons vaeterlicherseits in
einem Schneeloch suedlich des Nordpoles eigenhaendig die Nabelschnur ihres
erstgeborenen Sohnes durchtrennte.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Edelmetall](/kategorie/info-material-edelmetall.md "Kategorie:Info/Material/Edelmetall") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [3 (naja)](/kategorie/info-waffenstärke-naja.md "Kategorie:Info/Waffenstärke/naja") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [6 (solide)](/kategorie/info-waffenzustand-solide.md "Kategorie:Info/Waffenzustand/solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Auf dem Dach der [Abenteurergilde](/abenteurergilde.md "Abenteurergilde") von [Bruggstad](/bruggstad.md "Bruggstad").

## Besonderheit

Zum Mammutfänger gibt es eine spezielle [Mammutfängerscheide](/mammutfängerscheide.md "Mammutfängerscheide").

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Messer
- Gegend: Midgard
- Material: Edelmetall
- Waffenstärke: naja
- Waffenzustand: solide
- Gewicht: 2
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Mammutfänger)
