---
type: Wiki Article
title: Sonnenblume/Duftikuss
description: Zu kaufen bei Duftikuss im Blumenlanden von Koboldingen.
resource: "http://unitopia.intelligense.de/wiki/Sonnenblume/Duftikuss"
tags: [Fundort/Kauf, Gegenstand, Gegenstand/Märchenland, Gegenstand/Märchenland/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Licht, Info/Licht/leuchtet, Info/Material, Info/Material/Unbekannt]
timestamp: 2024-04-23T19:27:42Z
revid: 249532
namespace: 0
contenthash: 5bcfa99d394a2566742be963fc29482aa42ac7227e86f0dcfc85e0213a496882
---

## Aussehen

Eine der Lieblingsblumen des Duftikuss. Sie leuchtet wie eine Lampe,
solange sie die richtige Pflege geniesst. Ausserdem sieht sie natuerlich
auch wunderschoen aus.
An der Sonnenblume ist ein kleines, blaues Band befestigt.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Unbekannt](/kategorie/info-material-unbekannt.md "Kategorie:Info/Material/Unbekannt") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel"), [+1 (leuchtet normal)](/kategorie/info-licht-leuchtet.md "Kategorie:Info/Licht/leuchtet") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Duftikuss](/duftikuss.md "Duftikuss") im Blumenlanden von [Koboldingen](/koboldingen.md "Koboldingen").

## Besonderheit

Man kann nicht nur an Hand der Meldung im Aussehen den Frischegrad erkennen, das Adjektiv vor dem Namen verändert sich dahingehend genauso.

## Funktion

sende (Sonnen)Blume zu <Spieler>

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Märchenland
- Material: Unbekannt
- Gewicht: 1
- Licht: 0/+1
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Sonnenblume/Duftikuss)
