---
type: Wiki Article
title: Urbock
description: ""
resource: "http://unitopia.intelligense.de/wiki/Urbock"
tags: [Fundort, Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/betrunken, Info/Wirkung/durstlöschend, Nahrung, Nahrung/Alkohol, Nahrung/Midgard, Nahrung/Midgard/Alkohol]
timestamp: 2024-09-16T12:12:19Z
revid: 262708
namespace: 0
contenthash: 28d146e0f987421ef0abfdff614eee445ceca4b31fc9a2cbde254bc43e4a07b6
---

## Aussehen

Ein grosses Glas frisch gezapfter Bocklaender Urbock, gebraut nach altem
Halblingrezept. Das Bier leuchtet in dunklem Gold und seine praechtige
Schaumkrone ist strahlend weiss. Ein wahres Meisterwerk der
Halblingbrauerei, die dieses herrliche Bockbier gebraut und abgefuellt hat.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend"), [betrunken](/kategorie/info-wirkung-betrunken.md "Kategorie:Info/Wirkung/betrunken") |

## Fundort

-   Zu kaufen bei [Josif](/josif.md "Josif") im [Gasthof "Zur Stadtwache"](/magny.md "Magny") von [Magny](/magny.md "Magny").
-   Im [Bierfass](/bierfass-midgard.md "Bierfass/Midgard") in der Stube des Kommandanten und Vorratskammer in [Cirith Ungol](/mowan.md "Mowan").
-   Im [Bierfass](/bierfass-midgard.md "Bierfass/Midgard") in einer Gästeunterkunft im [Felsenkloster Laksos](/felsenkloster-laksos.md "Felsenkloster Laksos") auf dem [Klosterberg (Luntayberg)](/klosterberg.md "Klosterberg") der [Drachenberge](/drachenberge.md "Drachenberge").
-   Im [Bierfass](/bierfass-midgard.md "Bierfass/Midgard") auf dem Deck auf dem [Handelsschiff 'Meridian'](/meridian.md "Meridian").
-   Im [Bierfass](/bierfass-midgard.md "Bierfass/Midgard") im Keller im [Nachtclub](/merredin.md "Merredin") von [Merredin](/merredin.md "Merredin").
-   Im [Bierfass](/bierfass-midgard2.md "Bierfass/Midgard2") der [Zwergenhöhle](/nekromanteninsel.md "Nekromanteninsel") auf der [Nekromanteninsel](/nekromanteninsel.md "Nekromanteninsel").
-   Im [Bierfass](/bierfass-midgard2.md "Bierfass/Midgard2") in einem düsteren Kellerraum in den [Katakomben](/magny.md "Magny") von [Magny](/magny.md "Magny").
-   In der [Vorratskiste](/vorratskiste.md "Vorratskiste") in der engen Kammer des [schwarzen Turmes](/erzmagierturm.md "Erzmagierturm") auf der [Nekromanteninsel](/nekromanteninsel.md "Nekromanteninsel").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Alkohol
- Gegend: Midgard
- Gewicht: 1
- Wirkung: durstlöschend/betrunken

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Urbock)
