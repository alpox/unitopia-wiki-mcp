---
type: Wiki Article
title: Orkbogen/Orkhöhle/Wurzelwald
description: In der südlichen Kammer der Orkhöhle im Wurzelwald auf Nankea.
resource: "http://unitopia.intelligense.de/wiki/Orkbogen/Orkhöhle/Wurzelwald"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/4, Info/Material, Info/Material/Holz, Info/Schwimmt, Info/Waffenstärke, Info/Waffenstärke/prima, Info/Waffenzustand, Info/Waffenzustand/eher beständig, Waffe, Waffe/Bogen, Waffe/Midgard, Waffe/Midgard/Bogen]
timestamp: 2024-03-02T19:20:10Z
revid: 230305
namespace: 0
contenthash: ad1d12e34e10f0c023ff2add78c5476c769dcef2b3500a0e3d3b6cc3c2a7933e
---

## Aussehen

Ein Orkbogen, verziert mit Ork-Runen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [7 (prima)](/kategorie/info-waffenstärke-prima.md "Kategorie:Info/Waffenstärke/prima") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [4 (eher beständig)](/kategorie/info-waffenzustand-eher-beständig.md "Kategorie:Info/Waffenzustand/eher beständig") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [4 (gerade noch leicht)](/kategorie/info-gewicht-4.md "Kategorie:Info/Gewicht/4") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

In der südlichen Kammer der [Orkhöhle](/wurzelwald.md "Wurzelwald") im [Wurzelwald](/wurzelwald.md "Wurzelwald") auf [Nankea](/nankea.md "Nankea").

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Bogen
- Gegend: Midgard
- Material: Holz
- Waffenstärke: prima
- Waffenzustand: eher beständig
- Gewicht: 4
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Orkbogen/Orkhöhle/Wurzelwald)
