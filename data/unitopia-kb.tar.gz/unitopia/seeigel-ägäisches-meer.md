---
type: Wiki Article
title: Seeigel/Ägäisches Meer
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Seeigel/Ägäisches_Meer"
tags: [NPC, NPC/Kokosinseln, NPC/Kokosinseln/defensiv, NPC/defensiv, Rasse, Rasse/Fisch]
timestamp: 2018-11-07T18:37:03Z
revid: 215881
namespace: 0
contenthash: c59f0b8c8827452cc42b8a79a994ff6c63c563b26ff0cf866d4de2cdfc642f0d
---

## Aussehen

Eine grosse Stachelkugel mit Tausenden von Stacheln.

## Ausrüstung

Keine.

## Heimat

Auf dem Grund des [ägäischen Meeres](/aegaeisches-meer.md "Aegaeisches Meer").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Kokosinseln
- Rasse: Fisch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Seeigel/Ägäisches_Meer)
