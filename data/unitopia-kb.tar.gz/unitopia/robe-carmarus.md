---
type: Wiki Article
title: Robe/Carmarus
description: Robe von Carmarus in der Turmkammer des schwarzen Turmes auf der Nekromanteninsel.
resource: "http://unitopia.intelligense.de/wiki/Robe/Carmarus"
tags: [Fundort, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Kleidung, Kleidung/Brust, Kleidung/Midgard, Kleidung/Midgard/Brust]
timestamp: 2024-09-16T12:12:19Z
revid: 247708
namespace: 0
contenthash: f224f63df267827bb1524b27fc8d37db38990df83294f27905a5f171990ac2b4
---

## Aussehen

```
Eine einfache weisse Robe. Sie ist eng geschnitten, so dass man sie unter
einer Ruestung tragen kann. Sie sieht sehr bequem aus.
```

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Robe von [Carmarus](/carmarus.md "Carmarus") in der Turmkammer des [schwarzen Turmes](/erzmagierturm.md "Erzmagierturm") auf der [Nekromanteninsel](/nekromanteninsel.md "Nekromanteninsel").

## Kenndaten

- Kategorie: Kleidung
- Typ: Brust
- Gegend: Midgard
- Material: Textil
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Robe/Carmarus)
