---
type: Wiki Article
title: Passaufus
description: Im Gefängnis von Lutetia.
resource: "http://unitopia.intelligense.de/wiki/Passaufus"
tags: [NPC, NPC/Gallien, NPC/Gallien/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Wächter]
timestamp: 2018-11-07T18:26:35Z
revid: 260081
namespace: 0
contenthash: 318dda3ca442b1280ca9a367cda7796612f6c712cc44aa04809c9dec74071815
---

## Aussehen

Passaufus ist der Gefaengniswaerter von Lutetia. Normalerweise ist er immer
guter Laune, nur heute scheint ihn etwas zu bedruecken.

## Ausrüstung

-   Ein [Pilum](/pilum-legionär.md "Pilum/Legionär").
-   Ein [Brustpanzer](/brustpanzer-passaufus.md "Brustpanzer/Passaufus").

## Heimat

Im [Gefängnis](/lutetia.md "Lutetia") von [Lutetia](/lutetia.md "Lutetia").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Gallien
- Rasse: Mensch
- Tätigkeit: Wächter

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Passaufus)
