---
type: Wiki Article
title: "Shannara und die Ellcrys-Heilung"
description: "Der uralte Druide Allanon sandte uns einen dringenden Hilferuf. Er hat erfahren, dass Magyra von unzähligen Dämonen bedroht wird. Nur mit der Hilfe von Amberle, mit der man einen Samen aus dem Schatte"
resource: "http://unitopia.intelligense.de/wiki/Shannara_und_die_Ellcrys-Heilung"
tags: [Erfahrung, Erfahrung/Rätsel, Rätsel, Rätsel/Dörrland, Rätsel/Wahlpflicht, Rätsel/Wahlpflicht/Dörrland]
timestamp: 2020-06-03T13:47:11Z
revid: 263830
namespace: 0
contenthash: 01602085fae222ea1ae0891dc111a1bd9b860016df0e4993093c67d42fa50908
---

## Beschreibung

Der uralte Druide [Allanon](/allanon.md "Allanon") sandte uns einen dringenden Hilferuf. Er hat erfahren, dass [Magyra](/magyra.md "Magyra") von unzähligen Dämonen bedroht wird. Nur mit der Hilfe von [Amberle](/amberle.md "Amberle"), mit der man einen Samen aus dem Schattenbachtal holen und im [Sichermal](/sichermal.md "Sichermal") auffrischen muss.

Besucht [Allanon](/allanon.md "Allanon") in der [Druidenburg](/druidenburg.md "Druidenburg") von [Dörrland](/dörrland.md "Dörrland") und fragt ihn nach der Bedrohung.

## Meldungen

### Kurier

<Spieler> hat Magyra von der Gefahr der Daemonen befreit!

### Erfahrung

\* Du hast Amberle im Keller der Druidenburg gefunden.
\* Du hast den Samen des Ellcrys geholt.
\* Du hast Amberle zum Eingang vom Sichermal gebracht.
\* Du warst mit Amberle beim Blutfeuer.
\* Du hast Amberle durch die Gefahren des Sichermals geleitet
\* Du hast den Ellcrys erneuert.

* * *


## Kenndaten

- Typ: Wahlpflicht
- Gegend: Dörrland
- Erfahrung: 4500

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Shannara_und_die_Ellcrys-Heilung)
