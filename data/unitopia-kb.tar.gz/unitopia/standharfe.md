---
type: Wiki Article
title: Standharfe
description: Zu kaufen bei Ikealix in seinem Möbelhaus am Nordküstenweg.
resource: "http://unitopia.intelligense.de/wiki/Standharfe"
tags: [Fundort/Kauf, Gegenstand, Gegenstand/Gallien, Gegenstand/Gallien/Möbel, Gegenstand/Möbel, Info, Info/Gewicht, Info/Gewicht/unbeweglich, Info/Material, Info/Material/Holz]
timestamp: 2024-04-23T19:28:33Z
revid: 229435
namespace: 0
contenthash: fae4ee1adb70d35f53c2b7af9b966353cb73df91fc0e15a3c9e0465af8a73d4e
---

## Aussehen

Vor dir steht eine riesige Standharfe. Aus einem maechtigen Fuss, der am
Boden festgeschraubt wurde und einige Pedale traegt, geht eine grosse
Harfensaeule aus geschnitztem Elfenbein fast anderthalb Meter in die Hoehe.
Oben, am Kopf der Saeule geht ein weit geschwungener Hals ab, der in einem
ebenfalls geschwungenen Knie in den grossen Resonanzkoerper bis hinab zum
Harfenfuss uebergeht. Von 22 Stimmstiften gezogene Saiten, die seltsam blau
schimmern, laufen vom Hals bis zur Aufhaengeleiste am Resonanzkoerper.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [unbeweglich](/kategorie/info-gewicht-unbeweglich.md "Kategorie:Info/Gewicht/unbeweglich") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Ikealix](/ikealix.md "Ikealix") in seinem [Möbelhaus](/möbelhaus.md "Möbelhaus") am [Nordküstenweg](/nordküstenweg.md "Nordküstenweg").

## Funktion

-   setze an harfe
-   spiel harfe

## Besonderheit

Kann von einem Mitglied der [Bardengilde](/bardengilde.md "Bardengilde") benutzt werden.

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Möbel
- Gegend: Gallien
- Material: Holz
- Gewicht: unbeweglich
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Standharfe)
