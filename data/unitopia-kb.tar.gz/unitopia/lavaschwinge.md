---
type: Wiki Article
title: Lavaschwinge
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Lavaschwinge"
tags: [NPC, NPC/Midgard, NPC/Midgard/defensiv, NPC/Vaniorh, NPC/Vaniorh/defensiv, NPC/defensiv, Rasse, Rasse/Elementar, Rasse/Reptil, Rasse/multi, Transport, Transport/Luft, Transport/Midgard, Transport/Midgard/Luft, Transport/Vaniorh, Transport/Vaniorh/Luft, Tätigkeit, Tätigkeit/Transporteur]
timestamp: 2018-11-07T18:31:22Z
revid: 250783
namespace: 0
contenthash: 5a76c9b90f780073fdd1f7f46873d8eb7eb945b28fb433ababe2425718aff9e4
---

## Aussehen

Vor dir befindet sich etwas, was die an eine riesige urzeitliche Flugechse
erinnert. Es strahlt eine unheimliche Hitze aus. Seine gluehenden Augen
durchbohren dich. Aus dem Mund tropft gluehende Lava. Es ist mit
dunkelgrauen, steinernen Schuppen bedeckt zwischen denen es orange-roetlich
glueht. Die Schwingen haben einen halbfluessigen Charakter, als waere
dieses Ungeheuer gerade frisch Lava entstiegen. Auf dem Ruecken und zu den
Seiten herablaufen hat es groessere, dunklere, hoeckerfoermige Schuppen. Es
sieht so aus, als waeren diese kalt genug, um darueber auf den Ruecken des
Tieres zu klettern. Das Tier traegt ein Geschirr aus dunklem, magisch
gehaertetem Eisen, das scharf in sein Fleisch einschneidet. Die Zuegel aus
Dornenketten muenden in Reifen, die mit blau leuchtenden Runen verziert
sind.

## Ausrüstung

Keine.

## Heimat

1.  Auf einem Hügel westlich von [Glamoth](/glamoth.md "Glamoth") in [Mowan](/mowan.md "Mowan").
2.  Auf einer Bergkuppe in den [Orkbergen](/orkbergen.md "Orkbergen").

## Besonderheit

Sein Pilot ist meist ein [uralter Ork](/ork-lavaschwinge.md "Ork/Lavaschwinge"), doch gelegentlich hat der Pilot auch ein anderes Adjektiv.


## Kenndaten

- Typ: defensiv
- Gegend: Midgard/Vaniorh
- Rasse: Elementar/Reptil
- Tätigkeit: Transporteur

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Lavaschwinge)
