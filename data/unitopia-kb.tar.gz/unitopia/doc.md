---
type: Wiki Article
title: Doc
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Doc"
tags: [NPC, NPC/Ebenen, NPC/Ebenen/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Heiler]
timestamp: 2018-11-07T18:37:03Z
revid: 212910
namespace: 0
contenthash: 6784b8dea67a11f3f59d44fee038d6c34d15301f154e9323365199861cfaca1d
---

## Aussehen

Ein aelterer untersetzer Mann, der entweder gerne isst oder trinkt oder
beides. Er hat einen kugelrunden Bauch den er auf zwei duennen Beinen
traegt. Ein grauer Schnurrbart der Extraklasse ziert sein rundes Gesicht.
Seine grauen Augen schauen durch durch seinen Zwicker an. Sein Haar hat er
nach hinten gekaemmt, so dass seine Geheimratsecken in aller Pracht zu
sehen sind.
Im gruenen Gilet ueber seinem schwarzen Hemd steckt ein Flachmann.

## Ausrüstung

Keine.

## Heimat

In Doc Frankies Behandlungsstube in [Ameros](/ameros.md "Ameros") auf [Amerindia](/amerindia.md "Amerindia").

## Besonderheit

Heilt [Krankheiten](/kategorie/zustand-krankheit.md "Kategorie:Zustand/Krankheit"), [Vergiftungen](/kategorie/zustand-vergiftung.md "Kategorie:Zustand/Vergiftung"), [Verletzungen](/kategorie/zustand-verletzung.md "Kategorie:Zustand/Verletzung") und [Flüche](/kategorie/zustand-fluch.md "Kategorie:Zustand/Fluch").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Ebenen
- Rasse: Mensch
- Tätigkeit: Heiler

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Doc)
