---
type: Wiki Article
title: "Leder-Rüstung/Schmuggler"
description: ""
resource: "http://unitopia.intelligense.de/wiki/Leder-Rüstung/Schmuggler"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/3, Info/Material, Info/Material/Leder, Info/Rüstungsstärke, Info/Rüstungsstärke/gut, Info/Rüstungszustand, Info/Rüstungszustand/sehr solide, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Rüstung, Rüstung/Brust, Rüstung/Vaniorh, Rüstung/Vaniorh/Brust]
timestamp: 2024-03-02T19:18:11Z
revid: 227521
namespace: 0
contenthash: f523b41d8a88256bab9e2cb56f96d84b5a34acb908aca75a85d067184721ce95
---

## Aussehen

Eine schmucke Leder-Ruestung. Gefertigt aus feinem Wildschweinleder.   
Hoffentlich haelt die auch ein paar Schlaege ab.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [4 (gut)](/kategorie/info-rüstungsstärke-gut.md "Kategorie:Info/Rüstungsstärke/gut") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [7 (sehr solide)](/kategorie/info-rüstungszustand-sehr-solide.md "Kategorie:Info/Rüstungszustand/sehr solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [3 (schon eher leicht)](/kategorie/info-gewicht-3.md "Kategorie:Info/Gewicht/3") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Rüstung vom [Schmuggler](/schmuggler.md "Schmuggler") in der [Eisenhütte](/eisenhütte.md "Eisenhütte") von [Tadmor](/tadmor.md "Tadmor").
-   Rüstung vom [betrunkenen Schmuggler](/schmuggler.md "Schmuggler") in der [Eisenhütte](/eisenhütte.md "Eisenhütte") von [Tadmor](/tadmor.md "Tadmor").

* * *


## Kenndaten

- Kategorie: Rüstung
- Typ: Brust
- Gegend: Vaniorh
- Material: Leder
- Temperaturschutz: wärmt etwas
- Rüstungsstärke: gut
- Rüstungszustand: sehr solide
- Gewicht: 3
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Leder-Rüstung/Schmuggler)
