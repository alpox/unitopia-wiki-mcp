---
type: Wiki Article
title: Ring/Knopflabyrinth3
description: "In den Tiefen des großen Knopf-Labyrinths."
resource: "http://unitopia.intelligense.de/wiki/Ring/Knopflabyrinth3"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Edelmetall, Kleidung, Kleidung/Dörrland, Kleidung/Dörrland/Finger, Kleidung/Finger]
timestamp: 2024-03-02T19:20:43Z
revid: 222177
namespace: 0
contenthash: abc4313f5ad45e337241d2801c82d79927d52843195206ef0a02c34a791c7ddc
---

## Aussehen

Ein Mithrilring.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Edelmetall](/kategorie/info-material-edelmetall.md "Kategorie:Info/Material/Edelmetall") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

In den Tiefen des [großen Knopf-Labyrinths](/knopflabyrinth.md "Knopflabyrinth").

## Funktion

Der angezogene Ring verändert die Maximalen [ZP](/zp.md "ZP")[![Zauberpunkte](/images/4/4c/ZP.gif)](/zp.md "Zauberpunkte") oder [AP](/ap.md "AP")[![Ausdauerpunkte](/images/b/b4/AP.gif)](/ap.md "Ausdauerpunkte") um einen vom jeweiligen Ring individuell abhängigen positiven oder negativen Betrag.

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Finger
- Gegend: Dörrland
- Material: Edelmetall
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Ring/Knopflabyrinth3)
