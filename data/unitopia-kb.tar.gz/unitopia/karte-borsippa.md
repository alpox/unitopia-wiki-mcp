---
type: Wiki Article
title: Karte/Borsippa
description: Ein Stadtplan von Borsippa.
resource: "http://unitopia.intelligense.de/wiki/Karte/Borsippa"
tags: [Fundort/Kauf, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Papier, Info/Schwimmt, Schriften, Schriften/Karte, Schriften/Vaniorh, Schriften/Vaniorh/Karte]
timestamp: 2024-04-23T19:28:04Z
revid: 230993
namespace: 0
contenthash: affae0251e3dc861af7ba3cd5658d12529435d3875269479f6cd1fd1114c1c0f
---

## Aussehen

                                  Zugbruecke \_/\\_        Steinmetz Trainer
                                             |  |\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_| |\_\_| |\_\_
                                            / \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_   \_\_   \_\_Club
                                           / /\_\_Schuh-          | |  | |/^\
                                          / \_\_\_\_macher         Spiel-|  |#|
                                     /^\ / /                   platz | |
                                     |#|  /                          | |
                                       / /\_\_Scheren-       Schneider / |
                                      / \_\_\_\_schleifer           | | / /
                                     / /                        | |/ /
                                     \ \Schmied                 |   /
                                    \_\_\ \\_| |\_\_               \_\_|  /
                           Alchemisten-  Platz \         Laden\_\_  |
                             Gilde \_\_\_\_\_\_\_   \_\_ \               | |
                                          | |  \ \            \_\_| |\_\_
                                 Buergermeister\_\ \    Baecker\_\_   \_\_Konditor
                                        Gasthof\_\_\_ \ Bank  Post | |
  \_\_\_\_  \_\_\_\_\_  \_\_\_\_  \_\_\_  \_\_\_\_  \_\_\_\_  \_\_\_\_   \_\_   \ \\_| |\_\_| |\_\_| |
 (  \_ \(  \_  )(  \_ \/ \_\_)(\_  \_)(  \_ \(  \_ \ /\_\_\   \\_\_   \_\_\_\_\_\_\_ \_/\\_
  ) \_ < )(\_)(  )   /\\_\_ \ \_)(\_  )\_\_\_/ )\_\_\_//(\_\_)\     /^\        |  |
 (\_\_\_\_/(\_\_\_\_\_)(\_)\\_)(\_\_\_/(\_\_\_\_)(\_\_)  (\_\_) (\_\_)(\_\_)    |#|      Stadttor 

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Papier](/kategorie/info-material-papier.md "Kategorie:Info/Material/Papier") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

-   Zu kaufen bei [Sascha](/sascha.md "Sascha") in der NW-Ecke vom Trödlermarkt in [Tadmor](/tadmor.md "Tadmor").
-   Im Regal im Aufenthaltsraum der [Abenteurergilde](/abenteurergilde.md "Abenteurergilde") von [Tadmor](/tadmor.md "Tadmor").

## Inhalt

Ein Stadtplan von [Borsippa](/borsippa.md "Borsippa").

* * *


## Kenndaten

- Kategorie: Schriften
- Typ: Karte
- Gegend: Vaniorh
- Material: Papier
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Karte/Borsippa)
