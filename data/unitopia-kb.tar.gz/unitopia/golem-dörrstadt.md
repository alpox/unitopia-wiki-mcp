---
type: Wiki Article
title: Golem/Dörrstadt
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Golem/Dörrstadt"
tags: [NPC, NPC/Dörrland, NPC/Dörrland/defensiv, NPC/defensiv, Rasse, Rasse/Golem]
timestamp: 2018-11-07T18:46:15Z
revid: 215083
namespace: 0
contenthash: 30d99529552ed520afc6eee0fb450457bcd4828de485444c1f2a19ff772a3cc3
---

## Aussehen

Der Golem scheint den Raum zu bewachen, damit er nicht wegkommt.

## Ausrüstung

Keine.

## Heimat

-   Im Schließfachraum von [Edes Laden](/ede.md "Ede") in [Dörrstadt](/dörrstadt.md "Dörrstadt"),
-   Im Schließfachraum der [Landesbank](/alt-dörrstadt.md "Alt-Dörrstadt") von [Alt-Dörrstadt](/alt-dörrstadt.md "Alt-Dörrstadt").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Dörrland
- Rasse: Golem

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Golem/Dörrstadt)
