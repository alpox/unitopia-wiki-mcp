---
type: Wiki Article
title: Tuch/Niklas
description: Kleidung von Niklas Nordhaf in der Messe der Wappen von Hamburg.
resource: "http://unitopia.intelligense.de/wiki/Tuch/Niklas"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Info/Temperaturschutz, Info/Temperaturschutz/hält etwas kühl, Kleidung, Kleidung/Hände, Kleidung/Nordische Inseln, Kleidung/Nordische Inseln/Hände, Kleidung/Ozean, Kleidung/Ozean/Hände, Kleidung/Vaniorh, Kleidung/Vaniorh/Hände]
timestamp: 2024-03-02T19:19:07Z
revid: 255088
namespace: 0
contenthash: 8227dba475dedf384a41ec453aa9683eae691452fe7403dda4f707f25af514ab
---

## Aussehen

Ein weisses Tuch, wie es Kellner ueber dem Arm tragen. Es ist weiss und
riecht wie frisch gewaschen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [hält etwas kühl](/kategorie/info-temperaturschutz-hält-etwas-kühl.md "Kategorie:Info/Temperaturschutz/hält etwas kühl") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Kleidung von [Niklas Nordhaf](/niklas.md "Niklas") in der Messe der [Wappen von Hamburg](/wappen-von-hamburg.md "Wappen von Hamburg").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Hände
- Gegend: Nordische Inseln/Ozean/Vaniorh
- Material: Textil
- Temperaturschutz: hält etwas kühl
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Tuch/Niklas)
