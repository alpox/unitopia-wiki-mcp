---
type: Wiki Article
title: Piratenaxt
description: Waffe von Paul im Piratenlager am Strand auf Tobago.
resource: "http://unitopia.intelligense.de/wiki/Piratenaxt"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/4, Info/Material, Info/Material/Holz, Info/Material/Metall, Info/Waffenstärke, Info/Waffenstärke/prima, Info/Waffenzustand, Info/Waffenzustand/recht beständig, Waffe, Waffe/Axt, Waffe/Dörrland, Waffe/Dörrland/Axt]
timestamp: 2024-03-02T19:17:11Z
revid: 232553
namespace: 0
contenthash: fb06d9870be06b03a418344afad7ea8a5af4bf3a874b458aba7d751bc41d82a7
---

## Aussehen

Eine kurzstielige, schwere Axt. Sie ist scharf geschliffen und eignet sich
bestens für Kaempfe auf engstem Raume.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall"), [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [7 (prima)](/kategorie/info-waffenstärke-prima.md "Kategorie:Info/Waffenstärke/prima") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [5 (recht beständig)](/kategorie/info-waffenzustand-recht-beständig.md "Kategorie:Info/Waffenzustand/recht beständig") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [4 (gerade noch leicht)](/kategorie/info-gewicht-4.md "Kategorie:Info/Gewicht/4") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Waffe von [Paul](/paul.md "Paul") im Piratenlager am Strand auf [Tobago](/tobago.md "Tobago").


## Kenndaten

- Kategorie: Waffe
- Typ: Axt
- Gegend: Dörrland
- Material: Metall/Holz
- Waffenstärke: prima
- Waffenzustand: recht beständig
- Gewicht: 4
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Piratenaxt)
