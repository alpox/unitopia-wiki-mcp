---
type: Wiki Article
title: Feuerkobold
description: Ein Feuerschwert.
resource: "http://unitopia.intelligense.de/wiki/Feuerkobold"
tags: [NPC, NPC/Vaniorh, NPC/Vaniorh/defensiv, NPC/defensiv, Rasse, Rasse/Elementar, Rasse/Kobold, Rasse/multi]
timestamp: 2018-11-07T18:26:22Z
revid: 218292
namespace: 0
contenthash: fc527cbdcee13188b83fe1dafd877f663f4ebf8d2c01db4690beddac231ed371
---

## Aussehen

Der Feuerkobold ist ziemlich klein, hat aber dicke Muskeln. Er huepft sehr
flink von einem Bein auf das andere und schaut Dich dabei aus glutroten
Augen an. Er hat einen feuerroten, langen, zottigen Bart. Viele Flammen
bewegen sich flink um ihn herum. Reize ihn lieber nicht, er sieht aus, als
ob er auf seinen flinken Beinchen und kraeftigen Armen ein aeusserst
gefaehrlicher Gegner ist.

## Ausrüstung

Ein [Feuerschwert](/feuerschwert.md "Feuerschwert").

## Heimat

Im Tunnel der [Minen](/ebene-tadmor.md "Ebene/Tadmor") nördlich der [Tadmor-Ebene](/ebene-tadmor.md "Ebene/Tadmor").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Vaniorh
- Rasse: Elementar/Kobold

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Feuerkobold)
