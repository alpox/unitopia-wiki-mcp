---
type: Wiki Article
title: Quellwasser/Tadmor
description: Im Bach auf einer Kuhweide nahe des Weges zur Bibliothek von Tadmor.
resource: "http://unitopia.intelligense.de/wiki/Quellwasser/Tadmor"
tags: [Flüssigkeit, Flüssigkeit/neutral, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/durstlöschend, Nahrung, Nahrung/Getränk, Nahrung/Vaniorh, Nahrung/Vaniorh/Getränk]
timestamp: 2024-08-29T15:19:51Z
revid: 247299
namespace: 0
contenthash: 7686acefd671307591bfef9b23eb8bebaa3ff4e067788dda96c0501f396520b0
---

## Aussehen

_Quellwasser_

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend") |

## Fundort

Im Bach auf einer Kuhweide nahe des Weges zur [Bibliothek](/tadmor.md "Tadmor") von [Tadmor](/tadmor.md "Tadmor").

## Besonderheit

Mit dieser [Flüssigkeit](/kategorie/flüssigkeit.md "Kategorie:Flüssigkeit") kann man [Trinkgefäße](/gefäß.md "Gefäß") und das [Spritzgewehr](/spritzgewehr.md "Spritzgewehr") befüllen.

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Getränk
- Gegend: Vaniorh
- Gewicht: 1
- Wirkung: durstlöschend

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Quellwasser/Tadmor)
