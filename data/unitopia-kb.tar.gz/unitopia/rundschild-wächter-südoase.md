---
type: Wiki Article
title: Rundschild/Wächter/Südoase
description: Schild der aufmerksamen Wächter in der Südoase.
resource: "http://unitopia.intelligense.de/wiki/Rundschild/Wächter/Südoase"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Holz, Info/Material/Metall, Info/Rüstungsstärke, Info/Rüstungsstärke/gut, Info/Rüstungszustand, Info/Rüstungszustand/sehr solide, Info/Schwimmt, Waffe, Waffe/Dörrland, Waffe/Dörrland/Kleinschild, Waffe/Kleinschild]
timestamp: 2024-03-02T19:18:56Z
revid: 230059
namespace: 0
contenthash: 7c953893bd0dae67370d3d5523b878831f898c79a2119c934b3d0ed41f07fa88
---

## Aussehen

Der Schild ist rund und wurde aus Holz gezimmert und mit Metall verstaerkt.
Ein goldenes Wappen ist auf seiner Vorderseite zu sehen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz"), [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [4 (gut)](/kategorie/info-rüstungsstärke-gut.md "Kategorie:Info/Rüstungsstärke/gut") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [7 (sehr solide)](/kategorie/info-rüstungszustand-sehr-solide.md "Kategorie:Info/Rüstungszustand/sehr solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Schild der [aufmerksamen Wächter](/wächter-südoase.md "Wächter/Südoase") in der [Südoase](/südoase.md "Südoase").

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Kleinschild
- Gegend: Dörrland
- Material: Holz/Metall
- Rüstungsstärke: gut
- Rüstungszustand: sehr solide
- Gewicht: 2
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Rundschild/Wächter/Südoase)
