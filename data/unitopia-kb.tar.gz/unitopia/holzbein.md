---
type: Wiki Article
title: Holzbein
description: "Vom Skelett in einem engen, dunklen Gang der Festung Dol Guldur."
resource: "http://unitopia.intelligense.de/wiki/Holzbein"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/3, Info/Material, Info/Material/Holz, Info/Schwimmt, Info/Waffenstärke, Info/Waffenstärke/geht so, Info/Waffenzustand, Info/Waffenzustand/recht beständig, Waffe, Waffe/Keule, Waffe/Midgard, Waffe/Midgard/Keule]
timestamp: 2024-03-02T19:20:59Z
revid: 232275
namespace: 0
contenthash: b0a06014722c77f79dc88158ab0866032ac58b3c6239a521e83e8d9f6761f57d
---

## Aussehen

Ein schweres, aus Eichenholz gefertigtes Holzbein. Es laeuft nach unten hin
spitz zu. Oben hat es einen herausschauenden Holzbolzen, an dem man das
Holzbein am Oberschenkel befestigen konnte. Irgendwie erinnert es dich an
einen Pruegel...

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [4 (geht so)](/kategorie/info-waffenstärke-geht-so.md "Kategorie:Info/Waffenstärke/geht so") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [5 (recht beständig)](/kategorie/info-waffenzustand-recht-beständig.md "Kategorie:Info/Waffenzustand/recht beständig") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [3 (schon eher leicht)](/kategorie/info-gewicht-3.md "Kategorie:Info/Gewicht/3") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Vom [Skelett](/skelett-dol-guldur.md "Skelett/Dol Guldur") in einem engen, dunklen Gang der [Festung Dol Guldur](/dol-guldur.md "Dol Guldur").

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Keule
- Gegend: Midgard
- Material: Holz
- Waffenstärke: geht so
- Waffenzustand: recht beständig
- Gewicht: 3
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Holzbein)
