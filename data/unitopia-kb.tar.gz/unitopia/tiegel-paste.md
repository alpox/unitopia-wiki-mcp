---
type: Wiki Article
title: Tiegel/Paste
description: Von einem Mitglied des Hexenvolkes.
resource: "http://unitopia.intelligense.de/wiki/Tiegel/Paste"
tags: [Fundort, Gegenstand, Gegenstand/Nordische Inseln, Gegenstand/Nordische Inseln/Sonstige, Gegenstand/Sonstige, Hidden, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Unbekannt, Subpages, Subpages/Content, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2024-09-16T12:12:42Z
revid: 261640
namespace: 0
contenthash: 8668bcba99b05dc8a426c353fa007045a242a6e0ee942ad85ca261c551dcd650
---

< [Hexenvolk](/hexenvolk.md "Hexenvolk") < [Rezepte](/hexenvolk.md "Hexenvolk")

## Aussehen

In diesem Tiegel befindet sich eine seltsame, rostrote, pudrig wirkende
Substanz. Du glaubst, es handele sich hierbei um das natuerliche
Faerbemittel 'Henna', das neben Haarfaerbungen auch zu nichtpermanenten
Tattoos und anderen farbintensiven Koerperbemalungen genutzt wird.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Unbekannt](/kategorie/info-material-unbekannt.md "Kategorie:Info/Material/Unbekannt") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Von einem Mitglied des [Hexenvolkes](/hexenvolk.md "Hexenvolk").

## Funktion

-   Damit gezeichnet oder bestrichen wirkt die Paste Gesinnungsänderungen entgegen.
-   zeichne <Person> mit Eisenpaste
-   zeichne mich mit Eisenpaste
-   bestreiche <Person> mit Eisenpaste
-   bestreiche <Person> mit Eisenpaste

## Besonderheit

Zusätzliches Aussehen beim Betrachten einer Person - Bestrichen:

| **Alle:** | Auf <Person>s Stirn sieht man ein rostrotes Heptagramm. |
| --- | --- |

* * *


## Kenndaten

- Typ: Content
- Kategorie: Gegenstand
- Gegend: Nordische Inseln
- Material: Unbekannt
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein
- Alle: Auf s Stirn sieht man ein rostrotes Heptagramm.

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Tiegel/Paste)
