---
type: Wiki Article
title: Strümpfe/Nachtclub2
description: Im Lagerraum des Nachtclubs von Merredin.
resource: "http://unitopia.intelligense.de/wiki/Strümpfe/Nachtclub2"
tags: [Hidden, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Kleidung, Kleidung/Füße, Kleidung/Midgard, Kleidung/Midgard/Füße, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2024-03-02T19:20:27Z
revid: 261395
namespace: 0
contenthash: 115181df159d8e5fbb053c4f28870d0611afa858d01e023e091ec862c84b65f8
---

## Aussehen

Lange, gruene Struempfe mit einem Muster aus dunklen Ranken und roten
Blueten.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Im Lagerraum des [Nachtclubs](/nachtclub.md "Nachtclub") von [Merredin](/merredin.md "Merredin").

## Besonderheit

Zusätzliches Aussehen beim Betrachten einer Person:

| -   **Mann:** | Er traegt dunkelgruene Struempfe mit einem Muster, das wie Ranken von exotischen Pflanzen aussieht. Sie wirken wie lebendig und winden sich an seinen Beinen empor. Dunkle, rote Blueten verbergen sich darin. Sie leuchten in einem dunklen Licht, das dem Betrachter die Sinne verwirrt. |
| --- | --- |
| -   **Frau:** | Sie traegt dunkelgruene Struempfe mit einem Muster, das wie Ranken von exotischen Pflanzen aussieht. Sie wirken wie lebendig und winden sich an ihren Beinen empor. Dunkle, rote Blueten verbergen sich darin. Sie leuchten in einem dunklen Licht, das dem Betrachter die Sinne verwirrt. |
| -   **Etwas:** | Es traegt dunkelgruene Struempfe mit einem Muster, das wie Ranken von exotischen Pflanzen aussieht. Sie wirken wie lebendig und winden sich an seinen Beinen empor. Dunkle, rote Blueten verbergen sich darin. Sie leuchten in einem dunklen Licht, das dem Betrachter die Sinne verwirrt. |

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Füße
- Gegend: Midgard
- Material: Textil
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Strümpfe/Nachtclub2)
