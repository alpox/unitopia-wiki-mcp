---
type: Wiki Article
title: Rüschenkleid
description: Zu kaufen bei Mareen in ihrem Laden für Bekleidung in Knossos auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/Rüschenkleid"
tags: [Fundort/Kauf, Hidden, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Kleidung, Kleidung/Brust, Kleidung/Kokosinseln, Kleidung/Kokosinseln/Brust, ZusatzAussehen, ZusatzAussehen/Frau]
timestamp: 2024-04-23T19:28:20Z
revid: 261702
namespace: 0
contenthash: f1c6e5a32c2e38b1271b11de0ac5766dec3f7d1db23db87a565e93442278fd17
---

## Aussehen

Ein weites, fliessendes Kleid aus weissem Stoff. Liegt es am Oberkoerper
noch fest, fast schon stuetzend auf der Haut, so schmiegt es sich an Beinen
und Armen nur noch federleicht darum und schwingt bei jeder Bewegung mit.
Ausserdem sind Rock, Aermel sowie Kragen mit Rueschen aus weisser Spitze
verziert.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Mareen](/mareen.md "Mareen") in ihrem Laden für Bekleidung in [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").

## Besonderheit

Zusätzliches Aussehen beim Betrachten einer Person:

| **Frau:** | Sie huellt sich in ein weit fallendes, weisses Kleid, das mit Rueschen aus ebenso weisser Spitze besetzt wurde. Sie sieht darin so bezaubernd aus, wie ein Engel. |
| --- | --- |

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Brust
- Gegend: Kokosinseln
- Material: Textil
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Rüschenkleid)
