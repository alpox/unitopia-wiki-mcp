---
type: Wiki Article
title: Perle/rote unförmige
description: ""
resource: "http://unitopia.intelligense.de/wiki/Perle/rote_unförmige"
tags: [Fundort, Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Edelstein, Mineral, Mineral/Kokosinseln, Mineral/Kokosinseln/Perle, Mineral/Perle]
timestamp: 2024-09-16T12:11:31Z
revid: 240152
namespace: 0
contenthash: 20eb858a36a91272aed342e2bfec3877c42f0db76bf05257a3e16db1f4f59633
---

## Aussehen

Das ist eine rote, unfoermige Perle. Sie sieht wunderschoen aus.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Edelstein](/kategorie/info-material-edelstein.md "Kategorie:Info/Material/Edelstein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Als Belohnung von [Audrus](/audrus.md "Audrus") in der [alten Mine](/cyprus.md "Cyprus") auf [Cyprus](/cyprus.md "Cyprus").
-   In den [Muscheln](/muschel-cyprus.md "Muschel/Cyprus") an den [Sandstränden](/cyprus.md "Cyprus") auf [Cyprus](/cyprus.md "Cyprus").
-   Nach dem Töten der [Geschöpfe](/verfluchter-wald.md "Verfluchter Wald") im [verfluchten Wald](/verfluchter-wald.md "Verfluchter Wald") auf [Cyprus](/cyprus.md "Cyprus").

## Wirkung

| Waffe | Effekt |
| --- | --- |
| [blauglänzende Axt](/axt-blauglänzende.md "Axt/blauglänzende") |  |
| [blauglänzender Degen](/degen-blauglänzender.md "Degen/blauglänzender") |  |
| [blauglänzender Dolch](/dolch-blauglänzender.md "Dolch/blauglänzender") |  |
| [blauglänzender Kampfhammer](/kampfhammer-blauglänzender.md "Kampfhammer/blauglänzender") |  |
| [blauglänzender Kampfstab](/kampfstab-blauglänzender.md "Kampfstab/blauglänzender") |  |
| [blauglänzendes Kurzschwert](/kurzschwert-blauglänzendes.md "Kurzschwert/blauglänzendes") |  |
| [blauglänzendes Langschwert](/langschwert-blauglänzendes.md "Langschwert/blauglänzendes") |  |
| [blauglänzender Säbel](/säbel-blauglänzender.md "Säbel/blauglänzender") |  |

* * *


## Kenndaten

- Kategorie: Mineral
- Typ: Perle
- Gegend: Kokosinseln
- Material: Edelstein
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Perle/rote_unförmige)
