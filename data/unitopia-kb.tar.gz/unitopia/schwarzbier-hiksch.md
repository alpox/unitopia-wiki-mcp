---
type: Wiki Article
title: Schwarzbier/Hiksch
description: Zu kaufen bei Hiksch in der Schänke von Koboldingen.
resource: "http://unitopia.intelligense.de/wiki/Schwarzbier/Hiksch"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/betrunken, Info/Wirkung/durstlöschend, Nahrung, Nahrung/Alkohol, Nahrung/Märchenland, Nahrung/Märchenland/Alkohol]
timestamp: 2024-08-29T15:15:41Z
revid: 249206
namespace: 0
contenthash: 557d82df9c3a0080df140722b98d6be2f86a2881f426ec0fcd763c19270ff6cc
---

## Aussehen

Eine schwarzbraune Fluessigkeit mit Schaum obendrauf. Sieht nicht wirklich
wie Bier aus.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend"), [betrunken](/kategorie/info-wirkung-betrunken.md "Kategorie:Info/Wirkung/betrunken") |

## Fundort

Zu kaufen bei [Hiksch](/hiksch.md "Hiksch") in der Schänke von [Koboldingen](/koboldingen.md "Koboldingen").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Alkohol
- Gegend: Märchenland
- Gewicht: 1
- Wirkung: durstlöschend/betrunken

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schwarzbier/Hiksch)
