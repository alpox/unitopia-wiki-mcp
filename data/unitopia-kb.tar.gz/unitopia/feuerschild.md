---
type: Wiki Article
title: Feuerschild
description: Durch den schwarzen Obsidianring von Rexerus im Vorraum des schwarzen Turmes auf der Nekromanteninsel.
resource: "http://unitopia.intelligense.de/wiki/Feuerschild"
tags: [Info, Info/Gewicht, Info/Gewicht/0, "Info/Gewicht/0-9", Info/Licht, Info/Licht/leuchtet, Info/Material, Info/Material/Feuer, Info/Rüstungsstärke, Info/Rüstungsstärke/prima, Info/Rüstungszustand, Info/Rüstungszustand/solide, Waffe, Waffe/Großschild, Waffe/Midgard, Waffe/Midgard/Großschild]
timestamp: 2024-03-02T19:17:39Z
revid: 230014
namespace: 0
contenthash: 8e86b48556cabcef571ea9c98a3bf1c448ca56d8c712ec61d0729c44358be66b
---

## Aussehen

Ein Schild, der aus roten und blauen Flammen besteht.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Feuer](/kategorie/info-material-feuer.md "Kategorie:Info/Material/Feuer") |
| --- | --- |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [5 (prima)](/kategorie/info-rüstungsstärke-prima.md "Kategorie:Info/Rüstungsstärke/prima") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [6 (solide)](/kategorie/info-rüstungszustand-solide.md "Kategorie:Info/Rüstungszustand/solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [0 (federleicht)](/kategorie/info-gewicht-0.md "Kategorie:Info/Gewicht/0") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel"), [+1 (leuchtet normal)](/kategorie/info-licht-leuchtet.md "Kategorie:Info/Licht/leuchtet") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Durch den [schwarzen Obsidianring](/obsidianring-rexerus.md "Obsidianring/Rexerus") von [Rexerus](/rexerus.md "Rexerus") im Vorraum des [schwarzen Turmes](/erzmagierturm.md "Erzmagierturm") auf der [Nekromanteninsel](/nekromanteninsel.md "Nekromanteninsel").

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Großschild
- Gegend: Midgard
- Material: Feuer
- Rüstungsstärke: prima
- Rüstungszustand: solide
- Gewicht: 0
- Licht: 0/+1
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Feuerschild)
