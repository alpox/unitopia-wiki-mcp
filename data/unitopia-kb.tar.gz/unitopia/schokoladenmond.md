---
type: Wiki Article
title: Schokoladenmond
description: Im Adventskalender in der Küche der Villa von Knossos auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/Schokoladenmond"
tags: [Fundort, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Kokosinseln, Nahrung/Kokosinseln/Produkt, Nahrung/Produkt]
timestamp: 2024-09-16T12:10:08Z
revid: 267661
namespace: 0
contenthash: 05c2deeca48d7790e6d25779fed73ccaed788c42277894510f4c247a435c85b1
---

## Aussehen

Das ist ein kleiner Halbmond aus Schokolade. Er hat ein Gesicht mit Augen,
Mund und spitzer Nase.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Im [Adventskalender](/adventskalender-knossos.md "Adventskalender/Knossos") in der Küche der [Villa](/knossos.md "Knossos") von [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Kokosinseln
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schokoladenmond)
