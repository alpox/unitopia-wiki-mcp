---
type: Wiki Article
title: Beine
description: Abzuschneiden vom toten Wildesel auf Kreta und Phrygia.
resource: "http://unitopia.intelligense.de/wiki/Beine"
tags: [Gegenstand, Gegenstand/Kokosinseln, Gegenstand/Kokosinseln/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Bein]
timestamp: 2024-03-02T19:21:35Z
revid: 231554
namespace: 0
contenthash: f340509429f325aaa5a80844215934b7a0942b1cd58ea295d146f1ac4df63f01
---

## Aussehen

Zwei sehnige, lange Beine eines Wildesels. Sie erinnern dich etwas an die
Beine eines Zebras, da sie ebenfalls gestreift sind.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Bein](/kategorie/info-material-bein.md "Kategorie:Info/Material/Bein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Abzuschneiden vom [toten Wildesel](/wildesel.md "Wildesel") auf [Kreta](/kreta.md "Kreta") und [Phrygia](/phrygia.md "Phrygia").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Kokosinseln
- Material: Bein
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Beine)
