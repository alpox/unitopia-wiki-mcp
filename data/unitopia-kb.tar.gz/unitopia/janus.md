---
type: Wiki Article
title: Janus
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Janus"
tags: [NPC, NPC/Kokosinseln, NPC/Kokosinseln/defensiv, NPC/Ozean, NPC/Ozean/defensiv, NPC/Vaniorh, NPC/Vaniorh/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Transporteur]
timestamp: 2018-11-07T18:26:32Z
revid: 250887
namespace: 0
contenthash: 36f937deed08662a79764bd5acb62119e1bead9c5ffcf2ff24422a43d1186cf7
---

## Aussehen

Janus, der Kapitaen der Argo. Er hat mit dem bekannten Gott der Wege nur
eines gemein: er hat zwei Gesichter! Das Ganze ist wohl auf einen
genetischen Defekt zurueckzufuehren. So kommt's, dass Janus, ohne sich
einmal herumzudrehen, das Schiff manoevrieren kann...

## Ausrüstung

Keine.

## Heimat

Auf der Kommando-Brücke der [Argo](/argo.md "Argo").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Kokosinseln/Ozean/Vaniorh
- Rasse: Mensch
- Tätigkeit: Transporteur

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Janus)
