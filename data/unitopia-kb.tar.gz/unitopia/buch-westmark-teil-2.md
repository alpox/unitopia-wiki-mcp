---
type: Wiki Article
title: Buch/Westmark/Teil 2
description: Im Eingang des großen Bauernhofes von Fabeln.
resource: "http://unitopia.intelligense.de/wiki/Buch/Westmark/Teil_2"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Papier, Info/Schwimmt, Schriften, Schriften/Buch, Schriften/Midgard, Schriften/Midgard/Buch]
timestamp: 2024-03-02T19:18:23Z
revid: 229970
namespace: 0
contenthash: 10ff474d8e8053cd18f5a07411d92337fe7b7e3719657815332809c986b909da
---

## Aussehen

Eine Zusammenfassung des Buches von Bilbo Taeschlin, in dem seine Abenteuer
in der ganzen Welt beschrieben werden.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Papier](/kategorie/info-material-papier.md "Kategorie:Info/Material/Papier") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Im Eingang des großen [Bauernhofes](/fabeln.md "Fabeln") von [Fabeln](/fabeln.md "Fabeln").

## Inhalt

Die Abenteuer von [Bilbo Taeschlin](/bilbo.md "Bilbo").

## Faksimile

            Das Rote Buch der Westmark

            Eine Zusammenfassung der aufregenden Abenteuer
            von Herrn Bilbo Taeschlin, wohnhaft in Schneckenhaus,
            Fabeln, Wiesenland im Jahre 3019 auf seiner 
            Reise zum einsamen Berg Erebor und wieder zurueck.

            Vorliegende Auflage enthaelt 2 spannende Kapitel
            der insgesamt 19 Kapitel.
            Kapitel 4 bis Kapitel 5

            Auch "Hin und wieder zurueck" genannt.

            Seite 1

           Zusammenfassung der einzelnen Kapitel:

        1.      Eine unvorhergesehene Gesellschaft      
        2.      Gebratenes Hammelfleisch                 
        3.      Eine kurze Rast                         
        4.      Ueber den Berg und unter den Berg       Seiten 3 - 5
        5.      Raetsel in der Finsternis               Seiten 6 - 9
        6.      Raus aus der Bratpfanne, rein ins Feuer
        7.      Ein sonderbares Quartier
        8.      Fliegen und Spinnen
        9.      Faesser unverzollt
        10.     Ein warmes Willkommen
        11.     Auf der Tuerschwelle
        12.     Erkundung in der Tiefe
        13.     Nicht zu Hause
        14.     Feuer und Wasser
        15.     Die Wolken sammeln sich
        16.     Ein Dieb in der Nacht
        17.     Die Wolken bersten
        18.     Der Weg zurueck
        19.     Das letzte Kapitel
                                        Seite 2

 
                Kapitel 4:
        Ueber den Berg und unter den Berg

        ...in dem beschrieben wird, wie die Wanderer immer weiter
und weiter in die Berge hineingeraten und in der Naehe eines Passes
in ein maechtiges Gewitter mit Regen geraten. In diesem Gewitter
warfen sich maechtige Steinriesen grosse Felsbloecke zu und zer-
schmetterten so grosse Teile der Waelder und Berghaenge.

Die Gefaehrten fluechten sich in eine Hoehle, wo sie sich dann auch
zur Rast begeben. Mitten im Schlaf schreckt dann auf einmal Bilbo
auf und erkennt entsetzt, dass alle Ponies verschwunden sind. 
Gerade, als Bilbo einen Schrei ausstoesst, springen Massen von Orks
aus einer Felsspalt und nehmen Bilbo und die Zwerge gefangen. Nur
der graue Magier kann sich retten, gewarnt vom Schrei des Halblinge.

Die Gefangenen werden von den Orks eine weite Strecke zu ihrem
Anfuehrer geschleppt, einem riesenhaften Ork mit grossem Kopf.

        Fortsetzung von Kapitel 4 auf Seite 4

                Seite 3

                Kapitel 4:

Dort werden sie ueber ihre Ziele und den Grund ihrer Reise ausgefragt.
Erzuernt erkennt der grosse Ork, dass Thorin das maechtige Elfen-
schwert Orkrist bei sich traegt, den Orkspalter, auch Beisser von
den Orks genannt. Kaum eine Waffe fuerchten sie mehr, und kaum
eine Waffe bringt sie in groesseren Zorn gegen seinen Besitzer.

Der grosse Ork will sie umbringen lassen, aber in diesem Moment naht
die Rettung in Gestalt von der graue Magier. Er toetet in einem Flammenblitz
und Funkenflug den grossen Ork mit Glamdring und fuehrt die Zwerge
und Bilbo schnell weg aus der grossen Hoehle. Immer weiter und weiter
geraten sie in das Innere der Berge. Da Bilbo nicht so schnell laufen
kann wie die starken und ausdauernden Zwerge, nimmt Dori ihn hucke-
pack und folgt den anderen.
Aber die Orkmassen, die ihnen nun folgen, holen immer mehr auf,kommen
ihnen immer naeher. Schliesslich sind sie so nahe, dass sich der graue Magier
und Thorin umdrehen muessen, um sich den Orks in dem schmalen Gang
zu Kampfe zu stellen.
                        Fortsetzung von Kapitel 4 auf Seite 5

                Seite 4

                Kapitel 4:

Nichtsahnend laufen die rennenden Orks in die Falle, die ihnen von
der graue Magier und Thorin mit Glamdring und Orkrist gestellt wird. Viele
Orks fallen ueberrascht in diesem harten Kampf, und die Gefaehrten
haben wieder etwas Zeit gewonnen, bis sich die Uebermacht der Orks
sich erneut gegen sie zu wenden beginnt. Die Gefaehrten laufen
schnell weiter.

Aber die Orks schickten erneut Spaeher aus, diesmal ohne Licht, und
holen die Zwerge erneut ein. Dori wird von einem Ork an den Beinen
gepackt und verliert dabei Bilbo, der auf dem harten Fels aufschlaegt
und bewusstlos wird.

                Seite 5

                Kapitel 5:
        Raetsel in der Dunkelheit

        ...in dem beschrieben wird, wie Bilbo in totaler Dunkel-
heit in einem Orkstollen aufwacht, voller Angst und Schrecken.
Er findet schliesslich einen duennen Ring und steckt ihn ein.
Dann sucht er sich in der Dunkelheit seinen Weg und kommt an 
einem unterirdischen See an. Dort trifft er ein ekliges Wesen,
boese und hinterhaeltig, Gollum genannt. Er wird nur deshalb
nicht von Gollum angegriffen, weil Gollum gerade keinen Hunger
hat und ausserdem Bilbo noch sein Kurzschwert in den Haenden
haelt.
Schliesslich veranstaltet Bilbo mit Gollum einen Raetselwett-
kampf. Wenn Gollum gewinnt, darf er Bilbo fressen, wenn Bilbo
gewinnt, wird ihm der Ausweg aus der Orkhoehle gezeigt.
Da Bilbo nichts zu verlieren hat, willigt er ein.

Der Wettkampf geht gnadenlos hin und her, wobei die zwei sich
immer schwerere Raetsel stellen.
                Fortsetzung von Kapitel 5 auf Seite 7

                Seite 6

                Kapitel 5:
        
Mit knapper Not und Glueck gelingt es Bilbo, immer wieder, die
richtige Antwort auf Gollums Raetsel zu finden. Schliesslich
faellt ihm selbst keines mehr ein, das er Gollum stellen koennte.
Gollum rueckt immer naeher an ihn heran und betatscht und knufft 
ihn. Bilbo spielt mit der Hand in seiner Tasche und findet dabei
den Ring. Er fragt sich laut, was er in den Taschen habe.
Zu seinem Glueck fasst dies Gollum als Raetsel auf und kann
natuerlich nicht darauf antworten.
Wutentbrannt ueber die verloren gegangene Beute gibt Gollum
vor, er braeuchte noch etwas, um Bilbo aus den Stollen zu
fuehren. Er faehrt mit seinem Boot zurueck auf seine Insel
im See, um von dort seinen Ring zu holen, ein Kleinod von
besonderer Macht. Wer diesen Ring auf den Finger steckte, wurde
unsichtbar. Nur im vollen Sonnenlicht war sein Schatten zu er-
ahnen. Mit diesem Ring will er Bilbo erwuergen.

                Fortsetzung von Kapitel 5 auf Seite 8

                Seite 7

                Kapitel 5:

Aber Gollum findet ihn nicht. Ploetzlich kommt Gollum der furcht-
bare Verdacht, dass Bilbo Taeschlin ihn in seinen Taschen haben 
koennte. Mit all seiner Wut und seinem Zorn springt Gollum in
sein Boot zurueck, um Bilbo umzubringen und seinen Ring wiederzu-
bekommen. Bilbo hoert diese schrecklichen Geraeusche und flieht
schnell vor Gollum. Aber Gollum ist schneller.
Bilbo dreht sich waehrend des Rennens um und uebersieht eine kleine
Bodenunebenheit. Im Fallen stuetzt er sich ab und der Ring schluepft
auf seinen Finger. Gollum rennt an ihm vorbei, ohne ihn zu sehen.

Bilbo folgt ihm langsam, denn er kann sich nicht denken, warum
Gollum ihn nicht erwischt hat. Aus dessen Gerede erfaehrt Bilbo
schliesslich die Wahrheit ueber den Ring, und was fuer ein kostbares
Kleinod er da am Finger traegt.
Gollum rennt aber weiter in Richtung des Ausganges und zeigt so
Bilbo unfreiwillig den Ausweg aus den Stollen. 

                Fortsetzung von Kapitel 5 auf Seite 9

                Seite 8

                Kapitel 5:

Gollum kauert sich am Ausgang nieder und Bilbo ueberkommt das Mitleid
mit solch einer Kreatur. Er springt mit einem mutigen Satz ueber Gollum
hinweg und entkommt ihm.
Mit aller Schnelle rennt Bilbo auf das Licht zu. Als er um die letzte
Biegung kommt, steht er ploetzlich vor Dutzenden von Orks. Irgendwie
war der Ring von seinem Finger verschwunden und er war fuer die Orks
sichtbar. Schnell setzt er den Ring auf und versteckt sich hinter
einem Fass.
Gerade zur rechten Zeit witscht Bilbo zwischen den Orks durch und
versucht, sich durch die Aussentuere zu quetschen. Dort bleibt er
aber haengen. Mit grosser Anstrengung kommt er durch den Tuerspalt
hindurch, verliert dabei aber viele Knoepfe und zerreisst dabei
sein Hemd. Das war im letzten Moment, denn die Orks hatten seinen
Schatten schon im Sonnenlicht erspaeht.
Bilbo rennt schnell die Treppen hinunter und verschwindet im Schatten
der Baeume, waehrend die Orks vergeblich nach ihm suchen.

                Seite 9

* * *


## Kenndaten

- Kategorie: Schriften
- Typ: Buch
- Gegend: Midgard
- Material: Papier
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Buch/Westmark/Teil_2)
