---
type: Wiki Article
title: Delphin/grauer
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Delphin/grauer"
tags: [NPC, NPC/Midgard, NPC/Midgard/defensiv, NPC/defensiv, Rasse, Rasse/Säugetier]
timestamp: 2018-11-07T18:28:01Z
revid: 217745
namespace: 0
contenthash: 1eae57ac3da708e772b04d811fbae6f6863d78a741ddbf0b2600c866efc327ee
---

## Aussehen

Der Delphin schaut dich aus klugen, hellgrauen Augen an. Ob er aus den
fernen neuen Landen stammt? Sein schlanker Koerper befaehigt ihn, flink und
behende durchs Wasser zu schiessen. Trotz seiner schnellen Schwimmweise
taucht er von Zeit zu Zeit auf, so dass man einen genaueren Blick auf ihn
werfen kann.

## Ausrüstung

Keine.

## Heimat

In den Flüssen und im Meer [Midgards](/midgard.md "Midgard").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Midgard
- Rasse: Säugetier

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Delphin/grauer)
