---
type: Wiki Article
title: Sand/Kreta
description: In der Wüste auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/Sand/Kreta"
tags: [Gegenstand, Gegenstand/Kokosinseln, Gegenstand/Kokosinseln/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Unbekannt]
timestamp: 2024-03-02T19:21:35Z
revid: 229285
namespace: 0
contenthash: 03b7d137516fef5250f7a4675fbc8bab746b0c873f808088ffcc61236d95be9e
---

## Aussehen

Eine Hand voll ockerfarbener Sand aus der Wueste von Kreta.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Unbekannt](/kategorie/info-material-unbekannt.md "Kategorie:Info/Material/Unbekannt") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

In der Wüste auf [Kreta](/kreta.md "Kreta").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Kokosinseln
- Material: Unbekannt
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Sand/Kreta)
