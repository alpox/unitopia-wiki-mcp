---
type: Wiki Article
title: Petersilie/Bauernhof/Amerindia
description: Im Kräutergarten auf dem Bauernhof auf Amerindia.
resource: "http://unitopia.intelligense.de/wiki/Petersilie/Bauernhof/Amerindia"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Ebenen, Nahrung/Ebenen/Pflanze, Nahrung/Pflanze]
timestamp: 2024-08-29T15:21:27Z
revid: 251310
namespace: 0
contenthash: 02227e524f9f50ddd1012f3d833596ac70451740449be2bbdc14f83df0350753
---

## Aussehen

Ein Bund Petersilie. Die Staengel sind etwa 70 cm lang und leicht gerillt.
Die Blaetter haben eine krause Form und sind von dunkelgruener Farbe.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Im Kräutergarten auf dem [Bauernhof](/amerindia.md "Amerindia") auf [Amerindia](/amerindia.md "Amerindia").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Pflanze
- Gegend: Ebenen
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Petersilie/Bauernhof/Amerindia)
