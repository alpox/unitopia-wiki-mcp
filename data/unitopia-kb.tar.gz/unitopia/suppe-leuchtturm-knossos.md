---
type: Wiki Article
title: Suppe/Leuchtturm/Knossos
description: Auf dem Tisch im Leuchtturm des Hafengebietes von Knossos auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/Suppe/Leuchtturm/Knossos"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Kokosinseln, Nahrung/Kokosinseln/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:24:16Z
revid: 259074
namespace: 0
contenthash: c7afe95c6bce0772f3b92f60e5899d2fadc10f6cfbb6ff18ee494dbdd5751e0b
---

## Aussehen

In einem tiefen Teller schwappt eine undurchsichtige Bruehe hin und her.
Die kleinen Klumpen, die darin herum schwimmen, deuten darauf hin, dass es
sich wohl um Fischsuppe handelt.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Auf dem Tisch im [Leuchtturm](/knossos.md "Knossos") des [Hafengebietes](/knossos.md "Knossos") von [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Kokosinseln
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Suppe/Leuchtturm/Knossos)
