---
type: Wiki Article
title: Fruchtbonbon/Magyra
description: "Es gibt folgende Sorten:"
resource: "http://unitopia.intelligense.de/wiki/Fruchtbonbon/Magyra"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Midgard, Nahrung/Midgard/Produkt, Nahrung/Produkt, Nahrung/Vaniorh, Nahrung/Vaniorh/Produkt, Spalten]
timestamp: 2024-08-29T15:14:19Z
revid: 254836
namespace: 0
contenthash: 9060b77c352ea3639bde62da05683213ad0cd9f61a6d5f1d851d3842bb3efce9
---

## Aussehen

Es lacht Dich richtig an, das kesse Fruechtchen.
Von der Farbe her koennte es ein <[Sorte](#Besonderheit)\> sein.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

-   Im [Perpetuum Mobile](/perpetuum-mobile.md "Perpetuum Mobile") im [Zeitlabor](/erad-nairs-haus.md "Erad-Nairs Haus") in [Erad-Nairs Haus](/erad-nairs-haus.md "Erad-Nairs Haus").
-   Durch das [Tischfeuerwerk](/tischfeuerwerk.md "Tischfeuerwerk") aus [Oxedos' Alchemistenladen](/oxedos.md "Oxedos") von [Londar](/londar.md "Londar").
-   Unter der Fußmatte in der [Brauerei](/magny.md "Magny") von [Magny](/magny.md "Magny").
-   In einer Schublade in [Mellys Gewandschneiderei](/melly.md "Melly") von [Merredin](/merredin.md "Merredin").

## Besonderheit

Es gibt folgende Sorten:

-   Apfelbonbon
-   Ananasbonbon
-   Aprikosenbonbon
-   Bananenbonbon
-   Birnenbonbon
-   Brombeerbonbon
-   Erdbeerbonbon
-   Garthan-Spezialbonbon (Anis)
-   Himbeerbonbon
-   Honigmelonenbonbon
-   Ingwerbonbon
-   Johannisbeerbonbon
-   Kaffeebonbon
-   Kirschbonbon
-   Kiwibonbon
-   Mangobonbon
-   Maracujabonbon
-   Melonenbonbon
-   Pampelmusebonbon
-   Schlumpfbonbon
-   Traubenbonbon
-   Vanillebonbon
-   Waldmeisterbonbon
-   Whiskeybonbon
-   Zitronenbonbon

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Midgard/Vaniorh
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Fruchtbonbon/Magyra)
