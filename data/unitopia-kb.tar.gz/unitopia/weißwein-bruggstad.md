---
type: Wiki Article
title: Weißwein/Bruggstad
description: ""
resource: "http://unitopia.intelligense.de/wiki/Weißwein/Bruggstad"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/betrunken, Info/Wirkung/durstlöschend, Nahrung, Nahrung/Alkohol, Nahrung/Midgard, Nahrung/Midgard/Alkohol]
timestamp: 2024-08-29T15:22:39Z
revid: 245745
namespace: 0
contenthash: 7f43f7d71e2bd872a09b8151a3363c30a2ff8a47e37972484e3e1bcb63199023
---

## Aussehen

Ein Weisswein mit recht hellen Farbe.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend"), [betrunken](/kategorie/info-wirkung-betrunken.md "Kategorie:Info/Wirkung/betrunken") |

## Fundort

-   Zu kaufen bei [Bully](/bully.md "Bully") in einer finsteren Kneipe in [Bruggstad](/bruggstad.md "Bruggstad").
-   Zu kaufen bei [Heinz](/heinz-bruggstad.md "Heinz/Bruggstad") im Gasthaus "Zum Rappen" von [Bruggstad](/bruggstad.md "Bruggstad").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Alkohol
- Gegend: Midgard
- Gewicht: 1
- Wirkung: durstlöschend/betrunken

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Weißwein/Bruggstad)
