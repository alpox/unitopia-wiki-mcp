---
type: Wiki Article
title: Kriegspanzerhandschuhe
description: Zu kaufen bei Charsi in ihrer Rüstungsschmiede in Nankea (Stadt) auf Nankea.
resource: "http://unitopia.intelligense.de/wiki/Kriegspanzerhandschuhe"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Metall, Info/Rüstungsstärke, Info/Rüstungsstärke/geht so, Info/Rüstungszustand, Info/Rüstungszustand/extrem solide, Rüstung, Rüstung/Hände, Rüstung/Midgard, Rüstung/Midgard/Hände]
timestamp: 2024-04-23T19:27:39Z
revid: 228328
namespace: 0
contenthash: 9819a84affc26196c84590712e3914d6c77d0daa587fa6f94833badc44e94ac5
---

## Aussehen

Grosse, sehr feste Handschuhe, die die ganze Hand schuetzen. Sie haben
keine Extrakammern fuer die Finger, sondern nur eine grosse Kammer, wo die
vier Finger reinkommen und eine Extrakammer fuer den Daumen. Diese
Handschuhe halten bestimmt auch Schlaegen von groesseren Waffen problemlos
stand.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [3 (geht so)](/kategorie/info-rüstungsstärke-geht-so.md "Kategorie:Info/Rüstungsstärke/geht so") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [9 (extrem solide)](/kategorie/info-rüstungszustand-extrem-solide.md "Kategorie:Info/Rüstungszustand/extrem solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Charsi](/charsi.md "Charsi") in ihrer Rüstungsschmiede in [Nankea (Stadt)](/nankea-\(stadt\).md "Nankea (Stadt)") auf [Nankea](/nankea.md "Nankea").

* * *


## Kenndaten

- Kategorie: Rüstung
- Typ: Hände
- Gegend: Midgard
- Material: Metall
- Rüstungsstärke: geht so
- Rüstungszustand: extrem solide
- Gewicht: 2
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Kriegspanzerhandschuhe)
