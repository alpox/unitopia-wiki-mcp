---
type: Wiki Article
title: Geist/Nekromantentempel
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Geist/Nekromantentempel"
tags: [NPC, NPC/Midgard, NPC/Midgard/aggressiv, NPC/aggressiv, Rasse, Rasse/Geist, Tätigkeit, Tätigkeit/Wächter]
timestamp: 2018-11-07T18:45:33Z
revid: 215352
namespace: 0
contenthash: e4727430dd1f84a443cfa53d2cdf8c81611da0d13a972166e093eab2c1a619f4
---

## Aussehen

Die durchsichtige, unfoermige Gestalt eines Mannes wabert vor dir hin und
her. Seine kraeftige Statur laesst erahnen, dass er ein kriegerischer
Mensch gewesen sein muss, bevor er heraufbeschworen und als Schutzgeist
magisch an das Grab gebunden wurde. Erkennbare Narben in seinem
Geistergesicht lassen ihn noch bedrohlicher aussehen. Genauso wie seine
wortwoertlich blitzenden Augen. Er scheint nicht allzu gluecklich zu sein.

## Ausrüstung

Keine.

## Heimat

Im [Nekromantentempel](/nekromantentempel.md "Nekromantentempel") auf der [Nekromanteninsel](/nekromanteninsel.md "Nekromanteninsel")

## Besonderheit

Wenn man das Grab geschändet hat, erscheint er, greift einen an und brüllt:

Ein uralter Schutzgeist klagt unangenehm laut schreiend an:
SPIELER hat das Grab des Jarod geschaendet!

* * *


## Kenndaten

- Typ: aggressiv
- Gegend: Midgard
- Rasse: Geist
- Tätigkeit: Wächter

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Geist/Nekromantentempel)
