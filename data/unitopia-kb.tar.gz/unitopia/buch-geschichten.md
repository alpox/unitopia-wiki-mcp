---
type: Wiki Article
title: Buch/Geschichten
description: Im Bücherregal bei Bithra im Hexenhaus auf Thule.
resource: "http://unitopia.intelligense.de/wiki/Buch/Geschichten"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/3, Info/Material, Info/Material/Papier, Info/Schwimmt, Schriften, Schriften/Buch, Schriften/Nordische Inseln, Schriften/Nordische Inseln/Buch]
timestamp: 2024-03-02T19:17:42Z
revid: 238625
namespace: 0
contenthash: fd10e1c58cecddd818386e9ceb2028a4e0c34735716ebca8ede58907e9fdacee
---

## Aussehen

Auf dem Buch steht in schlichten, gedruckten Buchstaben 'Geschichten'.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Papier](/kategorie/info-material-papier.md "Kategorie:Info/Material/Papier") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [3 (schon eher leicht)](/kategorie/info-gewicht-3.md "Kategorie:Info/Gewicht/3") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Im Bücherregal bei [Bithra](/bithra.md "Bithra") im [Hexenhaus](/hexenhaus.md "Hexenhaus") auf [Thule](/thule.md "Thule").

## Besonderheit

Die Hexenbücher haben wechselnde Adjektive: altes, großes, ledernes, schwarzes, schweres und vergilbtes.

## Inhalt

Märchen, die viel mit Hexen und Katzen zu tun haben.

## Faksimile

Inhaltsverzeichnis:

                            ==== GESCHICHTEN ====

 Das Hexenfeuer .................  1  |  Die Frau mit den abgehackten Hae 32
 Das Kaetzchen und die Stricknade  3  |  Die Geschichte vom Feenkind .... 36
 Das Katzenschloss ..............  4  |  Die Hochzeit der Eulentochter .. 38
 Das Maedchen und Babajaga ......  6  |  Die Katze auf dem Dovreberg .... 39
 Das Waisenmaedchen Elenyte und J 10  |  Die Nixe ....................... 41
 Der Fuchs und die Katze ........ 14  |  Die sieben Raben ............... 52
 Der Muellerbursch und die Katze  15  |  Eine schwarz, eine rot ......... 55
 Der Spatz und das Katerchen .... 19  |  Hui aus und immer wo an! ....... 58
 Der Sturmzauber ................ 21  |  Joniukas ....................... 61
 Der schwarze Kater ............. 26  |  Mythos Katze - geliebtes Wesen - 65

* * *


## Kenndaten

- Kategorie: Schriften
- Typ: Buch
- Gegend: Nordische Inseln
- Material: Papier
- Gewicht: 3
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Buch/Geschichten)
