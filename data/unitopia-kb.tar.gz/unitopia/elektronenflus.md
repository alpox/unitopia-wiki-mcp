---
type: Wiki Article
title: Elektronenflus
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Elektronenflus"
tags: [NPC, NPC/Gallien, NPC/Gallien/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Wächter]
timestamp: 2018-11-07T18:34:32Z
revid: 214423
namespace: 0
contenthash: ef262d44df34ebdd1f6649d08c851d993c310e5a2117065dc0e9955abd615858
---

## Aussehen

Elektronenflus, ein roemischer Dekurio. Er ist der Anfuehrer dieser
Patrouille.

## Ausrüstung

Keine.

## Heimat

Auf der [Römerstraße V](/römerstraße-v.md "Römerstraße V").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Gallien
- Rasse: Mensch
- Tätigkeit: Wächter

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Elektronenflus)
