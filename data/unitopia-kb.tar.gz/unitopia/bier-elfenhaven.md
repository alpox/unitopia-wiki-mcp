---
type: Wiki Article
title: Bier/Elfenhaven
description: Zu kaufen bei den Angestellten in der Hafenkneipe vom Elfenhaven.
resource: "http://unitopia.intelligense.de/wiki/Bier/Elfenhaven"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/betrunken, Info/Wirkung/durstlöschend, Nahrung, Nahrung/Alkohol, Nahrung/Midgard, Nahrung/Midgard/Alkohol, Spalten]
timestamp: 2024-08-29T15:15:27Z
revid: 232039
namespace: 0
contenthash: d25de6813c90fecf350cdb60eaf1cf4624c9c3c4f77d42192b41721339f7f8a2
---

## Aussehen

Ein <[Groesse](#Besonderheit)\> <[Adjektiv](#Besonderheit)\> Bier. Man kann es trinken!

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1"), [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1"), [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend"), [betrunken](/kategorie/info-wirkung-betrunken.md "Kategorie:Info/Wirkung/betrunken") |

## Fundort

Zu kaufen bei den [Angestellten](/elfenhaven.md "Elfenhaven") in der Hafenkneipe vom [Elfenhaven](/elfenhaven.md "Elfenhaven").

## Besonderheit

Je Größer des Bier desto stärker die Wirkung:

-   **Größe:**
    -   kleines
    -   _mittleres - ohne Angabe_
    -   großes

  

-   **Adjektiv:**
    -   frisch gezapftes
    -   dunkles
    -   herbes
    -   kühles

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Alkohol
- Gegend: Midgard
- Gewicht: 1/1/1
- Wirkung: durstlöschend/betrunken
- Width: fit-content
- ColumnC: 2
- ColumnW: auto

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Bier/Elfenhaven)
