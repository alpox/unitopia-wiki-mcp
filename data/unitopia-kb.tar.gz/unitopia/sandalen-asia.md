---
type: Wiki Article
title: Sandalen/Asia
description: "Nur mit den Sandalen kommt man in das Tee- oder Badehaus."
resource: "http://unitopia.intelligense.de/wiki/Sandalen/Asia"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Kleidung, Kleidung/Ebenen, Kleidung/Ebenen/Füße, Kleidung/Füße]
timestamp: 2024-03-02T19:17:45Z
revid: 248317
namespace: 0
contenthash: cb4a6f60329097fe68d90ec577e34bbe10f616262c1c60907364ad65c03daa8e
---

## Aussehen

Ein Paar aeusserst bequeme Sandalen mit der Aufschrift:

_Teehaus:_

DIESE SANDALEN SIND EIGENTUM DES TEEHAUSES IN FOOLINGYOO!

_Badehaus:_

DIESE SANDALEN SIND EIGENTUM VOM BADEHAUS.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Auf Nachfrage von [Sakini](/sakini.md "Sakini") in der Garderobe des [Teehauses](/teehaus.md "Teehaus") von [Foo-Ling-Yoo](/foo-ling-yoo.md "Foo-Ling-Yoo") auf [Asia](/asia.md "Asia").
-   Im Regal des [Badehauses](/badehaus.md "Badehaus") im [Bambustal](/bambustal.md "Bambustal") über [Foo-Ling-Yoo](/foo-ling-yoo.md "Foo-Ling-Yoo") auf [Asia](/asia.md "Asia").

## Funktion

Nur mit den Sandalen kommt man in das [Tee-](/teehaus.md "Teehaus") oder [Badehaus](/badehaus.md "Badehaus").

## Besonderheit

-   Die Sandalen des [Teehauses](/teehaus.md "Teehaus") haben zusätzlich noch folgendes **Adjektiv:**
    -   **Ausgelatschte** Sandalen.
-   Zudem ändern die Sandalen, je nach [Metamorpherform](/metamorpher.md "Metamorpher"), ihren Namen:
    -   Beispiel: Elfensandalen, Zwergensandalen etc.

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Füße
- Gegend: Ebenen
- Material: Textil
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Sandalen/Asia)
