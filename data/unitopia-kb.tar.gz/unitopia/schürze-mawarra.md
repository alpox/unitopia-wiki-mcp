---
type: Wiki Article
title: Schürze/Mawarra
description: Kleidung von Mawarra in der Wohnung über dem Laden vor Ort und beim Brunnen von Merredin.
resource: "http://unitopia.intelligense.de/wiki/Schürze/Mawarra"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Kleidung, Kleidung/Hüfte, Kleidung/Midgard, Kleidung/Midgard/Hüfte]
timestamp: 2024-03-02T19:19:07Z
revid: 249286
namespace: 0
contenthash: ea84ea651bca67639736ae7da1a1286482980d14e1f6824bc541e91e80d7160a
---

## Aussehen

Eine huebsche, weisse Schuerze.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Kleidung von [Mawarra](/mawarra.md "Mawarra") in der Wohnung über dem Laden vor Ort und beim Brunnen von [Merredin](/merredin.md "Merredin").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Hüfte
- Gegend: Midgard
- Material: Textil
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schürze/Mawarra)
