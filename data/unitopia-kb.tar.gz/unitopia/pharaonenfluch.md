---
type: Wiki Article
title: Pharaonenfluch
description: "Durch dem mumifizierten Falken oder der wertvollen Ushabti-Figur im Geheimfach unter dem Planwagen in Barovia."
resource: "http://unitopia.intelligense.de/wiki/Pharaonenfluch"
tags: [Info, Info/Heilung, Info/Heilung/Antidots, Info/Heilung/Heiler, Info/Heilung/Heilstab, Info/Heilung/Hexenvolk, Info/Heilung/Kräuter, Info/Wirkung, Info/Wirkung/Zustand, Info/Wirkung/Zustand/negativ, Zustand, Zustand/Dörrland, Zustand/Dörrland/Fluch, Zustand/Fluch]
timestamp: 2024-08-29T15:19:03Z
revid: 218401
namespace: 0
contenthash: 800f9b94da6cb5700fd3b2970b6f2a375ffba66bfb108addd8d8ccdced99a13f
---

## Aussehen

Er/Sie/Es sieht irgendwie gar nicht gut aus.

## Informationen

| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [negativ](/kategorie/info-wirkung-zustand-negativ.md "Kategorie:Info/Wirkung/Zustand/negativ") |
| --- | --- |
| **[Heilung](/kategorie/info-heilung.md "Kategorie:Info/Heilung"):** | [Antidots](/druidengilde.md "Druidengilde"), [Heiler](/heiler.md "Heiler"), [Hexenvolk](/hexenvolk.md "Hexenvolk"), [Kräuter](/kräuter.md "Kräuter"), [Heilstab](/heilstab.md "Heilstab") |

## Fundort

Durch dem [mumifizierten Falken](/falke.md "Falke") oder der [wertvollen Ushabti-Figur](/ushabti-figur.md "Ushabti-Figur") im Geheimfach unter dem Planwagen in [Barovia](/barovia.md "Barovia").

## Gefährlichkeit

-   Zieht ca. 4 [AP](/ap.md "AP")[![Ausdauerpunkte](/images/b/b4/AP.gif)](/ap.md "Ausdauerpunkte") in der Minute ab, hält ca. 60 Minuten an.
-   Startmeldung:

Du hast das Gefuehl, dass irgendetwas dir diese Aktion uebel
genommen haben koennte.

-   Zwischenmeldungen:

Ein Schwarm fleischfressender Heuschrecken faellt dich an! Du
waelzt dich am Boden, um sie abzuschuetteln - aber als du deine
Augen wieder aufmachst ist es, als waeren sie nie dagewesen.
Aus heiterem Himmel stoesst ein Falke auf dich herab. Du kannst 
seine goldenen Augen deutlich sehen, als er dir im Vorbeifliegen
eine Schramme im Gesicht hinterlaesst. Du faehrst ueber deine
Wange, aber spuerst die Verletzung nicht. War wohl nur eine
Wahnvorstellung...
Du glaubst kurz im Augenwinkel eine wuetende Sphinx zu sehen, die
dich zerfetzen will.
Ein Skarabaeus landet auf dir und bohrt sich unter deine Haut.
Waaah! Du kratzt wie wild an der Stelle herum und... oh! War wohl
doch nur eine Wahnvorstellung.
Du fuehlst dich ganz fiebrig.
Du fuehlst dich ganz ausgetrocknet, wie in einer Wueste.
Du hustest bedenklich stark.

-   Endmeldung:

Der Zorn der Pharaonen ist endlich von dir gewichen.

* * *


## Kenndaten

- Kategorie: Zustand
- Typ: Fluch
- Gegend: Dörrland
- Wirkung: negativ
- Heilung: Antidots/Heiler/Hexenvolk/Kräuter/Heilstab

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Pharaonenfluch)
