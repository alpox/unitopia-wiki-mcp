---
type: Wiki Article
title: Förster
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Förster"
tags: [NPC, NPC/Kokosinseln, NPC/Kokosinseln/defensiv, NPC/defensiv, Rasse, Rasse/Insekt]
timestamp: 2019-04-05T10:39:44Z
revid: 262310
namespace: 0
contenthash: c138e684782522e897864889c53eed6b5335742f438d311181e93b2615fa211e
---

## Aussehen

Ein schwarzer Foerster, mit dunkelbraunen Fluegeln und fuenf Augenflecken.
Wie alle Insekten hat er sechs Beine und grosse Facettenaugen. Dazu kommen
dann noch zwei lange Fuehler und ein eingerollter Saugruessel.

## Ausrüstung

Keine.

## Heimat

Im Dschungel auf der [Dschungelinsel](/dschungelinsel.md "Dschungelinsel").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Kokosinseln
- Rasse: Insekt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Förster)
