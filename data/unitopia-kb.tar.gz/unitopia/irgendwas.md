---
type: Wiki Article
title: Irgendwas
description: Im Gerümpel auf dem Dachboden der Villa von Knossos auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/Irgendwas"
tags: [Gegenstand, Gegenstand/Kokosinseln, Gegenstand/Kokosinseln/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Unbekannt]
timestamp: 2024-03-02T19:22:11Z
revid: 264753
namespace: 0
contenthash: 6b24260c28225397e49562995697aba92b953dbb6bd7ccf56e8ff3da69a09ed6
---

## Aussehen

Irgendwas Anderes hat keinerlei Aehnlichkeit mit einem Besen. Insbesondere
die nicht vorhandenen Borsten bestaerken diesen Eindruck.

_oder:_

Zum Erleuchten von Raeumen ist Irgendwas Anderes nun wirklich nicht
geeignet. Es gibt keinerlei Licht ab und scheint auch nicht brennbar zu
sein.

_oder:_

Man kann Irgendwas Anderes nicht mit der Sonne verwechseln, es ist weder
rund noch strahlt es dich an.

_oder:_

Irgendwas Anderes sieht gar nicht wie ein Schiff aus. Schon die Segel
fehlen, und auch ist es nicht aus Holz. Und wer zum Teufel steuert das
Ding? 

_oder:_

Irgendwas Anderes hat nun wirklich keine Aehnlichkeit mit einem Frosch.
Weder hat es ein Maul, noch springt es unkontrolliert herum. Und auch das
Hexengetier scheint kein Interesse zu haben, daran herumzunagen.

_oder:_

Irgendwas Anderes sieht nicht wie ein Haus aus. Du siehst keine Fenster und
auch keine Tueren. Auch der Schornstein ist abwesend.

_oder:_

Irgendwas Anderes ist garantiert kein Schwein. Es hat keinen Ruessel und
auch das Ringelschwaenzchen suchst du vergebens.

_oder:_

Man kann Irgendwas Anderes nicht mit einer Tuete Eis vergleichen. Da ist
weder eine Waffel vorhanden, noch kugelfiermige Objekte im oberen Bereich.
Eigentlich muesstest du mal wieder Hans aufsuchen.

_oder:_

Irgendwas Anderes ist kein Ersatz fuer eine Klobuerste. Weder hat es einen
Griff, noch taugt es zum wegputzen klebengebliebener Stuhlreste.

_oder:_

Irgendwas Anderes sieht ganz anders aus als ein Teller Suppe. Da schwappt
nix rum und essbar scheint es schon gar nicht zu sein.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Unbekannt](/kategorie/info-material-unbekannt.md "Kategorie:Info/Material/Unbekannt") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Im Gerümpel auf dem Dachboden der [Villa](/knossos.md "Knossos") von [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").

## Funktion

-   vergrumsele <Irgendwas> - Das Irgendwas bekommt jedesmal eine Reihe weiterer, absurder Adjektive, bis es nach einigen Malen verschwindet.
-   Bei jedem Betrachten schaut es anders aus.

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Kokosinseln
- Material: Unbekannt
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Irgendwas)
