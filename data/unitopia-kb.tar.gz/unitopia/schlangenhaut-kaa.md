---
type: Wiki Article
title: Schlangenhaut/Kaa
description: Abzuziehen von der toten Schlange Kaa auf der Dschungelinsel.
resource: "http://unitopia.intelligense.de/wiki/Schlangenhaut/Kaa"
tags: [Gegenstand, Gegenstand/Kokosinseln, Gegenstand/Kokosinseln/Sonstige, Gegenstand/Sonstige, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Leder, Info/Material/Textil]
timestamp: 2024-03-02T19:20:54Z
revid: 222374
namespace: 0
contenthash: e8077519c89338726f603d227a05529ef48e7c825d5e9d51318632318aef52b3
---

## Aussehen

Kaa's Haut ist schon ziemlich abgewetzt und zeugt davon, dass Kaa wohl
schon ziemlich alt war. Trotz regelmaessigem Haeuten sind die Farben kaum
noch zu erkennen, es muss wohl mal eine recht schoene Zeichnung gewesen
sein. Jetzt ist sie ledrig und nur noch braun in braun.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder"), [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Abzuziehen von der [toten Schlange Kaa](/kaa.md "Kaa") auf der [Dschungelinsel](/dschungelinsel.md "Dschungelinsel").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Kokosinseln
- Material: Leder/Textil
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schlangenhaut/Kaa)
