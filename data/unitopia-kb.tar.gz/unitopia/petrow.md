---
type: Wiki Article
title: Petrow
description: Ein Kaftan.
resource: "http://unitopia.intelligense.de/wiki/Petrow"
tags: [Angebot, NPC, NPC/Dörrland, NPC/Dörrland/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Verkäufer]
timestamp: 2022-04-25T21:07:59Z
revid: 259317
namespace: 0
contenthash: fd03a4548a3fa23aa139211fb39ef807b280a0051256900c72b762b5ee733230
---

## Aussehen

Petrow, der Hehler. Er traegt eine verspiegelte, schwarze Sonnenbrille von
Bey Ran, die es unmoeglich macht, zu erkennen, was er gerade ansieht. Er
sieht verdammt COOL damit aus. Vermutlich ist mit dem Typen nicht zu
spassen.  Ausserdem traegt er einen weiten, etwas zerknitterten
Staubmantel, der offensichtlich dafuer gedacht ist, Sand und Staub von
seinem Traeger abzuhalten, und darunter einen bequemen Kaftan.

## Ausrüstung

Ein [Kaftan](/kaftan-dörrstadt.md "Kaftan/Dörrstadt").

## Heimat

In der Labgasse von [Dörrstadt](/dörrstadt.md "Dörrstadt").

## Angebot

| ![Angebot-tl.gif](/images/d/db/Angebot-tl.gif) | Preisliste | ![Angebot-tr.gif](/images/5/52/Angebot-tr.gif) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | \| **Hehlerware::** \| **[Dukaten](/währung.md "Währung")**: \| \| --- \| --- \| \| Einen [Froschhaarpinsel](/froschhaarpinsel.md "Froschhaarpinsel") \| 30 \| \| Ein [Zündfunkenrückholfeder](/zündfunkenrückholfeder.md "Zündfunkenrückholfeder"), gebraucht \| 60 \| \| Ein [toller Runenstein](/vas-stein.md "Vas Stein") \| 60 \| \| Eine [nagelneue Labyrinthkarte](/karte-steinernes-labyrinth.md "Karte/Steinernes Labyrinth"), unbeschrieben \| 230 \| \| Eine [garantiert wasserdichte Uhr von Garthier](/garthier-uhr.md "Garthier-Uhr") \| 770 \| \| Eine [verdammt coole Sonnenbrille von Bey Ran](/sonnenbrille-petrow.md "Sonnenbrille/Petrow") \| 770 \| \| Eine [praktische Leuchtkugel](/leuchtkugel-petrow.md "Leuchtkugel/Petrow") \| 1538 \| \| Einen [schwarzen Beutel mit einer aufgestickten goldenen 7](/beutel-petrow.md "Beutel/Petrow") \| 1538 \| \| Ein [versteckter Zettel](/karte-falltürenhaus.md "Karte/Falltürenhaus") den du fast übersehen hättest \| 100000 \| | **Hehlerware::** | **[Dukaten](/währung.md "Währung")**: | Einen [Froschhaarpinsel](/froschhaarpinsel.md "Froschhaarpinsel") | 30 | Ein [Zündfunkenrückholfeder](/zündfunkenrückholfeder.md "Zündfunkenrückholfeder"), gebraucht | 60 | Ein [toller Runenstein](/vas-stein.md "Vas Stein") | 60 | Eine [nagelneue Labyrinthkarte](/karte-steinernes-labyrinth.md "Karte/Steinernes Labyrinth"), unbeschrieben | 230 | Eine [garantiert wasserdichte Uhr von Garthier](/garthier-uhr.md "Garthier-Uhr") | 770 | Eine [verdammt coole Sonnenbrille von Bey Ran](/sonnenbrille-petrow.md "Sonnenbrille/Petrow") | 770 | Eine [praktische Leuchtkugel](/leuchtkugel-petrow.md "Leuchtkugel/Petrow") | 1538 | Einen [schwarzen Beutel mit einer aufgestickten goldenen 7](/beutel-petrow.md "Beutel/Petrow") | 1538 | Ein [versteckter Zettel](/karte-falltürenhaus.md "Karte/Falltürenhaus") den du fast übersehen hättest | 100000 |  |
| **Hehlerware::** | **[Dukaten](/währung.md "Währung")**: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Einen [Froschhaarpinsel](/froschhaarpinsel.md "Froschhaarpinsel") | 30 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Zündfunkenrückholfeder](/zündfunkenrückholfeder.md "Zündfunkenrückholfeder"), gebraucht | 60 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [toller Runenstein](/vas-stein.md "Vas Stein") | 60 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [nagelneue Labyrinthkarte](/karte-steinernes-labyrinth.md "Karte/Steinernes Labyrinth"), unbeschrieben | 230 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [garantiert wasserdichte Uhr von Garthier](/garthier-uhr.md "Garthier-Uhr") | 770 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [verdammt coole Sonnenbrille von Bey Ran](/sonnenbrille-petrow.md "Sonnenbrille/Petrow") | 770 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [praktische Leuchtkugel](/leuchtkugel-petrow.md "Leuchtkugel/Petrow") | 1538 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Einen [schwarzen Beutel mit einer aufgestickten goldenen 7](/beutel-petrow.md "Beutel/Petrow") | 1538 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [versteckter Zettel](/karte-falltürenhaus.md "Karte/Falltürenhaus") den du fast übersehen hättest | 100000 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ![Angebot-bl.gif](/images/3/3b/Angebot-bl.gif) |  | ![Angebot-br.gif](/images/9/92/Angebot-br.gif) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Dörrland
- Rasse: Mensch
- Tätigkeit: Verkäufer
- Gegenstand: Hehlerware:

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Petrow)
