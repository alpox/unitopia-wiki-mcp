---
type: Wiki Article
title: Plan/Landesbank
description: Im Schrank in den Amtsräumen der Bankdirektorin der Landesbank von Tadmor.
resource: "http://unitopia.intelligense.de/wiki/Plan/Landesbank"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Papier, Info/Schwimmt, Schriften, Schriften/Sonstige, Schriften/Vaniorh, Schriften/Vaniorh/Sonstige]
timestamp: 2024-03-02T19:21:07Z
revid: 214232
namespace: 0
contenthash: 06e42af8e01b5ee2fcd593255060b507570e55ad7785213cc6d0f988a5893e79
---

## Aussehen

Du haeltst einen Grundrissplan in den Haenden. Wenn dich sowas
interessiert: Man kann den Plan lesen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Papier](/kategorie/info-material-papier.md "Kategorie:Info/Material/Papier") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Im Schrank in den Amtsräumen der Bankdirektorin der [Landesbank](/tadmor.md "Tadmor") von [Tadmor](/tadmor.md "Tadmor").

## Inhalt

Grundriss der Landesbank.

## Faksimile

Du wirfst einen Blick auf den Plan:
+-----------------------------------------+
|                Landesbank zu Tadmor     |
|   6         --------------------------  |
|   |                                     |
|  -0-1-2        (0)  Vorhalle            |
|     |          (1)  Schalterhalle       |
|   4-3-3-5      (2)  dito                |
|                (3)  Flur                |
|                (4)  Buero Direktor      |
|                (5)  in den Keller       |
|                (6)  Tresorraum          |
+-----------------------------------------+

* * *


## Kenndaten

- Kategorie: Schriften
- Typ: Sonstige
- Gegend: Vaniorh
- Material: Papier
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Plan/Landesbank)
