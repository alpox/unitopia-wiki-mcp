---
type: Wiki Article
title: Aprikose/Knossos/Villa
description: Am Aprikosenbaum im Garten der Villa in Knossos auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/Aprikose/Knossos/Villa"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Kokosinseln, Nahrung/Kokosinseln/Pflanze, Nahrung/Pflanze]
timestamp: 2024-08-29T15:15:27Z
revid: 222579
namespace: 0
contenthash: e36eed1fc0fb7cf505b54cdbe5a975adb2185bdd70711fd5808a767764460b53
---

## Aussehen

Eine leckere, orange-gelbe Aprikose.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Am Aprikosenbaum im [Garten der Villa](/knossos.md "Knossos") in [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Pflanze
- Gegend: Kokosinseln
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Aprikose/Knossos/Villa)
