---
type: Wiki Article
title: Brosche/Iosa
description: Belohnung für die Wiederbeschaffung des verschollenen Kleinods auf Thule.
resource: "http://unitopia.intelligense.de/wiki/Brosche/Iosa"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Kleidung, Kleidung/Hals, Kleidung/Nordische Inseln, Kleidung/Nordische Inseln/Hals]
timestamp: 2024-09-11T20:39:15Z
revid: 268225
namespace: 0
contenthash: 354a7a06df7a89d90a1a0380b6a0528bebcf4c1661b39ff2521aa32e5a4eef9a
---

## Aussehen

Du siehst eine Brosche, die eine silberne Fassung besitzt, an deren
Rueckseite eine Nadel zum Anstecken befestigt ist. In der rechten Haelfte der
Fassung steckt ein rotes Drachenauge. Die linke Haelfte der Fassung enthaelt
eine blaue Feentraene.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Belohnung für die Wiederbeschaffung des [verschollenen Kleinods](/kleinod.md "Kleinod") auf [Thule](/thule.md "Thule").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Hals
- Gegend: Nordische Inseln
- Material: Textil
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Brosche/Iosa)
