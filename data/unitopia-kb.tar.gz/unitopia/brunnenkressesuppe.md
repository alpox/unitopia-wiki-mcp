---
type: Wiki Article
title: Brunnenkressesuppe
description: Zu kaufen bei Henriette im Theatercafé des Theaters von Tadmor.
resource: "http://unitopia.intelligense.de/wiki/Brunnenkressesuppe"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, "Info/Wirkung/gibt 1-5 AP", "Info/Wirkung/gibt 1-5 ZP", Info/Wirkung/sättigt, Nahrung, Nahrung/Produkt, Nahrung/Vaniorh, Nahrung/Vaniorh/Produkt]
timestamp: 2024-08-29T15:14:19Z
revid: 221510
namespace: 0
contenthash: 69e0ea4f0d263c525f58feb661c3882c21bda69102779917e4f835ee452bfde9
---

## Aussehen

In der Suppentasse befindet sich eine herrlich gruene saemige
Brunnenkressesuppe. Genau der richtige Anfang fuer ein Menue!

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt"), gibt 5 ZP wenn AP voll |

## Fundort

Zu kaufen bei [Henriette](/henriette.md "Henriette") im Theatercafé des [Theaters](/theater.md "Theater") von [Tadmor](/tadmor.md "Tadmor").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Vaniorh
- Gewicht: 1
- Wirkung: sättigt/gibt 5 ZP wenn AP voll

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Brunnenkressesuppe)
