---
type: Wiki Article
title: Gallertball
description: "Durch die Schriftrolle in der Truhe in Illios' Hütte im Elfendorf auf Drachenland."
resource: "http://unitopia.intelligense.de/wiki/Gallertball"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Nahrung, Nahrung/Ebenen, Nahrung/Ebenen/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:17:33Z
revid: 244289
namespace: 0
contenthash: 738b6625ac4f72f9d3889c763de15ae436b2e602ffdc2586c8e9dfa20d7211c3
---

## Aussehen

Ein blutroter, mit blauen Schattierungen versehener, gallertartiger
Klumpen.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [siehe Besonderheit](#Besonderheit) |

## Fundort

Durch die [Schriftrolle](/schriftrolle-elfendorf.md "Schriftrolle/Elfendorf") in der Truhe in [Illios' Hütte](/illios.md "Illios") im [Elfendorf](/elfendorf.md "Elfendorf") auf [Drachenland](/drachenland.md "Drachenland").

## Besonderheit

-   Erhöht die [Stärke](/stärke.md "Stärke") um 8 Punkte. (ca. 3 Minuten)
-   Senkt die [Intelligenz](/intelligenz.md "Intelligenz") um 10 Punkte.
-   Kostet 86 [ZP](/zp.md "ZP")[![Zauberpunkte](/images/4/4c/ZP.gif)](/zp.md "Zauberpunkte").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Ebenen
- Gewicht: 1
- Wirkung: siehe Besonderheit

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Gallertball)
