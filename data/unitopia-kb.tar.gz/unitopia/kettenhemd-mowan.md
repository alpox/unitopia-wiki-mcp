---
type: Wiki Article
title: Kettenhemd/Mowan
description: In der Schatztruhe auf dem Dachboden im Cirith Ungol in Mowan.
resource: "http://unitopia.intelligense.de/wiki/Kettenhemd/Mowan"
tags: [Hidden, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Edelmetall, Info/Rüstungsstärke, Info/Rüstungsstärke/geht so, Info/Rüstungszustand, Info/Rüstungszustand/extrem solide, Rüstung, Rüstung/Brust, Rüstung/Midgard, Rüstung/Midgard/Brust, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2024-03-02T19:20:41Z
revid: 261377
namespace: 0
contenthash: 08f7455055ddf8d1822965c5b067e7fae17235bf51a4990eb8acfc7ebf9ebe2a
---

## Aussehen

Ein Kettenhemd, bestehend aus feinsten Mithrilringen. Die hervorragende
Verarbeitung deutet auf die alte Handwerkskunst von Zwergen hin, wie sie
nur in Borefinian oder unter dem Drachenhorn zu finden war. Auch ist das
Kettenhemd bestenfalls gross genug fuer einen Zwerg oder fuer einen
Halbling.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Edelmetall](/kategorie/info-material-edelmetall.md "Kategorie:Info/Material/Edelmetall") |
| --- | --- |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [3 (geht so)](/kategorie/info-rüstungsstärke-geht-so.md "Kategorie:Info/Rüstungsstärke/geht so") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [9 (extrem solide)](/kategorie/info-rüstungszustand-extrem-solide.md "Kategorie:Info/Rüstungszustand/extrem solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

In der [Schatztruhe](/schatztruhe-mowan.md "Schatztruhe/Mowan") auf dem Dachboden im [Cirith Ungol](/mowan.md "Mowan") in [Mowan](/mowan.md "Mowan").

## Besonderheit

-   Das Hemd kann nur von kleinen Formen der Metamorphergilde getragen werden.

-   Zusätzliches Aussehen beim Betrachten einer Person:

| -   **Mann:** | Er traegt ein kleines Kettenhemd aus Mithril, das ihm ganz hervorragend passt. |
| --- | --- |
| -   **Frau:** | Sie traegt ein kleines Kettenhemd aus Mithril, das ihr ganz hervorragend passt. |
| -   **Etwas:** | Es traegt ein kleines Kettenhemd aus Mithril, das ihm ganz hervorragend passt. |

* * *


## Kenndaten

- Kategorie: Rüstung
- Typ: Brust
- Gegend: Midgard
- Material: Edelmetall
- Rüstungsstärke: geht so
- Rüstungszustand: extrem solide
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein
- ul: ja
- Mann: Er traegt ein kleines Kettenhemd aus Mithril, das ihm ganz hervorragend passt.
- Frau: Sie traegt ein kleines Kettenhemd aus Mithril, das ihr ganz hervorragend passt.
- Etwas: Es traegt ein kleines Kettenhemd aus Mithril, das ihm ganz hervorragend passt.

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Kettenhemd/Mowan)
