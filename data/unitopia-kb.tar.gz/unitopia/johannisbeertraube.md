---
type: Wiki Article
title: Johannisbeertraube
description: Am Strauch auf dem Spielplatz vor Phexcaer auf Thule.
resource: "http://unitopia.intelligense.de/wiki/Johannisbeertraube"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Nordische Inseln, Nahrung/Nordische Inseln/Pflanze, Nahrung/Pflanze]
timestamp: 2024-08-29T15:22:36Z
revid: 224726
namespace: 0
contenthash: 1f8b357c2cd08d23716f938bddaf828da28c3c776e112b842d9cb8938bd6fc60
---

## Aussehen

Eine Traube mit kugelrunden, leuchtroten, reifen Johannisbeeren.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Am Strauch auf dem Spielplatz vor [Phexcaer](/phexcaer.md "Phexcaer") auf [Thule](/thule.md "Thule").

## Besonderheit

Nach dem Essen bleibt ein [Fruchtstiel](/fruchtstiel.md "Fruchtstiel") zurück.

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Pflanze
- Gegend: Nordische Inseln
- Gewicht: 2
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Johannisbeertraube)
