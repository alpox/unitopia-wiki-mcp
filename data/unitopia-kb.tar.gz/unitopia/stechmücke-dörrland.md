---
type: Wiki Article
title: Stechmücke/Dörrland
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Stechmücke/Dörrland"
tags: [NPC, NPC/Dörrland, NPC/Dörrland/aggressiv, NPC/aggressiv, Rasse, Rasse/Insekt]
timestamp: 2022-08-23T23:34:20Z
revid: 266608
namespace: 0
contenthash: d26e942ed050e468f584fa7673e19f091d236c78e033660ccd0017d02b4bf1be
---

## Aussehen

Eine unangenehme, wild summende Stechmuecke.

## Ausrüstung

Keine.

## Heimat

In der Steppenlandschaft und unterhalb der [Druidenburg](/druidenburg.md "Druidenburg").

## Besonderheit

-   Die Stechmücken sind immer zu viert und verfolgen einen, auch unsichtbar.
-   Man wird auch als Unsichtbarer gestochen.
-   Der Stich kostet jedesmal 1 [AP](/ap.md "AP")[![Ausdauerpunkte](/images/b/b4/AP.gif)](/ap.md "Ausdauerpunkte").

* * *


## Kenndaten

- Typ: aggressiv
- Gegend: Dörrland
- Rasse: Insekt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Stechmücke/Dörrland)
