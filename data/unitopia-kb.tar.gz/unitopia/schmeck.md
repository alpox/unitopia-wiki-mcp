---
type: Wiki Article
title: Schmeck
description: Eine Nickelbrille.
resource: "http://unitopia.intelligense.de/wiki/Schmeck"
tags: [Angebot, NPC, NPC/Märchenland, NPC/Märchenland/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Verkäufer]
timestamp: 2022-04-25T21:07:54Z
revid: 216392
namespace: 0
contenthash: d5f4282aee16710272fe640ac5499e6d86e9a9f2b159f20624efc6f843337ab5
---

## Aussehen

Du siehst einen kleinen Mann mit einer Nickelbrille auf der Nase und einem
vertraeumtem Blick. In ganz Magyra ist Schmeck der anerkannte Tee-Fachmann.
Es gibt niemanden, der mehr und besser Bescheid wuesste ueber alle
wichtigen (und unwichtigen) Tee-Fragen.

## Ausrüstung

Eine [Nickelbrille](/nickelbrille.md "Nickelbrille").

## Heimat

Im Teeladen von [Koboldingen](/koboldingen.md "Koboldingen").

## Angebot

| ![Angebot-tl.gif](/images/d/db/Angebot-tl.gif) | Teesorten | ![Angebot-tr.gif](/images/5/52/Angebot-tr.gif) |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | \| **Sorte::** \| **[Taler](/währung.md "Währung")**: \| \| --- \| --- \| \| Ein [Beruhigungstee](/beruhigungstee.md "Beruhigungstee") \| 5 \| \| Ein [Ziegel-Tee](/ziegel-tee.md "Ziegel-Tee") \| 5 \| \| Ein [Assam-Tee](/assam-tee.md "Assam-Tee") \| 10 \| \| Ein [Earl Grey Tee](/earl-grey-tee.md "Earl Grey Tee") \| 10 \| \| Ein [Darjeeling-Tee](/darjeeling-tee.md "Darjeeling-Tee") \| 10 \| | **Sorte::** | **[Taler](/währung.md "Währung")**: | Ein [Beruhigungstee](/beruhigungstee.md "Beruhigungstee") | 5 | Ein [Ziegel-Tee](/ziegel-tee.md "Ziegel-Tee") | 5 | Ein [Assam-Tee](/assam-tee.md "Assam-Tee") | 10 | Ein [Earl Grey Tee](/earl-grey-tee.md "Earl Grey Tee") | 10 | Ein [Darjeeling-Tee](/darjeeling-tee.md "Darjeeling-Tee") | 10 |  |
| **Sorte::** | **[Taler](/währung.md "Währung")**: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Beruhigungstee](/beruhigungstee.md "Beruhigungstee") | 5 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Ziegel-Tee](/ziegel-tee.md "Ziegel-Tee") | 5 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Assam-Tee](/assam-tee.md "Assam-Tee") | 10 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Earl Grey Tee](/earl-grey-tee.md "Earl Grey Tee") | 10 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Darjeeling-Tee](/darjeeling-tee.md "Darjeeling-Tee") | 10 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ![Angebot-bl.gif](/images/3/3b/Angebot-bl.gif) |  | ![Angebot-br.gif](/images/9/92/Angebot-br.gif) |  |  |  |  |  |  |  |  |  |  |  |  |

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Märchenland
- Rasse: Mensch
- Tätigkeit: Verkäufer
- Gegenstand: Sorte:

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schmeck)
