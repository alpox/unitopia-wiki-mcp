---
type: Wiki Article
title: Erbsenhülse
description: Im Gemüsegarten des Bauernhofes von Terqa.
resource: "http://unitopia.intelligense.de/wiki/Erbsenhülse"
tags: [Behälter, Behälter/Kleine, Behälter/Vaniorh, Behälter/Vaniorh/Kleine, Info, Info/Fasst, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Biologisch, Info/Volumen, Info/Volumen/6]
timestamp: 2026-03-18T18:21:13Z
revid: 238990
namespace: 0
contenthash: fcd381bc080425a8f7003cff69ef5e87b8af94cb3b35fc08d21ba470efbb48fd
---

## Aussehen

Die Erbsenhuelse ist gruen und laenglich.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Biologisch](/kategorie/info-material-biologisch.md "Kategorie:Info/Material/Biologisch") |
| --- | --- |
| **[Fasst](/kategorie/info-fasst.md "Kategorie:Info/Fasst"):** | [Erbse](/erbse.md "Erbse") |
| **[Volumen](/kategorie/info-volumen.md "Kategorie:Info/Volumen"):** | 6 |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Im Gemüsegarten des [Bauernhofes](/terqa.md "Terqa") von [Terqa](/terqa.md "Terqa").

## Besonderheit

Die Hülse enthält anfangs sechse [Erbsen](/erbse.md "Erbse").

* * *


## Kenndaten

- Kategorie: Behälter
- Typ: Kleine
- Gegend: Vaniorh
- Material: Biologisch
- Fasst: Erbse
- Volumen: 6
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Erbsenhülse)
