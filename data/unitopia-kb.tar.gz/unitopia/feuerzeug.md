---
type: Wiki Article
title: Feuerzeug
description: "zuend feuer an - Damit lassen sich nur Feuerstellen entzünden."
resource: "http://unitopia.intelligense.de/wiki/Feuerzeug"
tags: [Fundort/Kauf, Gegenstand, Gegenstand/Midgard, Gegenstand/Midgard/Sonstige, Gegenstand/Sonstige, Gegenstand/Vaniorh, Gegenstand/Vaniorh/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Metall, Info/Material/Stein]
timestamp: 2024-04-23T19:27:45Z
revid: 254355
namespace: 0
contenthash: bec33902ed1971924faebdb4385bd6201db002ebac0f2a64be21bd6f03b4491b
---

## Aussehen

Ein Feuerzeug. Es besteht aus einem Feuerstein, aus dem mittels eines
Stahls Funken geschlagen werden. Diese setzen dann den Zunder in Brand.
Ganz schoen kompliziert, nicht? Am besten wirst Du wohl mit dem Feuerzeug
zurechtkommen, wenn Du versuchst, es zu entzuenden.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Stein](/kategorie/info-material-stein.md "Kategorie:Info/Material/Stein"), [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Zu kaufen bei [Bogumir](/bogumir.md "Bogumir") im Ramschladen von [Tadmor](/tadmor.md "Tadmor").
-   Im Regal in der Vorratskammer auf [Cirith Ungol](/mowan.md "Mowan") in [Mowan](/mowan.md "Mowan").

## Funktion

zuend feuer an \- Damit lassen sich nur Feuerstellen entzünden.

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Midgard/Vaniorh
- Material: Stein/Metall
- Gewicht: 2
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Feuerzeug)
