---
type: Wiki Article
title: Muschel/Oroonoque
description: Am Tropenstrand auf Oroonoque.
resource: "http://unitopia.intelligense.de/wiki/Muschel/Oroonoque"
tags: [Gegenstand, Gegenstand/Dörrland, Gegenstand/Dörrland/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Unbekannt, Spalten]
timestamp: 2024-03-02T19:20:27Z
revid: 239470
namespace: 0
contenthash: 06b285cbcc1edc035ae5011aa46f455b1ec69dcbc3774d4e137af488816c03a0
---

## Aussehen

Eine huebsche kleine <[förmige](#Besonderheit)\> Muschel. Sie ist <[farbige](#Besonderheit)\> und hat viele kleine
Rillen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Unbekannt](/kategorie/info-material-unbekannt.md "Kategorie:Info/Material/Unbekannt") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Am Tropenstrand auf [Oroonoque](/oroonoque.md "Oroonoque").

## Besonderheit

Die Muschel eine kleine Anzahl von Formen und Farben, die hier aufgelistet sind:

**Form:**

-   herzförmige
-   runde

  

**Farbe:**

-   feuerrot
-   limonengrün
-   sonnengelb

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Dörrland
- Material: Unbekannt
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein
- Width: 60%
- ColumnC: 2

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Muschel/Oroonoque)
