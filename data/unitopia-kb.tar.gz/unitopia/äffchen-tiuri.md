---
type: Wiki Article
title: Äffchen/Tiuri
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Äffchen/Tiuri"
tags: [NPC, NPC/Kokosinseln, NPC/Kokosinseln/defensiv, NPC/defensiv, Rasse, Rasse/Säugetier]
timestamp: 2018-11-07T18:34:02Z
revid: 215794
namespace: 0
contenthash: 70c350faf629f346b0031d78af7439bc5dc8ad838ae1fb52ed5ceedffdbb87c9
---

## Aussehen

Ein suesses kleines Aeffchen. Es hat hellwache Augen und recht
bewegliche Finger. Obwohl es doch soooo klein und suess aussieht,
scheint es enorme Kraefte zu haben. Um den Hals traegt das Aeffchen
ein kleines Kettchen.

## Ausrüstung

Keine.

## Heimat

Helferlein von [Narr Tiuri](/tiuri.md "Tiuri") südlich der Allee des Pharos in [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").

## Besonderheit

-   Erfüllt man eine bestimmte [Aufgabe](/affe-des-leierkastenmannes.md "Affe des Leierkastenmannes"), erhält man den Affen der dann bestimmte Kommandos ausführt.
-   Sein Name ist "[KingKongchen](/kingkongchen.md "KingKongchen")".

## Funktion

Schon bald wirst du feststellen, wie praktisch
es ist, [KingKongchen](/kingkongchen.md "KingKongchen") als Wegbegleiter bei
sich zu haben. Er kann dir naemlich eine prima
Hilfe sein. So nimmt er naemlich Gegenstaende
fuer dich auf, auch wenn du beide Haende voll
hast. Und das geht folgendermassen:

 'ano <objekt>'     -> KKchen nimmt das <Objekt>.
 'ana'              -> KKchen nimmt alles was rumliegt.
 'alo <objekt>'     -> KKchen nimmt das <Objekt> aus der
                       ersten Leiche.
 'ala'              -> KKchen nimmt alles aus der ersten
                       Leiche und begraebt diese dann.

 'lause mich'       -> KKchen befreit dich von stoerenden
                       Floehen.

 'spass <Spieler>   -> KKchen treibt netten Schabernack mit
                       dem Spieler <Spieler>.

 'strafe <Spieler>  -> KKchen macht sich und dich unbeliebt
                       beim Spieler <Spieler>. Allerdings
                       schadet dies deinem Ansehen ENORM!

 'jage kkchen fort' -> Du sagst deinem KKchen Lebewohl...

Aber wenn du dein Aeffchen nicht forderst, dann wirst du's
schnell verlieren, denn wenn es sich zu sehr langweilt,
dann wird es dich verlassen. 

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Kokosinseln
- Rasse: Säugetier

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Äffchen/Tiuri)
