---
type: Wiki Article
title: Ungrün
description: Ein Atemgerät.
resource: "http://unitopia.intelligense.de/wiki/Ungrün"
tags: [NPC, NPC/Kokosinseln, NPC/Kokosinseln/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Questgeber]
timestamp: 2018-11-07T18:31:44Z
revid: 260422
namespace: 0
contenthash: a0aaf1ff18ed1426135db18f4f9dd93368fa65d64d2724e5e518df83c6df3a13
---

## Aussehen

Dies ist Professor Ungruen vom seismologischen Institut von Vulkania.
Er sieht ziemlich mitgenommen aus.
Er hat einen verstauchten Fuss.

## Ausrüstung

Ein [Atemgerät](/atemgerät.md "Atemgerät").

## Heimat

Auf einer Insel der Vulkanhöhlen im [Polanskykrater](/polanskykrater.md "Polanskykrater") auf [Vulkanien](/vulkanien.md "Vulkanien").

## Besonderheit

Der Herr könnte eventuell deine [Rettung](/rette-professor-ungrün.md "Rette Professor Ungrün") gebrauchen.

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Kokosinseln
- Rasse: Mensch
- Tätigkeit: Questgeber

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Ungrün)
