---
type: Wiki Article
title: Magenverstimmung/Oroonoque
description: Durch das Wasser in einer großen Spalte im Fels am Vulkansandstrand auf Oroonoque.
resource: "http://unitopia.intelligense.de/wiki/Magenverstimmung/Oroonoque"
tags: [Info, Info/Heilung, Info/Heilung/Antidots, Info/Heilung/Heiler, Info/Heilung/Heilstab, Info/Heilung/Hexenvolk, Info/Heilung/Kräuter, Info/Wirkung, Info/Wirkung/Zustand, Info/Wirkung/Zustand/negativ, Zustand, Zustand/Dörrland, Zustand/Dörrland/Vergiftung, Zustand/Vergiftung]
timestamp: 2024-08-29T15:24:16Z
revid: 239356
namespace: 0
contenthash: 8f72211339dd1ff414df9ba6753f711320c40c027020e6f66a71a931f3a8ab9a
---

## Aussehen

Er/Sie/Es sieht ganz elend aus und haelt sich verkrampft den Bauch.

## Informationen

| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [negativ](/kategorie/info-wirkung-zustand-negativ.md "Kategorie:Info/Wirkung/Zustand/negativ") |
| --- | --- |
| **[Heilung](/kategorie/info-heilung.md "Kategorie:Info/Heilung"):** | [Antidots](/druidengilde.md "Druidengilde"), [Heiler](/heiler.md "Heiler"), [Hexenvolk](/hexenvolk.md "Hexenvolk"), [Kräuter](/kräuter.md "Kräuter"), [Heilstab](/heilstab.md "Heilstab") |

## Fundort

Durch das [Wasser](/wasser-oroonoque.md "Wasser/Oroonoque") in einer großen Spalte im Fels am Vulkansandstrand auf [Oroonoque](/oroonoque.md "Oroonoque").

## Gefährlichkeit

-   Zieht ca. 3 [AP](/ap.md "AP")[![Ausdauerpunkte](/images/b/b4/AP.gif)](/ap.md "Ausdauerpunkte") in der Minute ab, hält ca. 25 Minuten an.
-   Startmeldung:

Du trinkst einen kraeftigen Schluck Wasser aus der Pfuetze. Trotz des
ziemlich abstossenden Anblicks trinkst du einen kraeftigen Schluck Wasser
und sofort wird Dir speiuebel.

-   Zwischenmeldungen:

Irgendetwas hat Dir gar nicht gut getan. Deine Eingeweide krampfen sich schmerzhaft zusammen.
Du fuehlst Dich hundeelend.
Dir ist fuerchterlich schlecht.
Du hast schlimme Bauchkraempfe.
Meine Guete, was ist Dir da nur so schrecklich auf den Magen geschlagen?

-   Endmeldung:

Dein Magen hat sich endlich beruhigt.

* * *


## Kenndaten

- Kategorie: Zustand
- Typ: Vergiftung
- Gegend: Dörrland
- Wirkung: negativ
- Heilung: Antidots/Heiler/Hexenvolk/Kräuter/Heilstab

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Magenverstimmung/Oroonoque)
