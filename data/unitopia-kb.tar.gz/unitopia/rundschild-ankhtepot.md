---
type: Wiki Article
title: Rundschild/Ankhtepot
description: Schild vom Leichnam des Ankhtepot im Bauch des Totenschiffs in der Gruft der Pyramiden auf Amerindia.
resource: "http://unitopia.intelligense.de/wiki/Rundschild/Ankhtepot"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/3, Info/Material, Info/Material/Holz, Info/Rüstungszustand, Info/Rüstungszustand/sehr solide, Info/Schwimmt, Todo, Todo/Kontrolle, Waffe, Waffe/Ebenen, Waffe/Ebenen/Kleinschild, Waffe/Kleinschild]
timestamp: 2024-03-02T19:18:04Z
revid: 265474
namespace: 0
contenthash: d66ea622a16af795826f3fafecbdf0868f52b582a63b8a29d08d8262f69e246f
---

## Aussehen

Ein Rundschild.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** |  |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [7 (sehr solide)](/kategorie/info-rüstungszustand-sehr-solide.md "Kategorie:Info/Rüstungszustand/sehr solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [3 (schon eher leicht)](/kategorie/info-gewicht-3.md "Kategorie:Info/Gewicht/3") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Schild vom [Leichnam des Ankhtepot](/ankhtepot-leichnam.md "Ankhtepot/Leichnam") im [Bauch des Totenschiffs](/totenschiff.md "Totenschiff") in der [Gruft der Pyramiden](/pyramiden.md "Pyramiden") auf [Amerindia](/amerindia.md "Amerindia").

[![Todo.gif](/images/f/fa/Todo.gif)](/datei/todo.gif.md)**Zur Überarbeitung wegen inhaltlicher Mängel oder fehlenden Informationen vorgemerkt.** [Hilf mit](/kategorie/todo.md "Kategorie:Todo"), die inhaltlichen Mängel oder fehlende Informationen zu korrigieren oder zu ergänzen.

* * *

**Todo (Kontrolle):** Rüstungsstärke - Veraltete Stärke: geht so


## Kenndaten

- Kategorie: Waffe
- Typ: Kleinschild
- Gegend: Ebenen
- Material: Holz
- Rüstungszustand: sehr solide
- Licht: 0
- Gewicht: 3
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Rundschild/Ankhtepot)
