---
type: Wiki Article
title: Hemd/Valin
description: Kleidung von Valin in einem Stollen in Dvaergen.
resource: "http://unitopia.intelligense.de/wiki/Hemd/Valin"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Kleidung, Kleidung/Brust, Kleidung/Midgard, Kleidung/Midgard/Brust]
timestamp: 2024-03-02T19:19:20Z
revid: 233339
namespace: 0
contenthash: 4c31a84a4f6c2aea81cf58cde3855c93fbfa7735d06a7f1d00853419d763ff9d
---

## Aussehen

Ein fleckiges Hemd, das auch schon mal besser Zeiten erlebt hat.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Kleidung von [Valin](/valin.md "Valin") in einem Stollen in [Dvaergen](/dvaergen.md "Dvaergen").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Brust
- Gegend: Midgard
- Material: Textil
- Temperaturschutz: wärmt etwas
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Hemd/Valin)
