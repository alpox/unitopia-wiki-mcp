---
type: Wiki Article
title: Fell/Magyra
description: ""
resource: "http://unitopia.intelligense.de/wiki/Fell/Magyra"
tags: [Adjektiv, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Textil, Info/Rüstungsstärke, Info/Rüstungsstärke/schwach, Info/Rüstungszustand, Info/Rüstungszustand/mäßig haltbar, Rüstung, Rüstung/Brust, Rüstung/Dörrland, Rüstung/Dörrland/Brust, Rüstung/Kokosinseln, Rüstung/Kokosinseln/Brust]
timestamp: 2024-03-02T19:19:35Z
revid: 255256
namespace: 0
contenthash: f19b1f9059dc3bce1d274cec1a0743045f3a70424937dd430161ce4b8bc3c1b3
---

## Aussehen

Der Ork, dem dies gehoerte, hatte wirklich ein dickes Fell. Genauer gesagt,
ein mit Leder verstaerktes <[Tierfell](#Besonderheit)\>, das wohl mehr Schutz bietet, als man
zuerst glauben mag. Auf die Schulterpartien wurden als Schmuck noch viele
lange Lederstreifen genaeht, die von dort lose herunterhaengen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [2 (schwach)](/kategorie/info-rüstungsstärke-schwach.md "Kategorie:Info/Rüstungsstärke/schwach") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [3 (mäßig haltbar)](/kategorie/info-rüstungszustand-mäßig-haltbar.md "Kategorie:Info/Rüstungszustand/mäßig haltbar") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Rüstung vom [Bullywug](/bullywug.md "Bullywug") im Höhlensystem der [Unterwelt](/unterwelt.md "Unterwelt").
-   Rüstung vom [Gnoll](/gnoll.md "Gnoll") im Höhlensystem der [Unterwelt](/unterwelt.md "Unterwelt").
-   Rüstung vom [Käferbär](/käferbär.md "Käferbär") im Höhlensystem der [Unterwelt](/unterwelt.md "Unterwelt").
-   Rüstung der [Orks](/ork-wald-kreta.md "Ork/Wald/Kreta") im [wild wuchernden Wald](/kreta.md "Kreta") auf [Kreta](/kreta.md "Kreta").

## Besonderheit

-   Das Fell gehört zu den Rüstungen, die ständig wechselnde Adjektive haben. Diese werden hier nicht gesondert aufgelistet.
-   Die benutzte Tierart des Felles unterscheidet sich.

* * *


## Kenndaten

- Kategorie: Rüstung
- Typ: Brust
- Gegend: Dörrland/Kokosinseln
- Material: Textil
- Rüstungsstärke: schwach
- Rüstungszustand: mäßig haltbar
- Gewicht: 2
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Fell/Magyra)
