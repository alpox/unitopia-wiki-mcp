---
type: Wiki Article
title: Glasphiole/Alchemistengilde
description: Von einem Mitglied der Alchemistengilde.
resource: "http://unitopia.intelligense.de/wiki/Glasphiole/Alchemistengilde"
tags: [Fundort, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/besondere, Nahrung, Nahrung/Getränk, Nahrung/Vaniorh, Nahrung/Vaniorh/Getränk, Subpages, Subpages/Content]
timestamp: 2024-09-16T12:10:45Z
revid: 224041
namespace: 0
contenthash: 0a6e70e1cfb966839af718a776f1be98fba7b80365b329733f5319dffaf27159
---

< [Alchemistengilde](/alchemistengilde.md "Alchemistengilde") < [Fähigkeit: Immunisierung](/alchemistengilde.md "Alchemistengilde")

## Aussehen

Eine kleine glaeserne Phiole. Sie ist mit einer blutroten Fluessigkeit
gefuellt. Dem Elixier der Immunisierung!

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | immunisierend |

## Fundort

Von einem Mitglied der [Alchemistengilde](/alchemistengilde.md "Alchemistengilde").

* * *


## Kenndaten

- Typ: Content
- Kategorie: Nahrung
- Gegend: Vaniorh
- Gewicht: 1
- Wirkung: immunisierend

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Glasphiole/Alchemistengilde)
