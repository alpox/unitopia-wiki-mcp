---
type: Wiki Article
title: Kleid/Mareen2
description: Zu kaufen bei Mareen in ihrem Laden für Bekleidung in Knossos auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/Kleid/Mareen2"
tags: [Fundort/Kauf, Hidden, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Kleidung, Kleidung/Brust, Kleidung/Kokosinseln, Kleidung/Kokosinseln/Brust, ZusatzAussehen, ZusatzAussehen/Frau]
timestamp: 2024-04-23T19:28:20Z
revid: 261703
namespace: 0
contenthash: 95ee70e4103ab98b9f364da6f51756f484e71e5f4810cca4d1d865ebd0d2f554
---

## Aussehen

Ein schwarzes Samtkleid mit barockem Stehkragen. Der Samtrock reicht bis zu
den Knien, der seidene Unterrock hingegen bis ueber die Knoechel. Auch die
weiten, fallenden Aermel wurden aus schwarzer Seide gefertigt. Vorne ist es
mit einer huebschen Schnuerung verziert.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Mareen](/mareen.md "Mareen") in ihrem Laden für Bekleidung in [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").

## Besonderheit

Zusätzliches Aussehen beim Betrachten einer Person:

| **Frau:** | Sie traegt ein schoen fallendes, schwarzes Kleid aus Samt und Seide. Der hohe Stehkragen und die fest gezogene Schnuerung verleihen ihr eine strenge aber auch sehr elegante Ausstrahlung. |
| --- | --- |

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Brust
- Gegend: Kokosinseln
- Material: Textil
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Kleid/Mareen2)
