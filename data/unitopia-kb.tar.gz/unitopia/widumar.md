---
type: Wiki Article
title: Widumar
description: ""
resource: "http://unitopia.intelligense.de/wiki/Widumar"
tags: []
timestamp: 2018-05-21T15:11:34Z
revid: 251895
namespace: 0
contenthash: db8a2695ec46631e3f53ee235ae866ca999317ed723935bc70d6a539a58ba5bf
---

1.  WEITERLEITUNG [Forscher](/forscher.md "Forscher")

* * *

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Widumar)
