---
type: Wiki Article
title: Wasserbombe
description: Zu kaufen bei Hudson im Vampyrschloss.
resource: "http://unitopia.intelligense.de/wiki/Wasserbombe"
tags: [Fundort/Kauf, Gegenstand, Gegenstand/Midgard, Gegenstand/Midgard/Sonstige, Gegenstand/Sonstige, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Leder]
timestamp: 2024-04-23T19:27:46Z
revid: 228395
namespace: 0
contenthash: 1b4d8e473837281100c1d8457ba15453144ba61357f332d31a27d32bc0958165
---

## Aussehen

Eine Wasserbombe aus extrem duennem Leder. Wenn die platzt, wird es bestimmt
ziemlich nass.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Hudson](/hudson.md "Hudson") im [Vampyrschloss](/vampyrschloss.md "Vampyrschloss").

## Funktion

Wirft man sie auf jemanden, ist der oder die anschließend klatschnass.

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Midgard
- Material: Leder
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Wasserbombe)
