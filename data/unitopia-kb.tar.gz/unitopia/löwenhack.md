---
type: Wiki Article
title: Löwenhack
description: Zu kaufen bei Sokrates in seinem Gasthof in Knossos auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/Löwenhack"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, "Info/Wirkung/gibt 6-10 AP", "Info/Wirkung/gibt 6-10 ZP", Info/Wirkung/sättigt, Nahrung, Nahrung/Kokosinseln, Nahrung/Kokosinseln/Tier, Nahrung/Tier]
timestamp: 2024-08-29T15:22:39Z
revid: 246717
namespace: 0
contenthash: a09661866d64ffff1a06724baaf64ea2c58ac73e3d341f2d01e9d1bb6230b909
---

## Aussehen

Das feingehackte Loewenfleisch erinnert sehr an Katzenfleisch. Ob das wohl
damit zusammenhaengt, dass Loewen so schwer zu erlegen sind, und so viele
Hexen ihre schnurrenden Lieblinge vermissen? Gleichwohl gehoert dieses
Gericht zum Besten, was die kretische Kueche zu bieten hat, fuerwahr ein
Gaumenschmaus! - der nur leider durch die widerlichen, an aufgequollene
Blutegel erinnernden Pommes Frites beeintraechtigt wird.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt"), gibt 7 ZP wenn AP voll |

## Fundort

Zu kaufen bei [Sokrates](/sokrates.md "Sokrates") in seinem Gasthof in [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Tier
- Gegend: Kokosinseln
- Gewicht: 1
- Wirkung: sättigt/gibt 7 ZP wenn AP voll

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Löwenhack)
