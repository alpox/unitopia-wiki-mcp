---
type: Wiki Article
title: Zylinder/Houdini
description: ""
resource: "http://unitopia.intelligense.de/wiki/Zylinder/Houdini"
tags: [Behälter, Behälter/Große, Behälter/Midgard, Behälter/Midgard/Große, Fundort/Kauf, Hidden, Info, Info/Brennbar, Info/Fasst, Info/Fasst/Gegenstand, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Kleidung, Kleidung/Kopf, Kleidung/Midgard, Kleidung/Midgard/Kopf, ZusatzAussehen, ZusatzAussehen/Mann]
timestamp: 2026-03-18T18:21:24Z
revid: 261984
namespace: 0
contenthash: 5439bee313639d8ba3862576e93c0b7303b8084acc4ee3039ca795e22c5eeee7
---

## Aussehen

Ein eleganter Zylinder, wie ihn erfolgreiche Buehnenmagier tragen. Er ist
aus mattglaenzender, schwarzer Seide gefertigt und besitzt eine keck
geschwungene Krempe. Ein echtes Meisterstueck der Hutmacherkunst. Lediglich
an einer Stelle erkennt man eine kleine Falte.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Fasst](/kategorie/info-fasst.md "Kategorie:Info/Fasst"):** | [Gegenstand](/kategorie/gegenstand-sonstige.md "Kategorie:Gegenstand/Sonstige") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Zu kaufen bei [Houdini](/houdini.md "Houdini") im Zauberladen von [Magny](/magny.md "Magny").
-   Kleidung von [Houdini](/houdini.md "Houdini") im Zauberladen von [Magny](/magny.md "Magny").

## Besonderheit

-   Legt man Gegenstände in den Zylinder, scheinen sie zu verschwinden.

-   Zusätzliches Aussehen beim Betrachten einer Person:

| **Mann:** | Er hat einen eleganten, schwarzglaenzenden Zylinder auf dem Kopf. |
| --- | --- |

## Funktion

-   stecke Kopf in Zylinder
-   drücke Zylinder zusammen / schlage Zylinder auf Handkante
-   ziehe Hut vor <Person>
-   ziehe [Kaninchen](/kaninchen-zylinder-houdini.md "Kaninchen/Zylinder/Houdini") aus Hut - Unter Verwendung von 95 [ZP](/zp.md "ZP")[![Zauberpunkte](/images/4/4c/ZP.gif)](/zp.md "Zauberpunkte") (seltener Fall ein [Wolpertinger](/wolpertinger.md "Wolpertinger"))

* * *


## Kenndaten

- Typ: Kopf
- Gegend: Midgard
- Kategorie: Behälter
- Material: Textil
- Temperaturschutz: wärmt etwas
- Fasst: Gegenstand
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein
- ul: ja
- Mann: Er hat einen eleganten, schwarzglaenzenden Zylinder auf dem Kopf.

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Zylinder/Houdini)
