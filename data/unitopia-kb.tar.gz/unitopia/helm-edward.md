---
type: Wiki Article
title: Helm/Edward
description: Rüstung von Edward auf dem Friedhof beim alten Svalichwald von Barovia.
resource: "http://unitopia.intelligense.de/wiki/Helm/Edward"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Metall, Info/Rüstungsstärke, Info/Rüstungsstärke/geht so, Info/Rüstungszustand, Info/Rüstungszustand/extrem solide, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Rüstung, Rüstung/Dörrland, Rüstung/Dörrland/Kopf, Rüstung/Kopf]
timestamp: 2024-03-02T19:17:11Z
revid: 259181
namespace: 0
contenthash: 0d4ad97bb313c8bc578f6a0e0ac9eb1bb15c9bf5a992ec960c1809a29e89a394
---

## Aussehen

Ein grosser, schwerer, schwarzer Helm, welcher sehr gut den Kopf vor
Schlaegen schuetzen kann.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [3 (geht so)](/kategorie/info-rüstungsstärke-geht-so.md "Kategorie:Info/Rüstungsstärke/geht so") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [9 (extrem solide)](/kategorie/info-rüstungszustand-extrem-solide.md "Kategorie:Info/Rüstungszustand/extrem solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Rüstung von [Edward](/edward.md "Edward") auf dem Friedhof beim [alten Svalichwald](/barovia.md "Barovia") von [Barovia](/barovia.md "Barovia").

* * *


## Kenndaten

- Kategorie: Rüstung
- Typ: Kopf
- Gegend: Dörrland
- Material: Metall
- Temperaturschutz: wärmt etwas
- Rüstungsstärke: geht so
- Rüstungszustand: extrem solide
- Gewicht: 2
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Helm/Edward)
