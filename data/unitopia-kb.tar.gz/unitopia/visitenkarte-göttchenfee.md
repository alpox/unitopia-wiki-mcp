---
type: Wiki Article
title: Visitenkarte/Göttchenfee
description: Von der Göttchenfee aus Luvaria.
resource: "http://unitopia.intelligense.de/wiki/Visitenkarte/Göttchenfee"
tags: [Gegenstand, Gegenstand/Märchenland, Gegenstand/Märchenland/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Unbekannt]
timestamp: 2024-03-02T19:22:11Z
revid: 267273
namespace: 0
contenthash: ba1675d2f4c21d418b30d65b1a6361fa3c97cee3b4cf9503cdd4207763ebba9c
---

## Aussehen

           &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
           &&                                                    &&
           &&                 Hallo SPIELER!                     &&
           &&             Ich bin eine Goettchenfee.             &&
           &&                                                    &&
           &&     Ich sammele für dich Gummigoettchen, sogar     &&
           &&     über WeltuntergAenge hinaus bewahre ich sie    &&
           &&                   für dich auf.                    &&
           &&     Wenn ich dir mit meinem Hobby und Berufung     &&
           &&     zu Diensten sein darf, dann schnipse diese     &&
           &&    Visitenkarte an, und ich bin augenblicklich     &&
           &&                      bei dir.                      &&
           &&                 Egal wann und wo.                  &&
           &&                                                    &&
           &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Unbekannt](/kategorie/info-material-unbekannt.md "Kategorie:Info/Material/Unbekannt") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Von der [Göttchenfee](/göttchenfee.md "Göttchenfee") aus [Luvaria](/luvaria.md "Luvaria").

## Funktion

schnipse Karte an

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Märchenland
- Material: Unbekannt
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Visitenkarte/Göttchenfee)
