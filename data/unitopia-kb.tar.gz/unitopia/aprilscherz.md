---
type: Wiki Article
title: Aprilscherz
description: ""
resource: "http://unitopia.intelligense.de/wiki/Aprilscherz"
tags: []
timestamp: 2026-04-01T17:16:05Z
revid: 256802
namespace: 0
contenthash: e47caa8f05268f7f99e90fb9638d6615b036603d5aa7f4ae6e1e662e8eda3aa9
---

1.  REDIRECT [Feiertage#Aprilscherz](/feiertage.md "Feiertage")

* * *

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Aprilscherz)
