---
type: Wiki Article
title: Zeitung/Schriften
description: "Die Zeitung Magyra-Nachrichten oder auch Magyra News. Die Zeitung bringt in unregelmäßigen Abständen Artikel über das Leben in Magyra. Dabei wird von den Redakteuren, die diese Aufgabe ehrenamtlich üb"
resource: "http://unitopia.intelligense.de/wiki/Zeitung/Schriften"
tags: [Fundort/Kauf, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Papier, Info/Schwimmt, Schriften, Schriften/Campus, Schriften/Campus/Sonstige, Schriften/Dörrland, Schriften/Dörrland/Sonstige, Schriften/Kokosinseln, Schriften/Kokosinseln/Sonstige, Schriften/Midgard, Schriften/Midgard/Sonstige, Schriften/Sonstige, Schriften/Vaniorh, Schriften/Vaniorh/Sonstige]
timestamp: 2024-04-23T19:28:27Z
revid: 266059
namespace: 0
contenthash: a41c945ce8ca19793184a072716d7d74c09375ee10d89f06c8c44b07073454dd
---

## Aussehen

Die Magyrianischen Nachrichten. Du kannst sie lesen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Papier](/kategorie/info-material-papier.md "Kategorie:Info/Material/Papier") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

-   Zu kaufen bei [Mick](/mick.md "Mick") in der Abtei-Straße von [Tadmor](/tadmor.md "Tadmor").
-   Zu kaufen bei der [Verkäuferin](/verkäuferin-saarbrücken.md "Verkäuferin/Saarbrücken") in der Bahnhofsbuchhandlung von [Saarbrücken](/saarbrücken.md "Saarbrücken").
-   Im MN-Redaktionsbüro in [Dörrstadt](/dörrstadt.md "Dörrstadt").
-   Im Regal in der Bibliothek des Yachtclubs am [Hafen](/knossos.md "Knossos") von [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").
-   In der Zweigstelle der Magyra Nachrichten in [Merredin](/merredin.md "Merredin").
-   Auf dem Tisch vor dem [Rathaus](/tadmor.md "Tadmor") von [Tadmor](/tadmor.md "Tadmor").
-   Auf dem Tisch vor der Redaktion der [Magyra News](/tadmor.md "Tadmor") in [Tadmor](/tadmor.md "Tadmor").
-   In der [Regionalbahn 2605](/regionalbahn.md "Regionalbahn").

## Funktion

-   lese Zeitung
-   falte Zeitung zu [Hut](/papierhut.md "Papierhut")
-   falte Zeitung zu [Schiff](/schiff-zeitung-schriften.md "Schiff/Zeitung/Schriften")
-   falte Zeitung zu [Schwert](/papierschwert.md "Papierschwert")
-   falte Zeitung zu [Papierflieger](/papierschwalbe.md "Papierschwalbe")

## Inhalt

Die Zeitung [Magyra-Nachrichten](/magyra-nachrichten.md "Magyra-Nachrichten") oder auch [Magyra News](/magyra-nachrichten.md "Magyra-Nachrichten"). Die Zeitung bringt in unregelmäßigen Abständen Artikel über das Leben in [Magyra](/magyra.md "Magyra"). Dabei wird von den Redakteuren, die diese Aufgabe ehrenamtlich übernommen haben, ein strikter InGame-Gesichtspunkt benutzt, selbst wenn ein Ereignis von "Außerhalb" in diese Welt übergreift.

* * *


## Kenndaten

- Kategorie: Schriften
- Typ: Sonstige
- Gegend: Campus/Dörrland/Kokosinseln/Midgard/Vaniorh
- Material: Papier
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Zeitung/Schriften)
