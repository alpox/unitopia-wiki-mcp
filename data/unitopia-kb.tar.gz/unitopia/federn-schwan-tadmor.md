---
type: Wiki Article
title: Federn/Schwan/Tadmor
description: Auszurupfen vom toten Schwan im Stadtpark von Tadmor.
resource: "http://unitopia.intelligense.de/wiki/Federn/Schwan/Tadmor"
tags: [Gegenstand, Gegenstand/Sonstige, Gegenstand/Vaniorh, Gegenstand/Vaniorh/Sonstige, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Bein, Info/Material/Textil]
timestamp: 2024-03-02T19:20:57Z
revid: 222365
namespace: 0
contenthash: 769132851457f6f775855d2f68d1f086d14e01201da505e4c6289122257a09f1
---

## Aussehen

Die schoenen weissen Federn eines Schwans.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Bein](/kategorie/info-material-bein.md "Kategorie:Info/Material/Bein"), [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Auszurupfen vom [toten Schwan](/schwan-tadmor.md "Schwan/Tadmor") im [Stadtpark](/tadmor.md "Tadmor") von [Tadmor](/tadmor.md "Tadmor").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Vaniorh
- Material: Bein/Textil
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Federn/Schwan/Tadmor)
