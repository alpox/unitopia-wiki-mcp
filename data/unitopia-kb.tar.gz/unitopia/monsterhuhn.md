---
type: Wiki Article
title: Monsterhuhn
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Monsterhuhn"
tags: [Braten, Braten/Federn, Braten/Jagen, Braten/Stück, Fundort, NPC, NPC/Kokosinseln, NPC/Kokosinseln/defensiv, NPC/defensiv, Rasse, Rasse/Vogel]
timestamp: 2024-09-16T12:10:32Z
revid: 223219
namespace: 0
contenthash: 75885f005fe2fbbbf2fc21a54af9e3317d8b6fa07a3ed48c97776aa0f6bf0d29
---

## Aussehen

```
Das Monsterhuhn hat leicht die 10fache Groesse eines normalen Huhns und
einen mindestens 20 mal so gefaehrlichen Schnabel. Die riesigen Krallen
sehen auch nicht vertrauenserweckender aus. Nur schnell weg hier.
```

## Ausrüstung

Keine.

## Heimat

Im [verfluchten Wald](/verfluchter-wald.md "Verfluchter Wald") auf [Cyprus](/cyprus.md "Cyprus").

## Besonderheit

Nach dem Töten ist das Monsterhuhn [rupf-](/gefieder-verfluchter-wald.md "Gefieder/Verfluchter Wald") und [bratbar](/braten-magyra.md "Braten/Magyra"). Der Braten lässt sich in mehrere handliche [Braten](/bratenscheibe.md "Bratenscheibe")[scheiben](/braten-scheibe.md "Braten/Scheibe"), [Braten](/bratenstück.md "Bratenstück")[stücke](/braten-stück.md "Braten/Stück") oder [Braten](/bratenteil.md "Bratenteil")[teile](/braten-teil.md "Braten/Teil") zerlegen.

## Kenndaten

- Typ: defensiv
- Gegend: Kokosinseln
- Rasse: Vogel
- Artikel: das
- Federn: Gefieder/Verfluchter Wald
- Stück: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Monsterhuhn)
