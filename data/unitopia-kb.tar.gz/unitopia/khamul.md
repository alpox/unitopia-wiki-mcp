---
type: Wiki Article
title: Khamul
description: Khamuls Schwert aus Mowan.
resource: "http://unitopia.intelligense.de/wiki/Khamul"
tags: [NPC, NPC/Midgard, NPC/Midgard/aggressiv, NPC/aggressiv, Rasse, Rasse/Geist, Rasse/Mensch, Rasse/multi]
timestamp: 2018-11-07T18:28:07Z
revid: 211798
namespace: 0
contenthash: d5241d1428fe5ec15d2efd9e0c373ef9f73477082f97c9b8249222d4a2a3becb
---

## Aussehen

Khamul: Ein Schwarzer Reiter, groesser, furchteinfloessender und mit einer
kaelteren Aura als alle anderen Schwarzen Reiter, die du je gesehen hast.
Und trotzdem spuerst du, dass er nicht der Anfuehrer aller Schwarzen Reiter
ist, sondern es noch einen ueber ihm gibt, der vermutlich noch staerker,
intelligenter, gefaehrlicher, grausamer ist.

## Ausrüstung

[Khamuls Schwert aus Mowan](/schwert-khamul.md "Schwert/Khamul").

## Heimat

In seinem finsteren Turmzimmer auf [Dol Guldur](/dol-guldur.md "Dol Guldur").

## Besonderheit

Khamul ist einer der namentlichen neun [Drachenreiter](/drachenreiter.md "Drachenreiter").

* * *


## Kenndaten

- Typ: aggressiv
- Gegend: Midgard
- Rasse: Geist/Mensch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Khamul)
