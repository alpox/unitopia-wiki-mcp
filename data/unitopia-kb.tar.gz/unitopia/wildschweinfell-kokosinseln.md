---
type: Wiki Article
title: Wildschweinfell/Kokosinseln
description: "Das Fell des Wildebers hat das Gewicht: 3."
resource: "http://unitopia.intelligense.de/wiki/Wildschweinfell/Kokosinseln"
tags: [Gegenstand, Gegenstand/Kokosinseln, Gegenstand/Kokosinseln/Sonstige, Gegenstand/Sonstige, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Gewicht/3, Info/Material, Info/Material/Leder, Info/Material/Textil]
timestamp: 2024-03-02T19:21:35Z
revid: 253375
namespace: 0
contenthash: b5b9703955b3c773d74e0fa0d86361f50f3e3637c7c7df13afcf8338398a94a8
---

## Aussehen

Ein borstiges, dichtes Wildschweinfell. Eine schoene Jagdtrophaee.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder"), [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1"), [3 (schon eher leicht)](/kategorie/info-gewicht-3.md "Kategorie:Info/Gewicht/3") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Abzuziehen vom [toten Wildeber](/wildeber.md "Wildeber") auf [Kreta](/kreta.md "Kreta").
-   Abzuziehen von der [toten Wildsau](/wildsau-kokosinseln.md "Wildsau/Kokosinseln") auf [Kreta](/kreta.md "Kreta").

## Besonderheit

Das Fell des [Wildebers](/wildeber.md "Wildeber") hat das Gewicht: **3**.

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Kokosinseln
- Material: Leder/Textil
- Gewicht: 1/3
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Wildschweinfell/Kokosinseln)
