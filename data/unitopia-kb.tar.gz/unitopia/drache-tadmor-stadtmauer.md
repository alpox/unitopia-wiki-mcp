---
type: Wiki Article
title: Drache/Tadmor/Stadtmauer
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Drache/Tadmor/Stadtmauer"
tags: [Braten, Braten/Haut, Braten/Jagen, Braten/Stück, NPC, NPC/Vaniorh, NPC/Vaniorh/defensiv, NPC/defensiv, Rasse, Rasse/Drache, Rasse/Reptil, Rasse/multi, Tätigkeit, Tätigkeit/Wächter]
timestamp: 2026-06-07T11:55:25Z
revid: 268406
namespace: 0
contenthash: 74a4a483a071c04d1e8d725f9f499f0982776c636e1e297c9363e8ba8b4cf45b
---

## Aussehen

```
Er sieht wahnsinnig gefaehrlich aus. Irgendwie erinnert er Dich an den
Lindwurm der Siegfried-Sage.
Er hat gefaehrliche Klauen.
Seine Schulterhoehe betraegt ein paar Meter.
```

## Ausrüstung

Keine.

## Heimat

Im [Labyrinth](/tadmor.md "Tadmor") unter der [Stadtmauer](/tadmor.md "Tadmor") von [Tadmor](/tadmor.md "Tadmor").

## Besonderheit

-   Nach dem Töten ist der Drache [häut-](/drachenhaut-drache-tadmor-stadtmauer.md "Drachenhaut/Drache/Tadmor/Stadtmauer") und [bratbar](/braten-magyra.md "Braten/Magyra"). Der Braten lässt sich in mehrere handliche [Braten](/bratenscheibe.md "Bratenscheibe")[scheiben](/braten-scheibe.md "Braten/Scheibe"), [Braten](/bratenstück.md "Bratenstück")[stücke](/braten-stück.md "Braten/Stück") oder [Braten](/bratenteil.md "Bratenteil")[teile](/braten-teil.md "Braten/Teil") zerlegen.
-   Wenn man in seinem Blut badet erhält man eine [wetterfeste Drachenhaut](/drachenhaut-drache-tadmor-stadtmauer2.md "Drachenhaut/Drache/Tadmor/Stadtmauer2"), dafür muss man ihn aber nicht zwangsläufig umbringen.

## Kenndaten

- Typ: defensiv
- Gegend: Vaniorh
- Rasse: Drache/Reptil
- Tätigkeit: Wächter
- Artikel: der
- Haut: Drachenhaut/Drache/Tadmor/Stadtmauer
- Stück: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Drache/Tadmor/Stadtmauer)
