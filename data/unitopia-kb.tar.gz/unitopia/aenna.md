---
type: Wiki Article
title: Aenna
description: In der Waffenkammer des Olympiastadions von Phexcaer auf Thule.
resource: "http://unitopia.intelligense.de/wiki/Aenna"
tags: [Angebot, NPC, NPC/Nordische Inseln, NPC/Nordische Inseln/defensiv, NPC/defensiv, Rasse, Rasse/Mensch]
timestamp: 2022-04-25T21:08:28Z
revid: 212468
namespace: 0
contenthash: 5f87365b9f3605651d64af2ee5cec359b21b048127b94a8c8420d79de5d40cde
---

## Aussehen

Eine junge huebsche Frau mit hochgesteckten Haaren dient hier nicht nur als
Augenweide, sondern ist den Athleten auch mit den Leihwaffen behilflich.
Auf den ersten Blick wirkt sie recht leicht bekleidet mit einem weissen
Minikleid, wie man sich eine olympische Goettin vorstellt, aber Oma
Thjodhild hat sich nicht nur protestierend, sondern auch tatkraeftig fuer
'das arme frierende Kind' eingesetzt und ihr beinlange Stiefel und
Armstulpen geschneidert.

## Ausrüstung

-   Ein [goldglänzender Haarschmuck](/haarschmuck.md "Haarschmuck").
-   Ein Paar [warme Armstulpen](/armstulpen-odian.md "Armstulpen/Odian").
-   Ein [wollenes Unterkleid](/unterkleid.md "Unterkleid").
-   Ein [göttliches Minikleid](/minikleid-odian.md "Minikleid/Odian").
-   Ein Paar [sehr lange Stiefel](/stiefel-odian.md "Stiefel/Odian").

## Heimat

In der Waffenkammer des [Olympiastadions](/olympiastadion.md "Olympiastadion") von [Phexcaer](/phexcaer.md "Phexcaer") auf [Thule](/thule.md "Thule").

## Angebot

Sie gibt einem das jeweilige Paket als Leihgabe, wenn man durch Ziehen des passenden Hebels seine Wahl trifft.

| ![Angebot-tl.gif](/images/d/db/Angebot-tl.gif) | Preisliste | ![Angebot-tr.gif](/images/5/52/Angebot-tr.gif) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | \| **Ware:** \| **[Kronen](/währung.md "Währung")**: \| \| --- \| --- \| \| Ein [Helm](/helm-aenna.md "Helm/Aenna") \| leihweise \| \| Eine [Lederrüstung](/lederrüstung-aenna.md "Lederrüstung/Aenna") \| leihweise \| \| Ein [Schwert](/schwert-aenna.md "Schwert/Aenna") \| leihweise \| \| Ein [Stahlschild](/stahlschild.md "Stahlschild") \| leihweise \| \|  \|  \| \| **Offensiv-Paket:** \|  \| \| Eine [Lederrüstung](/lederrüstung-aenna.md "Lederrüstung/Aenna") \| leihweise \| \| Ein [Langschwert](/langschwert-aenna.md "Langschwert/Aenna") \| leihweise \| \| Ein [Holzschild](/holzschild-aenna.md "Holzschild/Aenna") \| leihweise \| \|  \|  \| \| **Defensiv-Paket:** \|  \| \| Ein [Helm](/helm-aenna.md "Helm/Aenna") \| leihweise \| \| Eine [Stahlrüstung](/stahlrüstung.md "Stahlrüstung") \| leihweise \| \| Ein [Kurzschwert](/kurzschwert-aenna.md "Kurzschwert/Aenna") \| leihweise \| \| Ein [Stahlschild](/stahlschild.md "Stahlschild") \| leihweise \| \| Ein [Paar Stiefel](/stiefel-aenna.md "Stiefel/Aenna") \| leihweise \| | **Ware:** | **[Kronen](/währung.md "Währung")**: | Ein [Helm](/helm-aenna.md "Helm/Aenna") | leihweise | Eine [Lederrüstung](/lederrüstung-aenna.md "Lederrüstung/Aenna") | leihweise | Ein [Schwert](/schwert-aenna.md "Schwert/Aenna") | leihweise | Ein [Stahlschild](/stahlschild.md "Stahlschild") | leihweise |  |  | **Offensiv-Paket:** |  | Eine [Lederrüstung](/lederrüstung-aenna.md "Lederrüstung/Aenna") | leihweise | Ein [Langschwert](/langschwert-aenna.md "Langschwert/Aenna") | leihweise | Ein [Holzschild](/holzschild-aenna.md "Holzschild/Aenna") | leihweise |  |  | **Defensiv-Paket:** |  | Ein [Helm](/helm-aenna.md "Helm/Aenna") | leihweise | Eine [Stahlrüstung](/stahlrüstung.md "Stahlrüstung") | leihweise | Ein [Kurzschwert](/kurzschwert-aenna.md "Kurzschwert/Aenna") | leihweise | Ein [Stahlschild](/stahlschild.md "Stahlschild") | leihweise | Ein [Paar Stiefel](/stiefel-aenna.md "Stiefel/Aenna") | leihweise |  |
| **Ware:** | **[Kronen](/währung.md "Währung")**: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Helm](/helm-aenna.md "Helm/Aenna") | leihweise |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Lederrüstung](/lederrüstung-aenna.md "Lederrüstung/Aenna") | leihweise |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Schwert](/schwert-aenna.md "Schwert/Aenna") | leihweise |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Stahlschild](/stahlschild.md "Stahlschild") | leihweise |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| **Offensiv-Paket:** |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Lederrüstung](/lederrüstung-aenna.md "Lederrüstung/Aenna") | leihweise |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Langschwert](/langschwert-aenna.md "Langschwert/Aenna") | leihweise |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Holzschild](/holzschild-aenna.md "Holzschild/Aenna") | leihweise |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| **Defensiv-Paket:** |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Helm](/helm-aenna.md "Helm/Aenna") | leihweise |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Stahlrüstung](/stahlrüstung.md "Stahlrüstung") | leihweise |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Kurzschwert](/kurzschwert-aenna.md "Kurzschwert/Aenna") | leihweise |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Stahlschild](/stahlschild.md "Stahlschild") | leihweise |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Paar Stiefel](/stiefel-aenna.md "Stiefel/Aenna") | leihweise |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ![Angebot-bl.gif](/images/3/3b/Angebot-bl.gif) |  | ![Angebot-br.gif](/images/9/92/Angebot-br.gif) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Nordische Inseln
- Rasse: Mensch
- gegenstand: Medium-Paket:

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Aenna)
