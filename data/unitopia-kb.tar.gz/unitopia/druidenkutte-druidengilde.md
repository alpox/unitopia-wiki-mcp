---
type: Wiki Article
title: Druidenkutte/Druidengilde
description: ""
resource: "http://unitopia.intelligense.de/wiki/Druidenkutte/Druidengilde"
tags: [Fundort, Fundort/Kauf, Hidden, Info, Info/Brennbar, Info/Fasst, Info/Fasst/Gegenstand, Info/Fasst/Kraut, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Info/Volumen, Info/Volumen/12, Info/Volumen/6, Kleidung, Kleidung/Brust, Kleidung/Dörrland, Kleidung/Dörrland/Brust, Kleidung/Gallien, Kleidung/Gallien/Brust, Kleidung/Kokosinseln, Kleidung/Kokosinseln/Brust, Kleidung/Vaniorh, Kleidung/Vaniorh/Brust, Spalten, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2026-03-18T18:21:24Z
revid: 267288
namespace: 0
contenthash: 97def9419aa37eb558a60496dec0ee1ac805871e33fba4e0fe2a6723881630ab
---

## Aussehen

Es ist die weisse Kutte eines Druiden. Sie besitzt eine grosse
Kapuze, unter der man sein Gesicht gut verbergen kann.
Ausserdem waere da noch so eine neckische Innentasche zu erwaehnen...

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Fasst](/kategorie/info-fasst.md "Kategorie:Info/Fasst"):** | [Gegenstand](/kategorie/gegenstand-sonstige.md "Kategorie:Gegenstand/Sonstige"), [Kraut](/kräuter.md "Kräuter") |
| **[Volumen](/kategorie/info-volumen.md "Kategorie:Info/Volumen"):** | 6, 12 |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Zu kaufen bei [Sardor](/sardor.md "Sardor") in seinem Refugium in der [Druidengilde](/druidengilde.md "Druidengilde") von [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").
-   Kutte von [Allanon](/allanon.md "Allanon") in seinem Arbeitszimmer der [Druidenburg](/druidenburg.md "Druidenburg").
-   Kutte vom [Druiden](/druide-druidengilde.md "Druide/Druidengilde"), erscheint wenn [Ramas](/ramas.md "Ramas") angegriffen wird, in der [Druidengilde](/druidengilde.md "Druidengilde") von [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").
-   Kutte vom [traurigen Druiden](/druide-tadmor.md "Druide/Tadmor") auf der [Stadtmauer](/tadmor.md "Tadmor") von [Tadmor](/tadmor.md "Tadmor").
-   Kutte von [Hermes](/hermes.md "Hermes") im [Café Teutates](/druidengilde.md "Druidengilde") in [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").
-   Kutte von [Ichton](/ichton.md "Ichton") in seiner Hütte inmitten des Haines nahe der [Römerstraße IV](#Römerstraße_IV).
-   Kutte von [Isabella](/isabella.md "Isabella") in ihrem Kräuterladen im [idyllischen Park](/knossos.md "Knossos") von [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").
-   Kutte von der [Leiche eines Druiden](/leiche-druide.md "Leiche/Druide") im Spinnennest in den Tiefen des [großen Knopf-Labyrinths](/knopflabyrinth.md "Knopflabyrinth") in [Nordwestdörrland](/nordwestdörrland.md "Nordwestdörrland").
-   Kutte von [Mixnix](/mixnix.md "Mixnix") in seiner Hütte nördlich von [Lutetia](/lutetia.md "Lutetia").
-   Kutte von [Panoramix](/panoramix.md "Panoramix") in der Krone einer Eiche südöstlich vom [Gallischen Dorf](/gallierdorf.md "Gallierdorf").
-   Kutte von [Ramas](/ramas.md "Ramas") in seinem Büro in der [Druidengilde](/druidengilde.md "Druidengilde") von [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").
-   Kutte von [Talesin](/talesin.md "Talesin") im Informationsraum der [Druidengilde](/druidengilde.md "Druidengilde") im [Rathaus](/tadmor.md "Tadmor") von [Tadmor](/tadmor.md "Tadmor").

## Besonderheit

-   Die Innentasche konserviert [Kräuter](/kräuter.md "Kräuter").

-   Zusätzliches Aussehen beim Betrachten einer Person:

| -   **Mann:** | Er traegt eine strahlend weisse Kutte. Auf der Kapuze siehst Du eine goldene Stickerei in Form eines Mistelzweigs. |
| --- | --- |
| -   **Frau:** | Sie traegt eine strahlend weisse Kutte. Auf der Kapuze siehst Du eine goldene Stickerei in Form eines Mistelzweigs. |
| -   **Etwas:** | Es traegt eine strahlend weisse Kutte. Auf der Kapuze siehst Du eine goldene Stickerei in Form eines Mistelzweigs. |

\[Spoilerwarnung\]  

-   Die Kutte ändert je nach Rang die Farbe und Stickerei:

| **Rang** | **Farbe** | **Stickerei** |
| --- | --- | --- |
| _Bei Erhalt_ | schwarz | _ohne_ |
| Novize | grau | _ohne_ |
| Initiat | hellgrau | _ohne_ |
| Adept | weiß | Auf ihr ist eine silberne Stickerei in Form eines Mistelzweigs. |
| Priester | weiß | Auf ihr ist eine goldene Stickerei in Form eines Mistelzweigs. |
| Hohepriester | strahlend weiß | Auf ihr ist eine Stickerei eines goldenen Mistelzweigs vor einem grünen Eichenblatt zu sehen. Das ist dann wohl die Kutte eines der Hohepriester der Druiden. |
| Eremit | grün und komplett mit Runen übersät | Auf ihr ist ein goldenes Auge aufgestickt, welches durch einen, ebenfalls aufgestickten, grünen Mistelzweig blickt. |
| Schutzgott | grün und komplett mit Runen übersät | Auf ihr ist ein goldenes Auge aufgestickt, das durch einen aufgestickten, grünen Mistelzweig blickt. |

-   Mit Saft aus der [Saftpresse](/saftpresse.md "Saftpresse") kann man die Kutte einfärben. - verfärbe Kutte <Farbe> mit ...saft - Wichtig dabei ist, dass die Farbe klein geschrieben wird.

-   rot -> Tomatensaft
-   grün -> Kiwisaft
-   blau -> Blaubeerensaft
-   orange -> Orangensaft
-   gelb -> Zitronensaft
-   violett -> Auberginensaft
-   rosa -> Himbeersaft

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Brust
- Gegend: Dörrland/Kokosinseln/Gallien/Vaniorh
- Material: Textil
- Temperaturschutz: wärmt etwas
- Fasst: Gegenstand/Kraut
- Volumen: 6/12
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein
- ul: ja
- ColumnC: 4
- Left: 1.6em

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Druidenkutte/Druidengilde)
