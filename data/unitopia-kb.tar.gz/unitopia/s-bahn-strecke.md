---
type: Wiki Article
title: "S-Bahn/Strecke"
description: "Das umfangreiche S-Bahn-System verbindet das Campusgelände der Universität Stuttgart über mehrere kleinere Zwischenhaltestellen mit dem Hauptbahnhof Stuttgart und der Haltestelle Vaihingen. Sie wird v"
resource: "http://unitopia.intelligense.de/wiki/S-Bahn/Strecke"
tags: [Campus, Karte]
timestamp: 2021-10-26T19:49:23Z
revid: 265748
namespace: 0
contenthash: 18114839e1caf542bd1f5dd7edb7b3b8ec151937af70746275e071353ba40e01
---

| **[Koordinaten](/kategorie/kompass.md "Kategorie:Kompass"):** Unbekannt | **[Gegend](/kategorie/magyra.md "Kategorie:Magyra"):** [Campus](/campus.md "Campus") | **[Währung](/kategorie/gegenstand-geld.md "Kategorie:Gegenstand/Geld"):** [Mark](/mark.md "Mark") |
| --- | --- | --- |

Das umfangreiche S-Bahn-System verbindet das [Campusgelände](/universität.md "Universität") der [Universität Stuttgart](#Universität) über mehrere kleinere Zwischenhaltestellen mit dem [Hauptbahnhof Stuttgart](#Hauptbahnhof) und der Haltestelle [Vaihingen](#Vaihingen). Sie wird von den S-Bahn [Linie 1](/s-bahn-linie-1.md "S-Bahn/Linie 1"), [Linie 2](/s-bahn-linie-2.md "S-Bahn/Linie 2") und [Linie 4](/s-bahn-linie-4.md "S-Bahn/Linie 4") befahren. Überall an den Bahnhöfen und Haltestellen wurden [VVS-Fahrkartenautomaten](/vvs-fahrkartenautomat.md "VVS-Fahrkartenautomat") aufgestellt, damit man dort seine [VVS-Fahrkarte](/vvs-fahrkarte.md "VVS-Fahrkarte") kaufen kann.

# [Streckenplan](#toc)

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

                        A
                       /
                      /
                     7--T--8--9--A
                      ˅
                       ˄
                        T
                       /
                      /
                     7
                    /
                   /
                  T
                 /    
                /
               6
              /
             /
            T
           /
          /
         5
        /
       /
      T
     /
    /
   4
  /
 /
T
|
|
1
|
|
1
|
|
T
|
|
2
|
|
D
|
|
3
|
|
A

A Abstellgleis
D S-Bahn-Damm
T S-Bahn-Tunnel

1 Haltestelle [Universität](#Universität)
  ([Campusgelände](/campusgelände.md "Campusgelände"))
2 Haltestelle [Oesterfeld](#Oesterfeld)
3 Haltestelle [Vaihingen](#Vaihingen)
4 Haltestelle [Schwabstraße](#Schwabstraße)
5 Haltestelle [Feuersee](#Feuersee)
6 Haltestelle [Stadtmitte](#Stadtmitte)
7 [Hauptbahnhof Stuttgart](#Hauptbahnhof)
8 Eisenbahnbrücke über den Neckar
9 Haltestelle [Bad Cannstatt](#Bad_Cannstatt)

## [Universität](#toc)

Die S-Bahn-Haltestelle Universität war viele Jahrzehnte lang die erste Anlaufstelle in [UNItopia](https://www.unitopia.de), denn am Südende von Bahnsteig 1 betrat man das [Campusgelände](/campusgelände.md "Campusgelände"). Im Tunnel nördlich des Nordendes des gleichen Bahnsteigs ist der Aufgang nach [Magyra](/magyra.md "Magyra"). Und über das [S-Bahngleis-System](/s-bahn-strecke.md "S-Bahn/Strecke") kann man weitere Teile vom [Campus](/campus.md "Campus") erreichen und wenn man will sogar andere Städte.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

2
'
˄
o     4     S
|     ˅     |
|     ˄     |
o  3--o--5  o
| ˅       ˅ |
|˄         ˄|
o           o
|           |
|           |
1           S

S [S-Bahngleis-System](#Streckenplan)
 
1 S-Bahn-Haltestelle Universität
2 Kathedrale in [Tadmor](/tadmor.md "Tadmor") 
  ([Magyra](/magyra.md "Magyra"))
3 S-Bahn-Unterführung an der Universität
  ([VVS-Fahrkartenautomat](/vvs-fahrkartenautomat.md "VVS-Fahrkartenautomat"))
4 [Campusgelände](/campusgelände.md "Campusgelände")
5 S-Bahn-Treppe Universität
  ([VVS-Fahrkartenautomat](/vvs-fahrkartenautomat.md "VVS-Fahrkartenautomat"))

## [Oesterfeld](#toc)

Die S-Bahn-Haltestelle "Oesterfeld" ist eine verlassene, laut Beschreibung zum Park+Ride gedachte Haltestelle mitten in einem kleinen Tal gelegen. Im Norden liegt der S-Bahn-Tunnel in Richtung [Stadtmitte](/stadtmitte.md "Stadtmitte"), während nach Süden ein Bahndamm weiter Richtung [Vaihingen](/vaihingen.md "Vaihingen") verläuft. Weiter gibt es hier nichts.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

S
|
|
1
|
|
S

S [S-Bahngleis-System](#Streckenplan)

1 Haltestelle Oesterfeld

## [Vaihingen](#toc)

Außer einer recht nahe an der Realität des Jahres 1992 angepassten Beschreibung der vor Ort zu sehenden Einrichtungen hat das virtuelle Vaihingen bisher leider nur den S-Bahnhof, zwei Telefonzellen und das Institutsgebäude der Fakultät Informatik zu bieten. Trotz intensiver Suche wurde kein einziger Bewohner ausgemacht.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

      S
      |
      |
   1  1
  ˅  ˅|
 ˄  ˄ |
3--3--+--4
      |  |
      |  |
      2  o--o--o--5--6--7
                        |
                        |
                        8
                        |
                        |
                        o--o--9-10--o----11--o
                                    |     |
                                    |     |
                                    o--F  F
                                    |
                                    |
                                   12--F

 F [Fakultät Informatik](#Fakultät_Informatik)
 S [S-Bahngleis-System](#Streckenplan)
 
 1 S-Bahnhof Vaihingen
   ([VVS-Fahrkartenautomat](/vvs-fahrkartenautomat.md "VVS-Fahrkartenautomat"))
 2 Abstellgleis
 3 Unter der S-Bahnstation
 4 Ostausgang
 5 Kautt und Bux
 6 Vor zwei Telefonzellen
 7 Vor einer Tankstelle
 8 Vor dem TWS-Gelaende
 9 Firma Albert Kuhn
10 Rampe der Firma Lapp Kabel
11 Vor der Fakultät Informatik
12 Treppe zur Fakultaet Informatik

### [Fakultät Informatik](#toc)

Neben einigen Hörsäälen hat die Informatik einiges für Nostalgiker zu bieten. Nicht allein das Institutseigene Museum, eine Aufstellung uralter Computer und Terminals, die wohl aus Gründen der Restzeit bis zur endgültigen Abschreibung erfolgt ist, sondern auch das durch den Zahn der Zeit gealterte Inventar ist einen Besuch unbedingt wert. Es gibt hier einen DEC-Pool, einen Terminalraum, einen VMS-Pool, einen PC-Pool, einen als Maschinenraum bekannten Computerraum und sogar ein Videolabor! Der Besuch lohnt sich unbedingt für den zur Nostalgie neigenden Computerkenner. Ein besonderes Erlebnis dürfte auch der Besuch in der Fachschaft Informatik sein, die mit all ihrem Durcheinander authentisch nach dem Zustand in den beginnenden Neunzigern beschrieben wurde.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

                      V        o ˅ ˄ o
                      |              ˅
                      |              ˄
    o        o ˅ ˄ o  |     2        4
    ˅               ˅ |     |        |
    ˄                ˄|     |        |
    4-----o--o--o--o--6-----o-----o--o
    |              |  |     |     |
    |              |  |     |     |
    |              5  |     |     7
    |                 |     |     |
    |                 |     |     |  
    |     o-----8-----o     |     7
    |    /      |     |     |     |
    |   /       |     |     |     |
 V--o-12        |  o  o-11  |     |
    |  |\\_\_\_    |  .  |     |     |
    |  |    \   |  .  |     |     |
    8  8     8  |  o..3     9-10  7
    |  |    /   |     |     |  |  |
    |  |   /    |     |     |  |  |
    |  o--o     |     |     9  |  |     o
    | /         |     |     |  |  |     ˅
    |/          |     |     |  |  |     ˄
 V--o       13--o 14  |     9 10  o     o
    |           |  |  |     | /   |     ˅
    |           |  |  |     |/    |     ˄
14--o-----o-----o--o--o-----o-----o--o--3
    |     |           |
    |     |           |
   16    17           o

 V [Vaihingen](#Vaihingen)
 
 1 Bushaltestelle
 2 Informatik-Bibliothek
 3 Treppe
 4 Sitzecke
 5 Kopierraum
 6 Foyer
 7 Hardware-Praktikums
 8 Hörsaal
 9 Terminalraum
10 Maschinenraum
11 PC-Pool
12 Museeum
13 DEC-Pool
14 Videolabor
15 Fachschaft Informatik
16 VMS-Pool
17 Nische
18 Rampe

## [Schwabstraße](#toc)

Die Haltestelle "Schwabstraße" ist eine einfache S-Bahn-Haltestelle. Geht man die Treppe hoch, kommt man in die "Schwabstraße", wo es außer einer Straßenlaterne nur einen einsamen [Fahrkartenautomaten der VVS](/vvs-fahrkartenautomat.md "VVS-Fahrkartenautomat") gibt.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

   2  S
   ˅ /
   ˄/
   1
  /
 /
S

S [S-Bahngleis-System](#Streckenplan)

1 Haltestelle Schwabstraße
2 Schwabstraße
  ([VVS-Fahrkartenautomat](/vvs-fahrkartenautomat.md "VVS-Fahrkartenautomat"))

## [Feuersee](#toc)

Die Haltestelle "Feuersee" ist eine einfache S-Bahn-Haltestelle. Geht man die Treppe hoch, kommt man nach einer Stelle namens "Am Feuersee", wo es außer einem Feuersee, der nicht wirklich da ist und einer Kirche, die nicht wirklich da ist, gar nichts gibt.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

   2  S
   ˅ /
   ˄/
   1
  /
 /
S

S [S-Bahngleis-System](#Streckenplan)

1 Haltestelle Feuersee
2 Am Feuersee
  ([VVS-Fahrkartenautomat](/vvs-fahrkartenautomat.md "VVS-Fahrkartenautomat"))

## [Stadtmitte](#toc)

Die Haltestelle "Stadtmitte" ist eine einfache Haltestelle und es gibt hier nicht viel zu sehen. Geht man hoch, kommt man zur "Calwer-Passage", deren einzige Besonderheit ein [Fahrkartenautomaten der VVS](/vvs-fahrkartenautomat.md "VVS-Fahrkartenautomat") ist.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

   2  S
   ˅ /
   ˄/
   1
  /
 /
S

S [S-Bahngleis-System](#Streckenplan)

1 Haltestelle Stadtmitte
2 Calwer-Passage
  ([VVS-Fahrkartenautomat](/vvs-fahrkartenautomat.md "VVS-Fahrkartenautomat"))

## [Hauptbahnhof](#toc)

Über den Hauptbahnhof von Stuttgart kann man die Städte [Erlangen](/erlangen.md "Erlangen"), [Mannheim](/mannheim.md "Mannheim"), [Paris](/paris-campus.md "Paris/Campus") und [Saarbrücken](/saarbrücken.md "Saarbrücken") erreichen, sowie andere [Haltestellen](#Streckenplan) von Stuttgart. Wer sich auf dem Hauptbahnhof länger aufhält und sich eventuell noch ein wenig um guckt kann das [Rangierenspiel](/rangieren.md "Rangieren") finden.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

           11
             ˅
              ˄
         8     o    10
        /       ˅   /
       /         ˄ /
      7--S        o
     / ˅         ˅
    /   ˅       ˄
   1     ˅     o
  / \     ˅   ˅
 /   \     ˅ ˅
2     \     ◊
 ˅     \   ˄ ˄    
  ˄     \ ˄   ˄  
   3     9     o
  / ˅         /
 /   ˄       /
4     5     /
       ˅   /
        ˄ /
         6
        /
       /
      S

 S [S-Bahngleis-System](#Streckenplan)
  
 1 Bahnsteig
   (Anzeigetafel)
   ([EuroCity 0815](/eurocity.md "EuroCity"))
   ([Regionalbahn 2605](/regionalbahn.md "Regionalbahn"))
 2 Stuttgarter Hauptbahnhof, obere Halle
 3 Stuttgarter Hauptbahnhof, untere Halle
 4 Schalterhalle
 5 Klett-Passage
   ([VVS-Fahrkartenautomat](/vvs-fahrkartenautomat.md "VVS-Fahrkartenautomat"))
 6 S-Bahn-Bahnsteig
 7 Gelände
 8 Abstellgleis
 9 Dunkle Abstellkammer
10 Stellwerk
11 Turm

## [Bad Cannstatt](#toc)

Bad Cannstatt hat neben dem Bahnhof noch eine [Postfiliale](/postbeamter-bad-cannstatt.md "Postbeamter/Bad Cannstatt") und eine Bank zu bieten, wobei diese Bank die zweite überhaupt ist, die es auf dem Campus und den dazu gehörenden Städten gibt. Und natürlich hat Bad Cannstatt den in der ganzen Welt, sowohl [Campus](/campus.md "Campus") als auch [Magyra](/magyra.md "Magyra"), bekannten und beliebten [Rummelplatz](/bad-cannstatt.md "Bad Cannstatt"), der Cannstatter Wasn!

Die [Bank](/bank.md "Bank") von Bad Cannstatt ist etwas ganz besonderes. Nicht allein, dass man erst an jeden Schalter herantreten muss, um die gewohnten Bankbefehle zu erhalten, es gibt außerdem auch noch eine Schließfachabteilung! Zwar ist es derzeit noch immer nicht möglich, eines der im Keller je paarweise in insgesamt acht einzelnen Räumen untergebrachten insgesamt sechzehn Schließfächer zu mieten, aber allein der Umstand, dass sie vorhanden sind und sichtlich fast fertig zur Inbetriebnahme, macht sie zu einem besuchenswerten Unikum!

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

               1
              ˅
             ˄
S--1--S  X  o
    ˅    | ˅
     ˄   |˄
      o  2--3--4--4
       ˅ |  |
        ˄|  |
         o  5
         |  |
         |  |
         |  o
         |   ˅
         |    ˄
         o--7  o     6
         |      ˅    |
         |       ˄   |
         o        o  6
         |         ˅ |
         |          ˄|
         o     6--6--o--6--6
         |           |
         |           |
         R           6
                     |
                     |
                     6

R [Rummel](#Rummel)
S [S-Bahngleis-System](#Streckenplan)

1 Bahnhof Bad Cannstatt
  ([VVS-Fahrkartenautomat](/vvs-fahrkartenautomat.md "VVS-Fahrkartenautomat"))
2 Bahnhofshalle
  ([VVS-Fahrkartenautomat](/vvs-fahrkartenautomat.md "VVS-Fahrkartenautomat"))
3 [Eingangshalle der Bad Cannstatter Bank](/bank.md "Bank")
4 Schalterhalle
5 Schließfachabteilung
6 Keller
  (Schließfach Nr. 1-16)
7 [Bad Cannstatter Postamt](/post.md "Post")
  ([Postbeamter](/postbeamter-bad-cannstatt.md "Postbeamter/Bad Cannstatt"))

### [Rummel](#toc)

Das Volksfest von Bad Cannstatt ist der bisher lebendigste Teil der Campuswelt. Hier gibt es ein [Fernsehzelt](/fernsehquiz.md "FernsehQuiz"), wo man einem [Fernsehexperten](/oliver.md "Oliver") sein Wissen beweisen kann, den Bungeeturm, eine [Geisterbahn](/slimer.md "Slimer"), in der man auf einer interessanten Fahrt sogar einen ungewöhnlichen [Reiseleiter](/dämon-bad-cannstatt.md "Dämon/Bad Cannstatt") erhält, ein [Karussel](/flip.md "Flip") und eine [Wasserbobbahn](/donatello.md "Donatello"). Wer all diese Fahrgeschäfte glücklich besucht hat, kann an einer [Süsswarenbude](/tekla.md "Tekla") etwas für sein leibliches Wohl tun oder sich zum Biertrinken ins [Bierzelt](/zenzi.md "Zenzi") begeben.

Der Bungeeturm wird von der Familie Bungee betrieben und stellt die Möglichkeit dar, sich seinen Mut zu beweisen und einen Bungeesprung am Seil zu machen! Es gibt einen eigenen Kiosk, an dem man bei [PeggyBungee](/peggybungee.md "PeggyBungee") das Ticket kaufen kann, oben auf dem Turm steht, je nach Geschlecht des Besuchers, als Turmaufseher [KellyBungee](/kellybungee.md "KellyBungee"), [BudBungee](/budbungee.md "BudBungee") oder [ItBungee](/itbungee.md "ItBungee"), die auch das Seil anbinden und der [AlBungee](/albungee.md "AlBungee") persönlich lässt es sich nicht nehmen, ein wachsames Auge auf alles zu haben und erfolgreichen Springern einen [Ansteckpin](/bungee-pin.md "Bungee-Pin") zu verleihen, der einem als [Autoloader](/autoloader.md "Autoloader") auf ewig erhalten bleibt, außer, man wirft ihn weg.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

5--o  o
 '  '/ \
  ' /'  \
   3--4  o  B
    \   /   |
     \ /    |
   2--o-----1--o--6
            |  |
            |  |
            o--7
            |  |
            |  |
        11  8--9
         |  |  |
         |  |  |
        10--o-12
            |  |
            |  |
         o--o--o
            |
            |
            o
            |
            |
            o
            |
            |
           13

 B [Bahnhof](#Bad_Cannstatt)
 
 1 Rummel in Cannstatt
   ([Mülltonne](/mülltonne.md "Mülltonne"))
 2 Kiosk
   ([PeggyBungee](/peggybungee.md "PeggyBungee"))
 3 Vor dem Bungeeturm
   ([AlBungee](/albungee.md "AlBungee"))
 4 _Wendeltreppe_
 5 Ausleger des Bungeeturmes
   ([Bud](/budbungee.md "BudBungee"), [Kelly](/kellybungee.md "KellyBungee") oder [ItBungee](/itbungee.md "ItBungee"))
 6 Fernseh-Zelt
   ([Oliver](/oliver.md "Oliver"))
   ([FernsehQuiz](/fernsehquiz.md "FernsehQuiz"))
 7 Vergnügungspark
   ([Slimer](/slimer.md "Slimer"))
 8 Karussellplatz
   ([Flip](/flip.md "Flip")))
 9 Süßigkeiten-Stand
   ([Tekla](/tekla-bad-cannstatt.md "Tekla/Bad Cannstatt"))
10 Bierzelt
   ([Zenzi](/zenzi.md "Zenzi"))
11 Bierzelt
   ([Band](/band-bierzelt.md "Band/Bierzelt"))
12 Wasserbobbahn
   ([Donatello](/donatello.md "Donatello"))
13 Weg zum Neckerstadion

* * *

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/S-Bahn/Strecke)
