---
type: Wiki Article
title: Erdbeeren/Barovia
description: An den Erdbeerstauden im Garten des Landhauses in Barovia.
resource: "http://unitopia.intelligense.de/wiki/Erdbeeren/Barovia"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Dörrland, Nahrung/Dörrland/Pflanze, Nahrung/Pflanze]
timestamp: 2024-08-29T15:21:27Z
revid: 211973
namespace: 0
contenthash: 5c842e102366302ac0b3630ccffa87eadcf52dd70ddcd7c1b3ef1c6472eab2e3
---

## Aussehen

Erdbeeren. Man kann sie essen.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

An den Erdbeerstauden im Garten des [Landhauses](/barovia.md "Barovia") in [Barovia](/barovia.md "Barovia").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Pflanze
- Gegend: Dörrland
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Erdbeeren/Barovia)
