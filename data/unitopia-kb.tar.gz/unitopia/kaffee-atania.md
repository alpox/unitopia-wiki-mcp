---
type: Wiki Article
title: Kaffee/Atania
description: Zu kaufen bei Atania im Café Seegarten in den hängenden Gärten von Knossos auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/Kaffee/Atania"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/durstlöschend, Nahrung, Nahrung/Getränk, Nahrung/Kokosinseln, Nahrung/Kokosinseln/Getränk]
timestamp: 2024-08-29T15:13:59Z
revid: 245264
namespace: 0
contenthash: e6e3bc100abedc209ec94109f3b7bec9e538d0e523412d94613a108fc6fff05b
---

## Aussehen

Eine Tasse schoener heisser Kaffee. Belebt und haelt wach.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend") |

## Fundort

Zu kaufen bei [Atania](/atania.md "Atania") im Café Seegarten in den [hängenden Gärten](/knossos.md "Knossos") von [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Getränk
- Gegend: Kokosinseln
- Gewicht: 1
- Wirkung: durstlöschend

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Kaffee/Atania)
