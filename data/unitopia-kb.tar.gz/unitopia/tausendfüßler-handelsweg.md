---
type: Wiki Article
title: Tausendfüßler/Handelsweg
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Tausendfüßler/Handelsweg"
tags: [Fundort, NPC, NPC/Gallien, NPC/Gallien/defensiv, NPC/Vaniorh, NPC/Vaniorh/defensiv, NPC/defensiv, Rasse, Rasse/Insekt]
timestamp: 2024-09-16T12:11:20Z
revid: 250805
namespace: 0
contenthash: 64637d36106d77c115aac610dbd02d236ed3e66d4049612a0c56a4cfacf2dd1d
---

## Aussehen

Ein Tausendfuessler mit 1000 Beinen. Er krabbelt ueber den Boden.

## Ausrüstung

Keine.

## Heimat

-   Durch [Schwarz sehen](/sehergilde.md "Sehergilde") von einem Mitglied der [Sehergilde](/sehergilde.md "Sehergilde").
-   Auf einem schmalen Weg des [alten Terqa-Handelsweges](/handelsweg-terqa.md "Handelsweg/Terqa").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Gallien/Vaniorh
- Rasse: Insekt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Tausendfüßler/Handelsweg)
