---
type: Wiki Article
title: Knochensplitter/Ghal
description: "Waffe vom Ghal an einer Kanal-Abzweigung in der Kanalisation unter Dörrstadt."
resource: "http://unitopia.intelligense.de/wiki/Knochensplitter/Ghal"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Bein, Info/Waffenstärke, Info/Waffenstärke/geht so, Info/Waffenzustand, Info/Waffenzustand/mäßig haltbar, Waffe, Waffe/Dörrland, Waffe/Dörrland/Messer, Waffe/Messer]
timestamp: 2024-03-02T19:19:28Z
revid: 257412
namespace: 0
contenthash: 6212ff728dc1c8b2849652d435d89af62ff6bc5c71a408f7b57e5a95262cd8fe
---

## Aussehen

Ein fies gesplittertes Stueck Knochen mit einer ziemlich scharfen Spitze.
Der Groesse und Form nach handelt es sich ziemlich sicher um den Rest eines
menschlichen Oberarmknochens.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Bein](/kategorie/info-material-bein.md "Kategorie:Info/Material/Bein") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [4 (geht so)](/kategorie/info-waffenstärke-geht-so.md "Kategorie:Info/Waffenstärke/geht so") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [3 (mäßig haltbar)](/kategorie/info-waffenzustand-mäßig-haltbar.md "Kategorie:Info/Waffenzustand/mäßig haltbar") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Waffe vom [Ghal](/ghal.md "Ghal") an einer Kanal-Abzweigung in der [Kanalisation](/dörrstadt.md "Dörrstadt") unter [Dörrstadt](/dörrstadt.md "Dörrstadt").

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Messer
- Gegend: Dörrland
- Material: Bein
- Waffenstärke: geht so
- Waffenzustand: mäßig haltbar
- Gewicht: 2
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Knochensplitter/Ghal)
