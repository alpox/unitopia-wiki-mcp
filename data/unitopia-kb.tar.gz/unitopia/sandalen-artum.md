---
type: Wiki Article
title: Sandalen/Artum
description: "Kleidung von Artum im Rathaus von Alt-Dörrstadt."
resource: "http://unitopia.intelligense.de/wiki/Sandalen/Artum"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Leder, Kleidung, Kleidung/Dörrland, Kleidung/Dörrland/Füße, Kleidung/Füße]
timestamp: 2024-03-02T19:19:14Z
revid: 208560
namespace: 0
contenthash: 85d3a7ae80a26a3edddfcc2959b36ad9675ac7ad6477714a69f15ac306c3ad77
---

## Aussehen

Diese Sandalen sind wenig mehr als Ledersohlen mit daran befestigten
Lederriemen. Nichts schickes, aber man verbrennt sich damit im Sand nicht
die Fuesse und kann laestige Skorpione zertreten. Ganz praktisch also.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Kleidung von [Artum](/artum.md "Artum") im [Rathaus](/alt-dörrstadt.md "Alt-Dörrstadt") von [Alt-Dörrstadt](/alt-dörrstadt.md "Alt-Dörrstadt").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Füße
- Gegend: Dörrland
- Material: Leder
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Sandalen/Artum)
