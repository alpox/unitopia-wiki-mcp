---
type: Wiki Article
title: Honigkuchen/Naike
description: Zu kaufen bei Naike auf dem Weihnachtsmarkt von Nankea (Stadt) auf Nankea.
resource: "http://unitopia.intelligense.de/wiki/Honigkuchen/Naike"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Midgard, Nahrung/Midgard/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:13:41Z
revid: 245243
namespace: 0
contenthash: fe296254732cb25e161ea01c6cebf1a2195eb9611c5da07df80f419a96cba0d1
---

## Aussehen

Ein Stueck leckerer Honigkuchen vom Weihnachtsmarkt zu Nankea.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Zu kaufen bei [Naike](/naike.md "Naike") auf dem [Weihnachtsmarkt](/weihnachtsmarkt.md "Weihnachtsmarkt") von [Nankea (Stadt)](/nankea-\(stadt\).md "Nankea (Stadt)") auf [Nankea](/nankea.md "Nankea").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Midgard
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Honigkuchen/Naike)
