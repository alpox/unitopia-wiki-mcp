---
type: Wiki Article
title: Oroonoque
description: roonoque ist eine Insel in der Nähe von Dörrland. Die Insel kann schwimmend erreicht werden oder über ihren Anlegersteg. Diese von undurchdringlichem Dschungel und unüberwindbaren Felsen bestimmte Ins
resource: "http://unitopia.intelligense.de/wiki/Oroonoque"
tags: [Dörrland, Insel, Insel/Dörrland, Insel/Magyra, Tabs]
timestamp: 2024-08-20T13:45:13Z
revid: 250586
namespace: 0
contenthash: ba6d22d97f09b80b18ca786131b3a00d638abeb55ca310e72c6609e6f30f2ffd
---

| [![Icon Unitopia.gif](/images/f/fe/Icon_Unitopia.gif)](/unitopia.md "Unitopia") |  | [Dörrland](/dörrland.md "Dörrland") |  | [Affeninsel](/affeninsel.md "Affeninsel") |  | [große Sandinsel](/große-sandinsel.md "Große Sandinsel") |  | [mittlere Sandinsel](/mittlere-sandinsel.md "Mittlere Sandinsel") |  | [kleine Sandinsel](/kleine-sandinsel.md "Kleine Sandinsel") |  | [Oroonoque](/oroonoque.md "Oroonoque") |  | [String Dreieck](/string-dreieck.md "String-Dreieck") |  | [Tobago](/tobago.md "Tobago") |  | [Höhlenwelt](/höhlenwelt.md "Höhlenwelt") |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

  

[![Oroonoque Logo.png](/images/thumb/9/94/Oroonoque_Logo.png/250px-Oroonoque_Logo.png)](/datei/oroonoque-logo.png.md)

[![O Letter.png](/images/thumb/a/a0/O_Letter.png/60px-O_Letter.png)](/datei/o-letter.png.md)roonoque ist eine Insel in der Nähe von [Dörrland](/dörrland.md "Dörrland"). Die Insel kann schwimmend erreicht werden oder über ihren Anlegersteg. Diese von undurchdringlichem Dschungel und unüberwindbaren Felsen bestimmte Insel kann man selbst erkunden und am Strand z.B. selbst eine Feuerstelle zusammenbauen. Es gibt hier einiges an Pflanzen und Tieren zu sehen. Am Nordrand der Insel gibt es eine gemütliche Hütte mit ausladender Veranda. Auf dieser steht auch der begehrte [rustikale Korbsessel](/korbsessel.md "Korbsessel"). Die Höhle am Ostrand der Insel ist seit dem letzten Vulkanausbruch leider nicht mehr sehr groß. Nur eine kleine Pfütze bietet hier eine Trinkwasserquelle. Wer durstig ist, sollte einen der Bachläufe suchen, die an einigen der Strände münden.

Am Weststrand der Insel lauert ein [Schwarm Moskitos](/moskitos.md "Moskitos"). Hier ist äußerste Vorsicht geboten, denn sie übertragen die [Malaria](/malaria.md "Malaria"). Am alten Anleger hält die [Fliegender Holländer](/fliegender-holländer.md "Fliegender Holländer"), um Wasser aufzunehmen. Mit dem eigenen Schiff, kann man auch die Insel erreichen. Dazu gibt es spezielle [Schiffskurse](/kompass-oroonoque.md "Kompass/Oroonoque") zu diesem Hafen und zu jedem Anreisekurs auch den für die Rückfahrt.

# Karte

![Oroonoque](/images/d/d7/Insel_Oroonoque.gif)

* * *

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Oroonoque)
