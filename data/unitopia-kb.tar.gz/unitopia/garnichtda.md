---
type: Wiki Article
title: Garnichtda
description: In der Ruine eines Hexenhauses auf einer Lichtung auf Vandras.
resource: "http://unitopia.intelligense.de/wiki/Garnichtda"
tags: [NPC, NPC/Nordische Inseln, NPC/Nordische Inseln/defensiv, NPC/defensiv, Rasse, Rasse/Mensch]
timestamp: 2024-03-04T20:15:49Z
revid: 267775
namespace: 0
contenthash: 53cb535924630a1642bcdacd97483f8ffe714363cca6f4071b9b1069fad3f48d
---

## Aussehen

Garnichtda steht vor dir in einer ueberdimensionierten, funkelnden
Zaubererrobe, die wahrscheinlich aus einem Katalog für angehende Magier
stammt. Sein Bart ist in zwei ungleichen Haelften gespalten, und seine Augen
haben den staendigen Ausdruck von Verwirrung, gemischt mit einem Funken
Hoffnung. Er scheint staendig auf der Suche nach dem naechsten maechtigen
Elixier zu sein. In seiner Hand haelt er eine Teetasse, die mit einem
dampfenden 'Zaubertrank' gefuellt ist.

## Ausrüstung

-   Ein [prächtiger Magierhut](/magierhut.md "Magierhut").
-   Eine [Teetasse](/teetasse.md "Teetasse").
-   [Garnichtdas Runenbeutel](/runenbeutel-garnichtda.md "Runenbeutel/Garnichtda").

## Heimat

In der Ruine eines Hexenhauses auf einer Lichtung auf [Vandras](/vandras.md "Vandras").

* * *


## Kenndaten

- Typ: Defensiv
- Gegend: Nordische Inseln
- Rasse: Mensch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Garnichtda)
