---
type: Wiki Article
title: Weißwein/Rudolf
description: "Zu kaufen bei Rudolf im Gasthaus \"Zum toten Ork\" in Borsippa."
resource: "http://unitopia.intelligense.de/wiki/Weißwein/Rudolf"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/betrunken, Nahrung, Nahrung/Alkohol, Nahrung/Vaniorh, Nahrung/Vaniorh/Alkohol]
timestamp: 2024-08-29T15:14:41Z
revid: 245753
namespace: 0
contenthash: 2e1244c8e62d98fb1142ebde38829b062a68c90b81b3b555042ca2c1e3a82ee3
---

## Aussehen

Ein Glas Weisswein. Koestlich zu FAST allen Speisen.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [betrunken](/kategorie/info-wirkung-betrunken.md "Kategorie:Info/Wirkung/betrunken") |

## Fundort

Zu kaufen bei [Rudolf](/rudolf.md "Rudolf") im Gasthaus "Zum toten Ork" in [Borsippa](/borsippa.md "Borsippa").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Alkohol
- Gegend: Vaniorh
- Gewicht: 1
- Wirkung: betrunken

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Weißwein/Rudolf)
