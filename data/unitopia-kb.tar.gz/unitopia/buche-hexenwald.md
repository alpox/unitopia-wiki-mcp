---
type: Wiki Article
title: Buche/Hexenwald
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Buche/Hexenwald"
tags: [NPC, NPC/Nordische Inseln, NPC/Nordische Inseln/pseudo, NPC/pseudo, Rasse, Rasse/Pflanze, Tätigkeit, Tätigkeit/Wächter]
timestamp: 2018-11-07T18:37:26Z
revid: 197838
namespace: 0
contenthash: acb8118d1498fd39a09c6ca29034e12d6422b4365ff19d607f5aaa2eb05e4813
---

## Aussehen

Eine riesige, alte, knorrige Buche versperrt Dir den Weg nach Westen.

## Ausrüstung

Keine.

## Heimat

Am Eingang des [Hexenwaldes](/hexenwald.md "Hexenwald") auf [Thule](/thule.md "Thule").

## Besonderheit

Sie lässt nur Leute mit Besen vorbei und bewacht so den Zugang zum inneren Hexenwald.

* * *


## Kenndaten

- Typ: pseudo
- Gegend: Nordische Inseln
- Rasse: Pflanze
- Tätigkeit: Wächter

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Buche/Hexenwald)
