---
type: Wiki Article
title: Studierende
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Studierende"
tags: [NPC, NPC/Campus, NPC/Campus/pseudo, NPC/pseudo, Rasse, Rasse/Mensch]
timestamp: 2021-02-14T05:11:03Z
revid: 264886
namespace: 0
contenthash: b3e307292d76e93bfbfd01f7786364861de8c709a08f2b8f452414800e5019cc
---

## Aussehen

Du siehst insgesamt 10 Studierende an den Tischen sitzen. Angestrengt
starren sie auf die Bildschirme vor sich und sind absolut nicht
ansprechbar.

## Ausrüstung

Keine.

## Heimat

Im Computerraum im [NWZ II](/campusgelände.md "Campusgelände") auf dem [Campusgelände](/campusgelände.md "Campusgelände") der [Universität Stuttgart](/universität.md "Universität").

* * *


## Kenndaten

- Typ: pseudo
- Gegend: Campus
- Rasse: Mensch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Studierende)
