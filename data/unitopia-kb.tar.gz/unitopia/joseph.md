---
type: Wiki Article
title: Joseph
description: Am Nordtor von Borsippa.
resource: "http://unitopia.intelligense.de/wiki/Joseph"
tags: [NPC, NPC/Vaniorh, NPC/Vaniorh/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Wächter]
timestamp: 2018-11-07T18:26:47Z
revid: 215617
namespace: 0
contenthash: 881ba6a7cd788c40cf52fd6eabfc5e0b395616c75842ba89d8b0f5be3800f08e
---

## Aussehen

Joseph ist ein tattriger alter Greis, der die besten Jahre seines Lebens
bereits weit hinter sich gelassen hat. Jetzt ist er nur noch dafuer
zustaendig im Falle eines Angriffes auf Borsippa die Zugbruecke hoch zu
kurbeln und ein wenig im Rahmen seiner Moeglichkeiten auf Ordnung und
Sicherheit zu achten. Joseph ist etwas schwerhoerig, deshalb kann es
passieren, dass man ein bisschen lauter werden muss.

## Ausrüstung

-   Eine [rostige Kurbel](/kurbel-joseph.md "Kurbel/Joseph").
-   Ein [Krückstock](/krückstock-joseph.md "Krückstock/Joseph").

## Heimat

Am Nordtor von [Borsippa](/borsippa.md "Borsippa").


## Kenndaten

- Typ: defensiv
- Gegend: Vaniorh
- Rasse: Mensch
- Tätigkeit: Wächter

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Joseph)
