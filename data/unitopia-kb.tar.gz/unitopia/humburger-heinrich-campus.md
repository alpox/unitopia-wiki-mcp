---
type: Wiki Article
title: Humburger/Heinrich/Campus
description: "Zu kaufen bei Heinrich im Speisewagen des EC \"Mörderischer Wahnsinn\"."
resource: "http://unitopia.intelligense.de/wiki/Humburger/Heinrich/Campus"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Campus, Nahrung/Campus/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:13:27Z
revid: 238503
namespace: 0
contenthash: 645eb9c12c63be15ef56e369b3f4c657af40458664ef3cff4cb7503e1751f7cf
---

## Aussehen

Der Humburger entpuppt sich als ein vor Ketchup und Mayonnaise triefender
stinknormaler Hamburger.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Zu kaufen bei [Heinrich](/heinrich-campus.md "Heinrich/Campus") im Speisewagen des [EC "Mörderischer Wahnsinn"](/eurocity.md "EuroCity").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Campus
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Humburger/Heinrich/Campus)
