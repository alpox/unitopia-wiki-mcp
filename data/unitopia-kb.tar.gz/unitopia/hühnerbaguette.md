---
type: Wiki Article
title: Hühnerbaguette
description: Auf dem Tisch auf der Veranda des Koboldhauses in Koboldingen.
resource: "http://unitopia.intelligense.de/wiki/Hühnerbaguette"
tags: [Fundort, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Märchenland, Nahrung/Märchenland/Produkt, Nahrung/Produkt]
timestamp: 2024-09-16T12:12:07Z
revid: 264421
namespace: 0
contenthash: 75352dad9e527153ed2229a0ebaaf9cb748f7796edcd1d247a93a5d8a5172828
---

## Aussehen

Neben der Huehnerbrust liegen in diesem Baguette auch noch ein paar
Auberginen und Mozzarella. Echt verlockend exotisch.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Auf dem [Tisch](/koboldingen.md "Koboldingen") auf der Veranda des [Koboldhauses](/koboldhaus.md "Koboldhaus") in [Koboldingen](/koboldingen.md "Koboldingen").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Märchenland
- Gewicht: 2
- Wirkung: sättigt
- 1: Koboldtisch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Hühnerbaguette)
