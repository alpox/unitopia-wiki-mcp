---
type: Wiki Article
title: Rumpelwicht
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Rumpelwicht"
tags: [NPC, NPC/Nordische Inseln, NPC/Nordische Inseln/defensiv, NPC/defensiv, Rasse, Rasse/Gnom]
timestamp: 2018-11-07T18:29:16Z
revid: 212351
namespace: 0
contenthash: 86d1282a1e68f2bfc085790136ac44b8bd71042a5fe65033641ceaaea5843952
---

## Aussehen

Vor dir wuselt ein handflaechenkleines Geschoepf auf dem Boden herum.
Soweit deine Augen mit dem Gucken nachkommen, besteht es nur aus einem
drollig breiten Hinterteil und einem ebensogrossen Kopf, wobei zwischen den
Kopfzottelhaaren noch abstehende Ohren, Kulleraugen und eine Stupsnase zu
finden sind, wogegen der Hintern nur aus Zotteln besteht.

## Ausrüstung

Keine.

## Heimat

In einer von Unkraut überwucherten Gegend und im Gestrüpp auf [Vandras](/vandras.md "Vandras").

## Besonderheit

-   Man kann ihn mit "Zum Donnerdrummel" verscheuchen.
-   Gelegentlich taucht er in der Schloßküche auf.

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Nordische Inseln
- Rasse: Gnom

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Rumpelwicht)
