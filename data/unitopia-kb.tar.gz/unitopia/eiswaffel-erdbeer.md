---
type: Wiki Article
title: Eiswaffel/Erdbeer
description: Zu kaufen bei Hans auf dem Campusgelände der Universität Stuttgart.
resource: "http://unitopia.intelligense.de/wiki/Eiswaffel/Erdbeer"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Campus, Nahrung/Campus/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:15:27Z
revid: 231946
namespace: 0
contenthash: ced7cbf720aad75429fb2775e5cc0092e7bcb8a03d7a059629cb7adad4bd3f5c
---

## Aussehen

Eine unheimlich leckere Eiswaffel mit einer Eiskugel zwischen rot und pink,
mit roten Fruchtstueckchen.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Zu kaufen bei [Hans](/hans-campus.md "Hans/Campus") auf dem [Campusgelände](/campusgelände.md "Campusgelände") der [Universität Stuttgart](/universität.md "Universität").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Campus
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Eiswaffel/Erdbeer)
