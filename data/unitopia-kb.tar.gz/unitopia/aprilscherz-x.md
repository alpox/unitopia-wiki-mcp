---
type: Wiki Article
title: Aprilscherz/X
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Aprilscherz/X"
tags: [NPC, NPC/Campus, NPC/Campus/defensiv, NPC/Dörrland, NPC/Dörrland/defensiv, NPC/Ebenen, NPC/Ebenen/defensiv, NPC/Gallien, NPC/Gallien/defensiv, NPC/Kokosinseln, NPC/Kokosinseln/defensiv, NPC/Levitanis, NPC/Levitanis/defensiv, NPC/Midgard, NPC/Midgard/defensiv, NPC/Märchenland, NPC/Märchenland/defensiv, NPC/Nordische Inseln, NPC/Nordische Inseln/defensiv, NPC/Ozean, NPC/Ozean/defensiv, NPC/Vaniorh, NPC/Vaniorh/defensiv, NPC/defensiv, Rasse, Rasse/Unbestimmt]
timestamp: 2018-11-07T18:44:33Z
revid: 250691
namespace: 0
contenthash: 48a18a76d44dc9fdc2a05528b17f0acef6a04e8faf68644e13ff2f79b3ae1581
---

## Aussehen

Ein X. Es ist die Ehefrau von Y.

## Ausrüstung

Keine.

## Heimat

Aus den Buchstaben der Anwesenden Spielerschaft in ganz [Unitopia](/unitopia.md "Unitopia").

## Besonderheit

-   Die Seherdaten zu den einzelnen Buchstaben haben sehr variiert, zudem griffen sie mit Serifen an.
-   Sind von alleine aus dem Namen gesprungen oder wieder hinein, man konnte den Buchstaben aber auch Fangen:

Das X springt aus deinem Namen.
Das X springt in deinem Namen.
<Spieler> faengt das X.

-   Fähigkeit: Untätigkeit

* * *


## Kenndaten

- Typ: defensiv
- Rasse: Unbestimmt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Aprilscherz/X)
