---
type: Wiki Article
title: "Sonnenbrille/Erad-Nairs Haus"
description: "Auf der Treppe im Keller in Erad-Nairs Haus."
resource: "http://unitopia.intelligense.de/wiki/Sonnenbrille/Erad-Nairs_Haus"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Glas, Kleidung, Kleidung/Kopf, Kleidung/Vaniorh, Kleidung/Vaniorh/Kopf]
timestamp: 2024-03-02T19:19:47Z
revid: 249550
namespace: 0
contenthash: 3efbcd6902682c7bc746f69aded6b4c16b27b8e71d357cc78c43c63064e14909
---

## Aussehen

Eine Brille mit dunklen Glaesern.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Glas](/kategorie/info-material-glas.md "Kategorie:Info/Material/Glas") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Auf der [Treppe](/erad-nairs-haus.md "Erad-Nairs Haus") im [Keller](/erad-nairs-haus.md "Erad-Nairs Haus") in [Erad-Nairs Haus](/erad-nairs-haus.md "Erad-Nairs Haus").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Kopf
- Gegend: Vaniorh
- Material: Glas
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Sonnenbrille/Erad-Nairs_Haus)
