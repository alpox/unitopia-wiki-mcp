---
type: Wiki Article
title: Fanta/Claudi
description: Zu kaufen bei Claudi im Cafe Campus auf dem Campusgelände der Universität Stuttgart.
resource: "http://unitopia.intelligense.de/wiki/Fanta/Claudi"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/durstlöschend, Nahrung, Nahrung/Campus, Nahrung/Campus/Getränk, Nahrung/Getränk]
timestamp: 2024-08-29T15:14:09Z
revid: 222201
namespace: 0
contenthash: 6f530fd129bca9e0444dfb9dd3eef71ccb2eb99e7ac52a448f395d4990ced013
---

## Aussehen

Fanta
(C) by Coca Cola

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend") |

## Fundort

Zu kaufen bei [Claudi](/claudi.md "Claudi") im [Cafe Campus](/cafe-campus.md "Cafe Campus") auf dem [Campusgelände](/campusgelände.md "Campusgelände") der [Universität Stuttgart](/universität.md "Universität").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Getränk
- Gegend: Campus
- Gewicht: 1
- Wirkung: durstlöschend

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Fanta/Claudi)
