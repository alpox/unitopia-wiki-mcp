---
type: Wiki Article
title: Lederpeitsche/Kokosinseln
description: "Auf dem Etikett steht:"
resource: "http://unitopia.intelligense.de/wiki/Lederpeitsche/Kokosinseln"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/3, Info/Material, Info/Material/Leder, Info/Waffenstärke, Info/Waffenstärke/geht so, Info/Waffenzustand, Info/Waffenzustand/mäßig haltbar, Waffe, Waffe/Kokosinseln, Waffe/Kokosinseln/Peitsche, Waffe/Peitsche]
timestamp: 2024-03-02T19:17:20Z
revid: 262284
namespace: 0
contenthash: f7436a3a0814b9cab7398f52258d2c61e9f5794fd65e24b37d3c9e865ee4d0ac
---

## Aussehen

Dies ist eine kraeftige, lange Lederpeitsche, die dunkelbraun bis schwarz
gefaerbt ist. Sie wurde in einer Ork-Werkstatt produziert, was Du leicht am
Etikett erkennst.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [4 (geht so)](/kategorie/info-waffenstärke-geht-so.md "Kategorie:Info/Waffenstärke/geht so") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [3 (mäßig haltbar)](/kategorie/info-waffenzustand-mäßig-haltbar.md "Kategorie:Info/Waffenzustand/mäßig haltbar") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [3 (schon eher leicht)](/kategorie/info-gewicht-3.md "Kategorie:Info/Gewicht/3") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Waffe vom [Kreta-Ork](/kreta-ork-kokosinseln.md "Kreta-Ork/Kokosinseln") auf den Straßen von [Kreta](/kreta.md "Kreta").
-   Waffe vom [Kreta-Ork](/kreta-ork-kokosinseln.md "Kreta-Ork/Kokosinseln") im [Labyrinth des Paion](/labyrinth-des-paion.md "Labyrinth des Paion") im [wild wuchernden Wald](/kreta.md "Kreta") auf [Kreta](/kreta.md "Kreta").
-   Waffe vom [einäugigen Orks](/ork-knossos.md "Ork/Knossos") in der [Kanalisation](/knossos.md "Knossos") von [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").

## Besonderheit

Auf dem Etikett steht:

Made in Orkinawa.
Produced for SNS.

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Peitsche
- Gegend: Kokosinseln
- Material: Leder
- Waffenstärke: geht so
- Waffenzustand: mäßig haltbar
- Gewicht: 3
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Lederpeitsche/Kokosinseln)
