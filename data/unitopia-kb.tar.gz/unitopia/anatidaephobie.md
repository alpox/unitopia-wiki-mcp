---
type: Wiki Article
title: Anatidaephobie
description: Durch die Schnatterente auf der Hochebene auf Cyprus.
resource: "http://unitopia.intelligense.de/wiki/Anatidaephobie"
tags: [Info, Info/Heilung, Info/Heilung/Antidots, Info/Heilung/Heilstab, Info/Heilung/Hexenvolk, Info/Wirkung, Info/Wirkung/Zustand, Info/Wirkung/Zustand/neutral, Zustand, Zustand/Kokosinseln, Zustand/Kokosinseln/Sonstige, Zustand/Sonstige]
timestamp: 2024-08-29T15:22:36Z
revid: 221859
namespace: 0
contenthash: e55863a3b95bd0ebb8172db0d0aae096dfb55707d1de0f73dfe0ca43c6440793
---

## Aussehen

Er/Sie/Es sieht sich immer wieder nervoes um.

## Informationen

| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [neutral](/kategorie/info-wirkung-zustand-neutral.md "Kategorie:Info/Wirkung/Zustand/neutral") |
| --- | --- |
| **[Heilung](/kategorie/info-heilung.md "Kategorie:Info/Heilung"):** | [Antidots](/druidengilde.md "Druidengilde"), [Hexenvolk](/hexenvolk.md "Hexenvolk"), [Heilstab](/heilstab.md "Heilstab") |

## Fundort

Durch die [Schnatterente](/schnatterente.md "Schnatterente") auf der [Hochebene](/hochebene.md "Hochebene") auf [Cyprus](/cyprus.md "Cyprus").

## Besonderheit

Betrachtet man einzelne Details, während man unter Anatidaephobie leidet, können diese ebenfalls Meldungen erzeugen, die mit Enten zu tun haben.

## Gefährlichkeit

-   Startmeldung:

Die nervige Schnatterente starrt dich unheilvoll an.

-   Zwischenmeldungen:

Du hoerst einen Entenschnabel klappern.
Eine Ente hat dich hierher verfolgt.
Gerade hast du eine Ente um die Ecke gucken sehen.
Ein starrer Blick bohrt sich in dein Genick.
Jemand starrt dich hypnotisch an.
Du wirst von einer Ente beobachtet.
Du meinst kurz, den Geruch einer Ente wahrzunehmen.
Hier ist eine Ente versteckt, die dich heimlich anstarrt.
Da war doch eben eine Ente? Jetzt sie hoffentlich weg.
Eine Ente schleicht sich heimlich von hinten an dich heran.
Du spuerst, dass hier eben noch eine Ente war.
Hinter dir steht eine Ente und beobachtet dich.
Gerade hast du eine Ente um die Ecke gucken sehen.
Hinter dir steht eine Ente, sie kann dich sehen.

-   Endmeldung:

Eigentlich sind Enten wohl doch nicht so gefaehrlich.

* * *


## Kenndaten

- Kategorie: Zustand
- Typ: Sonstige
- Gegend: Kokosinseln
- Wirkung: neutral
- Heilung: Antidots/Hexenvolk/Heilstab

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Anatidaephobie)
