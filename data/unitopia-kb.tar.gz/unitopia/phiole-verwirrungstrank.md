---
type: Wiki Article
title: Phiole/Verwirrungstrank
description: Von einem Mitglied des Hexenvolkes.
resource: "http://unitopia.intelligense.de/wiki/Phiole/Verwirrungstrank"
tags: [Behälter, Behälter/Gefäß, Behälter/Nordische Inseln, Behälter/Nordische Inseln/Gefäß, Fundort, Info, Info/Fasst, Info/Fasst/Flüssigkeit, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Glas, Info/Volumen, Info/Volumen/2, Info/Wirkung, Nahrung, Nahrung/Getränk, Nahrung/Nordische Inseln, Nahrung/Nordische Inseln/Getränk, Subpages, Subpages/Content]
timestamp: 2026-03-18T18:21:15Z
revid: 255463
namespace: 0
contenthash: 9be471fca63647ac764b7b2bf53cb33fcfb3f47aa971111e02f2c20718b3b80d
---

< [Hexenvolk](/hexenvolk.md "Hexenvolk") < [Rezepte](/hexenvolk.md "Hexenvolk")

## Aussehen

Eine schlanke Glasphiole mit einem kleinen Korkstopfen, der dieses
Flaeschchen sicher verschliesst, auf dass nichts unbedacht verschuettet
werden kann.
Vom Inhalt der wie Amethyst funkelnden Phiole erkennst Du:
Eine dickliche, wie Amethyst funkelnde, Fluessigkeit, mehr ist nicht zu
erkennen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Glas](/kategorie/info-material-glas.md "Kategorie:Info/Material/Glas") |
| --- | --- |
| **[Fasst](/kategorie/info-fasst.md "Kategorie:Info/Fasst"):** | [Flüssigkeit](/flüssigkeit.md "Flüssigkeit") |
| **[Volumen](/kategorie/info-volumen.md "Kategorie:Info/Volumen"):** | 2, Schluck |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [Verwirrung](/verwirrung.md "Verwirrung") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Von einem Mitglied des [Hexenvolkes](/hexenvolk.md "Hexenvolk").

## Besonderheit

Wenn die Phiole geleert ist, behält man eine [blaue Phiole](/phiole-hexenvolk.md "Phiole/Hexenvolk") zurück.

* * *


## Kenndaten

- Typ: Content
- Gegend: Nordische Inseln
- Kategorie: Behälter
- Material: Glas
- Fasst: Flüssigkeit
- Volumen: 2/Schluck
- Gewicht: 1
- Wirkung: Verwirrung
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Phiole/Verwirrungstrank)
