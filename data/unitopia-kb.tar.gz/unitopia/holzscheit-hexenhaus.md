---
type: Wiki Article
title: Holzscheit/Hexenhaus
description: In der Küche im Hexenhaus im Hexenwald auf Thule.
resource: "http://unitopia.intelligense.de/wiki/Holzscheit/Hexenhaus"
tags: [Gegenstand, Gegenstand/Nordische Inseln, Gegenstand/Nordische Inseln/Sonstige, Gegenstand/Sonstige, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Licht, Info/Licht/leuchtet, Info/Material, Info/Material/Holz, Info/Schwimmt]
timestamp: 2024-03-02T19:20:41Z
revid: 206755
namespace: 0
contenthash: 37ca75bcd45cec5bafda36db3bd13055c77bf2f8b99d45087b1501c7d825bdc3
---

## Aussehen

Ein Holzscheit. Man kann ihn sicher anzuenden und als Fackel oder sonstige
Feuerquelle benutzen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel"), [+1 (leuchtet normal)](/kategorie/info-licht-leuchtet.md "Kategorie:Info/Licht/leuchtet") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

In der Küche im [Hexenhaus](/hexenhaus.md "Hexenhaus") im [Hexenwald](/hexenwald.md "Hexenwald") auf [Thule](/thule.md "Thule").

## Besonderheit

Kann direkt als Fackel benutzt werden.

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Nordische Inseln
- Material: Holz
- Gewicht: 1
- Licht: 0/+1
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Holzscheit/Hexenhaus)
