---
type: Wiki Article
title: Stirnkettchen/Alatariel
description: Kleidung von Alatariel im Turmzimmer des Schlosses auf der Festung von Magny.
resource: "http://unitopia.intelligense.de/wiki/Stirnkettchen/Alatariel"
tags: [Hidden, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Kleidung, Kleidung/Kopf, Kleidung/Midgard, Kleidung/Midgard/Kopf, ZusatzAussehen, ZusatzAussehen/Frau]
timestamp: 2024-03-02T19:19:46Z
revid: 261546
namespace: 0
contenthash: 639d3b61a0ca333642f22d61a4f85dc94634b2c841eecf4a974e571fab16a826
---

## Aussehen

Ein aus duennen, silbernen Faeden gearbeitetes Stirnkettchen, wie es die
edlen Elfen tragen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Kleidung von [Alatariel](/alatariel.md "Alatariel") im Turmzimmer des Schlosses auf der [Festung](/magny.md "Magny") von [Magny](/magny.md "Magny").

## Besonderheit

Zusätzliches Aussehen beim Betrachten einer Person:

| **Frau:** | Sie trägt ein schmückendes Stirnkettchen auf dem Haupt. |
| --- | --- |

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Kopf
- Gegend: Midgard
- Material: Textil
- Temperaturschutz: wärmt etwas
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein
- Frau: Sie trägt ein schmückendes Stirnkettchen auf dem Haupt.

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Stirnkettchen/Alatariel)
