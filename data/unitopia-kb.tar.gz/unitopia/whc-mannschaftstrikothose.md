---
type: Wiki Article
title: "WHC-Mannschaftstrikothose"
description: Zu kaufen bei Sardor in seinem Refugium in der Druidengilde von Knossos auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/WHC-Mannschaftstrikothose"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Unbekannt, Kleidung, Kleidung/Beine, Kleidung/Kokosinseln, Kleidung/Kokosinseln/Beine]
timestamp: 2024-04-23T19:27:56Z
revid: 245969
namespace: 0
contenthash: 853007b5bbf896a8c4502788b3bea2d66ddc3e2eb2f6b20ebdf933bf555a72e1
---

## Aussehen

Eine bequeme, knielange, weiss Sporthose von Celtic Knossos, der Mannschaft
der Druidengilde, die am Weltherrschaftscup teilnimmt. An beiden Seiten ist
jeweils der Mannschaftsschriftzug aufgestickt.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Unbekannt](/kategorie/info-material-unbekannt.md "Kategorie:Info/Material/Unbekannt") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Sardor](/sardor.md "Sardor") in seinem Refugium in der [Druidengilde](/druidengilde.md "Druidengilde") von [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Beine
- Gegend: Kokosinseln
- Material: Unbekannt
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/WHC-Mannschaftstrikothose)
