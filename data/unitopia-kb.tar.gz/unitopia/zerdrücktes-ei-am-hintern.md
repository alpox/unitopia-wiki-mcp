---
type: Wiki Article
title: Zerdrücktes Ei am Hintern
description: Durch das Wollmilchsauei der Wollmilchsau im Stall des Bauernhofes von Phexcaer auf Thule.
resource: "http://unitopia.intelligense.de/wiki/Zerdrücktes_Ei_am_Hintern"
tags: [Hidden, Info, Info/Heilung, Info/Wirkung, Info/Wirkung/Zustand, Info/Wirkung/Zustand/neutral, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann, Zustand, Zustand/Nordische Inseln, Zustand/Nordische Inseln/Sonstige, Zustand/Sonstige]
timestamp: 2024-08-29T15:19:43Z
revid: 261967
namespace: 0
contenthash: cf1972c65eb1199667adb5b166268994685a16fb4d0db6c10e5cdc770cbb525d
---

## Aussehen

Er/Sie/Es hat ein zerdruecktes Wollmilchsauei am Hintern kleben.

## Informationen

| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [neutral](/kategorie/info-wirkung-zustand-neutral.md "Kategorie:Info/Wirkung/Zustand/neutral") |
| --- | --- |
| **[Heilung](/kategorie/info-heilung.md "Kategorie:Info/Heilung"):** | waschen |

## Fundort

Durch das [Wollmilchsauei](/wollmilchsauei.md "Wollmilchsauei") der [Wollmilchsau](/wollmilchsau.md "Wollmilchsau") im Stall des [Bauernhofes](/phexcaer.md "Phexcaer") von [Phexcaer](/phexcaer.md "Phexcaer") auf [Thule](/thule.md "Thule").

## Besonderheit

-   Zusätzliches Aussehen beim Betrachten einer Person:

| **Alle:** | Ein am Hintern festgeklebtes, zerdruecktes Wollmilchsauei. |
| --- | --- |

-   Die Endmeldung kommt erst, wenn man sich wäscht.

## Gefährlichkeit

-   Startmeldung:

Du setzt dich auf das weissbraun geringelte Wollmilchsauei.
Das weissbraun geringelte Wollmilchsauei zerbricht und du hast das ganze
glibschrige Zeug am Hintern kleben!

-   Endmeldung:

Du rubbelst wie wild an dem zerdrueckten Wollmilchsauei herum.
Die letzten Spuren deines peinlichen Versuchs, ein Wollmilchsauei
auszubrueten, fallen dir vom Hintern.

* * *


## Kenndaten

- Kategorie: Zustand
- Typ: Sonstige
- Gegend: Nordische Inseln
- Wirkung: neutral
- Heilung: waschen
- ul: ja
- Alle: Ein am Hintern festgeklebtes, zerdruecktes Wollmilchsauei.

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Zerdrücktes_Ei_am_Hintern)
