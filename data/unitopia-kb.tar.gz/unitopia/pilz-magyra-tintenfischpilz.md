---
type: Wiki Article
title: Pilz/Magyra/Tintenfischpilz
description: "Diese Pilze bedürfen zur eindeutigen Bestimmung, dass man sie auch betastet und daran riecht."
resource: "http://unitopia.intelligense.de/wiki/Pilz/Magyra/Tintenfischpilz"
tags: [Fundort, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/giftig, Info/Wirkung/sättigt, Nahrung, Nahrung/Dörrland, Nahrung/Dörrland/Sonstige, Nahrung/Ebenen, Nahrung/Ebenen/Sonstige, Nahrung/Gallien, Nahrung/Gallien/Sonstige, Nahrung/Kokosinseln, Nahrung/Kokosinseln/Sonstige, Nahrung/Midgard, Nahrung/Midgard/Sonstige, Nahrung/Märchenland, Nahrung/Märchenland/Sonstige, Nahrung/Nordische Inseln, Nahrung/Nordische Inseln/Sonstige, Nahrung/Sonstige, Nahrung/Vaniorh, Nahrung/Vaniorh/Sonstige]
timestamp: 2024-09-16T12:10:33Z
revid: 254670
namespace: 0
contenthash: 8d4a710ac802ae45c052b9a023817790a23212a9dfd843462f7561dfd74fe74b
---

## Aussehen

Ein eigenartig exotischer Pilz mit mehreren sternfoermigen,
roten Armen, die dunkel gesprenkelt sind.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt"), [Magenverstimmung](/magenverstimmung-magyra.md "Magenverstimmung/Magyra") |

## Fundort

-   In der Umgebung und den Wäldern von [Barovia](/barovia.md "Barovia").
-   Auf den Ebenen [Amerindia](/amerindia.md "Amerindia") und [Drachenland](/drachenland.md "Drachenland").
-   Auf [Cyprus](/cyprus.md "Cyprus"), [Kreta](/kreta.md "Kreta") und [Phrygia](/phrygia.md "Phrygia").
-   In den Weiten [Galliens](/gallien.md "Gallien").
-   In den Weiten [Märchenlands](/märchenland.md "Märchenland").
-   In den Weiten [Midgards](/midgard.md "Midgard").
-   Auf [Thule](/thule.md "Thule").
-   In den Wäldern und auf den Wiesen [Vaniorhs](/vaniorh.md "Vaniorh").

## Besonderheit

Diese Pilze bedürfen zur eindeutigen [Bestimmung](/pilzbestimmungsbuch.md "Pilzbestimmungsbuch"), dass man sie auch betastet und daran riecht.

| Geruch | Der Pilz stinkt nach Verwesendem. |
| --- | --- |
| Gefühl | Der Pilz fühlt sich glitschig an. |

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Sonstige
- Gegend: Dörrland/Ebenen/Gallien/Kokosinseln/Märchenland/Midgard/Nordische Inseln/Vaniorh
- Gewicht: 1
- Wirkung: sättigt/Magenverstimmung-Magyra

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Pilz/Magyra/Tintenfischpilz)
