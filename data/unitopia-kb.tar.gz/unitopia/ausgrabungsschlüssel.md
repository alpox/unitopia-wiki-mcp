---
type: Wiki Article
title: Ausgrabungsschlüssel
description: Im kleinen Höhlenkeller der Sphinx in Südostdörrland.
resource: "http://unitopia.intelligense.de/wiki/Ausgrabungsschlüssel"
tags: [Gegenstand, Gegenstand/Dörrland, Gegenstand/Dörrland/Schlüssel, Gegenstand/Schlüssel, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Metall]
timestamp: 2024-03-02T19:21:45Z
revid: 257367
namespace: 0
contenthash: 31d1febfeb6872f77a65e3215da3094936ee81def5d9a3ef11476a4790a7e998
---

## Aussehen

Ein alter, kleiner Schluessel.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Im kleinen Höhlenkeller der [Sphinx](/sphinx-dörrland.md "Sphinx/Dörrland") in [Südostdörrland](/südostdörrland.md "Südostdörrland").

## Funktion

Für die Vitrine im kleinen Höhlenkeller.

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Schlüssel
- Gegend: Dörrland
- Material: Metall
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Ausgrabungsschlüssel)
