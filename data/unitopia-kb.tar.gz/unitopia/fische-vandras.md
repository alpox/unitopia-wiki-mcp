---
type: Wiki Article
title: Fische/Vandras
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Fische/Vandras"
tags: [NPC, NPC/Nordische Inseln, NPC/Nordische Inseln/pseudo, NPC/pseudo, Rasse, Rasse/Fisch]
timestamp: 2018-11-07T18:48:01Z
revid: 205811
namespace: 0
contenthash: 0ca22dd14b36fb88454e92f134d90dc11f9d7bab1862996167e1895dab7283eb
---

## Aussehen

Roetliche Farbschatten, die unter leicht gekraeuselter Wasseroberflaeche
vorbeiflitzen. Fuer ausgiebigeres Gucken sind deine Augen nicht schnell
genug.

## Ausrüstung

Keine.

## Heimat

Am Weiher auf [Vandras](/vandras.md "Vandras").

* * *


## Kenndaten

- Typ: pseudo
- Gegend: Nordische Inseln
- Rasse: Fisch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Fische/Vandras)
