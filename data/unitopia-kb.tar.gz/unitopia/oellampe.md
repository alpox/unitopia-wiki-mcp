---
type: Wiki Article
title: Oellampe
description: ""
resource: "http://unitopia.intelligense.de/wiki/Oellampe"
tags: []
timestamp: 2014-06-12T18:47:04Z
revid: 76732
namespace: 0
contenthash: da72290c63a03e8afbf4e16beedfba65c1c7cecaaf765c0af12c141627438995
---

1.  REDIRECT [Öllampe](/öllampe.md "Öllampe")

* * *

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Oellampe)
