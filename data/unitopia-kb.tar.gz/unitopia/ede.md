---
type: Wiki Article
title: Ede
description: ""
resource: "http://unitopia.intelligense.de/wiki/Ede"
tags: [Angebot, NPC, NPC/Dörrland, NPC/Dörrland/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Händler]
timestamp: 2022-04-25T21:07:59Z
revid: 256206
namespace: 0
contenthash: 0e927ebe4b63e53c4cd94722677981bd7150222f57e3cb283fda5449e3fdb28c
---

## Aussehen

_Dörrstadt - Ede, der Händler:_

Ede ist ein kleiner, untersetzter Mann, der Dich aus listigen
Schweinsaeuglein mustert. Er haengt laessig auf einem kleinen Stuhl herum
und trinkt ab und zu aus einer verpackten Flasche, die ihm ein Mann
hin haelt. In seinem Mundwinkel haengt ein ausgefranster Zigarrenstummel.

_Alt-Dörrstadt - Ede, der Gauner:_

Ede ist ein kleiner, duenner junger Mann, der Dich aus listigen
Schweinsaeuglein mustert. Er haengt laessig auf einem kleinen Stuhl herum
und wirkt ganz so, als wollte er hier fuer die naechsten zwei Jahrhunderte
sitzen bleiben. In seinem Mundwinkel haengt ein glimmender Jointstummel.

## Ausrüstung

_Dörrstadt:_

-   Ein [Rucksack](/rucksack-diebesgilde.md "Rucksack/Diebesgilde").

_Alt-Dörrstadt:_

-   Ein [schlanker Dolch](/dolch-ede.md "Dolch/Ede").
-   Eine [speckige, schwarze Lederhose](/lederhose-ede.md "Lederhose/Ede").
-   Ein [schmuddeliges Rüschenhemd](/rüschenhemd-ede.md "Rüschenhemd/Ede").

## Heimat

-   In seinem Laden in [Dörrstadt](/dörrstadt.md "Dörrstadt").
-   In seinem Laden in [Alt-Dörrstadt](/alt-dörrstadt.md "Alt-Dörrstadt").

## Angebot

| ![Angebot-tl.gif](/images/d/db/Angebot-tl.gif) | Alt-Dörrstadt - Preisliste | ![Angebot-tr.gif](/images/5/52/Angebot-tr.gif) |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | \| **Ware:** \| **[Dukaten](/währung.md "Währung")**: \| \| --- \| --- \| \| Ein [Joint](/joint.md "Joint") \| 150 \| \| Eine [Fackel](/fackel-magyra.md "Fackel/Magyra") \| 450 \| \| Ein [Kohlensack](/kohlensack.md "Kohlensack") \| 2990 \| | **Ware:** | **[Dukaten](/währung.md "Währung")**: | Ein [Joint](/joint.md "Joint") | 150 | Eine [Fackel](/fackel-magyra.md "Fackel/Magyra") | 450 | Ein [Kohlensack](/kohlensack.md "Kohlensack") | 2990 |  |
| **Ware:** | **[Dukaten](/währung.md "Währung")**: |  |  |  |  |  |  |  |  |  |
| Ein [Joint](/joint.md "Joint") | 150 |  |  |  |  |  |  |  |  |  |
| Eine [Fackel](/fackel-magyra.md "Fackel/Magyra") | 450 |  |  |  |  |  |  |  |  |  |
| Ein [Kohlensack](/kohlensack.md "Kohlensack") | 2990 |  |  |  |  |  |  |  |  |  |
| ![Angebot-bl.gif](/images/3/3b/Angebot-bl.gif) |  | ![Angebot-br.gif](/images/9/92/Angebot-br.gif) |  |  |  |  |  |  |  |  |

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Dörrland
- Rasse: Mensch
- Tätigkeit: Händler

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Ede)
