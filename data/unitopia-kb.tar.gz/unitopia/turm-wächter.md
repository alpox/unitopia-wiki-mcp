---
type: Wiki Article
title: "Turm-Wächter"
description: Ein Krummsäbel.
resource: "http://unitopia.intelligense.de/wiki/Turm-Wächter"
tags: [NPC, NPC/Kokosinseln, NPC/Kokosinseln/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Wächter]
timestamp: 2018-11-07T18:32:48Z
revid: 233509
namespace: 0
contenthash: 6115b97eee8d1e40bd67ec636a8ee782ee3ec75515d94e45981c68234a82142b
---

## Aussehen

Ein baertiger, breitschultriger Waechter. Er laesst Dich nicht aus den
Augen. 

_Erdgeschoss:_

Ein baertiger, breitschultriger Waechter. Er laesst Dich nicht aus den
Augen. Es sei denn, er spielt mal wieder mit irgendwas.

## Ausrüstung

Ein [Krummsäbel](/krummsäbel-turm-wächter.md "Krummsäbel/Turm-Wächter").

## Heimat

Im [Rätselturm](/druidenturm.md "Druidenturm") auf [Kreta](/kreta.md "Kreta").

## Besonderheit

Der Wächter ist mit einem mitgebrachten [Spiel](/kategorie/spiele.md "Kategorie:Spiele") zu bestechen.

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Kokosinseln
- Rasse: Mensch
- Tätigkeit: Wächter

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Turm-Wächter)
