---
type: Wiki Article
title: Feldflasche/Troja
description: In einer dunklen Höhle im alten Troja auf Phrygia.
resource: "http://unitopia.intelligense.de/wiki/Feldflasche/Troja"
tags: [Behälter, Behälter/Gefäß, Behälter/Kokosinseln, Behälter/Kokosinseln/Gefäß, Info, Info/Brennbar, Info/Fasst, Info/Fasst/Flüssigkeit, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Glas, Info/Material/Leder, Info/Volumen, Info/Volumen/5]
timestamp: 2026-03-18T18:20:49Z
revid: 247219
namespace: 0
contenthash: e7d52a2459dbb0c4e0ac1bd5f943e8b2ba989c7917730a03a9d9a216045967a0
---

## Aussehen

Die Feldflasche ist rund und aus Glas. Zu ihrem Schutz wurde sie mit Leder
umwickelt und ein Korken bewahrt Fluessigkeiten vor dem Auslaufen.
Sie ist beinahe ganz mit suessem Aprikosensaft gefuellt.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Glas](/kategorie/info-material-glas.md "Kategorie:Info/Material/Glas"), [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder") |
| --- | --- |
| **[Fasst](/kategorie/info-fasst.md "Kategorie:Info/Fasst"):** | [Flüssigkeit](/flüssigkeit.md "Flüssigkeit") |
| **[Volumen](/kategorie/info-volumen.md "Kategorie:Info/Volumen"):** | 5, Schluck |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

In einer dunklen Höhle im [alten Troja](/troja.md "Troja") auf [Phrygia](/phrygia.md "Phrygia").

## Besonderheit

Die Flasche enthält anfangs [süßen Aprikosensaft](/aprikosensaft.md "Aprikosensaft").

* * *


## Kenndaten

- Kategorie: Behälter
- Typ: Gefäß
- Gegend: Kokosinseln
- Material: Glas/Leder
- Fasst: Flüssigkeit
- Volumen: 5/Schluck
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Feldflasche/Troja)
