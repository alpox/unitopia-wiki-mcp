---
type: Wiki Article
title: Kirschtörtchen
description: ""
resource: "http://unitopia.intelligense.de/wiki/Kirschtörtchen"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Produkt, Nahrung/Vaniorh, Nahrung/Vaniorh/Produkt]
timestamp: 2024-08-29T15:17:03Z
revid: 253482
namespace: 0
contenthash: f385391ffc23dfc6a12aa71b734ab85394a524a15ac29e1016f45bdb5ade100b
---

## Aussehen

Eine kleines Schwarzwaelder-Kirsch-Sahnetoertchen, fast vollstaendig aus
Sahne mit einem Sahnetupserchen und einer Kirsche oben drauf. Sieht sehr
appetitlich aus und macht Lust auf mehr.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

-   Zu kaufen bei [Brinkmann](/brinkmann.md "Brinkmann") in der Konditorei von [Borsippa](/borsippa.md "Borsippa").
-   Auf dem [Tisch](/tisch-märchenpark.md "Tisch/Märchenpark") am Packnickplatz im [Märchenpark](/märchenpark.md "Märchenpark") von [Tadmor](/tadmor.md "Tadmor").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Vaniorh
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Kirschtörtchen)
