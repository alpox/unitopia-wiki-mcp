---
type: Wiki Article
title: Lederschuhe/Oliver
description: "Kleidung von Oliver in seinem Fernseh-Zelt vom Rummel in Bad Cannstatt."
resource: "http://unitopia.intelligense.de/wiki/Lederschuhe/Oliver"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Leder, Kleidung, Kleidung/Campus, Kleidung/Campus/Füße, Kleidung/Füße]
timestamp: 2024-03-02T19:20:21Z
revid: 246601
namespace: 0
contenthash: fc90398d9c7f45fc0034cdd3f21680c3b50dfb3fe4376aa600e79e55a5e43220
---

## Aussehen

Ein Paar alte Schuhe aus schwarzem Leder. Sie sehen bereits ziemlich
ausgelatscht, aber sehr bequem aus.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Kleidung von [Oliver](/oliver.md "Oliver") in seinem Fernseh-Zelt vom [Rummel](/rummel.md "Rummel") in [Bad Cannstatt](/bad-cannstatt.md "Bad Cannstatt").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Füße
- Gegend: Campus
- Material: Leder
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Lederschuhe/Oliver)
