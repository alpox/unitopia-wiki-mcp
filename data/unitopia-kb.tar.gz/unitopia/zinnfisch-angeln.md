---
type: Wiki Article
title: Zinnfisch/Angeln
description: Im Silbersee der Ruinen von Seestadt.
resource: "http://unitopia.intelligense.de/wiki/Zinnfisch/Angeln"
tags: [Angeln, Braten, Braten/Angeln, Braten/Stück, Gegenstand, Gegenstand/Midgard, Gegenstand/Midgard/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, Info/Material, Info/Material/Bein]
timestamp: 2024-03-02T19:18:28Z
revid: 255647
namespace: 0
contenthash: 7f35e4d7775b7509ebe11d6e0c49fab51a3982f514755ede8b86fb5389c9ef3f
---

## Aussehen

```
Der Zinnfisch hat ein stumpfes, graues Schuppenkleid, ein spitzes Maul und
grosse Augen. Sein Koerperbau ist gedrungen und muskuloes.
```

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Bein](/kategorie/info-material-bein.md "Kategorie:Info/Material/Bein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [siehe Besonderheit](#Besonderheit) |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Im [Silbersee](/silbersee.md "Silbersee") der [Ruinen von Seestadt](/seestadtruinen.md "Seestadtruinen").

## Besonderheit

-   Nach dem Angeln ist der Zinnfisch [bratbar](/braten-magyra.md "Braten/Magyra"). Der Braten lässt sich in mehrere handliche [Braten](/bratenscheibe.md "Bratenscheibe")[scheiben](/braten-scheibe.md "Braten/Scheibe"), [Braten](/bratenstück.md "Bratenstück")[stücke](/braten-stück.md "Braten/Stück") oder [Braten](/bratenteil.md "Bratenteil")[teile](/braten-teil.md "Braten/Teil") zerlegen.  
    Sofern eine bestimmte Mindestgröße gefangen wurde.
-   Der Zinnfisch erscheint mit wechselnden Adjektiven, die seine Größe im Anglerjargon angeben.  
    Weitere [Fischarten](/kategorie/angeln.md "Kategorie:Angeln") oder generelle Informationen sind der [Kategorie:Angeln](/kategorie/angeln.md "Kategorie:Angeln") zu entnehmen.

## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Midgard
- Material: Bein
- Gewicht: siehe Besonderheit
- Licht: 0
- Brennbar: nein
- Schwimmt: nein
- Artikel: der
- Stück: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Zinnfisch/Angeln)
