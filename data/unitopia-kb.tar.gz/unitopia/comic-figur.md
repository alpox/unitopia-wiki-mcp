---
type: Wiki Article
title: "Comic-Figur"
description: Ein zweiter Preis bei der Glücksfee am Glücksrad auf dem Zentrum des Trödelmarktes in Tadmor.
resource: "http://unitopia.intelligense.de/wiki/Comic-Figur"
tags: [Gegenstand, Gegenstand/Sonstige, Gegenstand/Vaniorh, Gegenstand/Vaniorh/Sonstige, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Holz, Info/Schwimmt]
timestamp: 2024-03-02T19:18:20Z
revid: 232855
namespace: 0
contenthash: 4db22dec8342d90e62c9fd37f5ebb00c06bd96656a9cf06951709628283f899c
---

## Aussehen

Diese Comic-Figur ist dir wie aus den Gesicht geschnitten.

_niedriger Einsatz:_

Diese Ausfuehrung ist nur fuer die Aermsten der Spieler.

_hoher Einsatz:_

Solche Preise kann man wohl nur mit einem Hoechstmass an Einsatz gewinnen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Ein zweiter Preis bei der [Glücksfee](/glücksfee.md "Glücksfee") am [Glücksrad](/tadmor.md "Tadmor") auf dem Zentrum des [Trödelmarktes](/tadmor.md "Tadmor") in [Tadmor](/tadmor.md "Tadmor").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Vaniorh
- Material: Holz
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Comic-Figur)
