---
type: Wiki Article
title: Stier/Borsippa
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Stier/Borsippa"
tags: [NPC, NPC/Vaniorh, NPC/Vaniorh/aggressiv, NPC/aggressiv, Rasse, Rasse/Säugetier]
timestamp: 2018-11-07T18:30:23Z
revid: 218303
namespace: 0
contenthash: 77c141db1aaa6728ee99f177af3081af337399a86c8f3ccbc16c3148edf600ef
---

## Aussehen

Ein riesiger schwarzer Stier mit funkelnden Augen. Nimm Dich in Acht vor
seinen grossen, scharfen Hoernern, die er sicher virtuos zu handhaben
weiss!

## Ausrüstung

Keine.

## Heimat

Auf der Stierkoppel der [Borsippa-Ebene](/ebene-borsippa.md "Ebene/Borsippa").

* * *


## Kenndaten

- Typ: aggressiv
- Gegend: Vaniorh
- Rasse: Säugetier

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Stier/Borsippa)
