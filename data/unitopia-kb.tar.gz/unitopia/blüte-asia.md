---
type: Wiki Article
title: Blüte/Asia
description: An der Kletterpflanze im wunderschönen Garten des Babbaistischen Klosters auf Asia.
resource: "http://unitopia.intelligense.de/wiki/Blüte/Asia"
tags: [Adjektiv, Gegenstand, Gegenstand/Ebenen, Gegenstand/Ebenen/Sonstige, Gegenstand/Sonstige, Hidden, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Biologisch, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2024-03-02T19:20:27Z
revid: 261371
namespace: 0
contenthash: 0e0f4638905aae085aba3a60315d99393cda11a05820ca8283124ec0bbf46da3
---

## Aussehen

Eine wunderhuebsche Bluete mit <[Anzahl](#Besonderheit)\> <[farbigen](#Besonderheit)\> Bluetenblaettern.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Biologisch](/kategorie/info-material-biologisch.md "Kategorie:Info/Material/Biologisch") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

An der Kletterpflanze im wunderschönen Garten des [Babbaistischen Klosters](/babbaistisches-kloster.md "Babbaistisches Kloster") auf [Asia](/asia.md "Asia").

## Besonderheit

-   Die Blüte gehört zu den Gegenständen, die ständig wechselnde Adjektive haben. Diese werden hier nicht gesondert aufgelistet.
-   Man kann sich beliebig viele Blüten ins Haar stecken, egal, ob man bereits Hut oder Helm trägt.

-   Zusätzliches Aussehen beim Betrachten einer Person:

| -   **Mann:** | Er hat sich eine wunderhuebsche <farbige> Bluete ins Haar gesteckt. |
| --- | --- |
| -   **Frau:** | Sie hat sich eine wunderhuebsche <farbige> Bluete ins Haar gesteckt. |
| -   **Etwas:** | Es hat sich eine wunderhuebsche <farbige> Bluete ins Haar gesteckt. |

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Ebenen
- Material: Biologisch
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein
- ul: ja
- Mann: Er hat sich eine wunderhuebsche Bluete ins Haar gesteckt.
- Frau: Sie hat sich eine wunderhuebsche Bluete ins Haar gesteckt.
- Etwas: Es hat sich eine wunderhuebsche Bluete ins Haar gesteckt.

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Blüte/Asia)
