---
type: Wiki Article
title: Tischbein
description: Im verwüsteten Raum der alten Beschwörergilde.
resource: "http://unitopia.intelligense.de/wiki/Tischbein"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Holz, Info/Schwimmt, Info/Waffenstärke, Info/Waffenstärke/schlecht, Info/Waffenzustand, Info/Waffenzustand/eher beständig, Waffe, Waffe/Keule, Waffe/Vaniorh, Waffe/Vaniorh/Keule]
timestamp: 2024-03-02T19:21:47Z
revid: 262613
namespace: 0
contenthash: cbdcb3999553c717ba46c38ecf274955ad4170e975b9ecf6a344e6f8949407c1
---

## Aussehen

Es ist das hoelzerne Bein eines kleinen Tisches. Es wurde gewaltsam von
seinem Tisch getrennt und ist nur noch, wie eine einfache Keule, als Waffe
zu benutzen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [2 (schlecht)](/kategorie/info-waffenstärke-schlecht.md "Kategorie:Info/Waffenstärke/schlecht") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [4 (eher beständig)](/kategorie/info-waffenzustand-eher-beständig.md "Kategorie:Info/Waffenzustand/eher beständig") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Im verwüsteten Raum der [alten Beschwörergilde](/handelsweg-terqa.md "Handelsweg/Terqa").

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Keule
- Gegend: Vaniorh
- Material: Holz
- Waffenstärke: schlecht
- Waffenzustand: eher beständig
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Tischbein)
