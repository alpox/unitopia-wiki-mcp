---
type: Wiki Article
title: Figur/Annonay
description: Auf dem Altar in der Kirche von Annonay.
resource: "http://unitopia.intelligense.de/wiki/Figur/Annonay"
tags: [Gegenstand, Gegenstand/Gallien, Gegenstand/Gallien/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Stein]
timestamp: 2024-03-02T19:19:27Z
revid: 239381
namespace: 0
contenthash: c44648aac4d402235a581916ac524b96b76de447035189eb34fd71ebf4cd5ea7
---

## Aussehen

Die Figur stellt einen liegenden Bullen dar. Sie ist etwa einen Fuss gross
und aus schwarzem Stein gefertigt. Die Konturen sind sehr genau
herausgearbeitet und manche Details sind mit weissen Linien bemalt. Der
Stein ist sehr glatt poliert. Diese Figur hat sicherlich eine besondere
Bedeutung in einer fremden Religion.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Stein](/kategorie/info-material-stein.md "Kategorie:Info/Material/Stein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Auf dem Altar in der Kirche von [Annonay](/annonay.md "Annonay").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Gallien
- Material: Stein
- Gewicht: 2
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Figur/Annonay)
