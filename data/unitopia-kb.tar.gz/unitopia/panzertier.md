---
type: Wiki Article
title: Panzertier
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Panzertier"
tags: [NPC, NPC/Dörrland, NPC/Dörrland/aggressiv, NPC/aggressiv, Rasse, Rasse/Säugetier, Spalten]
timestamp: 2018-11-15T10:02:05Z
revid: 260984
namespace: 0
contenthash: fd7ae22da01508ebd929044f03b56a6fda2161a34fdaffde28ed19aa6af44f10
---

## Aussehen

Ein Panzertier. Es erinnert ein wenig an ein Nashorn - hat aber kein Horn,
sondern ist ueber und ueber mit grauen Panzerplatten bedeckt. Die Hitze
scheint ihm offenbar nichts auszumachen. Im Kampf benutzt es einfach seinen
mit Panzerplatten bedeckten Kopf als Rammbock.

## Ausrüstung

Keine.

## Heimat

In der Wüste [Dörrlands](/dörrland.md "Dörrland").

## Besonderheit

Nach dem Töten erlangt man folgenden Loot:

-   Eine [Panzerplatte](/panzerplatten.md "Panzerplatten"), den man der Leiche abtrennen kann.
-   Und diverse **zufällige** [Edelsteine](/edelsteine.md "Edelsteine"):

-   Ein [Andalusit](/andalusit.md "Andalusit")
-   Ein [Andar](/andar.md "Andar")
-   Eine [Apachenträne](/apachenträne-dörrland.md "Apachenträne/Dörrland")
-   Ein [Apatit](/apatit.md "Apatit")
-   Ein [Blutstein](/blutstein-dörrland.md "Blutstein/Dörrland")
-   Eine [Königsträne](/königsträne.md "Königsträne")
-   Ein [Lapislazuli](/lapislazuli-dörrland.md "Lapislazuli/Dörrland")
-   Ein [Luchsauge](/luchsauge.md "Luchsauge")
-   Ein [Padparadscha](/padparadscha.md "Padparadscha")
-   Ein [Regenbogenobsidian](/regenbogenobsidian.md "Regenbogenobsidian")
-   Ein [Spitzbubenstein](/spitzbubenstein.md "Spitzbubenstein")
-   Ein [Wasseropal](/wasseropal.md "Wasseropal")

* * *


## Kenndaten

- Typ: aggressiv
- Gegend: Dörrland
- Rasse: Säugetier
- Left: 1.6em

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Panzertier)
