---
type: Wiki Article
title: Wichtel/Gallierwald
description: Ein Messer.
resource: "http://unitopia.intelligense.de/wiki/Wichtel/Gallierwald"
tags: [NPC, NPC/Gallien, NPC/Gallien/defensiv, NPC/defensiv, Rasse, Rasse/Wichtel]
timestamp: 2018-11-07T18:32:48Z
revid: 257619
namespace: 0
contenthash: afd0117f2437678dfd386dc0b43bff94f1d26a406b1cf5855b2fb8e021150962
---

## Aussehen

Du siehst einen netten, kleinen Wichtel.
Er hat einen gruenen Umhang an und einen lustigen, braunen, spitzen Hut,
der mit einem gruenen Band umwickelt ist.
Irgendwas bastelt der Wichtel an der Wurzel des Baumes rum. Was es ist
kannst Du nicht erkennen. Was es auch immer ist, es muss fuer den Wichtel
sehr wichtig sein.
Irgendwie macht der Wichtel auf dich einen netten Eindruck.

## Ausrüstung

Ein [Messer](/messer-wichtel-gallierwald.md "Messer/Wichtel/Gallierwald").

## Heimat

Im [Gallischen Wald](/gallierwald.md "Gallierwald").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Gallien
- Rasse: Wichtel

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Wichtel/Gallierwald)
