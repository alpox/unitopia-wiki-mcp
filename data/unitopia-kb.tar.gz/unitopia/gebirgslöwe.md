---
type: Wiki Article
title: Gebirgslöwe
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Gebirgslöwe"
tags: [Braten, Braten/Haut, Braten/Jagen, Braten/Stück, NPC, NPC/Ebenen, NPC/Ebenen/defensiv, NPC/defensiv, Rasse, Rasse/Säugetier]
timestamp: 2019-02-13T19:42:30Z
revid: 223102
namespace: 0
contenthash: 9821a7cea222d30e21cfd69c9de5164e44cace4081f9afa092e21e70fc2a831d
---

## Aussehen

```
Diese Loewe ist erstaunlich gut an die Berge angepasst. Er ist etwas
kleiner als die Loewen in der Steppe. Er scheint gerade auf der Jagd zu
sein und du hast ihn gestoert. Nun scheint er ja eine andere Beute gefunden
zu haben. Er schaut dich sehr hungrig und interessiert an.
```

## Ausrüstung

Keine.

## Heimat

Im Randgebirge auf [Amerindia](/amerindia.md "Amerindia").

## Besonderheit

Nach dem Töten ist der Gebirgslöwe [häut-](/löwenfell-gebirgslöwe.md "Löwenfell/Gebirgslöwe") und [bratbar](/braten-magyra.md "Braten/Magyra"). Der Braten lässt sich in mehrere handliche [Braten](/bratenscheibe.md "Bratenscheibe")[scheiben](/braten-scheibe.md "Braten/Scheibe"), [Braten](/bratenstück.md "Bratenstück")[stücke](/braten-stück.md "Braten/Stück") oder [Braten](/bratenteil.md "Bratenteil")[teile](/braten-teil.md "Braten/Teil") zerlegen.

## Kenndaten

- Typ: defensiv
- Gegend: Ebenen
- Rasse: Säugetier
- Artikel: der
- Haut: Löwenfell/Gebirgslöwe
- Stück: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Gebirgslöwe)
