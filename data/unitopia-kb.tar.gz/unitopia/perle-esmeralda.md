---
type: Wiki Article
title: Perle/Esmeralda
description: Zu kaufen bei Esmeralda im Esoterikladen von Ephesos auf Phrygia.
resource: "http://unitopia.intelligense.de/wiki/Perle/Esmeralda"
tags: [Fundort/Kauf, Hidden, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Edelstein, Kleidung, Kleidung/Hals, Kleidung/Kokosinseln, Kleidung/Kokosinseln/Hals, Mineral, Mineral/Kokosinseln, Mineral/Kokosinseln/Perle, Mineral/Perle, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2024-04-23T19:27:39Z
revid: 261987
namespace: 0
contenthash: bbdc58ae5156ca2516f3c96d7277d01afaf39df333bf273e21ced0a0a7ab8509
---

## Aussehen

Eine cremefarben schimmernde Perle die warm in deiner Hand liegt. Ihr
Bezugsmonat ist der November.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Edelstein](/kategorie/info-material-edelstein.md "Kategorie:Info/Material/Edelstein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Esmeralda](/esmeralda.md "Esmeralda") im Esoterikladen von [Ephesos](/ephesos.md "Ephesos") auf [Phrygia](/phrygia.md "Phrygia").

## Besonderheit

Zusätzliches Aussehen beim Betrachten einer Person:

| **Alle:** | <Spieler> traegt an einem Silberkettchen eine weich schimmernde Perle um den Hals. Sie scheint Glueck zu bringen. |
| --- | --- |

* * *


## Kenndaten

- Typ: Hals
- Gegend: Kokosinseln
- Kategorie: Mineral
- Material: Edelstein
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Perle/Esmeralda)
