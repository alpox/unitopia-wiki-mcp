---
type: Wiki Article
title: Elfenkeule
description: Als Belohnung von Njoerd in einer kleinen Höhle Westlich vom Elfenhaven.
resource: "http://unitopia.intelligense.de/wiki/Elfenkeule"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/8, Info/Material, Info/Material/Stein, Info/Waffenzustand, Info/Waffenzustand/recht beständig, Set, Set/Elfen, Todo, Todo/Kontrolle, Waffe, Waffe/Keule, Waffe/Midgard, Waffe/Midgard/Keule]
timestamp: 2024-04-23T19:28:27Z
revid: 265416
namespace: 0
contenthash: 5e135b464c7414b9aa321bf499d134f73c99d7e8f19897a15ab73b7e9d668ac1
---

## Aussehen

Eine maechtige Elfenkeule.
Obgleich die Elfen eigentlich Schwerter bevorzugen, scheint diese Waffe
eine Ehrung an Tulkas, den maechtigen Valar, zu sein, der in den Kriegen
gegen Morgoth auch eine Keule benutzte. Ein blaeuliches Schimmern umgibt
sie.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Stein](/kategorie/info-material-stein.md "Kategorie:Info/Material/Stein") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** |  |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [5 (recht beständig)](/kategorie/info-waffenzustand-recht-beständig.md "Kategorie:Info/Waffenzustand/recht beständig") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [8 (schwer)](/kategorie/info-gewicht-8.md "Kategorie:Info/Gewicht/8") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Als Belohnung von [Njoerd](/njoerd.md "Njoerd") in einer kleinen Höhle Westlich vom [Elfenhaven](/elfenhaven.md "Elfenhaven").

[![Todo.gif](/images/f/fa/Todo.gif)](/datei/todo.gif.md)**Zur Überarbeitung wegen inhaltlicher Mängel oder fehlenden Informationen vorgemerkt.** [Hilf mit](/kategorie/todo.md "Kategorie:Todo"), die inhaltlichen Mängel oder fehlende Informationen zu korrigieren oder zu ergänzen.

* * *

**Todo (Kontrolle):** Waffenstärke

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Keule
- Set: Elfen
- Gegend: Midgard
- Material: Stein
- Waffenzustand: recht beständig
- Gewicht: 8
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Elfenkeule)
