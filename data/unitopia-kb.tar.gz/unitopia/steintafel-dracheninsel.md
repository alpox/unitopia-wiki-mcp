---
type: Wiki Article
title: Steintafel/Dracheninsel
description: "Rätsel-Spoiler:"
resource: "http://unitopia.intelligense.de/wiki/Steintafel/Dracheninsel"
tags: [Gegenstand, Gegenstand/Kokosinseln, Gegenstand/Kokosinseln/Sonstige, Gegenstand/Sonstige, Hidden, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Stein]
timestamp: 2024-03-02T19:21:34Z
revid: 252814
namespace: 0
contenthash: 1f2a95263120592ab5bb0d366bbd0a3ff0f66ee4013a03249eb4f4b1ea757e9b
---

## Aussehen

Eine ziemlich sperrige, fuenfeckige, flache Tafel aus grauschwarzem Stein.
Auf einer Seite ist sie voellig glatt. In die andere ist in
gleichmaessiger, altertuemlicher Schrift eine lange Inschrift
eingemeisselt.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Stein](/kategorie/info-material-stein.md "Kategorie:Info/Material/Stein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

\[Spoilerwarnung\]  

Rätsel-Spoiler:

Auf der kleinen [Dracheninsel](/dracheninsel.md "Dracheninsel").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Kokosinseln
- Material: Stein
- Gewicht: 2
- Licht: 0
- Brennbar: nein
- Schwimmt: nein
- Inhalt: Auf der kleinen Dracheninsel.

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Steintafel/Dracheninsel)
