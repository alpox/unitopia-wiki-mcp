---
type: Wiki Article
title: Marzipanfigürchen
description: "Das Figürchen isst man nicht, man vernascht es."
resource: "http://unitopia.intelligense.de/wiki/Marzipanfigürchen"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Dörrland, Nahrung/Dörrland/Produkt, Nahrung/Kokosinseln, Nahrung/Kokosinseln/Produkt, Nahrung/Produkt, Nahrung/Vaniorh, Nahrung/Vaniorh/Produkt]
timestamp: 2024-08-29T15:22:36Z
revid: 254768
namespace: 0
contenthash: 1b324f1025e93b52b199be740585125fd5e39567e1ebe80b5705fd265a3e0715
---

## Aussehen

Mmmmmmmmmmmm!!! Sieht das lecker aus!!! Am liebsten moechtest Du dieses
Marzipanfiguerchen mit Milchschokoladenglasur sofort vernaschen.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

-   In der [Verpflegungskiste](/verpflegungskiste.md "Verpflegungskiste") in der Kohte im [Pfadfinderlager](/pfadfinderlager.md "Pfadfinderlager") auf [Kyra](/kyra.md "Kyra").
-   In der [Strandhöhle](/strandhöhle.md "Strandhöhle") auf der [großen Sandinsel](/große-sandinsel.md "Große Sandinsel").
-   In der Kommode vom [Forsthaus](/forsthaus.md "Forsthaus") im [Laubwald](/laubwald.md "Laubwald") südlich des [Terqa-Handelsweges](/handelsweg-terqa.md "Handelsweg/Terqa").

## Besonderheit

Das Figürchen isst man nicht, man vernascht es.

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Dörrland/Kokosinseln/Vaniorh
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Marzipanfigürchen)
