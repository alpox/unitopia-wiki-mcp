---
type: Wiki Article
title: Rattenfell/Kanalratte/Lutetia
description: Abzuziehen von der toten Kanalratte in der Kanalisation von Lutetia.
resource: "http://unitopia.intelligense.de/wiki/Rattenfell/Kanalratte/Lutetia"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Leder, Info/Material/Textil, Info/Temperaturschutz, Info/Temperaturschutz/wärmt ziemlich, Kleidung, Kleidung/Gallien, Kleidung/Gallien/Rücken, Kleidung/Rücken]
timestamp: 2024-03-02T19:21:34Z
revid: 252831
namespace: 0
contenthash: c71a69f3ece5f5101f046b051c6c109d6f5280b3444060f7de6af1f788204386
---

## Aussehen

Ein graues Rattenfell

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder"), [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt ziemlich](/kategorie/info-temperaturschutz-wärmt-ziemlich.md "Kategorie:Info/Temperaturschutz/wärmt ziemlich") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Abzuziehen von der [toten Kanalratte](/kanalratte-lutetia.md "Kanalratte/Lutetia") in der [Kanalisation](/lutetia.md "Lutetia") von [Lutetia](/lutetia.md "Lutetia").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Rücken
- Gegend: Gallien
- Material: Leder/Textil
- Temperaturschutz: wärmt ziemlich
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Rattenfell/Kanalratte/Lutetia)
