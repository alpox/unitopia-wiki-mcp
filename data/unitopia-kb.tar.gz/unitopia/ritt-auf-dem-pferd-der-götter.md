---
type: Wiki Article
title: Ritt auf dem Pferd der Götter
description: "Man sagt, auf den Inseln des Nordens kann ein mutiger Abenteurer den Ritt seines Lebens machen. Findest du Sleipnir und versuchst es?"
resource: "http://unitopia.intelligense.de/wiki/Ritt_auf_dem_Pferd_der_Götter"
tags: [Abenteuer, Abenteuer/Nordische Inseln, Abenteuer/ohne, Abenteuer/ohne/Nordische Inseln]
timestamp: 2018-11-07T18:23:59Z
revid: 251447
namespace: 0
contenthash: a87c1804b94be5fe30cddad3788e47b6efb7edda137478942d73744580ad0068
---

## Beschreibung

Man sagt, auf den [Inseln des Nordens](/nordische-inseln.md "Nordische Inseln") kann ein mutiger Abenteurer den Ritt seines Lebens machen. Findest du [Sleipnir](/sleipnir.md "Sleipnir") und versuchst es?

## Belohnung

Ein Ritt, von dem du deinen Enkeln erzählen kannst.

* * *


## Kenndaten

- Typ: ohne
- Gegend: Nordische Inseln

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Ritt_auf_dem_Pferd_der_Götter)
