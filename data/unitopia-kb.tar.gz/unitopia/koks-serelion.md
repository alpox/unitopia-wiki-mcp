---
type: Wiki Article
title: Koks/SeRelion
description: ""
resource: "http://unitopia.intelligense.de/wiki/Koks/SeRelion"
tags: [Fundort/Kauf, Gegenstand, Gegenstand/Ebenen, Gegenstand/Ebenen/Sonstige, Gegenstand/Midgard, Gegenstand/Midgard/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Pflanzlich, Info/Schwimmt, Info/Wirkung]
timestamp: 2024-08-29T15:13:59Z
revid: 254307
namespace: 0
contenthash: 636f5e86864e668b9f3a411d9550a0ebf010008403628fbecd1e1b3ebe838abb
---

## Aussehen

Ein unscheinbares, weisses Puelverchen. Manche sagen, durch die Nase
geschnupft, verschaffe es Wachheit und Allmachtsgefuele. Ein anstaendiger
Abenteurer sollte lieber die Nase davon lassen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Pflanzlich](/kategorie/info-material-pflanzlich.md "Kategorie:Info/Material/Pflanzlich") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | zieht 10 AP |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

-   Zu kaufen bei [SeRelion](/serelion.md "SeRelion") in der Apotheke von [Bruggstad](/bruggstad.md "Bruggstad").
-   Von [Holmar](/holmar.md "Holmar") in der Küche auf [Burg Tregyln](/burg-tregyln.md "Burg Tregyln") auf [Drachenland](/drachenland.md "Drachenland").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Ebenen/Midgard
- Material: Pflanzlich
- Wirkung: zieht 10 AP
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Koks/SeRelion)
