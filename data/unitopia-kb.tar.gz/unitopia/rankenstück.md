---
type: Wiki Article
title: Rankenstück
description: Am nördlichen Strand auf Vandras.
resource: "http://unitopia.intelligense.de/wiki/Rankenstück"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Nordische Inseln, Nahrung/Nordische Inseln/Pflanze, Nahrung/Pflanze]
timestamp: 2024-08-29T15:24:16Z
revid: 247390
namespace: 0
contenthash: 1d0e7200abb6c447f666f5090c81e08372c07d68b0aacc13fc378251f1f64e28
---

## Aussehen

Ein Stueck einer wohl riesigen, fremdartigen Ranke. Dieses Gruenzeug wirkt
ziemlich zaeh und robust.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Am nördlichen Strand auf [Vandras](/vandras.md "Vandras").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Pflanze
- Gegend: Nordische Inseln
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Rankenstück)
