---
type: Wiki Article
title: Fuchs/Dschungelinsel
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Fuchs/Dschungelinsel"
tags: [NPC, NPC/Kokosinseln, NPC/Kokosinseln/defensiv, NPC/defensiv, Rasse, Rasse/Insekt]
timestamp: 2019-03-15T15:41:32Z
revid: 262154
namespace: 0
contenthash: 9eb6eb17e816eb642ea0378274eef227840c504a45c32bd8fb864f8b0e616414
---

## Aussehen

Ein grosser Fuchs, mit schoen bunt gemusterten Fluegeln. Wie alle Insekten
hat er sechs Beine und grosse Facettenaugen. Dazu kommen dann noch zwei
lange Fuehler und ein eingerollter Saugruessel.

## Ausrüstung

Keine.

## Heimat

Im Dschungel auf der [Dschungelinsel](/dschungelinsel.md "Dschungelinsel").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Kokosinseln
- Rasse: Insekt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Fuchs/Dschungelinsel)
