---
type: Wiki Article
title: Flirtini
description: Zu kaufen bei Agnieska an der Bar im Nachtclub von Merredin.
resource: "http://unitopia.intelligense.de/wiki/Flirtini"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/betrunken, Info/Wirkung/durstlöschend, Nahrung, Nahrung/Alkohol, Nahrung/Midgard, Nahrung/Midgard/Alkohol]
timestamp: 2024-08-29T15:13:41Z
revid: 244785
namespace: 0
contenthash: 784ff678cd79e69aeefbdc0ba1482760ef3fa847f996163e131f628864b107ba
---

## Aussehen

In einem Cocktailglas befindet sich ein alkoholischer Cocktail namens
Flirtini. Rote, gelbe und gruenliche Saefte wirbeln wild durcheinander.
Du koenntest am Cocktailglas nippen, mal probieren, was du wohl
herausschmecken kannst, oder den Cocktail ganz schnell austrinken, eh dir
jemand zuvorkommt.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend"), [betrunken](/kategorie/info-wirkung-betrunken.md "Kategorie:Info/Wirkung/betrunken") |

## Fundort

Zu kaufen bei [Agnieska](/agnieska.md "Agnieska") an der Bar im [Nachtclub](/merredin.md "Merredin") von [Merredin](/merredin.md "Merredin").

## Funktion

nippe an Cocktail

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Alkohol
- Gegend: Midgard
- Gewicht: 1
- Wirkung: durstlöschend/betrunken

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Flirtini)
