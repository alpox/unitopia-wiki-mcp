---
type: Wiki Article
title: Kette/Klippenturm
description: Im Schlafzimmer vom Klippenturm auf Cyprus.
resource: "http://unitopia.intelligense.de/wiki/Kette/Klippenturm"
tags: [Fundort, Hidden, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Edelmetall, Info/Material/Gold, Kleidung, Kleidung/Hals, Kleidung/Kokosinseln, Kleidung/Kokosinseln/Hals, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2024-09-16T12:12:30Z
revid: 261326
namespace: 0
contenthash: fe76cbfc6e9af6ae36712f252f5d04ae5924a9130bfb4f1b084efd822cd8b1b2
---

## Aussehen

Diese Kette besteht aus purem Gold. Sie sieht nahezu perfekt aus und du
vermutest, dass sie ein Vermoegen wert ist. Wer sie besitzt, wird ziemlich
maechtig sein. Auf ihren Verschluss wurde eine winzige Inschrift graviert.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Edelmetall](/kategorie/info-material-edelmetall.md "Kategorie:Info/Material/Edelmetall"), [Gold](/kategorie/info-material-gold.md "Kategorie:Info/Material/Gold") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Im [Schlafzimmer](/cyprus.md "Cyprus") vom [Klippenturm](/klippenturm.md "Klippenturm") auf [Cyprus](/cyprus.md "Cyprus").

## Besonderheit

Zusätzliches Aussehen beim Betrachten einer Person:

| -   **Mann:** | Er strahlt eine intensive Aura von Macht aus. |
| --- | --- |
| -   **Frau:** | Sie strahlt eine intensive Aura von Macht aus. |
| -   **Etwas:** | Es strahlt eine intensive Aura von Macht aus. |

## Funktion

Man kann dem Träger der [Kette der Sklaverei](/kette-klippenturm2.md "Kette/Klippenturm2") eine Reihe erniedrigender Handlungen aufzwingen:

-   zwinge <Person> knie nieder
-   zwinge <Person> krieche
-   zwinge <Person> tanz
-   zwinge <Person> verbeuge
-   zwinge <Person> knickse
-   zwinge <Person> bewundere
-   zwinge <Person> winsele
-   zwinge <Person> verneige

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Hals
- Gegend: Kokosinseln
- Material: Edelmetall/Gold
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein
- Mann: Er strahlt eine intensive Aura von Macht aus.
- Frau: Sie strahlt eine intensive Aura von Macht aus.
- Etwas: Es strahlt eine intensive Aura von Macht aus.

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Kette/Klippenturm)
