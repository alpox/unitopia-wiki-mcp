---
type: Wiki Article
title: Glück
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Glück"
tags: [NPC, NPC/Kokosinseln, NPC/Kokosinseln/defensiv, NPC/defensiv, Rasse, Rasse/Elementar, Rasse/Vogel, Rasse/multi]
timestamp: 2018-11-07T18:34:32Z
revid: 211889
namespace: 0
contenthash: 7973d6e2bd1ad8b7bcabfd74f552ccf1eb9a23b6d2862acbf3392c5480b86620
---

## Aussehen

Glueck ist einer der beiden Sturmvoegel, die geschaffen wurden, um Zeichen
in letzter Not zu versenden. Sein glaenzendes Gefieder und die grosse
Spannweite der Fluegel geben ihm die majestaetische Autoritaet eines
Adlers.

Mit 'ueberbringe <Nachricht>' kannst Du dem Vogel Deine wichtigen
Botschaften mitteilen und sie mit 'schicke Vogel zu <Wem>' ueberbringen. Er
traegt einen Zettel im Schnabel.

## Ausrüstung

Keine.

## Heimat

Zu beschwören mit dem [Pergament-Stein](/pergament-stein.md "Pergament-Stein") und der [Pergamentrolle](/pergamentrolle-paionlabyrinth.md "Pergamentrolle/Paionlabyrinth").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Kokosinseln
- Rasse: Elementar/Vogel

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Glück)
