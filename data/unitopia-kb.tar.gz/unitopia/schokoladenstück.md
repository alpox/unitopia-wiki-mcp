---
type: Wiki Article
title: Schokoladenstück
description: Zu kaufen bei Manfred in der Konditorei von Londar.
resource: "http://unitopia.intelligense.de/wiki/Schokoladenstück"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Midgard, Nahrung/Midgard/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:16:42Z
revid: 249096
namespace: 0
contenthash: a765aed546e734e73805f9b341e0ebe4f4d402bd2a1c07eb50b29f5d1eb726e6
---

## Aussehen

Ein kleines Stueckchen Schokolade.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Zu kaufen bei [Manfred](/manfred.md "Manfred") in der Konditorei von [Londar](/londar.md "Londar").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Midgard
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schokoladenstück)
