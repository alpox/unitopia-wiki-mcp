---
type: Wiki Article
title: Golemhose
description: ""
resource: "http://unitopia.intelligense.de/wiki/Golemhose"
tags: [Fundort/Kauf, Hidden, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/3, Info/Material, Info/Material/Stein, Kleidung, Kleidung/Beine, Kleidung/Kokosinseln, Kleidung/Kokosinseln/Beine, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2024-04-23T19:27:56Z
revid: 261796
namespace: 0
contenthash: d24a4e8a1e4da11ecef8614f4f977ef222d1d60985eb3909f1007d43103ff69d
---

## Aussehen

Diese aeusserst grosse Hose wurde aus einzelnen, duennen Steinplaettchen
angefertigt. Jedes Plaettchen wurde fein saeuberlich mit einem Draht
verbunden und halten so die Hose zusammen. Hinten wurde kaum sichtbar ein
kleines Zettelchen befestigt.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Stein](/kategorie/info-material-stein.md "Kategorie:Info/Material/Stein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [3 (schon eher leicht)](/kategorie/info-gewicht-3.md "Kategorie:Info/Gewicht/3") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Zu kaufen bei [Kiesel](/kiesel-stratos.md "Kiesel/Stratos") im Laden 'Rock n Roll' auf [Stratos](/stratos.md "Stratos").
-   Kleidung von [Kiesel](/kiesel-stratos.md "Kiesel/Stratos") im Laden 'Rock n Roll' auf [Stratos](/stratos.md "Stratos").

## Besonderheit

-   Kann nur von [Golems](/metamorpher.md "Metamorpher"), [Riesen](/metamorpher.md "Metamorpher") und [Trollen](/metamorpher.md "Metamorpher") getragen werden.

-   Zusätzliches Aussehen beim Betrachten einer Person:

| -   **Mann:** | Er traegt eine fein verarbeitete Hose aus Stein. |
| --- | --- |
| -   **Frau:** | Sie traegt eine fein verarbeitete Hose aus Stein. |
| -   **Etwas:** | Es traegt eine fein verarbeitete Hose aus Stein. |

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Beine
- Gegend: Kokosinseln
- Material: Stein
- Gewicht: 3
- Licht: 0
- Brennbar: nein
- Schwimmt: nein
- ul: ja
- Mann: Er traegt eine fein verarbeitete Hose aus Stein.
- Frau: Sie traegt eine fein verarbeitete Hose aus Stein.
- Etwas: Es traegt eine fein verarbeitete Hose aus Stein.

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Golemhose)
