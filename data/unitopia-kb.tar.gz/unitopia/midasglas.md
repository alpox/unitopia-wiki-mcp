---
type: Wiki Article
title: Midasglas
description: ""
resource: "http://unitopia.intelligense.de/wiki/Midasglas"
tags: [Fundort, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Edelstein, Mineral, Mineral/Edelstein, Mineral/Kokosinseln, Mineral/Kokosinseln/Edelstein]
timestamp: 2024-09-16T12:10:32Z
revid: 239577
namespace: 0
contenthash: c1ecc1b2a0a3f3b7ae5e3702ce477d50e79b79bfac386226501ea0cdf5c6d720
---

## Aussehen

Der Edelstein besteht aus einem intensiv gelblich schimmernden Material. Er
ist unfoermig wie eine Kartoffel, ein wenig rund, aber keine Kugel. Wer
weiss, vielleicht hat er ja besondere Kraefte, dem Midasglas sagt man ja
bekanntlich nach, dass es andere Gegenstaende auch in Glas verwandeln kann,
wenn diese nur die innewohnende Kraft richtig aufnehmen koennen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Edelstein](/kategorie/info-material-edelstein.md "Kategorie:Info/Material/Edelstein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   In der [alten Mine](/cyprus.md "Cyprus") auf [Cyprus](/cyprus.md "Cyprus").
-   Nach dem Töten der [Geschöpfe](/verfluchter-wald.md "Verfluchter Wald") im [verfluchten Wald](/verfluchter-wald.md "Verfluchter Wald") auf [Cyprus](/cyprus.md "Cyprus").

## Wirkung

| Waffe | Effekt |
| --- | --- |
| [blauglänzende Axt](/axt-blauglänzende.md "Axt/blauglänzende") |  |
| [blauglänzender Degen](/degen-blauglänzender.md "Degen/blauglänzender") |  |
| [blauglänzender Dolch](/dolch-blauglänzender.md "Dolch/blauglänzender") |  |
| [blauglänzender Kampfhammer](/kampfhammer-blauglänzender.md "Kampfhammer/blauglänzender") |  |
| [blauglänzender Kampfstab](/kampfstab-blauglänzender.md "Kampfstab/blauglänzender") |  |
| [blauglänzendes Kurzschwert](/kurzschwert-blauglänzendes.md "Kurzschwert/blauglänzendes") |  |
| [blauglänzendes Langschwert](/langschwert-blauglänzendes.md "Langschwert/blauglänzendes") |  |
| [blauglänzender Säbel](/säbel-blauglänzender.md "Säbel/blauglänzender") |  |

* * *


## Kenndaten

- Kategorie: Mineral
- Typ: Edelstein
- Gegend: Kokosinseln
- Material: Edelstein
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Midasglas)
