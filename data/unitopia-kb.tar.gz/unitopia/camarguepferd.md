---
type: Wiki Article
title: Camarguepferd
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Camarguepferd"
tags: [NPC, NPC/Gallien, NPC/Gallien/defensiv, NPC/defensiv, Rasse, Rasse/Säugetier, Tätigkeit, Tätigkeit/Reittier]
timestamp: 2018-11-07T18:32:48Z
revid: 253690
namespace: 0
contenthash: a24f090589db422f5fcb9e9eacdb13a06f41e31c02c8554440f0e9afb8b3b7b2
---

## Aussehen

Das Camarguepferd ist ein <Groesse>, halbwildes Pony. Es hat eine lange,
zottelige Maehne und einen dichten Schweif. Das Fell hat einen weissen
Grundton, doch ist es mit lauter grauen Sprenkeln versehen.

_Beschmutzt_

Das Camarguepferd ist ein <Groesse>, halbwildes Pony. Es hat eine lange,
zottelige Maehne und einen dichten Schweif. Das Fell hat einen weissen
Grundton, doch ist es ziemlich dreckig.

## Ausrüstung

Keine.

## Heimat

In der [Camargue](/camargue.md "Camargue").

## Besonderheit

Man kann das Pferd an bestimmen Stellen säubern.

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Gallien
- Rasse: Säugetier
- Tätigkeit: Reittier

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Camarguepferd)
