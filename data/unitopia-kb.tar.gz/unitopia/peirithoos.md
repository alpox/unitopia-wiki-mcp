---
type: Wiki Article
title: Peirithoos
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Peirithoos"
tags: [NPC, NPC/Kokosinseln, NPC/Kokosinseln/defensiv, NPC/defensiv, Rasse, Rasse/Mensch]
timestamp: 2018-11-07T18:32:48Z
revid: 215917
namespace: 0
contenthash: cd4e9623db88376f4782fe55fda3233f98ca4f95750340e3d9c58aad9be9a858
---

## Aussehen

Peirithoos ist ein grosser, breitschultriger Mann mit Muskeln wie ein Baer.
Er ist ein Freund des allbekannten Heracles, mit dem er schon mancherlei
Abenteuer durchgestanden hat. Nach griechischer Sitte traegt er einen
hellen Chiton.

## Ausrüstung

Keine.

## Heimat

Nahe der Nordwestküste auf [Kreta](/kreta.md "Kreta").

## Funktion

Beim Ringer kann man gegen jeden Gegner, auch ihn, im Ringkampf antreten.  
Sieger ist der, dessen Gegner zuerst auf den Schultern liegt.

| Allgemeine | Erklärung |
| --- | --- |
| hilfe ringen | Die Befehlsübersicht |
| beginne ringkampf mit <Gegner> | Man fordert <Gegner> zum Ringkampf auf |
| antworte ja | Man nimmt die Herausforderung an |
| antworte nein | Man lehnt die Herausforderung ab |
| aufgeben | Man gibt den Kampf auf |
| \[ab\]klopfen | Man gibt den Kampf auf |
| stand | Den Stand des Ringkampfe abfragen |
| Spezielle | Erklärung |
| box\[en\] | Man boxt den Gegner. |
| ausheb\[en\] | Man heb\[el\]t den Gegner aus |
| tret\[en\] | Man tritt den Gegner |
| wuerg\[en\] | Man würgt den Gegner |
| beinstell\[en\] | Man stellt dem Gegner ein Bein. |
| waelz\[en\] | Man wälzt den Gegner auf den Rücken. |
| spring\[en\] | Man springt auf den Gegner. |

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Kokosinseln
- Rasse: Mensch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Peirithoos)
