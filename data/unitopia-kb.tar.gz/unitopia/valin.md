---
type: Wiki Article
title: Valin
description: In einem Stollen in Dvaergen.
resource: "http://unitopia.intelligense.de/wiki/Valin"
tags: [NPC, NPC/Midgard, NPC/Midgard/defensiv, NPC/defensiv, Rasse, Rasse/Zwerg]
timestamp: 2018-11-07T18:26:51Z
revid: 233337
namespace: 0
contenthash: 771edc1c70e35948e5b3062c55754464592d5c0774de02999a985c993a38ecac
---

## Aussehen

Ein aelterer Zwerg, der sicher schon mal bessere Zeiten erlebt hat. Jetzt
vertreibt er sich die Zeit (und seine Sorgen) mit dem Genuss von mehreren
Glaesern Bier am Tag.

## Ausrüstung

-   Eine [abgewetzte Hose](/hose-valin.md "Hose/Valin").
-   Ein [fleckiges Hemd](/hemd-valin.md "Hemd/Valin").
-   Ein [breiter Gürtel](/gürtel-valin.md "Gürtel/Valin").

## Heimat

In einem Stollen in [Dvaergen](/dvaergen.md "Dvaergen").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Midgard
- Rasse: Zwerg

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Valin)
