---
type: Wiki Article
title: Leiche/Gallien
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Leiche/Gallien"
tags: [Gegenstand, Gegenstand/Gallien, Gegenstand/Gallien/Sonstige, Gegenstand/Sonstige]
timestamp: 2018-11-07T18:43:46Z
revid: 254561
namespace: 0
contenthash: 8265053d7bbc58ad6b8537534da54a95ba290e25f9505e029c3ed761232367d3
---

## Aussehen

Die Leiche liegt hier anscheinend noch nicht allzulang herum. So wie sie
aussieht, gehoeren die Blutlachen um sie herum zu ihr. Der Mann, dem da das
Leben ausgehaucht wurde, war sicher einer von den reicheren Geschoepfen
Galliens, aber nun ist er ziemlich arm dran. Ihm ist nicht mehr zu helfen.

## Ausrüstung

Keine.

## Fundort

Auf der [Römerstraße V](/römerstraße-v.md "Römerstraße V").

## Geschichte

Vor vielen Jahren hatte diese Leiche einen gravierenden Fehler. Sie war Gewichtslos, man konnte sie mitnehmen und konnte unbegrenzt Dinge hineinlegen. Und so hatte fast ein jeder den größten Behälter der [Unitopias](/unitopia.md "Unitopia") dabei.

* * *


## Kenndaten

- Typ: Sonstige
- Gegend: Gallien

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Leiche/Gallien)
