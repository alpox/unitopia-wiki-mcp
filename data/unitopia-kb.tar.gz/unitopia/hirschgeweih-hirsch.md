---
type: Wiki Article
title: Hirschgeweih/Hirsch
description: Abzuschneiden vom toten Hirsch im Wald auf Amerindia.
resource: "http://unitopia.intelligense.de/wiki/Hirschgeweih/Hirsch"
tags: [Gegenstand, Gegenstand/Ebenen, Gegenstand/Ebenen/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Bein]
timestamp: 2024-03-02T19:20:47Z
revid: 243999
namespace: 0
contenthash: 85de912b284ae69d49555b780c984b9243d11baa7d0041876c91feb25957655e
---

## Aussehen

Ein Prachtexemplar von einem Hirschgeweih, mit dem der Hirsch kraeftig
zustossen kann - aber auch Schlaege abfaengt.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Bein](/kategorie/info-material-bein.md "Kategorie:Info/Material/Bein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Abzuschneiden vom [toten Hirsch](/hirsch.md "Hirsch") im Wald auf [Amerindia](/amerindia.md "Amerindia").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Ebenen
- Material: Bein
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Hirschgeweih/Hirsch)
