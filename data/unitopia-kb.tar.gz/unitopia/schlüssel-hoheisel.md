---
type: Wiki Article
title: Schlüssel/Hoheisel
description: Schlüssel von Hoheisel in seiner Gruft in der Friedhofshöhle von Dörrstadt.
resource: "http://unitopia.intelligense.de/wiki/Schlüssel/Hoheisel"
tags: [Gegenstand, Gegenstand/Dörrland, Gegenstand/Dörrland/Schlüssel, Gegenstand/Schlüssel, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Metall]
timestamp: 2024-03-02T19:21:45Z
revid: 255782
namespace: 0
contenthash: a7edc09efa32961f9e60352b2fed6410d411dc0bb17e3ef90caec9b431d06a72
---

## Aussehen

Ein grosser, alter Kellerschluessel. Er hat nichts Besonderes an sich.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Schlüssel von [Hoheisel](/hoheisel.md "Hoheisel") in seiner Gruft in der [Friedhofshöhle](/friedhofshöhle.md "Friedhofshöhle") von [Dörrstadt](/dörrstadt.md "Dörrstadt").

## Funktion

Für den Kellerraum unter der alten Schmiede in [Dörrstadt](/dörrstadt.md "Dörrstadt").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Schlüssel
- Gegend: Dörrland
- Material: Metall
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schlüssel/Hoheisel)
