---
type: Wiki Article
title: Pommes/Eurodisnix
description: Zu kaufen bei der Maus im Eurodisnix.
resource: "http://unitopia.intelligense.de/wiki/Pommes/Eurodisnix"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Gallien, Nahrung/Gallien/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:15:27Z
revid: 247184
namespace: 0
contenthash: e7a4ee19f580033530427999b22ec1cb1b1ea351e7c41626904ab92c7a640a5a
---

## Aussehen

Du meinst einen leichten Geruch nach Fritierfett zu riechen.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Zu kaufen bei der [Maus](/maus-eurodisnix.md "Maus/Eurodisnix") im [Eurodisnix](/eurodisnix.md "Eurodisnix").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Gallien
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Pommes/Eurodisnix)
