---
type: Wiki Article
title: Zettel/Holzkiste/Piratenlager2
description: In der kleinen Holzkiste in einer Nische im Piratenlager auf Cyprus.
resource: "http://unitopia.intelligense.de/wiki/Zettel/Holzkiste/Piratenlager2"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Papier, Info/Schwimmt, Schriften, Schriften/Kokosinseln, Schriften/Kokosinseln/Sonstige, Schriften/Sonstige]
timestamp: 2024-03-02T19:20:24Z
revid: 239910
namespace: 0
contenthash: 3f70bc3d810eadfd43bf2e95c505c4d3621362643c0bd4496b4dceedb0909048
---

## Aussehen

Der Zettel ist ziemlich dreckig und verschmiert, aber man kann die Notiz
darauf trotzdem noch lesen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Papier](/kategorie/info-material-papier.md "Kategorie:Info/Material/Papier") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

In der [kleinen Holzkiste](/holzkiste-piratenlager.md "Holzkiste/Piratenlager") in einer Nische im [Piratenlager](/piratenlager.md "Piratenlager") auf [Cyprus](/cyprus.md "Cyprus").

## Inhalt

Nachricht wegen eines versenkten Schiffes

## Faksimile

An Commodore Morgos.

Die "Dunkler Seegraeber" wird vermisst.
Der Grossteil der Beute war an Bord.
Sind von Knossos Richtung 89 Grad gesegelt.
Nach 31sm letzte Sichtung der "Dunkler Seegraeber" suedlich unserer
Position.
Stand unter Beschuss durch kretische Flotte, moeglicherweise versenkt.
Starte Suchoperation, sobald sich Lage beruhigt hat.

gez. Kapitaen Anacios.

* * *


## Kenndaten

- Kategorie: Schriften
- Typ: Sonstige
- Gegend: Kokosinseln
- Material: Papier
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Zettel/Holzkiste/Piratenlager2)
