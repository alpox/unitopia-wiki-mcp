---
type: Wiki Article
title: Hüftsteak/James
description: "Zu kaufen bei James McGregor in 'McGregors' neuen Pub von Dörrstadt."
resource: "http://unitopia.intelligense.de/wiki/Hüftsteak/James"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, "Info/Wirkung/gibt 6-10 AP", "Info/Wirkung/gibt 6-10 ZP", Info/Wirkung/sättigt, Nahrung, Nahrung/Dörrland, Nahrung/Dörrland/Tier, Nahrung/Tier]
timestamp: 2024-08-29T15:15:41Z
revid: 218455
namespace: 0
contenthash: ac1d07b984e5501b0f3bbb49225bdfb4527a7a26a4641062527ca66f42310903
---

## Aussehen

  

-   **Ein daumendickes, blutiges Hüftsteak:**

Ein daumendickes, nur ganz leicht angebratenes Hueftsteak. Genau weist
du's nicht, aber es stammt vermutlich von einem Wildkamel. Es ist groesser
als der Teller und sieht verfuehrerisch gut aus - wenn mans blutig mag. Auf
Beilagen wurde hier bis auf ein wenig Zwiebel verzichtet.

-   **Ein daumendickes, kurzgebratenes Hüftsteak:**

Ein daumendickes Hueftsteak. Medium. Genau weist du's nicht, aber es
stammt vermutlich von einem Wildkamel. Es ist groesser als der Teller und
sieht verfuehrerisch gut aus. Auf Beilagen wurde hier bis auf ein wenig
Zwiebel ganz verzichtet, um den Geschmack des Fleisches nicht zu stoeren.

-   **Ein daumendickes, durchgebratenes Hüftsteak:**

Ein daumendickes Hueftsteak. Well done. Also ordentlich durchgebraten und
aussen leicht angebruzzelt. Genau weist du's nicht, aber es stammt
vermutlich von einem Wildkamel. Es ist groesser als der Teller und sieht
verfuehrerisch gut aus. Auf Beilagen wurde hier bis auf ein wenig Zwiebel
ganz verzichtet, um den Geschmack des Fleisches nicht zu stoeren.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt"), gibt 9 ZP wenn AP voll |

## Fundort

Zu kaufen bei [James McGregor](/james.md "James") in ['McGregors' neuen Pub](/dörrstadt.md "Dörrstadt") von [Dörrstadt](/dörrstadt.md "Dörrstadt").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Tier
- Gegend: Dörrland
- Gewicht: 1
- Wirkung: sättigt/gibt 9 ZP wenn AP voll

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Hüftsteak/James)
