---
type: Wiki Article
title: Apfelkerngehäuse
description: ""
resource: "http://unitopia.intelligense.de/wiki/Apfelkerngehäuse"
tags: [Gegenstand, Gegenstand/Dörrland, Gegenstand/Dörrland/Sonstige, Gegenstand/Ebenen, Gegenstand/Ebenen/Sonstige, Gegenstand/Kokosinseln, Gegenstand/Kokosinseln/Sonstige, Gegenstand/Midgard, Gegenstand/Midgard/Sonstige, Gegenstand/Nordische Inseln, Gegenstand/Nordische Inseln/Sonstige, Gegenstand/Sonstige, Gegenstand/Vaniorh, Gegenstand/Vaniorh/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Pflanzlich, Info/Schwimmt]
timestamp: 2024-03-02T19:20:27Z
revid: 254191
namespace: 0
contenthash: 419bda3707a093f312350dd34b16f117bd01120e6e7625d9e4ab10844ade35ac
---

## Aussehen

Ein Apfelkerngehaeuse ist nach dem Essen uebrig geblieben.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Pflanzlich](/kategorie/info-material-pflanzlich.md "Kategorie:Info/Material/Pflanzlich") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

-   Kerngehäuse des [Apfels](/apfel-bauernhof-amerindia.md "Apfel/Bauernhof/Amerindia") am Apfelbaum auf dem [Bauernhof](/amerindia.md "Amerindia") auf [Amerindia](/amerindia.md "Amerindia").
-   Kerngehäuse des [Apfels](/apfel-magyra.md "Apfel/Magyra") am einladenden Apfelbaum im Garten der [Druidenburg](/druidenburg.md "Druidenburg").
-   Kerngehäuse des [Apfels](/apfel-magyra.md "Apfel/Magyra") in der Obstkiste in der Wachstube am Osttor von [Merredin](/merredin.md "Merredin").
-   Kerngehäuse des [Apfels](/apfel-bardengilde.md "Apfel/Bardengilde") von den Apfelbäumen im Garten der [Bardengilde](/bardengilde.md "Bardengilde") in [Ephesos](/ephesos.md "Ephesos") auf [Phrygia](/phrygia.md "Phrygia").
-   Kerngehäuse des [Apfels](/apfel-magyra.md "Apfel/Magyra") am Apfelbaum auf der [Streuobstwiese](/felder.md "Felder") nahe des [Hafens](/tadmor.md "Tadmor") von [Tadmor](/tadmor.md "Tadmor").
-   Kerngehäuse des [Apfels](/apfel-terqa.md "Apfel/Terqa") am Apfelbaum aus dem Obstgarten von [Terqa](/terqa.md "Terqa").
-   Kerngehäuse des [Apfels](/apfel-magyra.md "Apfel/Magyra") am Apfelbaum aus dem Obstgarten des [Bauernhofes](/terqa.md "Terqa") von [Terqa](/terqa.md "Terqa").
-   Kerngehäuse des [Apfels](/apfel-magyra.md "Apfel/Magyra") am Apfelbaum auf einer Wiese mit Obstbäumen bei [Phexcaer](/phexcaer.md "Phexcaer") auf [Thule](/thule.md "Thule").
-   Kerngehäuse des [Apfels](/apfel-magyra.md "Apfel/Magyra") am Apfelbaum im Garten des [Bauernhofes](/phexcaer.md "Phexcaer") von [Phexcaer](/phexcaer.md "Phexcaer") auf [Thule](/thule.md "Thule").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Dörrland/Ebenen/Kokosinseln/Midgard/Nordische Inseln/Vaniorh
- Material: Pflanzlich
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Apfelkerngehäuse)
