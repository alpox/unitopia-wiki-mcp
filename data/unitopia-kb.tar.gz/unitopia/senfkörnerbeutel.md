---
type: Wiki Article
title: Senfkörnerbeutel
description: Zu kaufen bei Adventi in den Adventskalendern auf dem Weihnachtsmarkt in Nankea (Stadt) auf Nankea.
resource: "http://unitopia.intelligense.de/wiki/Senfkörnerbeutel"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Midgard, Nahrung/Midgard/Produkt, Nahrung/Produkt, Todo, Todo/Nachtragen]
timestamp: 2024-08-29T15:19:51Z
revid: 265495
namespace: 0
contenthash: 913a43388f192330047361f0df80702bd223fe9e4ddaf164b5bd26fd0ecafe25
---

## Aussehen

Ein Beutel voller Senfkoerner. Ob man die wohl essen kann? Du hast keinen
Plan, was man sonst damit anstellen koennte.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Zu kaufen bei [Adventi](/adventi.md "Adventi") in den [Adventskalendern](/adventskalender.md "Adventskalender") auf dem [Weihnachtsmarkt](/weihnachtsmarkt.md "Weihnachtsmarkt") in [Nankea (Stadt)](/nankea-\(stadt\).md "Nankea (Stadt)") auf [Nankea](/nankea.md "Nankea").

## Funktion

[![Todo.gif](/images/f/fa/Todo.gif)](/datei/todo.gif.md)**Zur Überarbeitung wegen inhaltlicher Mängel oder fehlenden Informationen vorgemerkt.** [Hilf mit](/kategorie/todo.md "Kategorie:Todo"), die inhaltlichen Mängel oder fehlende Informationen zu korrigieren oder zu ergänzen.

* * *

**Todo (Nachtragen):** Herausfinden

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Midgard
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Senfkörnerbeutel)
