---
type: Wiki Article
title: Druidenkutte/Seher/Tadmor
description: Kleidung vom Seher im Informationsbüro der Vampyrgilde im Rathaus von Tadmor.
resource: "http://unitopia.intelligense.de/wiki/Druidenkutte/Seher/Tadmor"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Leder, Kleidung, Kleidung/Brust, Kleidung/Vaniorh, Kleidung/Vaniorh/Brust]
timestamp: 2024-03-02T19:21:43Z
revid: 214107
namespace: 0
contenthash: 0b6f9fdb828ac59877e6a485a7d8e7358bb7c6f7fd06a4b92a737c5d18199a4a
---

## Aussehen

Diese schwarze Kutte ist so geschnitten wie die ueblichen weiten Kutten,
die es ja zuhauf gibt. Diese hier jedoch ist aus schwarzem Leder, und wird
durch Nieten und andere seltsam anmutende Metallteile zusammengehalten.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Kleidung vom [Seher](/seher-tadmor.md "Seher/Tadmor") im Informationsbüro der [Vampyrgilde](/vampyrgilde.md "Vampyrgilde") im [Rathaus](/tadmor.md "Tadmor") von [Tadmor](/tadmor.md "Tadmor").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Brust
- Gegend: Vaniorh
- Material: Leder
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Druidenkutte/Seher/Tadmor)
