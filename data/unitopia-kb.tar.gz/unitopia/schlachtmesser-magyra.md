---
type: Wiki Article
title: Schlachtmesser/Magyra
description: "Das Messer von Bully hat die Waffenstärke: naja, Zustand: recht beständig und Gewicht: 2."
resource: "http://unitopia.intelligense.de/wiki/Schlachtmesser/Magyra"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Gewicht/2, Info/Material, Info/Material/Metall, Info/Waffenstärke, Info/Waffenstärke/geht so, Info/Waffenstärke/naja, Info/Waffenzustand, Info/Waffenzustand/recht beständig, Info/Waffenzustand/solide, Waffe, Waffe/Kokosinseln, Waffe/Kokosinseln/Messer, Waffe/Messer, Waffe/Midgard, Waffe/Midgard/Messer]
timestamp: 2024-03-02T19:19:02Z
revid: 253890
namespace: 0
contenthash: 532c839e34a8b5f885a91c515a070a14d8f9cf228fd8d1bd66e4cf6742b54c0d
---

## Aussehen

Ein grosses scharfes Schlachtmesser

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [3 (naja)](/kategorie/info-waffenstärke-naja.md "Kategorie:Info/Waffenstärke/naja"), [4 (geht so)](/kategorie/info-waffenstärke-geht-so.md "Kategorie:Info/Waffenstärke/geht so") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [5 (recht beständig)](/kategorie/info-waffenzustand-recht-beständig.md "Kategorie:Info/Waffenzustand/recht beständig"), [6 (solide)](/kategorie/info-waffenzustand-solide.md "Kategorie:Info/Waffenzustand/solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2"), [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Waffe von [Bully](/bully.md "Bully") in einer finsteren Kneipe in [Bruggstad](/bruggstad.md "Bruggstad").
-   Waffe von [Drancol](/drancol.md "Drancol") im [Gasthaus "Zum Blutsauger"](/blutsauger.md "Blutsauger") auf [Phrygia](/phrygia.md "Phrygia").
-   Waffe von [Radu](/radu.md "Radu") in der [Herberge "Zum blutigen Knochen"](/vampyrschloss.md "Vampyrschloss") im [Vampyrschloss](/vampyrschloss.md "Vampyrschloss").

## Besonderheit

Das Messer von [Bully](/bully.md "Bully") hat die Waffenstärke: **naja**, Zustand: **recht beständig** und Gewicht: **2**.

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Messer
- Gegend: Kokosinseln/Midgard
- Material: Metall
- Waffenstärke: naja/geht so
- Waffenzustand: recht beständig/solide
- Gewicht: 2/1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schlachtmesser/Magyra)
