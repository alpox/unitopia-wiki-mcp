---
type: Wiki Article
title: Grasbüschel/Tadmor
description: Im mannshohen Gras im südlichen Stadtgraben von Tadmor.
resource: "http://unitopia.intelligense.de/wiki/Grasbüschel/Tadmor"
tags: [Gegenstand, Gegenstand/Sonstige, Gegenstand/Vaniorh, Gegenstand/Vaniorh/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Pflanzlich, Info/Schwimmt]
timestamp: 2024-03-02T19:21:43Z
revid: 252733
namespace: 0
contenthash: 20d75789f969c60044d175aff70ed05480225eaaff2e3d072c0221b0f566b45a
---

## Aussehen

Da haengt sogar noch ein Batzen Erde am Grasbueschel dran, es sieht aus wie
ein komplettes Stueck Grassoden. Ein Soden ist ein Stueck Gras, kein Typo.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Pflanzlich](/kategorie/info-material-pflanzlich.md "Kategorie:Info/Material/Pflanzlich") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Im mannshohen Gras im [südlichen Stadtgraben](/tadmor.md "Tadmor") von [Tadmor](/tadmor.md "Tadmor").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Vaniorh
- Material: Pflanzlich
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Grasbüschel/Tadmor)
