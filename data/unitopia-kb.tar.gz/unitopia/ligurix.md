---
type: Wiki Article
title: Ligurix
description: Eine Galliermütze.
resource: "http://unitopia.intelligense.de/wiki/Ligurix"
tags: [Angebot, NPC, NPC/Gallien, NPC/Gallien/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Verkäufer]
timestamp: 2022-04-25T21:07:54Z
revid: 256093
namespace: 0
contenthash: f88e79b7f5259cd2630faf8e5a8650c507cd19325760d48a44672473650cc14f
---

## Aussehen

Ligurix ist ein typischer Gallier. Er ist ein richtiger Wein-Experte. Sein
Lebensinhalt ist dieses Geschaeft, welches er auf keinem Fall weggeben
wuerde. Er scheint dem Essen nicht abgeneigt zu sein, was an seinem
Koerperumfang deutlich zu sehen ist.

## Ausrüstung

Eine [Galliermütze](/galliermütze.md "Galliermütze").

## Heimat

In seinem Weinladen des [Weingutes](/weingut.md "Weingut") an der [ausgebauten Straßen](/weingut.md "Weingut") südlich der [Römerstraße VII](/römerstraße-vii.md "Römerstraße VII").

## Besonderheit

-   Ligurix bietet außerdem noch von allen Weinen eine kostenlose Probe an.
-   Auf alle Amphoren wird ein Pfand von 10 [Sesterzen](/sesterzen.md "Sesterzen") erhoben.
-   Amphoren und [Gläser](/glas-ligurix.md "Glas/Ligurix") werden jederzeit wieder zurückgenommen.

## Angebot

| ![Angebot-tl.gif](/images/d/db/Angebot-tl.gif) | Weinkarte | ![Angebot-tr.gif](/images/5/52/Angebot-tr.gif) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | \| **Sorte::** \| **[Sesterzen](/währung.md "Währung")**: \| \| --- \| --- \| \| Eine [Weinamphore](/weinamphore-ligurix.md "Weinamphore/Ligurix") mit [Rotwein](/rotwein-ligurix.md "Rotwein/Ligurix") \| 60 \| \| Eine [Weinamphore](/weinamphore-ligurix.md "Weinamphore/Ligurix") mit [Weißwein](/weißwein-ligurix.md "Weißwein/Ligurix") \| 70 \| \| Eine [Weinamphore](/weinamphore-ligurix.md "Weinamphore/Ligurix") mit [Riesling](/riesling-ligurix.md "Riesling/Ligurix") \| 75 \| \| Eine [Weinamphore](/weinamphore-ligurix.md "Weinamphore/Ligurix") mit [Bordeaux](/bordeaux-ligurix.md "Bordeaux/Ligurix") \| 90 \| \| Eine [Weinamphore](/weinamphore-ligurix.md "Weinamphore/Ligurix") mit [Emile](/emile.md "Emile") \| 100 \| \| Eine [Weinamphore](/weinamphore-ligurix.md "Weinamphore/Ligurix") mit [Hautumwienix](/hautumwienix.md "Hautumwienix") \| 120 \| | **Sorte::** | **[Sesterzen](/währung.md "Währung")**: | Eine [Weinamphore](/weinamphore-ligurix.md "Weinamphore/Ligurix") mit [Rotwein](/rotwein-ligurix.md "Rotwein/Ligurix") | 60 | Eine [Weinamphore](/weinamphore-ligurix.md "Weinamphore/Ligurix") mit [Weißwein](/weißwein-ligurix.md "Weißwein/Ligurix") | 70 | Eine [Weinamphore](/weinamphore-ligurix.md "Weinamphore/Ligurix") mit [Riesling](/riesling-ligurix.md "Riesling/Ligurix") | 75 | Eine [Weinamphore](/weinamphore-ligurix.md "Weinamphore/Ligurix") mit [Bordeaux](/bordeaux-ligurix.md "Bordeaux/Ligurix") | 90 | Eine [Weinamphore](/weinamphore-ligurix.md "Weinamphore/Ligurix") mit [Emile](/emile.md "Emile") | 100 | Eine [Weinamphore](/weinamphore-ligurix.md "Weinamphore/Ligurix") mit [Hautumwienix](/hautumwienix.md "Hautumwienix") | 120 |  |
| **Sorte::** | **[Sesterzen](/währung.md "Währung")**: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Weinamphore](/weinamphore-ligurix.md "Weinamphore/Ligurix") mit [Rotwein](/rotwein-ligurix.md "Rotwein/Ligurix") | 60 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Weinamphore](/weinamphore-ligurix.md "Weinamphore/Ligurix") mit [Weißwein](/weißwein-ligurix.md "Weißwein/Ligurix") | 70 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Weinamphore](/weinamphore-ligurix.md "Weinamphore/Ligurix") mit [Riesling](/riesling-ligurix.md "Riesling/Ligurix") | 75 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Weinamphore](/weinamphore-ligurix.md "Weinamphore/Ligurix") mit [Bordeaux](/bordeaux-ligurix.md "Bordeaux/Ligurix") | 90 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Weinamphore](/weinamphore-ligurix.md "Weinamphore/Ligurix") mit [Emile](/emile.md "Emile") | 100 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Weinamphore](/weinamphore-ligurix.md "Weinamphore/Ligurix") mit [Hautumwienix](/hautumwienix.md "Hautumwienix") | 120 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ![Angebot-bl.gif](/images/3/3b/Angebot-bl.gif) |  | ![Angebot-br.gif](/images/9/92/Angebot-br.gif) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Gallien
- Rasse: Mensch
- Tätigkeit: Verkäufer
- Gegenstand: Sorte:

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Ligurix)
