---
type: Wiki Article
title: Bauigelcafete
description: ""
resource: "http://unitopia.intelligense.de/wiki/Bauigelcafete"
tags: []
timestamp: 2021-07-28T12:50:06Z
revid: 102672
namespace: 0
contenthash: 77d93c823f2e257bfc52d5e5dca64720d9fd71613f2d6f04328a3864234becf1
---

1.  WEITERLEITUNG [Campusgelände#Bauigelcafete](/campusgelände.md "Campusgelände")

* * *

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Bauigelcafete)
