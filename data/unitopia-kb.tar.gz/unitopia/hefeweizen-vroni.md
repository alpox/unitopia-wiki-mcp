---
type: Wiki Article
title: Hefeweizen/Vroni
description: "Zu kaufen bei Vroni im Gasthaus \"Zum erschossenen Wilderer\" in Dvaergen."
resource: "http://unitopia.intelligense.de/wiki/Hefeweizen/Vroni"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/betrunken, Info/Wirkung/durstlöschend, "Info/Wirkung/gibt 1-5 AP", "Info/Wirkung/gibt 1-5 ZP", Nahrung, Nahrung/Alkohol, Nahrung/Midgard, Nahrung/Midgard/Alkohol]
timestamp: 2024-08-29T15:14:41Z
revid: 244924
namespace: 0
contenthash: 02b65011731dfc3551173aed669a0344d35b4c81860d60d5283b6504199c3255
---

## Aussehen

Zwar kein blondes Bier, aber dafuer sehr durststillend und mit hohem
Alkoholgehalt.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend"), [betrunken](/kategorie/info-wirkung-betrunken.md "Kategorie:Info/Wirkung/betrunken"), gibt 5 ZP wenn AP voll |

## Fundort

Zu kaufen bei [Vroni](/vroni.md "Vroni") im Gasthaus "Zum erschossenen Wilderer" in [Dvaergen](/dvaergen.md "Dvaergen").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Alkohol
- Gegend: Midgard
- Gewicht: 1
- Wirkung: durstlöschend/betrunken/gibt 5 ZP wenn AP voll

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Hefeweizen/Vroni)
