---
type: Wiki Article
title: Gunda
description: Schlittschuhe.
resource: "http://unitopia.intelligense.de/wiki/Gunda"
tags: [NPC, NPC/Gallien, NPC/Gallien/defensiv, NPC/defensiv, Rasse, Rasse/Mensch]
timestamp: 2018-11-07T18:30:27Z
revid: 257501
namespace: 0
contenthash: 31a510e214bf6052a3a84ec020e48bea9137ae8d174fcf4348147857561d31e8
---

## Aussehen

Gunda Niemann traegt einen hautengen Rennanzug. In der typischen, stark
vornuebergeneigten Haltung rast sie kraftvoll ueber die Bahn, auf der Jagd
nach einem neuen Weltrekord. Dabei solltest du ihr besser nicht in die
Quere kommen!

## Ausrüstung

[Schlittschuhe](/schlittschuhe.md "Schlittschuhe").

## Heimat

Im Aufenthaltsraum der Eiskunstläufer der [Eisbahn](/eisbahn.md "Eisbahn") in den [Gallischen Alpen](/alpen.md "Alpen").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Gallien
- Rasse: Mensch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Gunda)
