---
type: Wiki Article
title: Lederhose/Kleptopoulos
description: Rüstung von Kleptopoulos Nachts auf dem Platz der Hehler in Knossos auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/Lederhose/Kleptopoulos"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Leder, Info/Rüstungsstärke, Info/Rüstungsstärke/geht so, Info/Rüstungszustand, Info/Rüstungszustand/extrem solide, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Rüstung, Rüstung/Beine, Rüstung/Kokosinseln, Rüstung/Kokosinseln/Beine]
timestamp: 2024-03-02T19:19:07Z
revid: 228651
namespace: 0
contenthash: 2174d66974d332b10c07d98f943af6b290c6552b0c0dc4a87419e1f09e9f5e3a
---

## Aussehen

Eine Hose aus dickem Leder. Man sagt, dass die Skythen solche Hosen tragen,
aber wie auch immer dem sei, sie sieht gut kampfgeeignet aus.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [3 (geht so)](/kategorie/info-rüstungsstärke-geht-so.md "Kategorie:Info/Rüstungsstärke/geht so") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [9 (extrem solide)](/kategorie/info-rüstungszustand-extrem-solide.md "Kategorie:Info/Rüstungszustand/extrem solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Rüstung von [Kleptopoulos](/kleptopoulos.md "Kleptopoulos") Nachts auf dem Platz der Hehler in [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").

* * *


## Kenndaten

- Kategorie: Rüstung
- Typ: Beine
- Gegend: Kokosinseln
- Material: Leder
- Temperaturschutz: wärmt etwas
- Rüstungsstärke: geht so
- Rüstungszustand: extrem solide
- Gewicht: 2
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Lederhose/Kleptopoulos)
