---
type: Wiki Article
title: Henriette
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Henriette"
tags: [Angebot, NPC, NPC/Vaniorh, NPC/Vaniorh/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Gastwirt]
timestamp: 2022-04-25T21:07:48Z
revid: 264306
namespace: 0
contenthash: 53b7bbce456c26a4a452a35a7f341735c4e6eeebc6c7e69b3be57c6d6c6c705b
---

## Aussehen

Henriette kuemmert sich um das Wohlergehen der Gaeste. Ihr Haupt wird von
einem kleinen Haeubchen gekroent. Dazu traegt sie eine schneeweisse
Schuerze mit Spitze an den Saeumen.
Ihrer umgaenglichen Art ist es zu verdanken, dass das Theatercaf
praechtig floriert und dadurch in der Lage ist, das staendig
konkursgefaehrdete Theater finanziell zu unterstuetzen.
Ihr fragendes Laecheln signalisiert, dass sie auf Deine Bestellung wartet.
Der Speisekarte kannst Du das abwechslungsreiche und sich staendig
aendernde Angebot an erlesenen Spezialitaeten entnehmen.

## Ausrüstung

Keine.

## Heimat

Im Theatercafé des [Theaters](/theater.md "Theater") von [Tadmor](/tadmor.md "Tadmor").

## Angebot

Je nach Tageszeit gibt es eine Frühstückskarte, eine Tageskarte, eine Abendkarte und immer wieder eine andere Auswahl an Gerichten.

| ![Angebot-tl.gif](/images/d/db/Angebot-tl.gif) | Speisekarte | ![Angebot-tr.gif](/images/5/52/Angebot-tr.gif) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | \| **Getränk::** \| **[Taler](/währung.md "Währung")**: \| \| --- \| --- \| \| Ein [Mineralwasser](/mineralwasser-henriette.md "Mineralwasser/Henriette") \| 5 \| \| Ein [Tee](/tee-henriette.md "Tee/Henriette") \| 5 \| \| Ein [Tasse Kaffee](/kaffee-henriette.md "Kaffee/Henriette") \| 5 \| \| Eine [heiße Schokolade](/schokolade-henriette.md "Schokolade/Henriette") \| 10 \| \| Ein [Grapefruitsaft](/grapefruitsaft-henriette.md "Grapefruitsaft/Henriette") \| 10 \| \| Ein [Borsippaner-Quell](/borsippaner-quell.md "Borsippaner-Quell") \| 15 \| \| Ein [Energiedrink](/energiegetränk.md "Energiegetränk") \| 25 \| \|  \|  \| \| **Vorspeise:** \|  \| \| Eine [Brunnenkressesuppe](/brunnenkressesuppe.md "Brunnenkressesuppe") \| 40 \| \| Eine [Suppe de la Suppe'](/suppe-henriette.md "Suppe/Henriette") \| 50 \| \| Eine [Hühnerconsomme](/hühnerconsomme.md "Hühnerconsomme") \| 50 \| \| Eine [Kartoffelsuppe](/kartoffelsuppe-henriette.md "Kartoffelsuppe/Henriette") \| 80 \| \|  \|  \| \| **Wein:** \|  \| \| Ein [28er Riesling](/riesling-henriette.md "Riesling/Henriette") \| 20 \| \| Ein [Veltliner](/veltliner.md "Veltliner") \| 20 \| \| Ein [Petitbonum](/rotwein-henriette.md "Rotwein/Henriette") \| 25 \| \| Ein [Champagner](/champagner-henriette.md "Champagner/Henriette") \| 30 \| | **Getränk::** | **[Taler](/währung.md "Währung")**: | Ein [Mineralwasser](/mineralwasser-henriette.md "Mineralwasser/Henriette") | 5 | Ein [Tee](/tee-henriette.md "Tee/Henriette") | 5 | Ein [Tasse Kaffee](/kaffee-henriette.md "Kaffee/Henriette") | 5 | Eine [heiße Schokolade](/schokolade-henriette.md "Schokolade/Henriette") | 10 | Ein [Grapefruitsaft](/grapefruitsaft-henriette.md "Grapefruitsaft/Henriette") | 10 | Ein [Borsippaner-Quell](/borsippaner-quell.md "Borsippaner-Quell") | 15 | Ein [Energiedrink](/energiegetränk.md "Energiegetränk") | 25 |  |  | **Vorspeise:** |  | Eine [Brunnenkressesuppe](/brunnenkressesuppe.md "Brunnenkressesuppe") | 40 | Eine [Suppe de la Suppe'](/suppe-henriette.md "Suppe/Henriette") | 50 | Eine [Hühnerconsomme](/hühnerconsomme.md "Hühnerconsomme") | 50 | Eine [Kartoffelsuppe](/kartoffelsuppe-henriette.md "Kartoffelsuppe/Henriette") | 80 |  |  | **Wein:** |  | Ein [28er Riesling](/riesling-henriette.md "Riesling/Henriette") | 20 | Ein [Veltliner](/veltliner.md "Veltliner") | 20 | Ein [Petitbonum](/rotwein-henriette.md "Rotwein/Henriette") | 25 | Ein [Champagner](/champagner-henriette.md "Champagner/Henriette") | 30 |  |
| **Getränk::** | **[Taler](/währung.md "Währung")**: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Mineralwasser](/mineralwasser-henriette.md "Mineralwasser/Henriette") | 5 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Tee](/tee-henriette.md "Tee/Henriette") | 5 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Tasse Kaffee](/kaffee-henriette.md "Kaffee/Henriette") | 5 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [heiße Schokolade](/schokolade-henriette.md "Schokolade/Henriette") | 10 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Grapefruitsaft](/grapefruitsaft-henriette.md "Grapefruitsaft/Henriette") | 10 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Borsippaner-Quell](/borsippaner-quell.md "Borsippaner-Quell") | 15 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Energiedrink](/energiegetränk.md "Energiegetränk") | 25 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| **Vorspeise:** |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Brunnenkressesuppe](/brunnenkressesuppe.md "Brunnenkressesuppe") | 40 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Suppe de la Suppe'](/suppe-henriette.md "Suppe/Henriette") | 50 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Hühnerconsomme](/hühnerconsomme.md "Hühnerconsomme") | 50 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Kartoffelsuppe](/kartoffelsuppe-henriette.md "Kartoffelsuppe/Henriette") | 80 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| **Wein:** |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [28er Riesling](/riesling-henriette.md "Riesling/Henriette") | 20 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Veltliner](/veltliner.md "Veltliner") | 20 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Petitbonum](/rotwein-henriette.md "Rotwein/Henriette") | 25 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Champagner](/champagner-henriette.md "Champagner/Henriette") | 30 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ![Angebot-bl.gif](/images/3/3b/Angebot-bl.gif) |  | ![Angebot-br.gif](/images/9/92/Angebot-br.gif) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

| ![Angebot-tl.gif](/images/d/db/Angebot-tl.gif) | Speisekarte | ![Angebot-tr.gif](/images/5/52/Angebot-tr.gif) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | \| **Speise::** \| **[Taler](/währung.md "Währung")**: \| \| --- \| --- \| \| Ein [Tafelspitz](/tafelspitz.md "Tafelspitz") \| 80 \| \| Ein [Omelett mit Champignons](/omelett-henriette.md "Omelett/Henriette") \| 90 \| \| Eine [Forelle blau](/forelle-henriette.md "Forelle/Henriette") \| 100 \| \| Ein [Risotto 'Camorra'](/risotto.md "Risotto") \| 110 \| \| Ein [Sauerbraten](/sauerbraten-henriette.md "Sauerbraten/Henriette") \| 140 \| \| Ein [Gallischer Hummer](/hummer-henriette.md "Hummer/Henriette") \| 200 \| \|  \|  \| \| **Spirituose:** \|  \| \| Ein [Gin](/gin.md "Gin") \| 25 \| \| Ein [Rum](/rum-henriette.md "Rum/Henriette") \| 25 \| \| Ein [Cocktail](/indigo.md "Indigo") \| 40 \| \| Ein [Whisky](/whisky-henriette.md "Whisky/Henriette") \| 100 \| \|  \|  \| \| **Dessert:** \|  \| \| Ein [Marillenknödel](/marillenknödel.md "Marillenknödel") \| 40 \| \| Eine [Aprikosentorte](/aprikosentorte.md "Aprikosentorte") \| 40 \| \| Eine [Schokoladenekstase](/schoko-ekstase.md "Schoko-Ekstase") \| 50 \| \| Ein [Schälchen Obstsalat](/obstsalat-henriette.md "Obstsalat/Henriette") \| 50 \| \| Ein [Eisbecher Othello](/eisbecher-henriette.md "Eisbecher/Henriette") \| 70 \| | **Speise::** | **[Taler](/währung.md "Währung")**: | Ein [Tafelspitz](/tafelspitz.md "Tafelspitz") | 80 | Ein [Omelett mit Champignons](/omelett-henriette.md "Omelett/Henriette") | 90 | Eine [Forelle blau](/forelle-henriette.md "Forelle/Henriette") | 100 | Ein [Risotto 'Camorra'](/risotto.md "Risotto") | 110 | Ein [Sauerbraten](/sauerbraten-henriette.md "Sauerbraten/Henriette") | 140 | Ein [Gallischer Hummer](/hummer-henriette.md "Hummer/Henriette") | 200 |  |  | **Spirituose:** |  | Ein [Gin](/gin.md "Gin") | 25 | Ein [Rum](/rum-henriette.md "Rum/Henriette") | 25 | Ein [Cocktail](/indigo.md "Indigo") | 40 | Ein [Whisky](/whisky-henriette.md "Whisky/Henriette") | 100 |  |  | **Dessert:** |  | Ein [Marillenknödel](/marillenknödel.md "Marillenknödel") | 40 | Eine [Aprikosentorte](/aprikosentorte.md "Aprikosentorte") | 40 | Eine [Schokoladenekstase](/schoko-ekstase.md "Schoko-Ekstase") | 50 | Ein [Schälchen Obstsalat](/obstsalat-henriette.md "Obstsalat/Henriette") | 50 | Ein [Eisbecher Othello](/eisbecher-henriette.md "Eisbecher/Henriette") | 70 |  |
| **Speise::** | **[Taler](/währung.md "Währung")**: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Tafelspitz](/tafelspitz.md "Tafelspitz") | 80 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Omelett mit Champignons](/omelett-henriette.md "Omelett/Henriette") | 90 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Forelle blau](/forelle-henriette.md "Forelle/Henriette") | 100 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Risotto 'Camorra'](/risotto.md "Risotto") | 110 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Sauerbraten](/sauerbraten-henriette.md "Sauerbraten/Henriette") | 140 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Gallischer Hummer](/hummer-henriette.md "Hummer/Henriette") | 200 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| **Spirituose:** |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Gin](/gin.md "Gin") | 25 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Rum](/rum-henriette.md "Rum/Henriette") | 25 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Cocktail](/indigo.md "Indigo") | 40 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Whisky](/whisky-henriette.md "Whisky/Henriette") | 100 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| **Dessert:** |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Marillenknödel](/marillenknödel.md "Marillenknödel") | 40 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Aprikosentorte](/aprikosentorte.md "Aprikosentorte") | 40 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Schokoladenekstase](/schoko-ekstase.md "Schoko-Ekstase") | 50 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Schälchen Obstsalat](/obstsalat-henriette.md "Obstsalat/Henriette") | 50 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Eisbecher Othello](/eisbecher-henriette.md "Eisbecher/Henriette") | 70 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ![Angebot-bl.gif](/images/3/3b/Angebot-bl.gif) |  | ![Angebot-br.gif](/images/9/92/Angebot-br.gif) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Vaniorh
- Rasse: Mensch
- Tätigkeit: Gastwirt
- Float: floatleft
- Gegenstand: Getränk:

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Henriette)
