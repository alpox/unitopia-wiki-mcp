---
type: Wiki Article
title: Butterkuchen/Wollmilchsauei
description: Aus dem Ei der Wollmilchsau im Stall des Bauernhofes von Phexcaer auf Thule.
resource: "http://unitopia.intelligense.de/wiki/Butterkuchen/Wollmilchsauei"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Nordische Inseln, Nahrung/Nordische Inseln/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:13:27Z
revid: 221561
namespace: 0
contenthash: 5da86f0ba18d178a0691063654d3696f8e36e496a17ee2ab2452f6da597b1bb2
---

## Aussehen

Ein ganz normaler, wunderbar duftender, goldgelber Butterkuchen. Es wuerde
wohl kaum jemand glauben, dass der nur aus einem Wollmilchsauei und sonst
gar nichts gemacht wurde.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Aus dem [Ei](/wollmilchsauei.md "Wollmilchsauei") der [Wollmilchsau](/wollmilchsau.md "Wollmilchsau") im Stall des [Bauernhofes](/phexcaer.md "Phexcaer") von [Phexcaer](/phexcaer.md "Phexcaer") auf [Thule](/thule.md "Thule").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Nordische Inseln
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Butterkuchen/Wollmilchsauei)
