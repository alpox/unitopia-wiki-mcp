---
type: Wiki Article
title: Russbedeckt/rituell
description: Von einem Mitglied vom Orden der Finsternis.
resource: "http://unitopia.intelligense.de/wiki/Russbedeckt/rituell"
tags: [Fundort, Info, Info/Heilung, Info/Wirkung, Info/Wirkung/Zustand, Info/Wirkung/Zustand/neutral, Zustand, Zustand/Sonstige, Zustand/Vaniorh, Zustand/Vaniorh/Sonstige]
timestamp: 2024-09-16T12:10:08Z
revid: 267952
namespace: 0
contenthash: 158290d9a2e7f60333ca6e50feddd0c2c151b0b42c72807619cb8d29971b9d0a
---

## Aussehen

Du bist ueber und ueber bedeckt mit schwarzem Russ durchsetzt mit winzigen,
oktarinen Partikeln. Du solltest dich echt mal waschen!

## Informationen

| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [neutral](/kategorie/info-wirkung-zustand-neutral.md "Kategorie:Info/Wirkung/Zustand/neutral") |
| --- | --- |
| **[Heilung](/kategorie/info-heilung.md "Kategorie:Info/Heilung"):** | waschen, automatisch |

## Fundort

Von einem Mitglied vom [Orden der Finsternis](/orden-der-finsternis.md "Orden der Finsternis").

## Besonderheit

-   Durch die oktarinen Partikel im Russ wird man sichtbar und daran gehindert, wieder unsichtbar zu werden.
-   Dies ist die Folge, wenn eine rituelle Feuerstelle explodiert. Ein Beschwörer kann aber auch eine normale Feuerstelle errichten und diese zur Explosion bringen. Alle Anwesenden sind dann anders [russbedeckt](/russbedeckt-normal.md "Russbedeckt/normal").

## Gefährlichkeit

-   Hält ca. 60 Minuten an.
-   Startmeldung:

Die rituelle Feuerstelle explodiert ploetzlich mit einem lauten Knall.

-   Endmeldung:

Die schwarze Schicht aus Russ, die dich umhuellt, faellt ab.

* * *


## Kenndaten

- Kategorie: Zustand
- Typ: Sonstige
- Gegend: Vaniorh
- Wirkung: neutral
- Heilung: waschen/automatisch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Russbedeckt/rituell)
