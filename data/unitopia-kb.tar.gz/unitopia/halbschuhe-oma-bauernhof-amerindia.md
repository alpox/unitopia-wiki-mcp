---
type: Wiki Article
title: Halbschuhe/Oma/Bauernhof/Amerindia
description: Kleidung von Oma Helen in der Küche auf dem Bauernhof auf Amerindia.
resource: "http://unitopia.intelligense.de/wiki/Halbschuhe/Oma/Bauernhof/Amerindia"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Leder, Kleidung, Kleidung/Ebenen, Kleidung/Ebenen/Füße, Kleidung/Füße]
timestamp: 2024-03-02T19:21:11Z
revid: 251266
namespace: 0
contenthash: 652696159106643c2bfd78e8f2405b693aa7e79ddd95d8a10287921adece7649
---

## Aussehen

Weisse Halbschuhe aus Hirschleder. Die Sohlen haben ein geriffeltes Profil
und sorgen fuer besonders gute Standfestigkeit auch auf rutschigem
Untergrund.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Kleidung von [Oma Helen](/oma-bauernhof-amerindia.md "Oma/Bauernhof/Amerindia") in der Küche auf dem [Bauernhof](/amerindia.md "Amerindia") auf [Amerindia](/amerindia.md "Amerindia").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Füße
- Gegend: Ebenen
- Material: Leder
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Halbschuhe/Oma/Bauernhof/Amerindia)
