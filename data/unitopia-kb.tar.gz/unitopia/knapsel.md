---
type: Wiki Article
title: Knapsel
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Knapsel"
tags: [Angebot, NPC, NPC/Märchenland, NPC/Märchenland/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Verkäufer]
timestamp: 2022-04-25T21:07:54Z
revid: 216218
namespace: 0
contenthash: 7818c5525d5f702ebf4574901b2bc61392587f3f4860bdcf201b8152de461bc2
---

## Aussehen

Ein ziemlich duenner Verkaeufer, dessen Haut von der Sonne gegerbt
wurde.

## Ausrüstung

Keine.

## Heimat

Im Zwiebackhaus von [Rumsrüttelkoge](/rumsrüttelkoge.md "Rumsrüttelkoge").

## Angebot

| ![Angebot-tl.gif](/images/d/db/Angebot-tl.gif) | Zwiebackverkauf | ![Angebot-tr.gif](/images/5/52/Angebot-tr.gif) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | \| **Speise::** \| **[Taler](/währung.md "Währung")**: \| \| --- \| --- \| \| Eine [Zwiebackscheibe](/zwieback-knapsel.md "Zwieback/Knapsel") \| 30 \| \| Ein [Kokoszwieback](/kokoszwieback.md "Kokoszwieback") \| 30 \| \| Ein [Schokozwieback](/schokozwieback.md "Schokozwieback") \| 30 \| \| Ein [Vollkornzwieback](/vollkornzwieback.md "Vollkornzwieback") \| 30 \| \| Eine [Tüte voller Mixzwieback](/zwiebacktüte.md "Zwiebacktüte") \| 150 \| \| Eine [große Menge Schiffszwieback](/zwieback-knapsel2.md "Zwieback/Knapsel2") \| 250 \| | **Speise::** | **[Taler](/währung.md "Währung")**: | Eine [Zwiebackscheibe](/zwieback-knapsel.md "Zwieback/Knapsel") | 30 | Ein [Kokoszwieback](/kokoszwieback.md "Kokoszwieback") | 30 | Ein [Schokozwieback](/schokozwieback.md "Schokozwieback") | 30 | Ein [Vollkornzwieback](/vollkornzwieback.md "Vollkornzwieback") | 30 | Eine [Tüte voller Mixzwieback](/zwiebacktüte.md "Zwiebacktüte") | 150 | Eine [große Menge Schiffszwieback](/zwieback-knapsel2.md "Zwieback/Knapsel2") | 250 |  |
| **Speise::** | **[Taler](/währung.md "Währung")**: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Zwiebackscheibe](/zwieback-knapsel.md "Zwieback/Knapsel") | 30 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Kokoszwieback](/kokoszwieback.md "Kokoszwieback") | 30 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Schokozwieback](/schokozwieback.md "Schokozwieback") | 30 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Ein [Vollkornzwieback](/vollkornzwieback.md "Vollkornzwieback") | 30 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [Tüte voller Mixzwieback](/zwiebacktüte.md "Zwiebacktüte") | 150 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Eine [große Menge Schiffszwieback](/zwieback-knapsel2.md "Zwieback/Knapsel2") | 250 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ![Angebot-bl.gif](/images/3/3b/Angebot-bl.gif) |  | ![Angebot-br.gif](/images/9/92/Angebot-br.gif) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Märchenland
- Rasse: Mensch
- Tätigkeit: Verkäufer
- Gegenstand: Speise:

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Knapsel)
