---
type: Wiki Article
title: Badeanzug/Arthuro
description: "Zu kaufen bei Arthuro im Surfladen der Stratos-Arkaden auf Stratos."
resource: "http://unitopia.intelligense.de/wiki/Badeanzug/Arthuro"
tags: [Fundort/Kauf, Hidden, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Kleidung, Kleidung/Brust, Kleidung/Kokosinseln, Kleidung/Kokosinseln/Brust, ZusatzAussehen, ZusatzAussehen/Frau]
timestamp: 2024-04-23T19:27:42Z
revid: 261576
namespace: 0
contenthash: 1155b682afd140038c28e38e1e207014ec7b0c6c2b5b0a9cf06c00e61dd3a0e9
---

## Aussehen

Ein smaragdgruener Badeanzug, dessen schimmernde Wetlook-Oberflaeche ganz
von alleine schon nass aussieht. Er besteht aus anschmiegsamen Material in
einer schlanken, traegerlosen Passform. Sehr hohe Beinauschnitte runden das
Bild ab. An einer Naht auf der Innenseite ist ein winziges Zettelchen
befestigt.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Arthuro](/arthuro.md "Arthuro") im Surfladen der [Stratos-Arkaden](/stratos-arkaden.md "Stratos-Arkaden") auf [Stratos](/stratos.md "Stratos").

## Besonderheit

Zusätzliches Aussehen beim Betrachten einer Person:

| **Frau:** | Sie traegt einen smaragdgruenen Badeanzug, der ihre perfekten Kurven unterstreicht und sie sehr sportlich aussehen laesst. |
| --- | --- |

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Brust
- Gegend: Kokosinseln
- Material: Textil
- Temperaturschutz: wärmt etwas
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Badeanzug/Arthuro)
