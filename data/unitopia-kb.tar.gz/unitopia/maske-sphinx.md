---
type: Wiki Article
title: Maske/Sphinx
description: ""
resource: "http://unitopia.intelligense.de/wiki/Maske/Sphinx"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Kleidung, Kleidung/Dörrland, Kleidung/Dörrland/Kopf, Kleidung/Kopf]
timestamp: 2024-03-02T19:17:46Z
revid: 257352
namespace: 0
contenthash: 9d8607ba5cb6bd4b5c0a19d95cc0711d4a74f00d8d42cdf9a63529ed22aa61a7
---

## Aussehen

Eine Maske, wie sie Waechter zu tragen pflegen. Sie hat kleine Sehschlitze
und eine Mundoeffnung.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Kleidung von [Garseh](/garseh.md "Garseh") auf dem schmalen Pfad auf der linken Seite der [Sphinx](/sphinx-dörrland.md "Sphinx/Dörrland") in [Südostdörrland](/südostdörrland.md "Südostdörrland").
-   Kleidung von [Giseh](/giseh.md "Giseh") auf dem schmalen Pfad auf der rechten Seite der [Sphinx](/sphinx-dörrland.md "Sphinx/Dörrland") in [Südostdörrland](/südostdörrland.md "Südostdörrland").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Kopf
- Gegend: Dörrland
- Material: Textil
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Maske/Sphinx)
