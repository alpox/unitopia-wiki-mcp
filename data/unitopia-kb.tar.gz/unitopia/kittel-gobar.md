---
type: Wiki Article
title: Kittel/Gobar
description: Kleidung von Gobar im Garten von Iljanas Villa in Borsippa.
resource: "http://unitopia.intelligense.de/wiki/Kittel/Gobar"
tags: [Hidden, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Kleidung, Kleidung/Brust, Kleidung/Vaniorh, Kleidung/Vaniorh/Brust, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2024-03-02T19:19:32Z
revid: 261719
namespace: 0
contenthash: 916814333bb3a2b4b0134971a305dd8296affa3c84dbf277c351c48156e7a6e7
---

## Aussehen

Dieser Kittel gehoert Gobar, der eine Anstellung als Gaertner in Borsippa
gefunden hat. Er hat eine gruene Farbe und ist teilweise mit bunten
Pflanzenteilen und kleinen gruenen Blaettern bedeckt.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Kleidung von [Gobar](/gobar.md "Gobar") im Garten von [Iljanas Villa](/iljanas-villa.md "Iljanas Villa") in [Borsippa](/borsippa.md "Borsippa").

## Besonderheit

Zusätzliches Aussehen beim Betrachten einer Person:

| -   **Mann:** | Er raegt einen gruenen Kittel ueber einem karierten Hemd. |
| --- | --- |
| -   **Frau:** | Sie raegt einen gruenen Kittel ueber einem karierten Hemd. |
| -   **Etwas:** | Es traegt einen gruenen Kittel ueber einem karierten Hemd. |

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Brust
- Gegend: Vaniorh
- Material: Textil
- Temperaturschutz: wärmt etwas
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein
- Mann: Er raegt einen gruenen Kittel ueber einem karierten Hemd.
- Frau: Sie raegt einen gruenen Kittel ueber einem karierten Hemd.
- Etwas: Es traegt einen gruenen Kittel ueber einem karierten Hemd.

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Kittel/Gobar)
