---
type: Wiki Article
title: Lederwams/Piratenjoe
description: Rüstung von Piratenjoe im Wachposten auf Tobago.
resource: "http://unitopia.intelligense.de/wiki/Lederwams/Piratenjoe"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/3, Info/Material, Info/Material/Leder, Info/Rüstungsstärke, Info/Rüstungsstärke/gut, Info/Rüstungszustand, Info/Rüstungszustand/solide, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Rüstung, Rüstung/Brust, Rüstung/Midgard, Rüstung/Midgard/Brust]
timestamp: 2024-03-02T19:17:53Z
revid: 227669
namespace: 0
contenthash: ec73336b79df7ad728c334dae3c728f1273a4974c1f9cc5526f8b1f7397424b3
---

## Aussehen

Das Lederwams ist sowas wie eine Weste, nur schoen dick und stabil. Auf die
Art und Weise kann man sich ein wenig vor laestigen Zahnstochern schuetzen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [4 (gut)](/kategorie/info-rüstungsstärke-gut.md "Kategorie:Info/Rüstungsstärke/gut") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [6 (solide)](/kategorie/info-rüstungszustand-solide.md "Kategorie:Info/Rüstungszustand/solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [3 (schon eher leicht)](/kategorie/info-gewicht-3.md "Kategorie:Info/Gewicht/3") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Rüstung von [Piratenjoe](/piratenjoe.md "Piratenjoe") im Wachposten auf [Tobago](/tobago.md "Tobago").

* * *


## Kenndaten

- Kategorie: Rüstung
- Typ: Brust
- Gegend: Midgard
- Material: Leder
- Temperaturschutz: wärmt etwas
- Rüstungsstärke: gut
- Rüstungszustand: solide
- Gewicht: 3
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Lederwams/Piratenjoe)
