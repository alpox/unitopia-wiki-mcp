---
type: Wiki Article
title: Schnuppi
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Schnuppi"
tags: [NPC, NPC/Märchenland, NPC/Märchenland/defensiv, NPC/defensiv, Rasse, Rasse/Säugetier]
timestamp: 2018-11-07T18:28:22Z
revid: 212033
namespace: 0
contenthash: 1f23b49d0a400c88527d6d30bf0b5e65efb8b3818330899c4147c78f886456b0
---

## Aussehen

Eines dieser zotteligen Wesen, bei denen man nicht genau weiss, wo vorne
und hinten ist. Er hat sich hierher verlaufen und ist sesshaft geworden, da
ihm Passanten etwas zu essen geben. Dank seiner guten Nase kann er die
Duftspur von vor kurzem vorbei gelaufenen Personen verfolgen. Seine
Lieblingsbeschaeftigung ist es deswegen, nach Personen zu suchen.

## Ausrüstung

Keine.

## Heimat

Im [Tierpark](/tierpark.md "Tierpark") von [Koboldingen](/koboldingen.md "Koboldingen").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Märchenland
- Rasse: Säugetier

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schnuppi)
