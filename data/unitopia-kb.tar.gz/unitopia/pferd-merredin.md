---
type: Wiki Article
title: Pferd/Merredin
description: Eines der edlen Reitpferde der Boten von Soederland. Es ist wohlgenährt und hat ein glänzendes Fell. Seine Vorfahren kamen sicherlich einmal von den grünen Wiesen Wessenachs.
resource: "http://unitopia.intelligense.de/wiki/Pferd/Merredin"
tags: [Adjektiv, NPC, NPC/Midgard, NPC/Midgard/defensiv, NPC/defensiv, Rasse, Rasse/Säugetier, Tätigkeit, Tätigkeit/Reittier]
timestamp: 2018-11-07T18:42:11Z
revid: 251031
namespace: 0
contenthash: fd051b32c1f9fc8f7a60c68cd309240562f5c81d5f7e32ba1b9debec2a773bcf
---

## Aussehen

Eines der edlen Reitpferde der Boten von Soederland. Es ist wohlgenährt  
und hat ein glänzendes Fell. Seine Vorfahren kamen sicherlich einmal von  
den grünen Wiesen Wessenachs.

## Ausrüstung

Keine.

## Heimat

Auf einer Pferdekoppel im [Merreland](/merreland.md "Merreland") von [Merredin](/merredin.md "Merredin").

## Besonderheit

Das edle Pferd gehört zu den Säugetieren, die ständig wechselnde Adjektive haben. Diese werden hier nicht gesondert aufgelistet.

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Midgard
- Rasse: Säugetier
- Tätigkeit: Reittier

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Pferd/Merredin)
