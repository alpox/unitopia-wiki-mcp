---
type: Wiki Article
title: "Sigma-Algebra"
description: In der Mathegilde von Ephesos auf Phrygia.
resource: "http://unitopia.intelligense.de/wiki/Sigma-Algebra"
tags: [Gegenstand, Gegenstand/Kokosinseln, Gegenstand/Kokosinseln/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/5, Info/Material, Info/Material/Unbekannt]
timestamp: 2024-03-02T19:17:35Z
revid: 249442
namespace: 0
contenthash: 269d280642f08fbdd6a4e6484c56bf2ff609f7b5c598c6e6a0dfa80eaf0fe5be
---

## Aussehen

Eine Sigma-Algebra. Sie ist abgeschlossen bezueglich Komplementbildung und
abzaehlbaren Vereinigungen. Des Weiteren enthaelt sie die leere Menge (und
den Gesamtraum).

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Unbekannt](/kategorie/info-material-unbekannt.md "Kategorie:Info/Material/Unbekannt") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [5 (ein klein wenig schwer)](/kategorie/info-gewicht-5.md "Kategorie:Info/Gewicht/5") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

In der [Mathegilde](/mathegilde.md "Mathegilde") von [Ephesos](/ephesos.md "Ephesos") auf [Phrygia](/phrygia.md "Phrygia").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Kokosinseln
- Material: Unbekannt
- Gewicht: 5
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Sigma-Algebra)
