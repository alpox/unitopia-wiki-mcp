---
type: Wiki Article
title: Eiswaffel/Vanille
description: Zu kaufen bei Hans auf dem Campusgelände der Universität Stuttgart.
resource: "http://unitopia.intelligense.de/wiki/Eiswaffel/Vanille"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Campus, Nahrung/Campus/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:15:27Z
revid: 231941
namespace: 0
contenthash: bc0c773dd932eef71c9bde747e8276a2d15feb3cf18be07c14cb780fbfcda96d
---

## Aussehen

Eine unheimlich leckere Eiswaffel mit einer gelblich-weissen Eiskugel mit
kleinen schwarzen Punkten.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Zu kaufen bei [Hans](/hans-campus.md "Hans/Campus") auf dem [Campusgelände](/campusgelände.md "Campusgelände") der [Universität Stuttgart](/universität.md "Universität").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Campus
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Eiswaffel/Vanille)
