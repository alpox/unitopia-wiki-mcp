---
type: Wiki Article
title: Trauerweide/Thule
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Trauerweide/Thule"
tags: [NPC, NPC/Nordische Inseln, NPC/Nordische Inseln/aggressiv, NPC/aggressiv, Rasse, Rasse/Pflanze]
timestamp: 2018-11-07T18:31:10Z
revid: 212485
namespace: 0
contenthash: 77d06774361255b6f5a5b761f708c59ed7867adfada9cf8b541e4d0613f77aee
---

## Aussehen

Die Trauerweide erhebt sich vor Dir wie ein Riese. Ihre gewaltige Äste
sehen aus wie die bedrohlichen Klauen eines Ungeheuers, welches Dich damit
zerreissen will. Du fuehlst Dich richtig winzig und hilflos in Gegenwart
dieses unheimlichen Baumes.

## Ausrüstung

Keine.

## Heimat

Mitten im [Moor](/thule-moor.md "Thule/Moor") auf [Thule](/thule.md "Thule").

* * *


## Kenndaten

- Typ: aggressiv
- Gegend: Nordische Inseln
- Rasse: Pflanze

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Trauerweide/Thule)
