---
type: Wiki Article
title: Morpho
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Morpho"
tags: [NPC, NPC/Kokosinseln, NPC/Kokosinseln/defensiv, NPC/defensiv, Rasse, Rasse/Insekt]
timestamp: 2019-04-23T13:14:08Z
revid: 262454
namespace: 0
contenthash: eb7a356fb0b001d77c8a3f999e1184b26d9d16997f7b30798ba9d4a9c97ae8ef
---

## Aussehen

Ein blauer Morpho, mit metallisch glaenzenden blauen Fluegeln. Wie alle
Insekten hat er sechs Beine und grosse Facettenaugen. Dazu kommen dann noch
zwei lange Fuehler und ein eingerollter Saugruessel.

## Ausrüstung

Keine.

## Heimat

Im Dschungel auf der [Dschungelinsel](/dschungelinsel.md "Dschungelinsel").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Kokosinseln
- Rasse: Insekt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Morpho)
