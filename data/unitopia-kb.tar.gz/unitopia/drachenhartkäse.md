---
type: Wiki Article
title: Drachenhartkäse
description: Zu kaufen bei Perin im Käseladen von Nankea (Stadt) auf Nankea.
resource: "http://unitopia.intelligense.de/wiki/Drachenhartkäse"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Midgard, Nahrung/Midgard/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:16:25Z
revid: 222123
namespace: 0
contenthash: f0b0be2dac6d0b21418b7055d53e91abbb04ba6a301414fcefb504081b0198d6
---

## Aussehen

Den Drachenhartkaese hat Perin zu Ehren der Stadt Nankea entwickelt. Er
reift 8 Monate lang und wird in dieser Zeit immer wieder mit einer Mischung
aus Kraeutern und Rotwein bestrichen, die ihm ein einzigartiges Aroma
verleiht.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Zu kaufen bei [Perin](/perin.md "Perin") im Käseladen von [Nankea (Stadt)](/nankea-\(stadt\).md "Nankea (Stadt)") auf [Nankea](/nankea.md "Nankea").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Midgard
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Drachenhartkäse)
