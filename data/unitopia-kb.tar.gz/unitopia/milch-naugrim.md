---
type: Wiki Article
title: Milch/Naugrim
description: Zu kaufen bei Naugrim im NAUGRIMS INN in Dvaergen.
resource: "http://unitopia.intelligense.de/wiki/Milch/Naugrim"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/durstlöschend, Nahrung, Nahrung/Getränk, Nahrung/Midgard, Nahrung/Midgard/Getränk]
timestamp: 2024-08-29T15:14:41Z
revid: 233211
namespace: 0
contenthash: 0f9b931376fe68f2f606be339fb7a392391b23d54cd862ab18e387bb3b511892
---

## Aussehen

Ein Glas Milch... doch was schwimmt darin herum?

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend") |

## Fundort

Zu kaufen bei [Naugrim](/naugrim.md "Naugrim") im NAUGRIMS INN in [Dvaergen](/dvaergen.md "Dvaergen").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Getränk
- Gegend: Midgard
- Gewicht: 1
- Wirkung: durstlöschend

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Milch/Naugrim)
