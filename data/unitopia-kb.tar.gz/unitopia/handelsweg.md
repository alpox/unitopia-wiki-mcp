---
type: Wiki Article
title: Handelsweg
description: ""
resource: "http://unitopia.intelligense.de/wiki/Handelsweg"
tags: [Subpages, Subpages/Spezial]
timestamp: 2021-03-21T14:56:08Z
revid: 246138
namespace: 0
contenthash: 7e40a3f901003f0216bd822c31ae3b12cfab95d0f7bc4d8b8bae010381eb9160
---

Meintest Du?

-   Den [Handelsweg](/handelsweg-borsippa.md "Handelsweg/Borsippa") nach [Borsippa](/borsippa.md "Borsippa")
-   Den [Handelsweg](/handelsweg-terqa.md "Handelsweg/Terqa") nach [Terqa](/terqa.md "Terqa")

oder

-   Den [alten Handelsweg](/handelsweg-terqa.md "Handelsweg/Terqa") nach [Terqa](/terqa.md "Terqa")

* * *


## Kenndaten

- Typ: Spezial

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Handelsweg)
