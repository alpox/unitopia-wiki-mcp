---
type: Wiki Article
title: Goldmünze/Silbersee
description: In einer Spalte im Turm auf dem Grund des Silbersees der Ruinen von Seestadt.
resource: "http://unitopia.intelligense.de/wiki/Goldmünze/Silbersee"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/3, Info/Material, Info/Material/Edelmetall, Info/Material/Gold, Mineral, Mineral/Metall, Mineral/Midgard, Mineral/Midgard/Metall]
timestamp: 2024-03-02T19:20:26Z
revid: 244245
namespace: 0
contenthash: aab86b07d588d97839d9e9f21d96c700891ac548a493e80a15848f371adcffcd
---

## Aussehen

Eine glaenzende Goldmuenze, die fast einen handtellergrossen Durchmesser
hat. Sie ist ausserdem nicht besonders duenn und sicher sehr wertvoll.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Edelmetall](/kategorie/info-material-edelmetall.md "Kategorie:Info/Material/Edelmetall"), [Gold](/kategorie/info-material-gold.md "Kategorie:Info/Material/Gold") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [3 (schon eher leicht)](/kategorie/info-gewicht-3.md "Kategorie:Info/Gewicht/3") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

In einer Spalte im Turm auf dem Grund des [Silbersees](/silbersee.md "Silbersee") der [Ruinen von Seestadt](/seestadtruinen.md "Seestadtruinen").

* * *


## Kenndaten

- Kategorie: Mineral
- Typ: Metall
- Gegend: Midgard
- Material: Edelmetall/Gold
- Gewicht: 3
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Goldmünze/Silbersee)
