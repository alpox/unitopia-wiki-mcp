---
type: Wiki Article
title: Vaextkraut
description: In einem nebligen Moorsumpf auf Vandras.
resource: "http://unitopia.intelligense.de/wiki/Vaextkraut"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Nahrung, Nahrung/Nordische Inseln, Nahrung/Nordische Inseln/Pflanze, Nahrung/Pflanze]
timestamp: 2024-08-29T15:15:30Z
revid: 261225
namespace: 0
contenthash: 4e458e5d7c64dee15593caf84c38131d36679c7ec66b55fe7e608a450d918290
---

## Aussehen

Aehnelt irgendwie gewoehnlichem Unkraut, wie man es auf fast jeder Wiese
findet. Warum dies nun Vaext sein soll, und worin es sich von Unkraut
unterscheidet ist dir schleierhaft.

_Experten/Seher:_

Vaext ist ein grasgruenes Kraut, das von vielen Leuten faelschlicherweise
fuer Unkraut gehalten wird. Es fuehlt sich auch recht gewoehnlich an. Nur
der Geruch ist auffallend herb. Richtig angewandt unterstuetzt es die
natuerliche Abwehrkraefte und hilft so bei verschiedenen Krankheiten ein
wenig.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | keine |

## Fundort

In einem nebligen Moorsumpf auf [Vandras](/vandras.md "Vandras").

## Besonderheit

-   Kann für spezielle [Druidenelixiere](/druidenelixiere.md "Druidenelixiere") verwendet werden.
-   Das Vaextkraut muss vorher aus dem [unbekannten Kraut](/kraut-vandras.md "Kraut/Vandras") bestimmt werden.

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Pflanze
- Gegend: Nordische Inseln
- Gewicht: 1
- Wirkung: keine

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Vaextkraut)
