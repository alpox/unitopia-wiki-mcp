---
type: Wiki Article
title: Papierblumenstrauß
description: In dem Ärmel des schwarzen Jacketts von Houdini im Zauberladen von Magny.
resource: "http://unitopia.intelligense.de/wiki/Papierblumenstrauß"
tags: [Gegenstand, Gegenstand/Midgard, Gegenstand/Midgard/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Pflanzlich, Info/Schwimmt]
timestamp: 2024-03-02T19:20:57Z
revid: 246955
namespace: 0
contenthash: 7302482c98bc7929f9780fde27c3f43f541408da3318bb6048df2484938b2042
---

## Aussehen

Ein kleiner Papierblumenstrauss, er besteht aus einer tuerkisen
Papierblume, einer orangenen Papierblume und einer roten Papierblume. Wenn
du willst, kannst du einzelne Blumen naeher ansehen oder nehmen. Ausserdem
kann man ihn anderen ueberreichen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Pflanzlich](/kategorie/info-material-pflanzlich.md "Kategorie:Info/Material/Pflanzlich") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

In dem Ärmel des [schwarzen Jacketts](/jackett-houdini.md "Jackett/Houdini") von [Houdini](/houdini.md "Houdini") im Zauberladen von [Magny](/magny.md "Magny").

## Besonderheit

Der Strauß besteht immer aus einigen [Papierblumen](/papierblume-houdini.md "Papierblume/Houdini") in verschiedenen Farben.

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Midgard
- Material: Pflanzlich
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Papierblumenstrauß)
