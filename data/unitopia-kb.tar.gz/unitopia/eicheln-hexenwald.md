---
type: Wiki Article
title: Eicheln/Hexenwald
description: Im Hexenwald auf Thule.
resource: "http://unitopia.intelligense.de/wiki/Eicheln/Hexenwald"
tags: [Gegenstand, Gegenstand/Nordische Inseln, Gegenstand/Nordische Inseln/Sonstige, Gegenstand/Sonstige, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Holz, Info/Schwimmt]
timestamp: 2024-03-02T19:21:13Z
revid: 262262
namespace: 0
contenthash: c2dbfe73404811a78c94ab6fd34565dfbc577f4b59d7976d62bee7bba509d908
---

## Aussehen

Ockerfarbene, etwa zwei bis drei Zentimeter grosse, ovale, holzschalige
Fruechte, die an ihrem dicken Ende eine Art Huetchen haben. Du selbst
kannst sie sicher nicht als Nahrung zu Dir nehmen, aber vielleicht weisst
Du ja ein paar Schweine, die sich sicher darueber freuen wuerden. Ausserdem
sind sie sicher auch gut zur Feuerung zu gebrauchen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Im [Hexenwald](/hexenwald.md "Hexenwald") auf [Thule](/thule.md "Thule").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Nordische Inseln
- Material: Holz
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Eicheln/Hexenwald)
