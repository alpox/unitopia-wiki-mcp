---
type: Wiki Article
title: Schneelied
description: Am Nordpol auf Veldergautland.
resource: "http://unitopia.intelligense.de/wiki/Schneelied"
tags: [Subpages, Subpages/Content, Zustand, Zustand/Nordische Inseln, Zustand/Nordische Inseln/Sonstige, Zustand/Sonstige]
timestamp: 2021-03-21T14:55:10Z
revid: 251581
namespace: 0
contenthash: 8f7d75d07b7482fcce904856604dd5d1600199cd6f5d6655733916f03b8078b9
---

< [Bardengilde](/bardengilde.md "Bardengilde") < [Fähigkeit: Schneelied](/bardengilde.md "Bardengilde")

## Aussehen

```
'Es schneielet, es beielet,
es goht en kalter Wind,
die Maedle zieget Handschuh a,
die Buaba laufat gschwind!'
```

## Fundort

Am [Nordpol](/nordpol.md "Nordpol") auf [Veldergautland](/veldergautland.md "Veldergautland").

## Funktion

-   Das Schneelied lässt es schneien. Mit dem Schnee geht eine gewisse Glätte des Bodens einher, man fällt also auf die Nase und holt sich [blaue Flecken](/blaue-flecken.md "Blaue Flecken").
-   Das Lied senkt die Raumtemperatur auf -10 Grad.
-   Der Schnee erlaubt es, [Schneebälle](/schneeball.md "Schneeball") für eine Schneeballschlacht zu machen und damit zu werfen oder jemanden einzuseifen.

Die [Schneebälle](/schneeball.md "Schneeball") sind essbar, sie helfen gegen Durst.

## Kenndaten

- Typ: Content
- Gegend: Nordische Inseln

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schneelied)
