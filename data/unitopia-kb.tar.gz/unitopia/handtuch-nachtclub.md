---
type: Wiki Article
title: Handtuch/Nachtclub
description: Am Haken in der Toilette im Nachtclub von Merredin.
resource: "http://unitopia.intelligense.de/wiki/Handtuch/Nachtclub"
tags: [Hidden, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Kleidung, Kleidung/Brust, Kleidung/Midgard, Kleidung/Midgard/Brust, ZusatzAussehen, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2024-03-02T19:21:35Z
revid: 261623
namespace: 0
contenthash: 1d13ee5c17864fa0dd9a2881465de09d0ffe5878e827d9698f69bb339a5b482f
---

## Aussehen

Ein wunderbar weiches, sandfarbenes Handtuch

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Am Haken in der Toilette im [Nachtclub](/nachtclub.md "Nachtclub") von [Merredin](/merredin.md "Merredin").

## Funktion

-   lege Tuch um Hals
-   binde Tuch um
-   trockne mich/<Person> ab

## Besonderheit

Zusätzliches Aussehen beim Betrachten einer Person:

| -   **Mann:** | Er hat sich ein grosses, weiches, sandfarbenes Handtuch um die Hueften gewickelt. |
| --- | --- |
| -   **Frau:** | Sie hat sich ein grosses, weiches, sandfarbenes Handtuch um die Brust gebunden. |

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Brust
- Gegend: Midgard
- Material: Textil
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein
- Frau: Sie hat sich ein grosses, weiches, sandfarbenes Handtuch um die Brust gebunden.

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Handtuch/Nachtclub)
