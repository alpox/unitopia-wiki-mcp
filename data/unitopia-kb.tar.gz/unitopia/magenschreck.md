---
type: Wiki Article
title: Magenschreck
description: Zu kaufen bei Hengist im SCHNELLEN REITER von Banbergen.
resource: "http://unitopia.intelligense.de/wiki/Magenschreck"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Wirkung, Info/Wirkung/betrunken, Info/Wirkung/durstlöschend, "Info/Wirkung/gibt 11-15 AP", "Info/Wirkung/gibt 11-15 ZP", Nahrung, Nahrung/Alkohol, Nahrung/Midgard, Nahrung/Midgard/Alkohol]
timestamp: 2024-08-29T15:17:03Z
revid: 232990
namespace: 0
contenthash: 8136f5be372baba2a2493ca7e9462b55d4cdab7c8e8dffe33efc3606eb887cc0
---

## Aussehen

Der Magenschreck ist ein dickfluessiges, brodelndes Gesoeff.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend"), [betrunken](/kategorie/info-wirkung-betrunken.md "Kategorie:Info/Wirkung/betrunken"), gibt 15 ZP wenn AP voll |

## Fundort

Zu kaufen bei [Hengist](/hengist.md "Hengist") im SCHNELLEN REITER von [Banbergen](/banbergen.md "Banbergen").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Alkohol
- Gegend: Midgard
- Gewicht: 2
- Wirkung: durstlöschend/betrunken/gibt 15 ZP wenn AP voll

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Magenschreck)
