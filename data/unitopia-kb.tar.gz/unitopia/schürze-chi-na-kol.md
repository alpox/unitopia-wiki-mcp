---
type: Wiki Article
title: "Schürze/Chi-Na-Kol"
description: "Kleidung von Ori-Gano in der Herberge Südblick am Nordpol auf Veldergautland."
resource: "http://unitopia.intelligense.de/wiki/Schürze/Chi-Na-Kol"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Kleidung, Kleidung/Hüfte, Kleidung/Nordische Inseln, Kleidung/Nordische Inseln/Hüfte]
timestamp: 2020-03-07T12:19:29Z
revid: 251775
namespace: 0
contenthash: e53f5dee1313027c56b17ab5b4df9a0456c3fec18330709258327a1260cf1230
---

## Aussehen

Eine strahlend weisse Kuechenschuerze, wie sie jeder gute Wirt wohl traegt.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Kleidung von [Ori-Gano](/ori-gano.md "Ori-Gano") in der [Herberge Südblick](/herberge-südblick.md "Herberge Südblick") am [Nordpol](/nordpol.md "Nordpol") auf [Veldergautland](/veldergautland.md "Veldergautland").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Hüfte
- Gegend: Nordische Inseln
- Naterial: Textil
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schürze/Chi-Na-Kol)
