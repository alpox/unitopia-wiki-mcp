---
type: Wiki Article
title: Flachmann
description: "Im Aktenschrank in der Zweigstelle der Magyra-Nachrichten in Merredin."
resource: "http://unitopia.intelligense.de/wiki/Flachmann"
tags: [Behälter, Behälter/Gefäß, Behälter/Midgard, Behälter/Midgard/Gefäß, Info, Info/Fasst, Info/Fasst/Flüssigkeit, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Edelmetall, Info/Volumen, Info/Volumen/3]
timestamp: 2026-03-18T18:21:13Z
revid: 255739
namespace: 0
contenthash: b199ab39b99da50f3694a82ac5ca7f777f65f22e5006eb3baff0e7975913577c
---

## Aussehen

Ein kleiner, silberner Flachmann. Perfekt um ihn in der Tasche verschwinden
zu lassen und zwischendurch mal heimlich einen zu nehmen.
Er ist ganz mit Schnaps gefuellt.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Edelmetall](/kategorie/info-material-edelmetall.md "Kategorie:Info/Material/Edelmetall") |
| --- | --- |
| **[Fasst](/kategorie/info-fasst.md "Kategorie:Info/Fasst"):** | [Flüssigkeit](/flüssigkeit.md "Flüssigkeit") |
| **[Volumen](/kategorie/info-volumen.md "Kategorie:Info/Volumen"):** | 3, Schluck |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Im [Aktenschrank](/aktenschrank.md "Aktenschrank") in der Zweigstelle der [Magyra-Nachrichten](/magyra-nachrichten.md "Magyra-Nachrichten") in [Merredin](/merredin.md "Merredin").

## Besonderheit

Der Flachmann enthält anfangs [Schnaps](/schnaps-flachmann.md "Schnaps/Flachmann").

* * *


## Kenndaten

- Kategorie: Behälter
- Typ: Gefäß
- Gegend: Midgard
- Material: Edelmetall
- Fasst: Flüssigkeit
- Volumen: 3/Schluck
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Flachmann)
