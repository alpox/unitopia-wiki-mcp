---
type: Wiki Article
title: Sonnenblume/Marei
description: Zu kaufen bei Marei auf dem Kahn am Trödelmarkt von Bruggstad.
resource: "http://unitopia.intelligense.de/wiki/Sonnenblume/Marei"
tags: [Fundort/Kauf, Gegenstand, Gegenstand/Midgard, Gegenstand/Midgard/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Pflanzlich, Info/Schwimmt]
timestamp: 2024-04-23T19:28:22Z
revid: 249538
namespace: 0
contenthash: f8e8b5bad5b96820b0132e80f5208f5b26e70e37899d1180d9b262e00fb67f1a
---

## Aussehen

Eine grosse, froehliche Blume. Goldene Blaetter sind um einen grossen
Bluetenkorb angeordnet, auf dem die Kerne ein geometrisches Muster bilden.
Der Stiel ist fingerdick, es sitzen noch zwei Blaetter daran.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Pflanzlich](/kategorie/info-material-pflanzlich.md "Kategorie:Info/Material/Pflanzlich") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Zu kaufen bei [Marei](/marei.md "Marei") auf dem Kahn am Trödelmarkt von [Bruggstad](/bruggstad.md "Bruggstad").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Midgard
- Material: Pflanzlich
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Sonnenblume/Marei)
