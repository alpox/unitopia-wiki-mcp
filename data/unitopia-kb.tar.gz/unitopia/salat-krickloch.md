---
type: Wiki Article
title: Salat/Krickloch
description: Im Garten des Kricklochhauses nahe Goldwassermark.
resource: "http://unitopia.intelligense.de/wiki/Salat/Krickloch"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Midgard, Nahrung/Midgard/Pflanze, Nahrung/Pflanze]
timestamp: 2024-08-29T15:24:16Z
revid: 248236
namespace: 0
contenthash: 307fce3f0847051525a94da8959b54ef422d388b001db6e74dbd828fd38419f6
---

## Aussehen

Hellgruener Blattsalat mit zarten, aber schon grossen Salatblaettern.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Im Garten des [Kricklochhauses](/goldwassermark.md "Goldwassermark") nahe [Goldwassermark](/goldwassermark.md "Goldwassermark").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Pflanze
- Gegend: Midgard
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Salat/Krickloch)
