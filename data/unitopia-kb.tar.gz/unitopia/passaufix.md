---
type: Wiki Article
title: Passaufix
description: Am Nordeingang im Gallischen Dorf.
resource: "http://unitopia.intelligense.de/wiki/Passaufix"
tags: [NPC, NPC/Gallien, NPC/Gallien/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Wächter]
timestamp: 2018-11-07T18:26:35Z
revid: 257527
namespace: 0
contenthash: a2d07eeff7b4630ea3ae36f750e28f10fbef7bf5f181e6cf1fe062aa6f0cf8e8
---

## Aussehen

Er ist wie die meisten Gallier von recht kleiner Statur, aber trotzdem
nicht zu unterschaetzen.

## Ausrüstung

-   Ein [gallischer Rundschild](/rundschild-magyra.md "Rundschild/Magyra").
-   Ein [gallisches Kurzschwert](/kurzschwert-gallien.md "Kurzschwert/Gallien").

## Heimat

Am Nordeingang im [Gallischen Dorf](/gallierdorf.md "Gallierdorf").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Gallien
- Rasse: Mensch
- Tätigkeit: Wächter

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Passaufix)
