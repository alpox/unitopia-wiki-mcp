---
type: Wiki Article
title: Schalterwesen
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Schalterwesen"
tags: [NPC, NPC/Dörrland, NPC/Dörrland/pseudo, NPC/Gallien, NPC/Gallien/pseudo, NPC/Kokosinseln, NPC/Kokosinseln/pseudo, NPC/Midgard, NPC/Midgard/pseudo, NPC/Märchenland, NPC/Märchenland/pseudo, NPC/Nordische Inseln, NPC/Nordische Inseln/pseudo, NPC/Ozean, NPC/Ozean/pseudo, NPC/Vaniorh, NPC/Vaniorh/pseudo, NPC/pseudo, Rasse, Rasse/Unbestimmt, Tätigkeit, Tätigkeit/Bankier]
timestamp: 2018-11-07T18:41:41Z
revid: 250745
namespace: 0
contenthash: beefc21edfc8f00b567bb76582538502513f1f3edf505730f0a9a21fb389fb32
---

## Aussehen

Das Schalterwesen hat grosse Augen, damit es im Dunkeln gut sehen kann, gut
Muenzen zaehlen kann und die richtigen Eintraege in Sparbuecher vornehmen
kann. Es fuehrt sehr gerne Bankgeschaefte durch. Und zwar stumm und leise
und still und diskret. Keiner hat es jemals sprechen gehoert, und niemand
hat gesehen, wie es den Schalter jemals verlassen hat. 

## Ausrüstung

Keine.

## Heimat

In der Reisebank des [Kreuzfahrtschiffes "Wirbelwind"](/wirbelwind-transport.md "Wirbelwind/Transport").

* * *


## Kenndaten

- Typ: pseudo
- Gegend: Dörrland/Gallien/Kokosinseln/Märchenland/Midgard/Nordische Inseln/Ozean/Vaniorh
- Rasse: Unbestimmt
- Tätigkeit: Bankier

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schalterwesen)
