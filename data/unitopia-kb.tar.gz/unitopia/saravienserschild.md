---
type: Wiki Article
title: Saravienserschild
description: Im Keller der leeren Hütte im gallischen Dorf.
resource: "http://unitopia.intelligense.de/wiki/Saravienserschild"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Metall, Info/Rüstungsstärke, Info/Rüstungsstärke/gut, Info/Rüstungszustand, Info/Rüstungszustand/eher beständig, Waffe, Waffe/Gallien, Waffe/Gallien/Kleinschild, Waffe/Kleinschild]
timestamp: 2024-03-02T19:17:20Z
revid: 230002
namespace: 0
contenthash: 7cac073a351dec8af530f1a1807787641f156acbce71a0319a8d4ae0379c362e
---

## Aussehen

Ein schon recht abgenutztes Saravienserschild mit dem typischen Abbild
einer stilisierten Eule auf der Vorderseite.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [4 (gut)](/kategorie/info-rüstungsstärke-gut.md "Kategorie:Info/Rüstungsstärke/gut") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [4 (eher beständig)](/kategorie/info-rüstungszustand-eher-beständig.md "Kategorie:Info/Rüstungszustand/eher beständig") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Im Keller der leeren Hütte im [gallischen Dorf](/gallierdorf.md "Gallierdorf").

## Besonderheit

Vorsicht, der Keller hat einen [aggressiven Bewohner](/spinne-gallierdorf.md "Spinne/Gallierdorf").

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Kleinschild
- Gegend: Gallien
- Material: Metall
- Rüstungsstärke: gut
- Rüstungszustand: eher beständig
- Gewicht: 2
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Saravienserschild)
