---
type: Wiki Article
title: Marie
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Marie"
tags: [Angebot, NPC, NPC/Midgard, NPC/Midgard/defensiv, NPC/defensiv, Rasse, Rasse/Halbling]
timestamp: 2022-04-25T21:08:28Z
revid: 217480
namespace: 0
contenthash: 955c8c6db7447b377fb1083dcf4b19438077a1bdd2c49e15c7f6dd3e7b1b7c3c
---

## Aussehen

Marie ist eine kleine, etwas fuellige Halblingsfrau. Sie macht einen netten,
muetterlichen Eindruck.

## Ausrüstung

Keine.

## Heimat

Auf der [Kirmes](/festwiese.md "Festwiese") in [Fabeln](/fabeln.md "Fabeln").

## Angebot

| ![Angebot-tl.gif](/images/d/db/Angebot-tl.gif) | Preisliste | ![Angebot-tr.gif](/images/5/52/Angebot-tr.gif) |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | \| **Ware:** \| **[Taler](/währung.md "Währung")**: \| \| --- \| --- \| \| Ein [Kaffee](/kaffee-marie.md "Kaffee/Marie") \| gratis \| \| Ein [Tee](/tee-marie.md "Tee/Marie") \| gratis \| | **Ware:** | **[Taler](/währung.md "Währung")**: | Ein [Kaffee](/kaffee-marie.md "Kaffee/Marie") | gratis | Ein [Tee](/tee-marie.md "Tee/Marie") | gratis |  |
| **Ware:** | **[Taler](/währung.md "Währung")**: |  |  |  |  |  |  |  |
| Ein [Kaffee](/kaffee-marie.md "Kaffee/Marie") | gratis |  |  |  |  |  |  |  |
| Ein [Tee](/tee-marie.md "Tee/Marie") | gratis |  |  |  |  |  |  |  |
| ![Angebot-bl.gif](/images/3/3b/Angebot-bl.gif) |  | ![Angebot-br.gif](/images/9/92/Angebot-br.gif) |  |  |  |  |  |  |

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Midgard
- Rasse: Halbling
- gegenstand: Getränk:

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Marie)
