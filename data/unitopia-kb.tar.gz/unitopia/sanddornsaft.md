---
type: Wiki Article
title: Sanddornsaft
description: Der Sanddornsaft von Lamanja wird im Becher verkauft.
resource: "http://unitopia.intelligense.de/wiki/Sanddornsaft"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/durstlöschend, "Info/Wirkung/gibt 1-5 AP", "Info/Wirkung/gibt 1-5 ZP", Nahrung, Nahrung/Dörrland, Nahrung/Dörrland/Getränk, Nahrung/Gallien, Nahrung/Gallien/Getränk, Nahrung/Getränk, Nahrung/Kokosinseln, Nahrung/Kokosinseln/Getränk, Nahrung/Midgard, Nahrung/Midgard/Getränk, Nahrung/Märchenland, Nahrung/Märchenland/Getränk, Nahrung/Nordische Inseln, Nahrung/Nordische Inseln/Getränk, Nahrung/Ozean, Nahrung/Ozean/Getränk, Nahrung/Vaniorh, Nahrung/Vaniorh/Getränk]
timestamp: 2024-08-29T15:22:39Z
revid: 254816
namespace: 0
contenthash: 405e5385b48b40cc9bd2594288536ed0e9c42606b1e6c457a12431ad416fdfd6
---

## Aussehen

Ein grosses Glas mit einer dunkelroten, leicht dickfluessigen Fluessigkeit,
es sieht mehr gesund als lecker aus, aber immerhin, es ist fluessig und man
kanns trinken!

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend"), gibt 5 ZP wenn AP voll |

## Fundort

-   Zu kaufen bei [Lamanja](/lamanja.md "Lamanja") im Partybereich des [Kreuzfahrtschiffes "Wirbelwind"](/wirbelwind-transport.md "Wirbelwind/Transport").
-   Zu kaufen bei [Zaffi](/zaffi.md "Zaffi") im Restaurant Schad in [Alt-Dörrstadt](/alt-dörrstadt.md "Alt-Dörrstadt").

## Besonderheit

Der Sanddornsaft von [Lamanja](/lamanja.md "Lamanja") wird im Becher verkauft.

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Getränk
- Gegend: Dörrland/Gallien/Kokosinseln/Märchenland/Midgard/Nordische Inseln/Ozean/Vaniorh
- Gewicht: 1
- Wirkung: durstlöschend/gibt 5 ZP wenn AP voll

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Sanddornsaft)
