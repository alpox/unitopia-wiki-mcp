---
type: Wiki Article
title: Buch/Hohepriester
description: Im Forum der Druidengilde von Knossos auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/Buch/Hohepriester"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Papier, Info/Schwimmt, Schriften, Schriften/Buch, Schriften/Kokosinseln, Schriften/Kokosinseln/Buch]
timestamp: 2024-03-02T19:20:59Z
revid: 229959
namespace: 0
contenthash: 03905e1ed8e615a129a8158ff6e20918158f691df77ab5e64f3dbaf23992008b
---

## Aussehen

Das Buch der Hohepriester. Darin steht so einiges Interessantes ueber
Hohepriester.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Papier](/kategorie/info-material-papier.md "Kategorie:Info/Material/Papier") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Im Forum der [Druidengilde](/druidengilde.md "Druidengilde") von [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").

## Inhalt

Kodex der Hohepriester.

* * *


## Kenndaten

- Kategorie: Schriften
- Typ: Buch
- Gegend: Kokosinseln
- Material: Papier
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Buch/Hohepriester)
