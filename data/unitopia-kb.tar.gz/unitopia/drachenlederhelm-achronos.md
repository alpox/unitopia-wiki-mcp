---
type: Wiki Article
title: Drachenlederhelm/Achronos
description: "Zu kaufen bei Vorlage von Achronos' Schuppenpanzer beim Sattler in seiner Hütte im Elfendorf auf Drachenland."
resource: "http://unitopia.intelligense.de/wiki/Drachenlederhelm/Achronos"
tags: [Fundort/Kauf, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Leder, Info/Rüstungsstärke, Info/Rüstungsstärke/geht so, Info/Rüstungszustand, Info/Rüstungszustand/extrem solide, Rüstung, Rüstung/Ebenen, Rüstung/Ebenen/Kopf, Rüstung/Kopf, Set, Set/Achronosrüstung]
timestamp: 2024-04-23T19:28:29Z
revid: 266843
namespace: 0
contenthash: a0eca0b6cc93ab53698c3589a78cb82603d2bb292df6f8cceefb3fb5b2fb328a
---

## Aussehen

Ein gruenlich schillernder Drachenlederhelm. Sie sind aus derbem
Drachenleder zusammengenaeht und sollten in einem harten Kampf gute Dienste
leisten. Seine Schuppen schillern gruenlich.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder") |
| --- | --- |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [3 (geht so)](/kategorie/info-rüstungsstärke-geht-so.md "Kategorie:Info/Rüstungsstärke/geht so") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [9 (extrem solide)](/kategorie/info-rüstungszustand-extrem-solide.md "Kategorie:Info/Rüstungszustand/extrem solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei Vorlage von [Achronos' Schuppenpanzer](/achronos'-schuppenpanzer.md "Achronos' Schuppenpanzer") beim [Sattler](/sattler.md "Sattler") in seiner Hütte im [Elfendorf](/elfendorf.md "Elfendorf") auf [Drachenland](/drachenland.md "Drachenland").

* * *


## Kenndaten

- Kategorie: Rüstung
- Typ: Kopf
- Gegend: Ebenen
- Set: Achronosrüstung
- Material: Leder
- Rüstungsstärke: geht so
- Rüstungszustand: extrem solide
- Gewicht: 2
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Drachenlederhelm/Achronos)
