---
type: Wiki Article
title: Porzellanvase
description: In der Vitrine in der Eingangshalle im Haus der Familie Montgolfier in Annonay.
resource: "http://unitopia.intelligense.de/wiki/Porzellanvase"
tags: [Behälter, Behälter/Gallien, Behälter/Gallien/Kleine, Behälter/Kleine, Info, Info/Fasst, Info/Fasst/Flüssigkeit, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Keramik, Info/Volumen, Info/Volumen/10]
timestamp: 2026-03-18T18:20:49Z
revid: 247324
namespace: 0
contenthash: 18ef34973a1462306ec30931bcadeb4b4acc3f78a3db69e6097e4e259fee560c
---

## Aussehen

Eine gruen-weisse, verschnoerkelte und bemalte Vase. Du erkennst auf den
ersten Blick, dass es sich dabei nur um Augartenporzellan handeln kann.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Keramik](/kategorie/info-material-keramik.md "Kategorie:Info/Material/Keramik") |
| --- | --- |
| **[Fasst](/kategorie/info-fasst.md "Kategorie:Info/Fasst"):** | [Flüssigkeit](/flüssigkeit.md "Flüssigkeit"), [Blume](/blume.md "Blume") |
| **[Volumen](/kategorie/info-volumen.md "Kategorie:Info/Volumen"):** | 10, Schluck |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

In der Vitrine in der Eingangshalle im Haus der [Familie Montgolfier](/annonay.md "Annonay") in [Annonay](/annonay.md "Annonay").

## Besonderheit

Die Vase kann 74 Blumen aufnehmen, ohne Wasser sind es 75 Blumen.

* * *


## Kenndaten

- Kategorie: Behälter
- Typ: Kleine
- Gegend: Gallien
- Material: Keramik
- Fasst: Flüssigkeit/Blume
- Volumen: 10/Schluck
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Porzellanvase)
