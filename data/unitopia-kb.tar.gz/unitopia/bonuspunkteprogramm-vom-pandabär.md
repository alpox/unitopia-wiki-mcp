---
type: Wiki Article
title: Bonuspunkteprogramm vom Pandabär
description: "Auf Asia, in der Stadt Foo-Ling-Yoo befindet sich der Zugang zum Bambustal, das durchweg mit kleinen Bambuswäldern bewachsen ist. Dahinter steht das große Badehaus. Hier sitzt der große, dicke Panabär"
resource: "http://unitopia.intelligense.de/wiki/Bonuspunkteprogramm_vom_Pandabär"
tags: [Abenteuer, Abenteuer/Ebenen, Abenteuer/mit, Abenteuer/mit/Ebenen]
timestamp: 2018-11-07T18:23:59Z
revid: 206241
namespace: 0
contenthash: 3f35c37ef79f409a3efc09e19c1c4c757d88094d3ff943d2bd66393288ef6e5b
---

## Beschreibung

Auf [Asia](/asia.md "Asia"), in der Stadt [Foo-Ling-Yoo](/foo-ling-yoo.md "Foo-Ling-Yoo") befindet sich der Zugang zum [Bambustal](/bambustal.md "Bambustal"), das durchweg mit kleinen Bambuswäldern bewachsen ist. Dahinter steht das große [Badehaus](/badehaus.md "Badehaus"). Hier sitzt der [große, dicke Panabär](/pandabär.md "Pandabär"). Von ihm kann man ein [Bonusprogramm](/bonusprogramm.md "Bonusprogramm") erhalten, um sich Bonuspunkte zu verdienen, indem man ihm Bambus holt.

## Belohnung

Zum Lohn für seine Mühen erhält man je einen Bonuspunkt, den man in eine der folgenden Sachen umtauschen kann:

-   Eine [Tatami](/tatami.md "Tatami") ([Bambusmatte](/bambusmatte.md "Bambusmatte"))
-   Ein [Plüschpanda](/plüschpanda.md "Plüschpanda")
-   Ein [Bambustopf](/bambustopf.md "Bambustopf")

* * *


## Kenndaten

- Typ: mit
- Gegend: Ebenen

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Bonuspunkteprogramm_vom_Pandabär)
