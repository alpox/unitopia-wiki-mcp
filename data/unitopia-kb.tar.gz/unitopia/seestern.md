---
type: Wiki Article
title: Seestern
description: Auf dem Grund des Meeres auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/Seestern"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/3, Info/Material, Info/Material/Biologisch, Info/Waffenstärke, Info/Waffenstärke/prima, Info/Waffenzustand, Info/Waffenzustand/ziemlich spröde, Waffe, Waffe/Kokosinseln, Waffe/Kokosinseln/Wurfmesser, Waffe/Wurfmesser]
timestamp: 2024-03-02T19:22:11Z
revid: 263342
namespace: 0
contenthash: 2357a7afeb5f994202ec7ea53a0edd617e2e3691947922d5df5da2a86dfcc7e7
---

## Aussehen

Dieser Seestern ist ein Exemplar einer sehr seltenen und aussterbenden
Seesternart. Er hat vier Arme oder wie man sie in diesem Fall nennen wuerde
Fuesse, die je in eine Himmelsrichtung zeigen. Weiterhin ist er pechschwarz
und hat in der Mitte, wo alle vier Gliedmassen zusammenlaufen einen
dunkelroten Punkt, der dir nicht ganz geheuer ist.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Biologisch](/kategorie/info-material-biologisch.md "Kategorie:Info/Material/Biologisch") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [7 (prima)](/kategorie/info-waffenstärke-prima.md "Kategorie:Info/Waffenstärke/prima") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [1 (ziemlich spröde)](/kategorie/info-waffenzustand-ziemlich-spröde.md "Kategorie:Info/Waffenzustand/ziemlich spröde") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [3 (schon eher leicht)](/kategorie/info-gewicht-3.md "Kategorie:Info/Gewicht/3") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Auf dem [Grund des Meeres](/meeresgrund.md "Meeresgrund") auf [Kreta](/kreta.md "Kreta").

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Wurfmesser
- Gegend: Kokosinseln
- Material: Biologisch
- Waffenstärke: prima
- Waffenzustand: ziemlich spröde
- Gewicht: 3
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Seestern)
