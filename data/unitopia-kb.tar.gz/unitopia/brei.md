---
type: Wiki Article
title: Brei
description: "Zu kaufen bei Eichler im \"Efeubusch\" in Fabeln."
resource: "http://unitopia.intelligense.de/wiki/Brei"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Midgard, Nahrung/Midgard/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:17:03Z
revid: 221430
namespace: 0
contenthash: 1b7681e95d4a175796e402333252a3621b89cac59af39e4b81328b14122ed300
---

## Aussehen

Eine selbst fuer einen Halbling nicht allzu grosse Portion Brei, wie er in
der Kueche seit Jahren kocht. Er sieht einfach ... aeh 'lecker' aus!

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Zu kaufen bei [Eichler](/eichler.md "Eichler") im "Efeubusch" in [Fabeln](/fabeln.md "Fabeln").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Midgard
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Brei)
