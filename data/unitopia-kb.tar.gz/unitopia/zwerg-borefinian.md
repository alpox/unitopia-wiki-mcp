---
type: Wiki Article
title: Zwerg/Borefinian
description: Vor dem Bergwerk und im Rathaus von Borefinian.
resource: "http://unitopia.intelligense.de/wiki/Zwerg/Borefinian"
tags: [NPC, NPC/Midgard, NPC/Midgard/defensiv, NPC/defensiv, Rasse, Rasse/Zwerg, Tätigkeit, Tätigkeit/Wächter]
timestamp: 2018-11-07T18:34:31Z
revid: 217144
namespace: 0
contenthash: 961c92c09642a04bf37544ee85e648e39267347ba1ac80f7df0fd32c03f2fe5d
---

## Aussehen

Ein kraeftiger Zwerg, fuer seine Rasse ziemlich hochgewachsen, ausserdem
hat er kraeftige Arm- und Beinmuskeln. Er traegt ein kurzes, aermelloses
Kettenhemd und eine gefaehrlich aussehende Axt, dazu noch einen ledernen
Helm, ebensolche Stiefel und gepanzerte Handschuhe.

## Ausrüstung

-   Ein [Paar Panzerhandschuhe](/panzerhandschuhe-swerka.md "Panzerhandschuhe/Swerka").
-   Eine [einfache Kappe aus gehärtetem Leder](/kappe-swerka.md "Kappe/Swerka").
-   [Schwere Lederstiefel](/lederstiefel-swerka.md "Lederstiefel/Swerka").
-   Ein [ärmelloses Kettenwams](/kettenwams-magyra.md "Kettenwams/Magyra").
-   Eine [Handaxt](/handaxt-xetolosch.md "Handaxt/Xetolosch").

## Heimat

Vor dem [Bergwerk](/borefinian.md "Borefinian") und im Rathaus von [Borefinian](/borefinian.md "Borefinian").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Midgard
- Rasse: Zwerg
- Tätigkeit: Wächter

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Zwerg/Borefinian)
