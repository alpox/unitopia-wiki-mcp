---
type: Wiki Article
title: Schlehenspanner
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Schlehenspanner"
tags: [NPC, NPC/Kokosinseln, NPC/Kokosinseln/defensiv, NPC/defensiv, Rasse, Rasse/Insekt]
timestamp: 2019-04-03T08:37:15Z
revid: 262290
namespace: 0
contenthash: a1af5a782e75ea8b81a8f265a9d157b138d649a83cc7887a8ea85792e6e385d2
---

## Aussehen

Ein Schlehenspanner, mit einer fuer einen Nachtfalter recht auffaelligen,
rot-orangenen Fluegelfaerbung. Wie alle Insekten hat er sechs Beine und
grosse Facettenaugen. Dazu kommen dann noch zwei lange Fuehler und ein
eingerollter Saugruessel.

## Ausrüstung

Keine.

## Heimat

Im Dschungel auf der [Dschungelinsel](/dschungelinsel.md "Dschungelinsel").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Kokosinseln
- Rasse: Insekt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schlehenspanner)
