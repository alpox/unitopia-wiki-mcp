---
type: Wiki Article
title: Hut/Wenar
description: "Rüstung von Wenar am Nurta-Tor der Festung Bruchberg auf Nankea."
resource: "http://unitopia.intelligense.de/wiki/Hut/Wenar"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Info/Rüstungsstärke, Info/Rüstungsstärke/schwach, Info/Rüstungszustand, Info/Rüstungszustand/unverwüstlich, Info/Schwimmt, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Rüstung, Rüstung/Kopf, Rüstung/Midgard, Rüstung/Midgard/Kopf]
timestamp: 2024-03-02T19:19:03Z
revid: 228631
namespace: 0
contenthash: 9f10b983f96d087ff449deae6ff60c931c74ae7eb53a708e3137c9e074740a69
---

## Aussehen

Ein gruener Hut aus Leinen. Eine weisse Feder ist an der rechten Seite des
Hutes angebracht.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [2 (schwach)](/kategorie/info-rüstungsstärke-schwach.md "Kategorie:Info/Rüstungsstärke/schwach") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [11 (unverwüstlich)](/kategorie/info-rüstungszustand-unverwüstlich.md "Kategorie:Info/Rüstungszustand/unverwüstlich") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Rüstung von [Wenar](/wenar.md "Wenar") am Nurta-Tor der [Festung Bruchberg](/bruchberg.md "Bruchberg") auf [Nankea](/nankea.md "Nankea").

* * *


## Kenndaten

- Kategorie: Rüstung
- Typ: Kopf
- Gegend: Midgard
- Material: Textil
- Temperaturschutz: wärmt etwas
- Rüstungsstärke: schwach
- Rüstungszustand: unverwüstlich
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Hut/Wenar)
