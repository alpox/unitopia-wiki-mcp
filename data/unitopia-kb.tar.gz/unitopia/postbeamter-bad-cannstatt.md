---
type: Wiki Article
title: Postbeamter/Bad Cannstatt
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Postbeamter/Bad_Cannstatt"
tags: [Angebot, NPC, NPC/Campus, NPC/Campus/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Postbeamter]
timestamp: 2022-04-25T21:07:47Z
revid: 238771
namespace: 0
contenthash: 047cc9952395bceaa4ce1358692a26729efa3a2bd2f21e4a3c9256b18114a1e8
---

## Aussehen

Der Postbeamte sitzt hinter seinem Schalter und erledigt Papierkram. Wenn
du Fragen hast oder eine Postkarte kaufen moechtest, so wende Dich einfach
an ihn.

## Ausrüstung

Keine.

## Heimat

Im Postamt von [Bad Cannstatt](/bad-cannstatt.md "Bad Cannstatt").

## Angebot

Hat man kein Geld dabei, erklärt der Postbeamte bei der Bitte um eine Postkarte im breitesten Schwäbisch, dass eine Karte 4 [Mark](/mark.md "Mark") kostet.

| ![Angebot-tl.gif](/images/d/db/Angebot-tl.gif) | Postkarten | ![Angebot-tr.gif](/images/5/52/Angebot-tr.gif) |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | \| **Ware:** \| **[Mark](/währung.md "Währung")**: \| \| --- \| --- \| \| Eine [Postkarte](/postkarte-unitopia.md "Postkarte/Unitopia") \| 4 \| | **Ware:** | **[Mark](/währung.md "Währung")**: | Eine [Postkarte](/postkarte-unitopia.md "Postkarte/Unitopia") | 4 |  |
| **Ware:** | **[Mark](/währung.md "Währung")**: |  |  |  |  |  |
| Eine [Postkarte](/postkarte-unitopia.md "Postkarte/Unitopia") | 4 |  |  |  |  |  |
| ![Angebot-bl.gif](/images/3/3b/Angebot-bl.gif) |  | ![Angebot-br.gif](/images/9/92/Angebot-br.gif) |  |  |  |  |

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Campus
- Rasse: Mensch
- Tätigkeit: Postbeamter

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Postbeamter/Bad_Cannstatt)
