---
type: Wiki Article
title: Mückenstich
description: Durch den Mückenschwarm nordöstlich von Bruggstad.
resource: "http://unitopia.intelligense.de/wiki/Mückenstich"
tags: [Info, Info/Heilung, Info/Heilung/Heiler, Info/Heilung/Heilstab, Info/Heilung/Hexenvolk, Info/Wirkung, Info/Wirkung/Zustand, Info/Wirkung/Zustand/negativ, Zustand, Zustand/Midgard, Zustand/Midgard/Vergiftung, Zustand/Vergiftung]
timestamp: 2024-08-29T15:24:16Z
revid: 239452
namespace: 0
contenthash: e31fd38e2ba77e92e9944db3b5a727b03cde59992ba5225f7ee52b25de225291
---

## Aussehen

Er/Sie/Es hat ein paar Mueckenstiche.

## Informationen

| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [negativ](/kategorie/info-wirkung-zustand-negativ.md "Kategorie:Info/Wirkung/Zustand/negativ") |
| --- | --- |
| **[Heilung](/kategorie/info-heilung.md "Kategorie:Info/Heilung"):** | [Heiler](/heiler.md "Heiler"), [Hexenvolk](/hexenvolk.md "Hexenvolk"), [Heilstab](/heilstab.md "Heilstab") |

## Fundort

Durch den [Mückenschwarm](/mückenschwarm.md "Mückenschwarm") nordöstlich von [Bruggstad](/bruggstad.md "Bruggstad").

## Gefährlichkeit

-   Zieht ca. 3 [AP](/ap.md "AP")[![Ausdauerpunkte](/images/b/b4/AP.gif)](/ap.md "Ausdauerpunkte") in der Minute ab, hält ca. 3 Minuten an.
-   Startmeldung:

Eine Muecke landet auf dir und sticht dich.

-   Zwischenmeldungen:

Langsam werden die Mueckenstiche laestig.

-   Endmeldung:

Das Gift hat sich in deinen Adern aufgeloest.

* * *


## Kenndaten

- Kategorie: Zustand
- Typ: Vergiftung
- Gegend: Midgard
- Wirkung: negativ
- Heilung: Heiler/Hexenvolk/Heilstab

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Mückenstich)
