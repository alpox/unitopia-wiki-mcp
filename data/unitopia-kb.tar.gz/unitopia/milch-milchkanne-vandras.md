---
type: Wiki Article
title: Milch/Milchkanne/Vandras
description: In der Milchkanne in der Burgküche der Burg auf Vandras.
resource: "http://unitopia.intelligense.de/wiki/Milch/Milchkanne/Vandras"
tags: [Flüssigkeit, Flüssigkeit/positiv, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/durstlöschend, "Info/Wirkung/gibt 1-5 AP", "Info/Wirkung/gibt 1-5 ZP", Nahrung, Nahrung/Nordische Inseln, Nahrung/Nordische Inseln/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:19:51Z
revid: 253355
namespace: 0
contenthash: 437cd5db2fe4689e6b4870b27b69abb77d31f243770a856b47c97514f0922243
---

## Aussehen

Eine milchig weisse Fluessigkeit.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend"), gibt 1 ZP wenn AP voll |

## Fundort

In der Milchkanne in der [Burgküche](/vandras.md "Vandras") der [Burg](/vandras.md "Vandras") auf [Vandras](/vandras.md "Vandras").

## Besonderheit

Mit dieser [Flüssigkeit](/kategorie/flüssigkeit.md "Kategorie:Flüssigkeit") kann man [Trinkgefäße](/gefäß.md "Gefäß") und das [Spritzgewehr](/spritzgewehr.md "Spritzgewehr") befüllen.

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Nordische Inseln
- Gewicht: 1
- Wirkung: durstlöschend/gibt 1 ZP wenn AP voll

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Milch/Milchkanne/Vandras)
