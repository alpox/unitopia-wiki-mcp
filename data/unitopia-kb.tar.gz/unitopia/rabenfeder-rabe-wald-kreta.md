---
type: Wiki Article
title: Rabenfeder/Rabe/Wald/Kreta
description: Nach dem Töten des Rabens auf dem Dach des verfallenen Hauses östlich vom wild wuchernden Wald auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/Rabenfeder/Rabe/Wald/Kreta"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Info/Rüstungsstärke, Info/Rüstungsstärke/schwach, Info/Rüstungszustand, Info/Rüstungszustand/wenig haltbar, Rüstung, Rüstung/Kokosinseln, Rüstung/Kokosinseln/Kopf, Rüstung/Kopf]
timestamp: 2024-03-02T19:20:16Z
revid: 227992
namespace: 0
contenthash: ac1713e15e64db24130304a541afda3ad595450d06f91cc387ab625d2ee6e56e
---

## Aussehen

Eine lange, tiefschwarze Rabenfeder. Im Licht schimmert sie in den
wunderschoenen Farben eines Regenbogens.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [2 (schwach)](/kategorie/info-rüstungsstärke-schwach.md "Kategorie:Info/Rüstungsstärke/schwach") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [2 (wenig haltbar)](/kategorie/info-rüstungszustand-wenig-haltbar.md "Kategorie:Info/Rüstungszustand/wenig haltbar") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Nach dem Töten des [Rabens](/rabe-wald-kreta.md "Rabe/Wald/Kreta") auf dem Dach des verfallenen Hauses östlich vom [wild wuchernden Wald](/kreta.md "Kreta") auf [Kreta](/kreta.md "Kreta").

* * *


## Kenndaten

- Kategorie: Rüstung
- Typ: Kopf
- Gegend: Kokosinseln
- Material: Textil
- Rüstungsstärke: schwach
- Rüstungszustand: wenig haltbar
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Rabenfeder/Rabe/Wald/Kreta)
