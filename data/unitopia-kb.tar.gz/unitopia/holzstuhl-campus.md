---
type: Wiki Article
title: Holzstuhl/Campus
description: Im Computerraum im NWZ II auf dem Campusgelände der Universität Stuttgart.
resource: "http://unitopia.intelligense.de/wiki/Holzstuhl/Campus"
tags: [Gegenstand, Gegenstand/Campus, Gegenstand/Campus/Möbel, Gegenstand/Möbel, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Holz, Info/Schwimmt]
timestamp: 2024-03-02T19:21:21Z
revid: 239513
namespace: 0
contenthash: fba63f33b45d3d4ccba6ebd94d118d12d75aacccd0ba2a2bb3ede9a1901c4f1d
---

## Aussehen

Ein einfacher Holzstuhl, der genauso schlicht wie funktional ist.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Im Computerraum im [NWZ II](/campusgelände.md "Campusgelände") auf dem [Campusgelände](/campusgelände.md "Campusgelände") der [Universität Stuttgart](/universität.md "Universität").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Möbel
- Gegend: Campus
- Material: Holz
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Holzstuhl/Campus)
