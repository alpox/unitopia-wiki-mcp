---
type: Wiki Article
title: Eisbecher/Liamica
description: Zu kaufen bei Liamica im Cafe Beauregard der Sehergilde.
resource: "http://unitopia.intelligense.de/wiki/Eisbecher/Liamica"
tags: [Behälter, Behälter/Gallien, Behälter/Gallien/Gefäß, Behälter/Gefäß, Fundort/Kauf, Info, Info/Fasst, Info/Fasst/Flüssigkeit, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Glas, Info/Volumen, Info/Volumen/2, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Gallien, Nahrung/Gallien/Produkt, Nahrung/Produkt]
timestamp: 2026-03-18T18:21:27Z
revid: 256951
namespace: 0
contenthash: 5871182cbe1b902876236c488ae11feb87f423246f131a97458f00bf172339de
---

## Aussehen

In einem geschwungenen Eisbecher aus blauem Glas siehst du drei Kugeln
Vanilleeis. Rote Geleesosse fliesst langsam ueber die Kugeln hinab. Geziert
wird das Ganze von heissen Kirschen, welche das Eis langsam zum Schmelzen
bringen.

_Leer:_

Dir faellt sofort der leuchtende Blauton des Glases auf, aus welchem der
Eisbecher gefertigt ist. Das Glas wurde schwungvoll geformt und hat eine
gewisse Aehnlichkeit zu einer Bluete.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Glas](/kategorie/info-material-glas.md "Kategorie:Info/Material/Glas") |
| --- | --- |
| **[Fasst](/kategorie/info-fasst.md "Kategorie:Info/Fasst"):** | [Flüssigkeit](/flüssigkeit.md "Flüssigkeit") |
| **[Volumen](/kategorie/info-volumen.md "Kategorie:Info/Volumen"):** | 2, Schluck |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Liamica](/liamica.md "Liamica") im Cafe Beauregard der [Sehergilde](/sehergilde.md "Sehergilde").

* * *


## Kenndaten

- Typ: Produkt
- Gegend: Gallien
- Kategorie: Behälter
- Material: Glas
- Gewicht: 1
- Volumen: 2/Schluck
- Fasst: Flüssigkeit
- Wirkung: sättigt
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Eisbecher/Liamica)
