---
type: Wiki Article
title: Croissant/Barovia
description: In Jean Pierres privatem Reich in der Fechtschule von Barovia.
resource: "http://unitopia.intelligense.de/wiki/Croissant/Barovia"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Dörrland, Nahrung/Dörrland/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:19:51Z
revid: 232836
namespace: 0
contenthash: f3a3bb265ad28757aceb11fbf331065717e180d928b771dd7bb729d3e14d752c
---

## Aussehen

Ein leckeres Croissant. Herrlich luftiger Blaetterteig, goldbraun gebacken,
wie er leckerer kaum sein koennte. Jean Pierre muss wirklich gute
Beziehungen haben, um in dieser Gegend an so ein vorzuegliches Backwerk zu
kommen.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

In [Jean Pierres](/jean-pierre.md "Jean Pierre") privatem Reich in der Fechtschule von [Barovia](/barovia.md "Barovia").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Dörrland
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Croissant/Barovia)
