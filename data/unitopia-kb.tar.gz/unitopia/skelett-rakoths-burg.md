---
type: Wiki Article
title: Skelett/Rakoths Burg
description: Im Madentopf im Arbeitsraum in Rakoths Burg auf Drachenland.
resource: "http://unitopia.intelligense.de/wiki/Skelett/Rakoths_Burg"
tags: [Gegenstand, Gegenstand/Ebenen, Gegenstand/Ebenen/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Bein]
timestamp: 2024-03-02T19:20:41Z
revid: 249474
namespace: 0
contenthash: c9d4f3709a52cf34fb20601bd9e99c2284174388576ac1c40018635f1afa84ed
---

## Aussehen

Das Skelett eines <NPC-Name>.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Bein](/kategorie/info-material-bein.md "Kategorie:Info/Material/Bein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Im [Madentopf](/maden.md "Maden") im Arbeitsraum in [Rakoths Burg](/rakoths-burg.md "Rakoths Burg") auf [Drachenland](/drachenland.md "Drachenland").

## Besonderheit

Das Skelett bewahrt den Namen der Leiche, die es zuvor war, nebst allen Adjektiven.

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Ebenen
- Material: Bein
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Skelett/Rakoths_Burg)
