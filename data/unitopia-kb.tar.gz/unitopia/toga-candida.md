---
type: Wiki Article
title: Toga/candida
description: Zu kaufen bei Carlus Lagerfeldus in der Handwerksgasse in einer Schneiderei von Lutetia.
resource: "http://unitopia.intelligense.de/wiki/Toga/candida"
tags: [Fundort/Kauf, Hidden, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Kleidung, Kleidung/Brust, Kleidung/Gallien, Kleidung/Gallien/Brust, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2024-04-23T19:27:46Z
revid: 261877
namespace: 0
contenthash: d537b1d0fbf4a2ae987854280e0f15a1d301c24c997f4faf135d59ac81c939a6
---

## Aussehen

Die Toga candida ist weiss, ja eigentlich weisser als weiss, strahlend
weiss! (Unwillkuerlich regt sich in dir der Drang, nachzufragen, wie man
eine Toga sooo weiss bekommt!)

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundorte

Zu kaufen bei [Carlus Lagerfeldus](/carlus.md "Carlus") in der Handwerksgasse in einer Schneiderei von [Lutetia](/lutetia.md "Lutetia").

## Besonderheit

Zusätzliches Aussehen beim Betrachten einer Person:

| -   **Mann:** | Er traegt eine strahlend weisse roemische Toga. |
| --- | --- |
| -   **Frau:** | Sie traegt eine strahlend weisse roemische Toga. |
| -   **Etwas:** | Es traegt eine strahlend weisse roemische Toga. |

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Brust
- Gegend: Gallien
- Material: Textil
- Temperaturschutz: wärmt etwas
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein
- Mann: Er traegt eine strahlend weisse roemische Toga.
- Frau: Sie traegt eine strahlend weisse roemische Toga.
- Etwas: Es traegt eine strahlend weisse roemische Toga.

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Toga/candida)
