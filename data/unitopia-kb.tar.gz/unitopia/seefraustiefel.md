---
type: Wiki Article
title: Seefraustiefel
description: Kleidung von Juliette auf der Julie Celeste.
resource: "http://unitopia.intelligense.de/wiki/Seefraustiefel"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Info/Temperaturschutz, Info/Temperaturschutz/wärmt ziemlich, Kleidung, Kleidung/Füße, Kleidung/Nordische Inseln, Kleidung/Nordische Inseln/Füße, Kleidung/Ozean, Kleidung/Ozean/Füße]
timestamp: 2024-03-02T19:19:07Z
revid: 255084
namespace: 0
contenthash: 4790c392878b4454cccd8e70350e891de89a1e7960b19e42bcef60cd6f502c31
---

## Aussehen

Diese festen Lederstiefel haben ein gutes Profil und sehen absolut
wasserfest aus.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt ziemlich](/kategorie/info-temperaturschutz-wärmt-ziemlich.md "Kategorie:Info/Temperaturschutz/wärmt ziemlich") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Kleidung von [Juliette](/juliette.md "Juliette") auf der [Julie Celeste](/julie-celeste.md "Julie Celeste").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Füße
- Gegend: Nordische Inseln/Ozean
- Material: Textil
- Temperaturschutz: wärmt ziemlich
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Seefraustiefel)
