---
type: Wiki Article
title: Naike
description: Auf dem Weihnachtsmarkt in Nankea (Stadt) auf Nankea.
resource: "http://unitopia.intelligense.de/wiki/Naike"
tags: [Angebot, NPC, NPC/Midgard, NPC/Midgard/defensiv, NPC/defensiv, Rasse, Rasse/Fee, Tätigkeit, Tätigkeit/Verkäufer]
timestamp: 2022-04-25T21:08:28Z
revid: 217431
namespace: 0
contenthash: 0ee67e3c517c97e817d864e64a0d9066021e8a8839156573b6a946919b608e48
---

## Aussehen

Honigkuchen-Fee Naike.

## Ausrüstung

-   Eine [rote Zipfelmütze](/zipfelmütze-rote.md "Zipfelmütze/rote").
-   Ein [rotes Weihnachtsmann-Kostüm](/weihnachtsmann-kostüm.md "Weihnachtsmann-Kostüm").

## Heimat

Auf dem [Weihnachtsmarkt](/weihnachtsmarkt.md "Weihnachtsmarkt") in [Nankea (Stadt)](/nankea-\(stadt\).md "Nankea (Stadt)") auf [Nankea](/nankea.md "Nankea").

## Angebot

| ![Angebot-tl.gif](/images/d/db/Angebot-tl.gif) | Speisekarte | ![Angebot-tr.gif](/images/5/52/Angebot-tr.gif) |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | \| **Kuchen::** \| **[Riki](/währung.md "Währung")**: \| \| --- \| --- \| \| Ein [Honigkuchen](/honigkuchen-naike.md "Honigkuchen/Naike") \| 120 \| | **Kuchen::** | **[Riki](/währung.md "Währung")**: | Ein [Honigkuchen](/honigkuchen-naike.md "Honigkuchen/Naike") | 120 |  |
| **Kuchen::** | **[Riki](/währung.md "Währung")**: |  |  |  |  |  |
| Ein [Honigkuchen](/honigkuchen-naike.md "Honigkuchen/Naike") | 120 |  |  |  |  |  |
| ![Angebot-bl.gif](/images/3/3b/Angebot-bl.gif) |  | ![Angebot-br.gif](/images/9/92/Angebot-br.gif) |  |  |  |  |

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Midgard
- Rasse: Fee
- Tätigkeit: Verkäufer
- Gegenstand: Kuchen:

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Naike)
