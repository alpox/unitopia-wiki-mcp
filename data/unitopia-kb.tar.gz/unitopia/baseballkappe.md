---
type: Wiki Article
title: Baseballkappe
description: Kleidung von Wolfi tagsüber am Hafen von Knossos auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/Baseballkappe"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Kleidung, Kleidung/Kokosinseln, Kleidung/Kokosinseln/Kopf, Kleidung/Kopf]
timestamp: 2024-03-02T19:21:21Z
revid: 248715
namespace: 0
contenthash: 66e005f23274270a46221ad8c27a4a01346cf8cf9ae9db099446a34b37783745
---

## Aussehen

Eine blaue Baseballkappe mit gelben Streifen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Kleidung von [Wolfi](/wolfi.md "Wolfi") tagsüber am [Hafen](/knossos.md "Knossos") von [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Kopf
- Gegend: Kokosinseln
- Material: Textil
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Baseballkappe)
