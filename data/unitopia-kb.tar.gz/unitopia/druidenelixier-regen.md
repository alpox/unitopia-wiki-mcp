---
type: Wiki Article
title: Druidenelixier/Regen
description: Von einem Mitglied der Druidengilde.
resource: "http://unitopia.intelligense.de/wiki/Druidenelixier/Regen"
tags: [Fundort, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/durstlöschend, Nahrung, Nahrung/Getränk, Nahrung/Kokosinseln, Nahrung/Kokosinseln/Getränk, Subpages, Subpages/Content]
timestamp: 2024-09-16T12:13:08Z
revid: 231930
namespace: 0
contenthash: 3ad4b8877d0cf59f122d4051e9d73ca02e697ee7fa437b6fc4a7153d4297701d
---

< [Druidengilde](/druidengilde.md "Druidengilde") < [Elixiere](/druidengilde.md "Druidengilde")

## Aussehen

In der Flasche befindet sich eine undurchsichtige Fluessigkeit.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [siehe Funktion](#Funktion), [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend") |

## Fundort

Von einem Mitglied der [Druidengilde](/druidengilde.md "Druidengilde").

## Funktion

Eine [Regenwolke](/regenwolke.md "Regenwolke") erscheint und es regnet. Alle Anwesenden trinken einige Schlucke Wasser.

## Besonderheit

| Geruch | Riecht nach Meer. |
| --- | --- |
| Tasten | Du tauchst Deinen Finger in die Flasche und es fühlt sich nass an. |
| Meldung | Du öffnest die Flasche und springst dabei im Kreis herum. Ein türkisfarbener Nebel steigt zum Himmel empor. Die Kraft des Segens beginnt zu wirken. Dunkle Wolken nähern sich und es beginnt ganz fürchterlich zu regnen. |

* * *


## Kenndaten

- Typ: Content
- Kategorie: Nahrung
- Gegend: Kokosinseln
- Gewicht: 1
- Wirkung: siehe Funktion/durstlöschend

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Druidenelixier/Regen)
