---
type: Wiki Article
title: Pfahlmuscheln
description: Zu kaufen bei Sardine auf dem Fischmarkt am Hafen von Massilia.
resource: "http://unitopia.intelligense.de/wiki/Pfahlmuscheln"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Gallien, Nahrung/Gallien/Produkt, Nahrung/Produkt]
timestamp: 2024-08-29T15:13:59Z
revid: 247015
namespace: 0
contenthash: e09b8d08a3310fa86aa09f3bf7d60295c934037ee25fb57445c1cecce39f6625
---

## Aussehen

Leckere Pfahlmuscheln, ohne Schale, in Weissweinsauce gekocht und
raffiniert gewuerzt mit Kraeutern aus der Provincia Narbonensis.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

Zu kaufen bei [Sardine](/sardine.md "Sardine") auf dem Fischmarkt am [Hafen](/massilia.md "Massilia") von [Massilia](/massilia.md "Massilia").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Produkt
- Gegend: Gallien
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Pfahlmuscheln)
