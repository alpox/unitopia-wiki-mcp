---
type: Wiki Article
title: Gedriht/Evusatria
description: "Der Gedriht gehört zu den NPCs, die ständig wechselnde Adjektive haben. Diese werden hier nicht gesondert aufgelistet."
resource: "http://unitopia.intelligense.de/wiki/Gedriht/Evusatria"
tags: [Adjektiv, NPC, NPC/Midgard, NPC/Midgard/defensiv, NPC/defensiv, Rasse, Rasse/Mensch, Tätigkeit, Tätigkeit/Wächter]
timestamp: 2018-11-07T18:26:51Z
revid: 217666
namespace: 0
contenthash: 86e2e7dc57a5562749505c9780b867e2b84757b47f32193d2cea566813cf4011
---

## Aussehen

Ein schwer gepanzerter Elitekaempfer Wessenachs. Er dient im Regiment der
Gedrihts, die direkt dem Koenig unterstehen. Mit wachem Auge beobachtet er
jede Bewegung, jederzeit bereit einzugreifen.

## Ausrüstung

-   Ein [Langspeer](/langspeer.md "Langspeer").
-   Ein [Wessenschild](/wessenschild.md "Wessenschild").
-   Ein [Wessenhelm](/wessenhelm.md "Wessenhelm").
-   Ein [Kettenhemd](/kettenhemd-banbergen.md "Kettenhemd/Banbergen").
-   [Kettenhandschuhe](/kettenhandschuhe.md "Kettenhandschuhe").
-   Eine [Kettenhose](/kettenhose-banbergen.md "Kettenhose/Banbergen").
-   [Beschlagene Lederstiefel](/lederstiefel-banbergen.md "Lederstiefel/Banbergen").

## Heimat

-   Auf einem Weg um [Evusatria](/banbergen.md "Banbergen") in [Banbergen](/banbergen.md "Banbergen").
-   In einem kleinen Gang von [Evusatria](/banbergen.md "Banbergen") in [Banbergen](/banbergen.md "Banbergen").
-   Im vorderen Teil von [Evusatria](/banbergen.md "Banbergen") in [Banbergen](/banbergen.md "Banbergen").
-   Vor der Halle [Evusatria](/banbergen.md "Banbergen") in [Banbergen](/banbergen.md "Banbergen").

## Besonderheit

Der Gedriht gehört zu den NPCs, die ständig wechselnde Adjektive haben. Diese werden hier nicht gesondert aufgelistet.

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Midgard
- Rasse: Mensch
- Tätigkeit: Wächter

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Gedriht/Evusatria)
