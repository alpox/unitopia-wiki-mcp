---
type: Wiki Article
title: Elanor/Midgard
description: ""
resource: "http://unitopia.intelligense.de/wiki/Elanor/Midgard"
tags: [Fundort/Kauf, Gegenstand, Gegenstand/Midgard, Gegenstand/Midgard/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Pflanzlich, Info/Schwimmt]
timestamp: 2024-04-23T19:27:42Z
revid: 239106
namespace: 0
contenthash: 7ea627d57c606ce23127512daed6c7138d3cf261e36cfb7c98de649f61837429
---

## Aussehen

Die Elanor ist eine kleine, goldfarbene Blume. Sie ist wunderschoen mit
ihren leuchtenden Bluetenblaettern und dem Duft, den sie verstroemt!

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Pflanzlich](/kategorie/info-material-pflanzlich.md "Kategorie:Info/Material/Pflanzlich") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

-   Zu kaufen bei [Marei](/marei.md "Marei") auf dem Kahn am Trödelmarkt von [Bruggstad](/bruggstad.md "Bruggstad").
-   In den Weiten [Midgards](/midgard.md "Midgard").


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Midgard
- Material: Pflanzlich
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Elanor/Midgard)
