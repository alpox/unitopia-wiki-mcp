---
type: Wiki Article
title: Aprikose/Obstkorb
description: Im Obstkorb im Salon des Stadthauses von Londar.
resource: "http://unitopia.intelligense.de/wiki/Aprikose/Obstkorb"
tags: [Adjektiv, Gegenstand, Gegenstand/Midgard, Gegenstand/Midgard/Sonstige, Gegenstand/Sonstige, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Wachs]
timestamp: 2024-03-02T19:20:18Z
revid: 220624
namespace: 0
contenthash: b12aabc3554bd78e3260d2ed1f6d5183066c8788e1d41d7dace97b0d62bdb9bc
---

## Aussehen

Eine Aprikose aus Wachs. Sie sieht einer richtigen Aprikose fast zum
Verwechseln aehnlich - rundlich, mit einer Einkerbung an einer Seite und
auch schoen kraeftig gefaerbt.
Du bist beinahe verlockt, mal reinzubeissen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Wachs](/kategorie/info-material-wachs.md "Kategorie:Info/Material/Wachs") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Im [Obstkorb](/obstkorb.md "Obstkorb") im Salon des [Stadthauses](/londar.md "Londar") von [Londar](/londar.md "Londar").

## Besonderheit

Die Aprikose gehört zu den Gegenständen, die ständig wechselnde Adjektive haben. Diese werden hier nicht gesondert aufgelistet.

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Midgard
- Material: Wachs
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Aprikose/Obstkorb)
