---
type: Wiki Article
title: Dorain
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Dorain"
tags: [NPC, NPC/Midgard, NPC/Midgard/defensiv, NPC/defensiv, Rasse, Rasse/Zwerg]
timestamp: 2020-05-29T18:38:17Z
revid: 263575
namespace: 0
contenthash: e5a5a7db9401974d4740f82b84116d550a77b93ece9e8f0f69b5becf930a6847
---

## Aussehen

Dorain sieht selbst fuer einen Zwerg noch raubeinig und versoffen aus. Ein
kecker, gruener Hut thront auf seiner braunen Haarpracht und deutlich sieht
man die Aehnlichkeit zu seiner Schwester Kendra. Auf seiner Nase sitzt
zudem eine unwahrscheinlich coole Sonnenbrille.

## Ausrüstung

Keine.

## Heimat

In der glitzernden Grotte der [Tropfsteinhöhlen von Sala](/tropfsteinhöhlen.md "Tropfsteinhöhlen").

## Besonderheit

Er könnte etwas [Hilfe](/zwerg-will-feiern.md "Zwerg will feiern") bei seinem Durstproblem gebrauchen.

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Midgard
- Rasse: Zwerg

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Dorain)
