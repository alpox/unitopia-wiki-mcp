---
type: Wiki Article
title: Immaculada
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Immaculada"
tags: [NPC, NPC/Midgard, NPC/Midgard/defensiv, NPC/defensiv, Rasse, Rasse/Untoter]
timestamp: 2018-11-07T18:29:56Z
revid: 217583
namespace: 0
contenthash: 874a841005104375b6e1590a59500c58cd52e0d9d8b9591a27363d2a9ff59c2e
---

## Aussehen

Du erblickst ein zierliches Maedchen mit erschreckend blasser Haut, welches
sich verfuehrerisch zwischen den schwarzen Laken raekelt. Sie hat den Kopf
leicht in den Nacken gelegt und bietet einen entzueckenden Ausblick auf
eine weisse Kehle und ein tiefes Dekolletee. Ihre strahlend blauen Augen
mustern dich vertraeumt und ein leichtes Laecheln umspielt ihre vollen
Lippen. Ihre langen, leicht zerzausten, blonden Haare fallen ihr ins
Gesicht und lassen sie ziemlich jung und unschuldig wirken. Immaculada
traegt ein kurzes Kleid aus weisser Seide, welches etwas hochgerutscht ist,
so dass du einen freien Blick auf lange, schlanke Beine und makellose
Schenkel hast. Ihre bezaubernde Figur zeichnet sich leicht unter dem
duennen Stoff ab, so dass du sie fasziniert anstarrst. Ein samtenes,
weisses Band, an dem ein Amulett baumelt, ziert ihren Hals. Sie ist
Radamirs zweite Tochter.

## Ausrüstung

Keine.

## Heimat

Im Gästezimmer der [Herberge "Zum blutigen Knochen"](/vampyrschloss.md "Vampyrschloss") im [Vampyrschloss](/vampyrschloss.md "Vampyrschloss").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Midgard
- Rasse: Untoter

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Immaculada)
