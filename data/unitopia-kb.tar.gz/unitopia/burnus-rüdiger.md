---
type: Wiki Article
title: Burnus/Rüdiger
description: Burnus von Rüdiger auf Rundgang in ganz Dörrstadt.
resource: "http://unitopia.intelligense.de/wiki/Burnus/Rüdiger"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Textil, Info/Temperaturschutz, Info/Temperaturschutz/gut gegen die Wüstenhitze, Kleidung, Kleidung/Brust, Kleidung/Dörrland, Kleidung/Dörrland/Brust]
timestamp: 2024-03-02T19:20:26Z
revid: 266882
namespace: 0
contenthash: f57670c44fef0f97c3b5abcab2149cf539ba0b94991c47e824eb781be44ce585
---

## Aussehen

Der Burnus ist eine Art Hemd (oder Kleid?) - auf jeden Fall ein Gewand, wie
es fuer die Wuestenbewohner Doerrlands typisch ist. Er ist leicht und
schuetzt erstaunlich gut vor der sengenden Sonne. Dieses spezielle Exemplar
hier ist allerdings nur knielang und starrt vor Schmutz. Wenn es schon mal
bessere Zeiten gehabt hat, dann muessen die im letzten Jahrhundert gewesen
sein.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [gut gegen die Wüstenhitze](/kategorie/info-temperaturschutz-gut-gegen-die-wüstenhitze.md "Kategorie:Info/Temperaturschutz/gut gegen die Wüstenhitze") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Burnus von [Rüdiger](/rüdiger.md "Rüdiger") auf Rundgang in ganz [Dörrstadt](/dörrstadt.md "Dörrstadt").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Brust
- Gegend: Dörrland
- Material: Textil
- Temperaturschutz: gut gegen die Wüstenhitze
- Gewicht: 2
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Burnus/Rüdiger)
