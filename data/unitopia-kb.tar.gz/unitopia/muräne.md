---
type: Wiki Article
title: Muräne
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Muräne"
tags: [NPC, NPC/Nordische Inseln, NPC/Nordische Inseln/aggressiv, NPC/aggressiv, Rasse, Rasse/Fisch]
timestamp: 2018-11-07T18:31:14Z
revid: 212370
namespace: 0
contenthash: 5a84be985f8ed7d3fcdfc11b3381214cbc1cfe4868dbbda79c956f1e3fe3cf80
---

## Aussehen

Aus dunklen Augenhoehlen glitzern dich zwei Raubtieraugen an. Dieses Biest
ist ueber drei Meter lang und erinnert aeusserlich sehr an eine Schlange.
Die schuppige Haut der Muraene, vor allem aber der spitze Kopf und die
kammartige Rueckenflosse, die sich vom Kopf bis zur Schwanzspitze zieht,
sind mit Stacheln uebersaet. Dazu passend reihen sich in den extrem
muskuloes aussehenden Kiefern unzaehlige scharfe Zaehne auf. Sie weiss von
dir.

## Ausrüstung

Keine.

## Heimat

Im Wrack der "[Marie Celeste](/marie-celeste.md "Marie Celeste")" unterhalb der Klippen von [Imneboerg](/imneboerg.md "Imneboerg").

## Besonderheit

Weidet man ihre Leiche aus, findet man darin wichtige Teile vom Spiel [Materie](/materie.md "Materie").

* * *


## Kenndaten

- Typ: aggressiv
- Gegend: Nordische Inseln
- Rasse: Fisch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Muräne)
