---
type: Wiki Article
title: Lederkoffer
description: Im Keller des leerstehenden Hauses in Borsippa.
resource: "http://unitopia.intelligense.de/wiki/Lederkoffer"
tags: [Behälter, Behälter/Kleine, Behälter/Vaniorh, Behälter/Vaniorh/Kleine, Info, Info/Brennbar, Info/Fasst, Info/Fasst/Gegenstand, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Leder, Info/Volumen, Info/Volumen/8]
timestamp: 2026-03-18T18:21:13Z
revid: 246583
namespace: 0
contenthash: 01179837a14cd6c4f8da78ad2c0a88fc8cb0845be1d3fda664a0e008ffd37dd5
---

## Aussehen

Der Koffer besteht aus fleckigem alten Leder und sieht ziemlich schaebig
aus. Ein Wunder, dass er noch haelt.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder") |
| --- | --- |
| **[Fasst](/kategorie/info-fasst.md "Kategorie:Info/Fasst"):** | [Gegenstand](/kategorie/gegenstand-sonstige.md "Kategorie:Gegenstand/Sonstige") |
| **[Volumen](/kategorie/info-volumen.md "Kategorie:Info/Volumen"):** | 8 |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Im Keller des leerstehenden Hauses in [Borsippa](/borsippa.md "Borsippa").

## Besonderheit

Der Koffer enthält anfangs einen [Degen](/degen-lederkoffer.md "Degen/Lederkoffer") und ein [Capa](/tuch-lederkoffer.md "Tuch/Lederkoffer").

* * *


## Kenndaten

- Kategorie: Behälter
- Typ: Kleine
- Gegend: Vaniorh
- Material: Leder
- Fasst: Gegenstand
- Volumen: 8
- Gewicht: 2
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Lederkoffer)
