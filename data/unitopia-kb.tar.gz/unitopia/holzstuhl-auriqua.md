---
type: Wiki Article
title: Holzstuhl/Auriqua
description: Im Gasthaus von Auriqua.
resource: "http://unitopia.intelligense.de/wiki/Holzstuhl/Auriqua"
tags: [Gegenstand, Gegenstand/Midgard, Gegenstand/Midgard/Möbel, Gegenstand/Möbel, Info, Info/Brennbar, Info/Gewicht, Info/Gewicht/10, "Info/Gewicht/10-19", Info/Material, Info/Material/Holz, Info/Schwimmt]
timestamp: 2024-03-02T19:20:29Z
revid: 245201
namespace: 0
contenthash: d704f14a43602ccaf5cff416fca430cf4faa41d2d4050fb85f1aa52e44bcdd75
---

## Aussehen

Ein breiter, stabiler Stuhl aus massivem Holz.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [10 (sehr schwer)](/kategorie/info-gewicht-10.md "Kategorie:Info/Gewicht/10") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Im Gasthaus von [Auriqua](/auriqua.md "Auriqua").

## Funktion

setze auf stuhl

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Möbel
- Gegend: Midgard
- Material: Holz
- Gewicht: 10
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Holzstuhl/Auriqua)
