---
type: Wiki Article
title: Quietsche
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Quietsche"
tags: [NPC, NPC/Vaniorh, NPC/Vaniorh/defensiv, NPC/defensiv, Rasse, Rasse/Konstrukt]
timestamp: 2018-11-07T18:30:23Z
revid: 252832
namespace: 0
contenthash: 9575fc258c0d45ef54af3148f093cb9a6aa17d8a331d27800df9bf7bb82bb18d
---

## Aussehen

Die Quietsche betrachtet Dich zutraulich aus grossen rosa Augen, die direkt
auf dem knallgelben Trompetenschnabel sitzen. Das possierliche Tierchen hat
Entenfuesse, die an kurzen Beinen an dem unfoermigen, lila Blasebalg
haengen, welcher den Koerper der Quietsche darstellen soll.

## Ausrüstung

Keine.

## Heimat

Im [Wunderhaus](/terqa.md "Terqa") in [Terqa](/terqa.md "Terqa").

## Besonderheit

Drückt man die Quietsche, fliegt man aus dem Wundergarten wieder raus.

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Vaniorh
- Rasse: Konstrukt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Quietsche)
