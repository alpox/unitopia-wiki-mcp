---
type: Wiki Article
title: Russbedeckt/normal
description: Von einem Mitglied vom Orden der Finsternis.
resource: "http://unitopia.intelligense.de/wiki/Russbedeckt/normal"
tags: [Fundort, Info, Info/Heilung, Info/Wirkung, Info/Wirkung/Zustand, Info/Wirkung/Zustand/neutral, Zustand, Zustand/Sonstige, Zustand/Vaniorh, Zustand/Vaniorh/Sonstige]
timestamp: 2024-09-16T12:10:22Z
revid: 267951
namespace: 0
contenthash: 49819d9ab3ddc1411143cba43f5f4ab911830146aabf83f540b670dc2e76956b
---

## Aussehen

Du siehst ziemlich rußverschmiert aus.

## Informationen

| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [neutral](/kategorie/info-wirkung-zustand-neutral.md "Kategorie:Info/Wirkung/Zustand/neutral") |
| --- | --- |
| **[Heilung](/kategorie/info-heilung.md "Kategorie:Info/Heilung"):** | waschen, automatisch |

## Fundort

Von einem Mitglied vom [Orden der Finsternis](/orden-der-finsternis.md "Orden der Finsternis").

## Gefährlichkeit

-   Hält ca. 12 Minuten an.
-   Startmeldung:

Die Feuerstelle explodiert ploetzlich mit einem lauten Knall.

-   Endmeldung:

Die schwarze Schicht aus Russ, die dich umhuellt faellt von dir ab.

* * *


## Kenndaten

- Kategorie: Zustand
- Typ: Sonstige
- Gegend: Vaniorh
- Wirkung: neutral
- Heilung: waschen/automatisch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Russbedeckt/normal)
