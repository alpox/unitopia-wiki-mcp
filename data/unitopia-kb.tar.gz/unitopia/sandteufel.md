---
type: Wiki Article
title: Sandteufel
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Sandteufel"
tags: [NPC, NPC/Dörrland, NPC/Dörrland/defensiv, NPC/defensiv, Rasse, Rasse/Elementar, Rasse/Konstrukt, Rasse/multi]
timestamp: 2018-11-07T18:29:03Z
revid: 211413
namespace: 0
contenthash: 08ee91ad026986e0e88fd8ea6ac5db24e8ce9f1e17dc98f2c27fbc7270d653d2
---

## Aussehen

Ein kleiner Wirbelsturm, der viel Sand aufgewirbelt hat. Er bewegt sich
fast so als waere er lebendig. Aber in einer Welt voller Magie ist alles
moeglich.

## Ausrüstung

Keine.

## Heimat

In der Wüste [Dörrlands](/dörrland.md "Dörrland").

## Besonderheit

-   Wenn man neben einem Sandteufel steht, wird man oft eingesaugt.
-   Beim Versuch rauszukommen, werden einem 10 [AP](/ap.md "AP")[![Ausdauerpunkte](/images/b/b4/AP.gif)](/ap.md "Ausdauerpunkte") abgezogen.

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Dörrland
- Rasse: Elementar/Konstrukt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Sandteufel)
