---
type: Wiki Article
title: Vampire
description: ""
resource: "http://unitopia.intelligense.de/wiki/Vampire"
tags: []
timestamp: 2022-06-02T08:59:12Z
revid: 10284
namespace: 0
contenthash: eea4a84432781fe779d692c10865bdd6e8337c33138986588ceaf7cf8acd2f5b
---

1.  WEITERLEITUNG [Vampyrgilde](/vampyrgilde.md "Vampyrgilde")

* * *

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Vampire)
