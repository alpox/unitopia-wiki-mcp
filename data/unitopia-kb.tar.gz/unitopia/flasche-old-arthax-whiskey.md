---
type: Wiki Article
title: Flasche/Old Arthax Whiskey
description: Flasche vom Old Arthax Whiskey aus dem Spar auf dem Campusgelände der Universität Stuttgart.
resource: "http://unitopia.intelligense.de/wiki/Flasche/Old_Arthax_Whiskey"
tags: [Fundort, Gegenstand, Gegenstand/Campus, Gegenstand/Campus/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Glas]
timestamp: 2024-09-16T12:10:44Z
revid: 226318
namespace: 0
contenthash: cbb5f47a4aa435f1f914272a6c7cb9d0f8ee3fc1664a4d60b1b4167051afcb72
---

## Aussehen

Ein leere Flasche aus Braunglas mit einem Etikett.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Glas](/kategorie/info-material-glas.md "Kategorie:Info/Material/Glas") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Flasche vom [Old Arthax Whiskey](/old-arthax-whiskey.md "Old Arthax Whiskey") aus dem [Spar](/spar.md "Spar") auf dem [Campusgelände](/campusgelände.md "Campusgelände") der [Universität Stuttgart](/universität.md "Universität").

## Besonderheit

Man kann die Flasche bei [Frau Gruber](/gruber.md "Gruber") im [Spar](/spar.md "Spar") zurückgeben.

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Campus
- Material: Glas
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Flasche/Old_Arthax_Whiskey)
