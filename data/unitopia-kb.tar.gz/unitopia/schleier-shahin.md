---
type: Wiki Article
title: Schleier/Shahin
description: Zu kaufen bei Shahin beim Schneider von Sarasande.
resource: "http://unitopia.intelligense.de/wiki/Schleier/Shahin"
tags: [Fundort/Kauf, Hidden, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Kleidung, Kleidung/Dörrland, Kleidung/Dörrland/Kopf, Kleidung/Kopf, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2024-04-23T19:27:46Z
revid: 261559
namespace: 0
contenthash: 93380fda8b7bb7543734e9e0f55114df8cea737c74b24011a3ccf110deeb350c
---

## Aussehen

Ein orientalischer Schleier aus feinster Seide. Er lässt den Traeger
ziemlich geheimnisvoll aussehen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Shahin](/shahin.md "Shahin") beim Schneider von [Sarasande](/sarasande.md "Sarasande").

## Funktion

-   zieh Schleier an
-   zieh Schleier aus

## Besonderheit

-   Der Name ändert sich je nach Geschlecht zu:
    -   Ein verschleierter Mann.
    -   Eine verschleierte Frau.
    -   Ein verschleiertes Etwas.

-   Zusätzliches Aussehen beim Betrachten einer Person:

| -   **Mann:** | Du siehst einen verschleierten Mann. Erst, als Du noch einmal genauer hinsiehst, stellst Du fest, dass es sich um <Spieler> handelt. |
| --- | --- |
| -   **Frau:** | Du siehst eine verschleierte Frau. Erst, als Du noch einmal genauer hinsiehst, stellst Du fest, dass es sich um <Spielerin> handelt. |
| -   **Etwas:** | Du siehst ein verschleiertes Etwas. Erst, als Du noch einmal genauer hinsiehst, stellst Du fest, dass es sich um <Spielendes> handelt. |

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Kopf
- Gegend: Dörrland
- Material: Textil
- Temperaturschutz: wärmt etwas
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein
- ul: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schleier/Shahin)
