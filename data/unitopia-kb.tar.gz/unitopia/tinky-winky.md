---
type: Wiki Article
title: Tinky Winky
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Tinky_Winky"
tags: [NPC, NPC/Gallien, NPC/Gallien/defensiv, NPC/defensiv, Rasse, Rasse/Konstrukt]
timestamp: 2018-11-07T18:31:21Z
revid: 213749
namespace: 0
contenthash: 16c7a2f07befb52c321fc313827190498dc802c223d45986a4b6bbe8e6e9cb15
---

## Aussehen

Tinky Winky ist ein lila Teletubbie und das groesste von den vier hier. Auf
seinem Kopf befindet sich eine dreieckige Antenne und auf seinem Bauch
befindet sich ein Monitor.

## Ausrüstung

Keine.

## Heimat

In den Höhlen des [Beerenhöhlentals](/beerenhöhlental.md "Beerenhöhlental") südlich der [Pyrenäen](/pyrenäen.md "Pyrenäen").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Gallien
- Rasse: Konstrukt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Tinky_Winky)
