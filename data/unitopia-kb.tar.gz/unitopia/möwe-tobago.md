---
type: Wiki Article
title: Möwe/Tobago
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Möwe/Tobago"
tags: [Braten, Braten/Jagen, Braten/Stück, NPC, NPC/Dörrland, NPC/Dörrland/defensiv, NPC/defensiv, Rasse, Rasse/Vogel]
timestamp: 2019-02-13T19:42:30Z
revid: 239227
namespace: 0
contenthash: d93c45cb4cbc0ff8a47867404b768faf697eb32d077c7fa9dda1d2a8929b1ad9
---

## Aussehen

```
Eine grosse Moewe, mit weissen Federn. Die Fluegelspitzen und die
Schwanzfedern sind schwarz. Sie besitzt ausserdem einen kleinen aber
gefaehrlichen Schnabel und zwei dunkle Knopfaugen.
```

## Ausrüstung

Keine.

## Heimat

-   Am Nordwestzipfel der Insel [Tobago](/tobago.md "Tobago").
-   Auf der hervorstehenden Klippe auf [Tobago](/tobago.md "Tobago").
-   Auf der östlichsten aller Klippen auf [Tobago](/tobago.md "Tobago").

## Besonderheit

Nach dem Töten ist die Möwe [bratbar](/braten-magyra.md "Braten/Magyra"). Der Braten lässt sich in mehrere handliche [Braten](/bratenscheibe.md "Bratenscheibe")[scheiben](/braten-scheibe.md "Braten/Scheibe"), [Braten](/bratenstück.md "Bratenstück")[stücke](/braten-stück.md "Braten/Stück") oder [Braten](/bratenteil.md "Bratenteil")[teile](/braten-teil.md "Braten/Teil") zerlegen.

## Kenndaten

- Typ: defensiv
- Gegend: Dörrland
- Rasse: Vogel
- Artikel: die
- Stück: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Möwe/Tobago)
