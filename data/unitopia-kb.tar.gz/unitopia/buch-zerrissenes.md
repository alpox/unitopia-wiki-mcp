---
type: Wiki Article
title: Buch/zerrissenes
description: ""
resource: "http://unitopia.intelligense.de/wiki/Buch/zerrissenes"
tags: [Fundort, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Unbekannt, Schriften, Schriften/Buch, Schriften/Midgard, Schriften/Midgard/Buch]
timestamp: 2024-09-16T12:10:44Z
revid: 229967
namespace: 0
contenthash: 2aff99435034c3630f49ac079b231c968df823b505d816146364cddb59aea6b7
---

## Aussehen

Eine Haelfte eines Zauberbuches, das in der Mitte durchgerissen wurde.
Leider kann man so damit nichts anfangen, aber vielleicht findest du ja die
andere Haelfte.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Unbekannt](/kategorie/info-material-unbekannt.md "Kategorie:Info/Material/Unbekannt") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Buch von [Fredd](/fredd.md "Fredd") der [Zwergenhöhle](/nekromanteninsel.md "Nekromanteninsel") auf der [Nekromanteninsel](/nekromanteninsel.md "Nekromanteninsel").
-   Auf einem Tisch im [Tempel der Nekromanten](/nekromantentempel.md "Nekromantentempel") auf der [Nekromanteninsel](/nekromanteninsel.md "Nekromanteninsel").

* * *


## Kenndaten

- Kategorie: Schriften
- Typ: Buch
- Gegend: Midgard
- Material: Unbekannt
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Buch/zerrissenes)
