---
type: Wiki Article
title: Lederschürze/Panian
description: Rüstung von Panian in der Rüstungsschmiede auf der Festung von Magny.
resource: "http://unitopia.intelligense.de/wiki/Lederschürze/Panian"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Leder, Info/Rüstungsstärke, Info/Rüstungsstärke/schwach, Info/Rüstungszustand, Info/Rüstungszustand/mäßig haltbar, Rüstung, Rüstung/Brust, Rüstung/Midgard, Rüstung/Midgard/Brust]
timestamp: 2024-03-02T19:19:28Z
revid: 227631
namespace: 0
contenthash: e255e38fd70ad80a40f5d0865ab48a3bb7d90f85f3cf3caec7b1104f9672c4bb
---

## Aussehen

Eine alte Lederschuerze, wie sie Schmiede oft tragen.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder") |
| --- | --- |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [2 (schwach)](/kategorie/info-rüstungsstärke-schwach.md "Kategorie:Info/Rüstungsstärke/schwach") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [3 (mäßig haltbar)](/kategorie/info-rüstungszustand-mäßig-haltbar.md "Kategorie:Info/Rüstungszustand/mäßig haltbar") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Rüstung von [Panian](/panian.md "Panian") in der Rüstungsschmiede auf der [Festung](/magny.md "Magny") von [Magny](/magny.md "Magny").

* * *


## Kenndaten

- Kategorie: Rüstung
- Typ: Brust
- Gegend: Midgard
- Material: Leder
- Rüstungsstärke: schwach
- Rüstungszustand: mäßig haltbar
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Lederschürze/Panian)
