---
type: Wiki Article
title: Zorkmid
description: ""
resource: "http://unitopia.intelligense.de/wiki/Zorkmid"
tags: [Fundort, Gegenstand, Gegenstand/Campus, Gegenstand/Campus/Geld, Gegenstand/Dörrland, Gegenstand/Dörrland/Geld, Gegenstand/Ebenen, Gegenstand/Ebenen/Geld, Gegenstand/Gallien, Gegenstand/Gallien/Geld, Gegenstand/Geld, Gegenstand/Kokosinseln, Gegenstand/Kokosinseln/Geld, Gegenstand/Levitanis, Gegenstand/Levitanis/Geld, Gegenstand/Midgard, Gegenstand/Midgard/Geld, Gegenstand/Märchenland, Gegenstand/Märchenland/Geld, Gegenstand/Nordische Inseln, Gegenstand/Nordische Inseln/Geld, Gegenstand/Ozean, Gegenstand/Ozean/Geld, Gegenstand/Vaniorh, Gegenstand/Vaniorh/Geld, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Edelmetall]
timestamp: 2024-09-16T12:10:32Z
revid: 254433
namespace: 0
contenthash: 9d82d19898a022dbb35bc216fbe1e8f513e83dbc729047204bab92abdf81f55e
---

## Aussehen

```
Ein Zorkmid.
```

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Edelmetall](/kategorie/info-material-edelmetall.md "Kategorie:Info/Material/Edelmetall") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Direkt oder per Wechselschalter in jeder [Bank](/bank.md "Bank") in [UNItopia](/unitopia.md "Unitopia").
-   Per Bankier durch die [Kristallkugel](/kristallkugel.md "Kristallkugel") in ganz [UNItopia](/unitopia.md "Unitopia").

## Funktion

-   Zahlungsmittel im [Felsenkloster Laksos](/felsenkloster-laksos.md "Felsenkloster Laksos").
-   schnipp zorkmid

## Wechselkurs

| Valuta | Zorkmid |
| --- | --- |
| 1000 [Dinar](/dinar-währung.md "Dinar/Währung") | 877 |
| 1000 [Dukaten](/dukate.md "Dukate") | 65 |
| 1000 [Drachmen](/drachme.md "Drachme") | 750 |
| 1000 [Franken](/franken-währung.md "Franken/Währung") | 384 |
| 1000 [Gulden](/gulden-währung.md "Gulden/Währung") | 625 |
| 1000 [Groschen](/groschen.md "Groschen") | 54 |
| 1000 [Kauri](/kauri.md "Kauri") | 200 |
| 1000 [Kronen](/krone-währung.md "Krone/Währung") | 1000 |
| 1000 [Mark](/mark-währung.md "Mark/Währung") | 1501 |
| 1000 [Riki](/riki-währung.md "Riki/Währung") | 250 |
| 1000 [Sesterze](/sesterz.md "Sesterz") | 1250 |
| 1000 [Taler](/taler-währung.md "Taler/Währung") | 500 |

| Valuta | Zorkmid |  |
| --- | --- | --- |
| 1140 | [Dinar](/dinar-währung.md "Dinar/Währung") | 1000 |
| 15380 | [Dukaten](/dukate.md "Dukate") | 1000 |
| 1332 | [Drachmen](/drachme.md "Drachme") | 1000 |
| 2600 | [Franken](/franken-währung.md "Franken/Währung") | 1000 |
| 1600 | [Gulden](/gulden-währung.md "Gulden/Währung") | 1000 |
| 18400 | [Groschen](/groschen.md "Groschen") | 1000 |
| 5000 | [Kauri](/kauri.md "Kauri") | 1000 |
| 1000 | [Kronen](/krone-währung.md "Krone/Währung") | 1000 |
| 666 | [Mark](/mark-währung.md "Mark/Währung") | 1000 |
| 4000 | [Riki](/riki-währung.md "Riki/Währung") | 1000 |
| 800 | [Sesterze](/sesterz.md "Sesterz") | 1000 |
| 2000 | [Taler](/taler-währung.md "Taler/Währung") | 1000 |

## Kenndaten

- Kategorie: Gegenstand
- Typ: Geld
- Material: Edelmetall
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein
- Valuta: 1000

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Zorkmid)
