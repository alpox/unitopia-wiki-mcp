---
type: Wiki Article
title: Eimer/Kosmo
description: Gefäß von Kosmo in der Dritten Alchemistenprüfung der Alchemistengilde von Borsippa.
resource: "http://unitopia.intelligense.de/wiki/Eimer/Kosmo"
tags: [Behälter, Behälter/Gefäß, Behälter/Vaniorh, Behälter/Vaniorh/Gefäß, Info, Info/Fasst, Info/Fasst/Flüssigkeit, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Metall]
timestamp: 2026-03-18T18:20:49Z
revid: 232361
namespace: 0
contenthash: 2b79d07a74d495759bee6f8a0d8e5757193d4b15f0f896cba752acda3d9890d4
---

## Aussehen

Ein metallener Eimer zur sicheren Aufbewahrung von bis zu zehn Litern
Saeure.
Er enthaelt 10 Liter Saeure.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Fasst](/kategorie/info-fasst.md "Kategorie:Info/Fasst"):** | [Flüssigkeit](/flüssigkeit.md "Flüssigkeit") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Gefäß von [Kosmo](/kosmo.md "Kosmo") in der Dritten Alchemistenprüfung der [Alchemistengilde](/alchemistengilde.md "Alchemistengilde") von [Borsippa](/borsippa.md "Borsippa").

* * *


## Kenndaten

- Kategorie: Behälter
- Typ: Gefäß
- Gegend: Vaniorh
- Material: Metall
- Fasst: Flüssigkeit
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Eimer/Kosmo)
