---
type: Wiki Article
title: Dämonenschwert/Dämonenlord
description: Waffe vom Dämonenlord im Labyrinth vom Sichermal.
resource: "http://unitopia.intelligense.de/wiki/Dämonenschwert/Dämonenlord"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/7, Info/Material, Info/Material/Metall, Info/Waffenstärke, Info/Waffenzustand, Info/Waffenzustand/wenig haltbar, Waffe, Waffe/Dörrland, Waffe/Dörrland/Langschwert, Waffe/Langschwert]
timestamp: 2024-03-02T19:19:38Z
revid: 228693
namespace: 0
contenthash: 3b7d2cd0b4ce2f88d7491b6ef8117e90648078c210c1370e4e0882fe076926d1
---

## Aussehen

Ein Daemonenschwert aus einem dir unbekannten Material, das wegen seines
Schimmers durchaus als Metall identifizierbar ist.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Metall](/kategorie/info-material-metall.md "Kategorie:Info/Material/Metall") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [siehe Besonderheit](#Besonderheit) |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [2 (wenig haltbar)](/kategorie/info-waffenzustand-wenig-haltbar.md "Kategorie:Info/Waffenzustand/wenig haltbar") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [7 (eher schwer)](/kategorie/info-gewicht-7.md "Kategorie:Info/Gewicht/7") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Waffe vom [Dämonenlord](/dämonenlord.md "Dämonenlord") im Labyrinth vom [Sichermal](/sichermal.md "Sichermal").

## Besonderheit

Das Schwert kann nur von [Dämonen](/dämonen.md "Dämonen") geführt werden.

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Langschwert
- Gegend: Dörrland
- Material: Metall
- Waffenstärke: siehe Besonderheit
- Waffenzustand: wenig haltbar
- Gewicht: 7
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Dämonenschwert/Dämonenlord)
