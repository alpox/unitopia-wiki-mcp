---
type: Wiki Article
title: "Leuchtfisch/String-Dreieck"
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Leuchtfisch/String-Dreieck"
tags: [NPC, NPC/Dörrland, NPC/Dörrland/defensiv, NPC/defensiv, Rasse, Rasse/Fisch]
timestamp: 2018-11-07T18:34:58Z
revid: 260557
namespace: 0
contenthash: bc746b25762cfd35b591b671e1e970788d925f5506e597dbef661d7b5206c538
---

## Aussehen

Ein kleiner Leuchtfisch.
Ein kleiner, schlanker Fisch mit schillernden Flossen. Sein gesamter
Koerper leuchtet in einem bläulich gruenen Licht.

## Ausrüstung

Keine.

## Heimat

-   In der [Unterwassersiedlung](/unterwassersiedlung.md "Unterwassersiedlung") im [String-Dreieck](/string-dreieck.md "String-Dreieck").
-   Im [dichten Unterwasserwald](/unterwasserwald.md "Unterwasserwald") im [String-Dreieck](/string-dreieck.md "String-Dreieck").

## Besonderheit

Der Fisch hat eine [Leuchtkraft](/kategorie/info-licht-leuchtet.md "Kategorie:Info/Licht/leuchtet") von +7.

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Dörrland
- Rasse: Fisch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Leuchtfisch/String-Dreieck)
