---
type: Wiki Article
title: Storchenei/Storchennest2
description: Durch das Storchenei im Storchennest im südlichen Stadtgraben von Tadmor.
resource: "http://unitopia.intelligense.de/wiki/Storchenei/Storchennest2"
tags: [Behälter, Behälter/Gefäß, Behälter/Vaniorh, Behälter/Vaniorh/Gefäß, Info, Info/Fasst, Info/Fasst/Flüssigkeit, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Glas, Info/Material/Leder, Info/Volumen, Info/Volumen/8]
timestamp: 2026-03-18T18:21:15Z
revid: 214117
namespace: 0
contenthash: 2397d7a04e481acdf6a67d7c1ccc7bddcd1c00585f6507b2d3dc694b91e7ce6a
---

## Aussehen

Ein leergeschluerftes Storchenei.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Glas](/kategorie/info-material-glas.md "Kategorie:Info/Material/Glas"), [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder") |
| --- | --- |
| **[Fasst](/kategorie/info-fasst.md "Kategorie:Info/Fasst"):** | [Flüssigkeit](/flüssigkeit.md "Flüssigkeit") |
| **[Volumen](/kategorie/info-volumen.md "Kategorie:Info/Volumen"):** | 8 |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Durch das [Storchenei](/storchenei-storchennest.md "Storchenei/Storchennest") im [Storchennest](/storchennest.md "Storchennest") im [südlichen Stadtgraben](/tadmor.md "Tadmor") von [Tadmor](/tadmor.md "Tadmor").

* * *


## Kenndaten

- Kategorie: Behälter
- Typ: Gefäß
- Gegend: Vaniorh
- Material: Glas/Leder
- Fasst: Flüssigkeit
- Volumen: 8
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Storchenei/Storchennest2)
