---
type: Wiki Article
title: Tonschale/Ordos
description: Zu kaufen bei Ordos im Nautischen Zubehörladen von Knossos auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/Tonschale/Ordos"
tags: [Fundort/Kauf, Gegenstand, Gegenstand/Kokosinseln, Gegenstand/Kokosinseln/Sonstige, Gegenstand/Sonstige, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Keramik]
timestamp: 2024-04-23T19:27:32Z
revid: 209418
namespace: 0
contenthash: 6f9513466cbfd91f2696e0586a8837f5f0ac6c9b6cf2c1f852739e2e13ae29b8
---

## Aussehen

Eine kleine, handliche und feuerfeste Tonschale mit ein paar Russspuren am
Rand. Sie hat unten einen flachen Standfuß und einen griffigen Henkel zum
Anfassen, an dem noch ein kleiner Zettel befestigt wurde.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Keramik](/kategorie/info-material-keramik.md "Kategorie:Info/Material/Keramik") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Ordos](/ordos.md "Ordos") im Nautischen Zubehörladen von [Knossos](/knossos.md "Knossos") auf [Kreta](/kreta.md "Kreta").

## Funktion

Die Tonschale ist dazu da um Räume auf seinem Schiff zu ändern. Hier ganz speziell den Geruch des Raumes. Dafür legt man die jeweilige Schale in dem gewünschten Raum auf den Boden und zündet sie an. Die Schale erlischt nach kurzer Zeit von allein und der Geruch hat sich im Raum festgesetzt. Leider brennt die Schale nur einmal und kann/muss danach entsorgt werden.

## Gerüche

Die Tonschale gibt es in 12 verschiedenen Geruchsrichtungen. Auf dem Zettel an der Schale steht eine Kurzbeschreibung:

-   Die Brücke | Spindrift

Die aufspritzende Gischt vom Bug riecht nach Abenteuer, Freiheit und Ozean.

-   Die Reling | Sanfte Brise

Der sanfte Geruch des Meeres nach Salz, Algen und Feuchtigkeit durchweht alle Decks.

-   Die Masten | Krähennest

Der zischende Wind trägt den Geruch der azurblauen Weite und das Versprechen nach neuen Ufern.

-   Das Sonnendeck | Soleil

Ein interessantes olfaktorisches Gemisch aus Pflanzen, Meer und Sonnenöl.

-   Das Bad | Spa

Hier duftet es aber gut nach Seife und kostbaren Badezusätzen, Salben und Ölen.

-   Das Schlafzimmer | Plumard

Es riecht nach nach Schlaf und frisch gewaschener Wäsche.

-   Der Tierstall | Animals

Es riecht nach warmen, lebendigen Tierkörpern und flauschigem Fell mit einer Herznote aus Heuduft und tiefer versteckt in der Basis nach Futter.

-   Die Waffenkammer | Combat

Ein deutlicher Geruch nach Waffenöl und Lederpolitur mit Anklängen an Metall und Leder liegt in der Luft.

-   Die Küche | La Cuisine

Oh lala, ein wahrer Sturzbach an olfaktorischen Eindrücken überflutet deine Nase: leckerer Bratenduft, scharfe Gewürze, frischer Kuchen, knusprige Kekse und frischgebackenes Brot.

-   Erde | Earth

Der erdige Duft von fruchtbarer, feuchten Humus und Wurzeln wie nach einem warmen Sommerregen umschmeichelt deine Nase.

-   Der Garten | Garden

Der wunderbare Duft von grünem Gras wird vom frischen Blumenduft begleitet. Am liebsten würdest du hier gleich ein Picknick veranstalten.

-   Raucher | Smokey

In der Luft liegt der besondere Duft den teuersten und edelsten Tabaken. Was hier verbrannt wurde hat eine Menge gekostet.

-   Labor | Purgatorium

Die stickige Luft riecht stark nach Schwefel, Schwarzpulver und anderen, undefinierbaren Substanzen.

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Kokosinseln
- Material: Keramik
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Tonschale/Ordos)
