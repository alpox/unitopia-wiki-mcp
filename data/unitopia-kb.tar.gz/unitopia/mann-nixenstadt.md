---
type: Wiki Article
title: Mann/Nixenstadt
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Mann/Nixenstadt"
tags: [NPC, NPC/Ebenen, NPC/Ebenen/defensiv, NPC/defensiv, Rasse, Rasse/Mensch]
timestamp: 2018-11-07T18:28:20Z
revid: 212833
namespace: 0
contenthash: dafff97d3ddcc8220006bc6ab8ee428683cc4ac48fe565b590aa930527665c1f
---

## Aussehen

Ein komisch aussehender Mann mit einem Nixencocktail in der Hand.
Ihn umgibt eine Luftblase.

## Ausrüstung

Keine.

## Heimat

In der Kneipe von [Nixenstadt](/nixenstadt.md "Nixenstadt") auf [Okeanos](/okeanos.md "Okeanos").

* * *


## Kenndaten

- Typ: defensiv
- Gegend: Ebenen
- Rasse: Mensch

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Mann/Nixenstadt)
