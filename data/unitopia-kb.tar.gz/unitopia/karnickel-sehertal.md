---
type: Wiki Article
title: Karnickel/Sehertal
description: Keine.
resource: "http://unitopia.intelligense.de/wiki/Karnickel/Sehertal"
tags: [NPC, NPC/Nordische Inseln, NPC/Nordische Inseln/defensiv, NPC/defensiv, Rasse, Rasse/Säugetier]
timestamp: 2018-11-07T18:31:04Z
revid: 212398
namespace: 0
contenthash: db842d199a13155a3e3d7944bb1a37200159823df1637a087775ec30b4ab445e
---

## Aussehen

Das Karnickel hat ein grau-braunes Fell. Wenn es stehenbleibt, schaut es
Dich mit seinen schwarzen Augen an. Aus sicherer Entfernung mustert es
Dich. Es kaut genuesslich Gras.

## Ausrüstung

Keine.

## Heimat

Im [Sehertal](/sehertal.md "Sehertal") auf [Thule](/thule.md "Thule").


## Kenndaten

- Typ: defensiv
- Gegend: Nordische Inseln
- Rasse: Säugetier

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Karnickel/Sehertal)
