---
type: Wiki Article
title: Saphir/Tatzelwurm/Istaro
description: "Bei der Leiche von Arcanarton's Tatzelwurm im Brunnenschacht auf Istaro im Düsterwald südwestlich des Terqa-Handelsweges."
resource: "http://unitopia.intelligense.de/wiki/Saphir/Tatzelwurm/Istaro"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Edelstein, Mineral, Mineral/Edelstein, Mineral/Vaniorh, Mineral/Vaniorh/Edelstein]
timestamp: 2024-03-02T19:20:59Z
revid: 217978
namespace: 0
contenthash: 6934be28f90847b980dc44b1bf87b90e68755706efc25c17b0d3cfa6c0fe4eb6
---

## Aussehen

Der Saphir leuchtet in einer hellen Farbe.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Edelstein](/kategorie/info-material-edelstein.md "Kategorie:Info/Material/Edelstein") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Bei der Leiche von [Arcanarton's Tatzelwurm](/tatzelwurm-istaro.md "Tatzelwurm/Istaro") im Brunnenschacht auf [Istaro](/istaro.md "Istaro") im [Düsterwald](/düsterwald-vaniorh.md "Düsterwald/Vaniorh") südwestlich des [Terqa-Handelsweges](/handelsweg-terqa.md "Handelsweg/Terqa").

## Wirkung

| Waffe | Effekt |
| --- | --- |
| [blauglänzende Axt](/axt-blauglänzende.md "Axt/blauglänzende") |  |
| [blauglänzender Degen](/degen-blauglänzender.md "Degen/blauglänzender") |  |
| [blauglänzender Dolch](/dolch-blauglänzender.md "Dolch/blauglänzender") |  |
| [blauglänzender Kampfhammer](/kampfhammer-blauglänzender.md "Kampfhammer/blauglänzender") |  |
| [blauglänzender Kampfstab](/kampfstab-blauglänzender.md "Kampfstab/blauglänzender") |  |
| [blauglänzendes Kurzschwert](/kurzschwert-blauglänzendes.md "Kurzschwert/blauglänzendes") |  |
| [blauglänzendes Langschwert](/langschwert-blauglänzendes.md "Langschwert/blauglänzendes") |  |
| [blauglänzender Säbel](/säbel-blauglänzender.md "Säbel/blauglänzender") |  |

* * *


## Kenndaten

- Kategorie: Mineral
- Typ: Edelstein
- Gegend: Vaniorh
- Material: Edelstein
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Saphir/Tatzelwurm/Istaro)
