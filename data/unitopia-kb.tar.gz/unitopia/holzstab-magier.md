---
type: Wiki Article
title: Holzstab/Magier
description: Waffe vom grauen Magier auf einem Pfad in Fabeln.
resource: "http://unitopia.intelligense.de/wiki/Holzstab/Magier"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/3, Info/Material, Info/Material/Holz, Info/Schwimmt, Info/Waffenstärke, Info/Waffenstärke/geht so, Info/Waffenzustand, Info/Waffenzustand/sehr solide, Waffe, Waffe/Midgard, Waffe/Midgard/Stock, Waffe/Stock]
timestamp: 2024-03-02T19:19:04Z
revid: 230076
namespace: 0
contenthash: dfc8b6e3c3ec5e0e676c2b83492d776b62393c53da5df32f3ff4a203465616f1
---

## Aussehen

Ein langer und duenner Holzstab. Er gehoert der graue Magier, der diesen
Holzstab mit auf saemtliche Reisen durch die ganze Welt nimmt.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Holz](/kategorie/info-material-holz.md "Kategorie:Info/Material/Holz") |
| --- | --- |
| **[Waffenstärke](/kategorie/info-waffenstärke.md "Kategorie:Info/Waffenstärke"):** | [4 (geht so)](/kategorie/info-waffenstärke-geht-so.md "Kategorie:Info/Waffenstärke/geht so") |
| **[Waffenzustand](/kategorie/info-waffenzustand.md "Kategorie:Info/Waffenzustand"):** | [7 (sehr solide)](/kategorie/info-waffenzustand-sehr-solide.md "Kategorie:Info/Waffenzustand/sehr solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [3 (schon eher leicht)](/kategorie/info-gewicht-3.md "Kategorie:Info/Gewicht/3") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | [ja](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt") |

## Fundort

Waffe vom [grauen Magier](/magier.md "Magier") auf einem Pfad in [Fabeln](/fabeln.md "Fabeln").

* * *


## Kenndaten

- Kategorie: Waffe
- Typ: Stock
- Gegend: Midgard
- Material: Holz
- Waffenstärke: geht so
- Waffenzustand: sehr solide
- Gewicht: 3
- Licht: 0
- Brennbar: ja
- Schwimmt: ja

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Holzstab/Magier)
