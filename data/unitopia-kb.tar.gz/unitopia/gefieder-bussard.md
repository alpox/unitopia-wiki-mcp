---
type: Wiki Article
title: Gefieder/Bussard
description: Auszurupfen vom toten Bussard in den Weiten Midgards.
resource: "http://unitopia.intelligense.de/wiki/Gefieder/Bussard"
tags: [Gegenstand, Gegenstand/Midgard, Gegenstand/Midgard/Sonstige, Gegenstand/Sonstige, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Bein, Info/Material/Textil]
timestamp: 2024-03-02T19:20:54Z
revid: 222366
namespace: 0
contenthash: 950245e9288b260fdcff60f45f311ac4eaf2b5663318bcb2077a61cfb1739643
---

## Aussehen

Das Gefieder wurde nicht fachgerecht abgebalgt, sondern einfach
ausgerissen. Jetzt ist es weder schoen, noch wertvoll.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Bein](/kategorie/info-material-bein.md "Kategorie:Info/Material/Bein"), [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Auszurupfen vom [toten Bussard](/bussard.md "Bussard") in den Weiten [Midgards](/midgard.md "Midgard").

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Midgard
- Material: Bein/Textil
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Gefieder/Bussard)
