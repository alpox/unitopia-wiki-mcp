---
type: Wiki Article
title: Kerze/Holle3
description: Zu kaufen bei Herrn Holle in einem verwinkelten kleinen Laden in Koboldingen.
resource: "http://unitopia.intelligense.de/wiki/Kerze/Holle3"
tags: [Fundort/Kauf, Gegenstand, Gegenstand/Märchenland, Gegenstand/Märchenland/Sonstige, Gegenstand/Sonstige, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Licht, Info/Licht/leuchtet, Info/Material, Info/Material/Wachs]
timestamp: 2024-04-23T19:28:10Z
revid: 206771
namespace: 0
contenthash: 644471cf498ef6bc25b2745c0672f50a3677e6826286629e24c720f5eb03786d
---

## Aussehen

Eine kugelfoermige Kerze aus allerfeinstem Wachs.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Wachs](/kategorie/info-material-wachs.md "Kategorie:Info/Material/Wachs") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel"), [+1 (leuchtet normal)](/kategorie/info-licht-leuchtet.md "Kategorie:Info/Licht/leuchtet") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Herrn Holle](/holle.md "Holle") in einem [verwinkelten kleinen Laden](/koboldingen.md "Koboldingen") in [Koboldingen](/koboldingen.md "Koboldingen").

## Besonderheit

Gibt es in den Farben Rot, Weiß, Violett, Blau oder ohne.

* * *


## Kenndaten

- Kategorie: Gegenstand
- Typ: Sonstige
- Gegend: Märchenland
- Material: Wachs
- Gewicht: 1
- Licht: 0/+1
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Kerze/Holle3)
