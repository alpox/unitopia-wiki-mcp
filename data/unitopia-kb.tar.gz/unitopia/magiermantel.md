---
type: Wiki Article
title: Magiermantel
description: Rüstung von Garethor im Gebirge der Weltumspannenden Berge auf Kreta.
resource: "http://unitopia.intelligense.de/wiki/Magiermantel"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Textil, Info/Rüstungsstärke, Info/Rüstungsstärke/geht so, Info/Rüstungszustand, Info/Rüstungszustand/eher beständig, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Rüstung, Rüstung/Kokosinseln, Rüstung/Kokosinseln/Magie, Rüstung/Magie]
timestamp: 2024-03-02T19:17:36Z
revid: 253221
namespace: 0
contenthash: 0d3ae15bf9da1764ef41160957b9a5b10a883dc0683b39e82df36155c2629031
---

## Aussehen

Dieser beeindruckende, nachtschwarz glaenzende Mantel verleiht seinem
Traeger eine ganz besondere Aura. Sein feines Material gleitet weich und
knisternd durch deine Finger, als spruehten winzige silberne Funken davon.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [3 (geht so)](/kategorie/info-rüstungsstärke-geht-so.md "Kategorie:Info/Rüstungsstärke/geht so") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [4 (eher beständig)](/kategorie/info-rüstungszustand-eher-beständig.md "Kategorie:Info/Rüstungszustand/eher beständig") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Rüstung von [Garethor](/garethor.md "Garethor") im [Gebirge der Weltumspannenden Berge](/weltumspannende-berge.md "Weltumspannende Berge") auf [Kreta](/kreta.md "Kreta").

* * *


## Kenndaten

- Kategorie: Rüstung
- Typ: Magie
- Gegend: Kokosinseln
- Material: Textil
- Temperaturschutz: wärmt etwas
- Rüstungsstärke: geht so
- Rüstungszustand: eher beständig
- Gewicht: 2
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Magiermantel)
