---
type: Wiki Article
title: Rüsselringe
description: In Wurzelhupfs Hütte im tiefsten Wurzelwald auf Nankea.
resource: "http://unitopia.intelligense.de/wiki/Rüsselringe"
tags: [Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/sättigt, Nahrung, Nahrung/Midgard, Nahrung/Midgard/Tier, Nahrung/Tier]
timestamp: 2024-08-29T15:24:16Z
revid: 248204
namespace: 0
contenthash: 8588a5a1fa5f3d81ecc1f5917e5eb3b976b64c26bdde76cc5c1e01fcc3fe9be1
---

## Aussehen

Dies ist eine Portion frittierter Ruesselringe von einem Mammut. Lecker
sehen die Ringe aus, goldig-kross.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [sättigt](/kategorie/info-wirkung-sättigt.md "Kategorie:Info/Wirkung/sättigt") |

## Fundort

In [Wurzelhupfs Hütte](/wurzelhupf.md "Wurzelhupf") im [tiefsten Wurzelwald](/wurzelwald.md "Wurzelwald") auf [Nankea](/nankea.md "Nankea").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Tier
- Gegend: Midgard
- Gewicht: 1
- Wirkung: sättigt

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Rüsselringe)
