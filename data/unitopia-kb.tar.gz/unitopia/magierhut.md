---
type: Wiki Article
title: Magierhut
description: Kleidung von Garnichtda in der Ruine eines Hexenhauses auf einer Lichtung auf Vandras.
resource: "http://unitopia.intelligense.de/wiki/Magierhut"
tags: [Hidden, Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Kleidung, Kleidung/Kopf, Kleidung/Nordische Inseln, Kleidung/Nordische Inseln/Kopf, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2024-03-04T14:49:39Z
revid: 267762
namespace: 0
contenthash: beb99b4dfc3f05e91de3db4f0d4004dc70a0f45de09dab9202f8d49a324740ec
---

## Aussehen

Ein praechtiger Magierhut, reich verziert mit schimmernden Runen und Symbolen.
Er scheint fast eine eigene magische Aura zu besitzen, die jeden in seinen
Bann zieht.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Kleidung von [Garnichtda](/garnichtda.md "Garnichtda") in der Ruine eines Hexenhauses auf einer Lichtung auf [Vandras](/vandras.md "Vandras").

## Besonderheit

Zusätzliches Aussehen beim Betrachten einer Person:

| -   **Mann:** | Er hat einen schön anzusehenden Magierhut auf dem Kopf. |
| --- | --- |
| -   **Frau:** | Sie hat einen schön anzusehenden Magierhut auf dem Kopf. |
| -   **Etwas:** | Es hat einen schön anzusehenden Magierhut auf dem Kopf. |

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Kopf
- Gegend: Nordische Inseln
- Material: Textil
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein
- Mann: Er hat einen schön anzusehenden Magierhut auf dem Kopf.
- Frau: Sie hat einen schön anzusehenden Magierhut auf dem Kopf.
- Etwas: Es hat einen schön anzusehenden Magierhut auf dem Kopf.

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Magierhut)
