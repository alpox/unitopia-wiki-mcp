---
type: Wiki Article
title: Alpen
description: "Die Gallischen Alpen sind ein großes Gebirge, das am Rand Galliens liegt und mit der Grenze nach Rom gen Osten abschließt. Es gibt viel zu erkunden in den Alpen. Hier findet man die Unheimliche Höhle,"
resource: "http://unitopia.intelligense.de/wiki/Alpen"
tags: [Gallien, Karte, Todo, Todo/Nachtragen]
timestamp: 2021-07-28T12:49:04Z
revid: 265398
namespace: 0
contenthash: 6edc3313f8c554e8966e7e5c352d87329f78838f5562604fc415c944aad1603b
---

| **[Koordinaten](/kategorie/kompass.md "Kategorie:Kompass"):** | **[Gegend](/kategorie/magyra.md "Kategorie:Magyra"):** [Gallien](/gallien.md "Gallien") | **[Währung](/kategorie/gegenstand-geld.md "Kategorie:Gegenstand/Geld"):** [Sesterzen](/sesterzen.md "Sesterzen") |
| --- | --- | --- |

Die Gallischen Alpen sind ein großes Gebirge, das am Rand [Galliens](/gallien.md "Gallien") liegt und mit der Grenze nach Rom gen Osten abschließt. Es gibt viel zu erkunden in den Alpen. Hier findet man die [Unheimliche Höhle](#Höhle), die berühmte [Eisbahn](/eisbahn.md "Eisbahn"), es gibt neben vielen anderen Bergen einen besonders hohen Alpengipfel, von dem man auf dem Adler [Silberschwinge](/silberschwinge.md "Silberschwinge") bis nach Midgard fliegen kann und wo es eine Möglichkeit gibt, nach [Levitanis](/levitanis.md "Levitanis") zu kommen, wenn die Wolke über [Gallien](/gallien.md "Gallien") schwebt. Für diese Reise wende man sich vertrauensvoll an [Scottix](/scottix.md "Scottix"), wenn er gerade da ist. In den Alpen gibt es eine einzige Stadt, allerdings ist [Frigorn](/frigorn.md "Frigorn") weitgehend verlassen. Das gefährlichste Geschöpf der Alpen ist der [Yeti](/yeti-alpen.md "Yeti/Alpen"). Wer ihm begegnet, sollte sich schnellstens kampfbereit machen oder das Weite suchen.

# [Karte](#toc)

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

  

[![Todo.gif](/images/f/fa/Todo.gif)](/datei/todo.gif.md)**Zur Überarbeitung wegen inhaltlicher Mängel oder fehlenden Informationen vorgemerkt.** [Hilf mit](/kategorie/todo.md "Kategorie:Todo"), die inhaltlichen Mängel oder fehlende Informationen zu korrigieren oder zu ergänzen.

* * *

**Todo (Nachtragen):** Karte erstellen

## [Eisbahn](#toc)

Die Eisbahn liegt weit im Osten [Galliens](/gallien.md "Gallien") in den Gallischen Alpen. Sie ist bequem über einen abzweigenden Pfad der [Römerstraße V](/römerstraße-v.md "Römerstraße V") zu erreichen. Hat man die Bahn erreicht, muss man sich zuerst bei [Dysprosia](/dysprosia.md "Dysprosia") ein passendes [Ticket](/dysprosia.md "Dysprosia") kaufen und dieses bei [Protactinius](/protactinius.md "Protactinius") entwerten lassen. Gleich geradezu kann man sich bei [Palladius](/palladius.md "Palladius") passende [Schlittschuhe](/schlittschuhe.md "Schlittschuhe") im Austausch gegen die erhaltene Leihmünze ausleihen. Hat man sich diese im Vorraum angezogen, kann es auch schon auf die Eisbahn gehen. Gleich nebenan bewirtet [Terbia](/terbia.md "Terbia") die Gäste der Eisbahn in einem kleinen Gasthof, von dem aus man auch auf die Tribünen und in den Aufenthaltsraum der Eiskunstläufer kommt. Auf dem Tribühnendach hat sich außerdem [Mykell](/mykell.md "Mykell") der freundliche Eisdrache niedergelassen und probiert von seiner Krankheit zu genesen. Frag ihn doch mal ob du ihm vielleicht [helfen](/drachenheilung.md "Drachenheilung") kannst. Wer jemanden auf der Eisbahn anfliegt, wird vom Drachen in seinem Maul zum Eingang getragen. Auch wenn er krank ist, achtet er sehr darauf, dass man ein Ticket kauft. Und wer auf der Eisbahn abfliegt, kommt in den [Luftraum über der Eisbahn](#Luftraum_über_der_Eisbahn), wo der Drache so gerne fliegt.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

         8
          ˅
           ˄
o--4        o
|           |
|           |
o--o--o--7  o
|  |     | ˅ 
|  |     |˄
o--o-----5
   |     |
   |     |
   |     6
   |
   |
3--o--2--1

1 Pfad durch die [Alpen](#Alpen)
2 Eingang zum Eislaufplatz 
  ([Dysprosia](/dysprosia.md "Dysprosia") & [Protactinius](/protactinius.md "Protactinius"))
3 Schlittschuhverleih
  ([Palladius](/palladius.md "Palladius"))
4 Geräteschuppen
  ([Schleifmaschine](/schleifmaschine.md "Schleifmaschine"))
5 Gasthof der Eisbahn
  ([Terbia](/terbia.md "Terbia"))
6 Küche der Eisbahnkneipe
7 Aufenthaltsraum der Eiskunstläufer
  ([Kalle](/kalle-eisbahn.md "Kalle/Eisbahn"))
  ([Gunda Niemann](/gunda.md "Gunda") & [Katharina Witt](/katharina.md "Katharina"))
  ([Norbert Schramm](/norbert-eisbahn.md "Norbert/Eisbahn") & [Tonya Harding](/tonya.md "Tonya"))
8 Tribünendach der Eisbahn
  ([Mykell](/mykell.md "Mykell")) 

### [Luftraum über der Eisbahn](#toc)

Direkt über der [Eisbahn](#Eisbahn) [Galliens](/gallien.md "Gallien") liegt dieser Luftraum. Er ist der Spielplatz von [Mykell](/mykell.md "Mykell"), wenn er mal nicht wieder [krank](/drachenheilung.md "Drachenheilung") ist. Man erreicht ihn, wenn man versucht von der Eisbahn los zu fliegen oder zu [buddeln](/buddelschiff.md "Buddelschiff").

Im Luftraum über der Eisbahn. 
Der Himmel über der Eisbahn ist klar und die Luft kalt. Von hier oben aus
sieht alles niedlich und klein aus. Nun kannst Du verstehen, wieso der
Eisdrache hier oft seine Runden dreht.

## [Frigorn](#toc)

Frigorn liegt in den Gallischen Alpen und macht einen sehr ausgestorbenen Eindruck. Die Häuser sind bis zum Dach eingeschneit, und die Anzahl der Einwohner beträgt nach der letzten Zählung etwa zwei. Außer einem [Yeti](/yeti-alpen.md "Yeti/Alpen"), der in Ruhe gelassen werden will, hält nur der alte [Bürgermeister](/urrisk.md "Urrisk") die Stellung, er erzählt einem bei etwas intensiverer Ausfragerei auch gern die Geschichte der Stadt. Mit etwas Geschick und nach langem Hinschauen schafft man es sogar, in die Schmiede von Frigorn zu gelangen. Der ehemalige Schmied hat dort seinen [Schmiedehammer](/schmiedehammer-frigorn.md "Schmiedehammer/Frigorn") liegen gelassen. Nach etwas Sucherei findet man auch den Eingang in die Kneipe von Frigorn, auch wenn dort nur noch ein vereistes [Spiel](/cant-stop.md "Cant Stop") zu finden ist. Frigorn eignet sich wohl ideal für eine ausgiebige Schneeballschlacht, denn der Schnee erweist sich als ausreichend pappig, um feine Schneebälle daraus zu machen.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

   1
   |
   |
   o
   |
   |
   o     3
  / \   /
 /   \ /
o--2--2
|  |  |
|  |  |
o  p  o--o
|  |  '
|  |  '
o  5  4

o Eingeschneite Straße
  ([Yeti](/yeti-alpen.md "Yeti/Alpen"))

1 Stadttor
2 Alter Marktplatz
3 Alte Schmiede
4 Kneipe
5 Rathaus
  ([Urrisk](/urrisk.md "Urrisk"))

## [Tal](#toc)

Am Westrand der Alpen nahe der Rhone. Hat man das Weite gefunden, dann findet man am Rand der Alpen einen eine interessante Gegend, unter anderem mit einem Steinbruch und in [Tonix Töpferei](/tonix.md "Tonix") eine Einkaufsmöglichkeit. Nicht weit weg von der Töpferei wollen manche eine [Fee](/gadolinia.md "Gadolinia") gesehen haben, aber wer weiß? Aber vielleicht kann man in der Nähe jemandem [Hilfe](/tantalos-und-der-götterfluch.md "Tantalos und der Götterfluch") leisten...

Der Zugang zum Steinbruch liegt am westlichen Rande des [Tales](#Tal). Hier wurden einst die berühmten Gallischen Hinkelsteine geschlagen. Ein unverzichtbarer Schmuck für den Vorgarten, genauso wie heute der Gartenzwerg. Inzwischen wird hier kaum noch abgebaut und nur ein alter [Arbeiter](/steinbehaunix.md "Steinbehaunix") lebt hier in seiner Hütte. In den Felsen hinauf kann man in eine finstere Höhle hinaufklettern, in der es interessante Dinge zu finden und interessante Höhlenmalereien zu entdecken gibt.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

                           8
                            .
                             .
2                             o
|                              .
|                               .
1              o--5              o
|               .               /
|                .             /
o              o--4--6--7     o
|              |         .    |
|              |          .   |
o              o           o--o
|              |            
|              |
o--o--o--o--o--3

1 [Hafen Rhone](/rhonehafen.md "Rhonehafen")
2 [Nautix](/nautix.md "Nautix")' Gebrauchtschiffladen
3 [Tonix](/tonix.md "Tonix")' Töpferei
4 Gallischer Steinbruch
  ([Steinbehaunix](/steinbehaunix.md "Steinbehaunix"))
5 Finstere Höhle 
6 Tal
  ([Frantzi](/frantzi.md "Frantzi"))
7 Tal
  ([Tantalos](/tantalos.md "Tantalos"))
8 [Gadolinias](/gadolinia.md "Gadolinia") Kammer  

## [Höhle](#toc)

Die Unheimliche Höhle liegt in den [Gallischen Alpen](/alpen.md "Alpen"). Diese Höhle ist ein recht gefährlicher Ort für unbedarfte Besucher, denn sie ist von zahlreichen [Höhlenspinnen](/höhlenspinne-gallien.md "Höhlenspinne/Gallien") bewohnt, die recht ungehalten auf einen Besuch reagieren und den Kampf suchen. Hat man Glück, dann begegnet man erst mal nur dem einzigen menschlichen Bewohner, dem [alten Kelten](/kelte-alpen.md "Kelte/Alpen"). Ist man vorsichtig und achtet auf alles, dann kann man sich auch zu anfangs verborgenen Räumen Zugang verschaffen und selbst Abgründe überwinden. Der [alte Kelte](/kelte-alpen.md "Kelte/Alpen") erzählt gerne von Früher und man kann von ihm erfahren, was es hier zu finden gibt.

**Zeichenerklärung**

| **\|** Nord/Süd **\-** West/Ost | **/** Nordost/Südwest **\** Nordwest/Südost | **˄** Hoch **˅** Runter | **'** Keine erkennbare Himmelsrichtung **.** oder zur Verlängerung von Wegen | **▼ ◄** Nur hinein **► ▲** Kein zurück |
| --- | --- | --- | --- | --- |

         4
         |
         |
         3--------5..2
         |           .
         |           .
   3     o  o        2
   |     |  |       /
   |     |  |      /
o--2..2--o--3--2..2
         |
         |
         1
         .
         .
         A

A [Gallische Alpen](/alpen.md "Alpen")

1 Eingangsbereich
2 Unheimliche Höhle
3 Unheimliche Höhle
  ([Höhlenspinne](/höhlenspinne-gallien.md "Höhlenspinne/Gallien"))
4 Unheimliche Höhle
  ([Kelte](/kelte-alpen.md "Kelte/Alpen"))
5 Boden des Abgrundes

* * *


## Kenndaten

- Typ: Nachtragen

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Alpen)
