---
type: Wiki Article
title: Lederstiefel/Banbergen
description: ""
resource: "http://unitopia.intelligense.de/wiki/Lederstiefel/Banbergen"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/2, Info/Material, Info/Material/Leder, Info/Rüstungsstärke, Info/Rüstungsstärke/geht so, Info/Rüstungszustand, Info/Rüstungszustand/extrem solide, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Rüstung, Rüstung/Füße, Rüstung/Midgard, Rüstung/Midgard/Füße]
timestamp: 2024-03-02T19:18:28Z
revid: 229614
namespace: 0
contenthash: a6864bdcf8fdd064800a90d263c36b701ed823367209f28a6d6a0aa9a22f0a56
---

## Aussehen

Schwere Treter. Das dickste Leder ist dafuer grade gut genug. Zwar
schuetzen sie den Fuss des Kaempfers ziemlich gut - aber das Gewicht...

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Leder](/kategorie/info-material-leder.md "Kategorie:Info/Material/Leder") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Rüstungsstärke](/kategorie/info-rüstungsstärke.md "Kategorie:Info/Rüstungsstärke"):** | [3 (geht so)](/kategorie/info-rüstungsstärke-geht-so.md "Kategorie:Info/Rüstungsstärke/geht so") |
| **[Rüstungszustand](/kategorie/info-rüstungszustand.md "Kategorie:Info/Rüstungszustand"):** | [9 (extrem solide)](/kategorie/info-rüstungszustand-extrem-solide.md "Kategorie:Info/Rüstungszustand/extrem solide") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [2 (leicht)](/kategorie/info-gewicht-2.md "Kategorie:Info/Gewicht/2") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

-   Rüstung von [Beowald](/beowald.md "Beowald") vor der Halle von Evusatria in [Banbergen](/banbergen.md "Banbergen").
-   Rüstung von [Coenred](/coenred.md "Coenred") in der Hauptbank von [Banbergen](/banbergen.md "Banbergen").
-   Rüstung von [Eohart](/eohart.md "Eohart") in einem Wachraum von [Evusatria](/banbergen.md "Banbergen") in [Banbergen](/banbergen.md "Banbergen").
-   Rüstung vom [Gedrihten](/gedriht-evusatria.md "Gedriht/Evusatria") in und um [Evusatria](/banbergen.md "Banbergen") in [Banbergen](/banbergen.md "Banbergen").
-   Rüstung von [Horsa](/horsa.md "Horsa") vor einem Stadttor von [Banbergen](/banbergen.md "Banbergen").
-   Rüstung vom [Leibwächter](/leibwächter.md "Leibwächter") am Thron des Königs in [Evusatria](/banbergen.md "Banbergen") in [Banbergen](/banbergen.md "Banbergen").
-   Rüstung von [Oswald](/oswald.md "Oswald") in der Hauptbank von [Banbergen](/banbergen.md "Banbergen").

* * *


## Kenndaten

- Kategorie: Rüstung
- Typ: Füße
- Gegend: Midgard
- Material: Leder
- Temperaturschutz: wärmt etwas
- Rüstungsstärke: geht so
- Rüstungszustand: extrem solide
- Gewicht: 2
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Lederstiefel/Banbergen)
