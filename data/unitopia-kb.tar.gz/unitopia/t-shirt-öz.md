---
type: Wiki Article
title: "T-Shirt/ÖZ"
description: In einer sonderbaren Kammer im Ökumenisches Zentrum auf dem Campusgelände der Universität Stuttgart.
resource: "http://unitopia.intelligense.de/wiki/T-Shirt/ÖZ"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Info/Temperaturschutz, Info/Temperaturschutz/gut gegen die Wüstenhitze, Kleidung, Kleidung/Brust, Kleidung/Campus, Kleidung/Campus/Brust]
timestamp: 2024-03-02T19:20:54Z
revid: 243974
namespace: 0
contenthash: 41225f477498c90b2545d414f24dae32fc05dbe3f2ab01403965f8383da0f6bd
---

## Aussehen

Ein luftiges, schwarzes T-Shirt. Auf der Rueckseite ist ein Pentagramm
aufgedruckt.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [gut gegen die Wüstenhitze](/kategorie/info-temperaturschutz-gut-gegen-die-wüstenhitze.md "Kategorie:Info/Temperaturschutz/gut gegen die Wüstenhitze") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

In einer sonderbaren Kammer im [Ökumenisches Zentrum](/ökumenisches-zentrum.md "Ökumenisches Zentrum") auf dem [Campusgelände](/campusgelände.md "Campusgelände") der [Universität Stuttgart](/universität.md "Universität").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Brust
- Gegend: Campus
- Material: Textil
- Temperaturschutz: gut gegen die Wüstenhitze
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/T-Shirt/ÖZ)
