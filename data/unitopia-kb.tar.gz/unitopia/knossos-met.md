---
type: Wiki Article
title: "Knossos-Met"
description: "Zu kaufen bei James McGregor in 'McGregors' neuen Pub von Dörrstadt."
resource: "http://unitopia.intelligense.de/wiki/Knossos-Met"
tags: [Fundort/Kauf, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Wirkung, Info/Wirkung/betrunken, Info/Wirkung/durstlöschend, Nahrung, Nahrung/Alkohol, Nahrung/Dörrland, Nahrung/Dörrland/Alkohol]
timestamp: 2024-08-29T15:14:41Z
revid: 245728
namespace: 0
contenthash: 5d1843c3b989274e8bae87020402a61e2489b1968904751232c6cb4fabae729b
---

## Aussehen

Ein honigfarbenes, dickes, suesses Bier aus Knossos. Es wird aus vergorenem
Honig hergestellt, zieht ordentlich rein und macht feine Kopfschmerzen.
Naja. Von Wein verstehen die dort eh mehr als von Bier. Aber es ist
ansonsten ziemlich lecker. Fuer Met.

## Informationen

| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| --- | --- |
| **[Wirkung](/kategorie/info-wirkung.md "Kategorie:Info/Wirkung"):** | [betrunken](/kategorie/info-wirkung-betrunken.md "Kategorie:Info/Wirkung/betrunken"), [durstlöschend](/kategorie/info-wirkung-durstlöschend.md "Kategorie:Info/Wirkung/durstlöschend") |

## Fundort

Zu kaufen bei [James McGregor](/james.md "James") in ['McGregors' neuen Pub](/dörrstadt.md "Dörrstadt") von [Dörrstadt](/dörrstadt.md "Dörrstadt").

* * *


## Kenndaten

- Kategorie: Nahrung
- Typ: Alkohol
- Gegend: Dörrland
- Gewicht: 1
- Wirkung: betrunken/durstlöschend

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Knossos-Met)
