---
type: Wiki Article
title: Schürze/Bischa
description: "Kleidung von Bischa in der Küche des Gasthaus \"Schwarzer Zwerg\" in Borefinian."
resource: "http://unitopia.intelligense.de/wiki/Schürze/Bischa"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/3, Info/Material, Info/Material/Textil, Kleidung, Kleidung/Hüfte, Kleidung/Midgard, Kleidung/Midgard/Hüfte]
timestamp: 2024-03-02T19:19:35Z
revid: 263025
namespace: 0
contenthash: 6832b9c2354f2922c23913c75a11f976587400ca3207df59bdb41caf8787cd13
---

## Aussehen

Eine Schuerze. Aber was fuer eine! Die hat seit Jahren kein Waschbrett mehr
aus der Naehe gesehen...

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [3 (schon eher leicht)](/kategorie/info-gewicht-3.md "Kategorie:Info/Gewicht/3") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Kleidung von [Bischa](/bischa.md "Bischa") in der Küche des Gasthaus "Schwarzer Zwerg" in [Borefinian](/borefinian.md "Borefinian").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Hüfte
- Gegend: Midgard
- Material: Textil
- Gewicht: 3
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Schürze/Bischa)
