---
type: Wiki Article
title: Halskettchen/Kunibert
description: Zu kaufen bei Kunibert Klunker im Juweliergeschäft von Koboldingen.
resource: "http://unitopia.intelligense.de/wiki/Halskettchen/Kunibert"
tags: [Fundort/Kauf, Hidden, Info, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Edelmetall, Kleidung, Kleidung/Hals, Kleidung/Märchenland, Kleidung/Märchenland/Hals, ZusatzAussehen, ZusatzAussehen/Etwas, ZusatzAussehen/Frau, ZusatzAussehen/Mann]
timestamp: 2024-04-23T19:27:45Z
revid: 261604
namespace: 0
contenthash: f501892a94b4bfa8145287815a09c7018bf0e72363373a721415d3dd70ef6b23
---

## Aussehen

Ein goldenes Halskettchen, das sehr wertvoll aussieht.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Edelmetall](/kategorie/info-material-edelmetall.md "Kategorie:Info/Material/Edelmetall") |
| --- | --- |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | nein |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Zu kaufen bei [Kunibert Klunker](/kunibert.md "Kunibert") im Juweliergeschäft von [Koboldingen](/koboldingen.md "Koboldingen").

## Besonderheit

Zusätzliches Aussehen beim Betrachten einer Person:

| -   **Mann:** | Ein duennes Halskettchen verziert seinen Hals. Sieht an einem Mann schon arg machohaft aus. |
| --- | --- |
| -   **Frau:** | Ein duennes Halskettchen verziert ihren Hals. |
| -   **Etwas:** | Ein duennes Halskettchen verziert seinen Hals. |

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Hals
- Gegend: Märchenland
- Material: Edelmetall
- Gewicht: 1
- Licht: 0
- Brennbar: nein
- Schwimmt: nein
- Frau: Ein duennes Halskettchen verziert ihren Hals.
- Etwas: Ein duennes Halskettchen verziert seinen Hals.

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Halskettchen/Kunibert)
