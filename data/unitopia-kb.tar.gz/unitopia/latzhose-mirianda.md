---
type: Wiki Article
title: Latzhose/Mirianda
description: Kleidung von Mirianda auf dem Waldbauernhof im Wurzelwald auf Nankea.
resource: "http://unitopia.intelligense.de/wiki/Latzhose/Mirianda"
tags: [Info, Info/Brennbar, Info/Gewicht, "Info/Gewicht/0-9", Info/Gewicht/1, Info/Material, Info/Material/Textil, Info/Temperaturschutz, Info/Temperaturschutz/wärmt etwas, Kleidung, Kleidung/Beine, Kleidung/Midgard, Kleidung/Midgard/Beine]
timestamp: 2024-03-02T19:19:28Z
revid: 246459
namespace: 0
contenthash: 92f42f028b53fcb1f06aecd7e5175d1b2682216ff9d6411192d583f55e8e3a50
---

## Aussehen

Eine blaue Latzhose.

## Informationen

| **[Material](/kategorie/info-material.md "Kategorie:Info/Material"):** | [Textil](/kategorie/info-material-textil.md "Kategorie:Info/Material/Textil") |
| --- | --- |
| **[Temperaturschutz](/kategorie/info-temperaturschutz.md "Kategorie:Info/Temperaturschutz"):** | [wärmt etwas](/kategorie/info-temperaturschutz-wärmt-etwas.md "Kategorie:Info/Temperaturschutz/wärmt etwas") |
| **[Gewicht](/kategorie/info-gewicht.md "Kategorie:Info/Gewicht"):** | [1 (sehr leicht)](/kategorie/info-gewicht-1.md "Kategorie:Info/Gewicht/1") |
| **[Licht](/kategorie/info-licht.md "Kategorie:Info/Licht"):** | [0 (leuchtet nicht)](/kristallkugel-engel.md "Kristallkugel/Engel") |
| **[Brennbar](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar"):** | [ja](/kategorie/info-brennbar.md "Kategorie:Info/Brennbar") |
| **[Schwimmt](/kategorie/info-schwimmt.md "Kategorie:Info/Schwimmt"):** | nein |

## Fundort

Kleidung von [Mirianda](/mirianda.md "Mirianda") auf dem [Waldbauernhof](/waldbauernhof.md "Waldbauernhof") im [Wurzelwald](/wurzelwald.md "Wurzelwald") auf [Nankea](/nankea.md "Nankea").

* * *


## Kenndaten

- Kategorie: Kleidung
- Typ: Beine
- Gegend: Midgard
- Material: Textil
- Temperaturschutz: wärmt etwas
- Gewicht: 1
- Licht: 0
- Brennbar: ja
- Schwimmt: nein

# Citations

[1] [Originalseite im Unitopia-Wiki](http://unitopia.intelligense.de/wiki/Latzhose/Mirianda)
